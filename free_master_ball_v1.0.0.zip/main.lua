-- Free Master Ball v1.0.0
-- Adds MASTER_BALL to every mart stock found in the active game's
-- text_pointers registry and sets its price to 0.
--
-- Works against the merged registry view, so it also detects marts added by
-- other mods that load before this one.

return function(mod)
  local ITEM_ID = "MASTER_BALL"

  -- The item must exist in the imported game data before marts can reference it.
  if not mod.content.items:get(ITEM_ID) then
    mod.log:warn("%s is missing; Free Master Ball made no changes", ITEM_ID)
    return
  end

  mod.content.items:patch(ITEM_ID, { price = 0 })

  -- Collect patches first instead of mutating text_pointers while iterating it.
  local pending = {}
  local martCount = 0

  for mapId, entries in mod.content.text_pointers:each() do
    if type(entries) == "table" then
      local mapPatch = nil

      for textConst, entry in pairs(entries) do
        if type(entry) == "table" and type(entry.mart) == "table" then
          local stock = {}
          local alreadyPresent = false

          for i, itemId in ipairs(entry.mart) do
            stock[i] = itemId
            if itemId == ITEM_ID then
              alreadyPresent = true
            end
          end

          if not alreadyPresent then
            stock[#stock + 1] = ITEM_ID
            mapPatch = mapPatch or {}
            mapPatch[textConst] = { mart = stock }
            martCount = martCount + 1
          end
        end
      end

      if mapPatch then
        pending[#pending + 1] = { mapId = mapId, patch = mapPatch }
      end
    end
  end

  for _, change in ipairs(pending) do
    mod.content.text_pointers:patch(change.mapId, change.patch)
  end

  mod.log:info("Master Ball price set to 0; added to %d mart stock list(s)", martCount)
end
