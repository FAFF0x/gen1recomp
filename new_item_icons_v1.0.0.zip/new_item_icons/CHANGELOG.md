# Changelog

## 1.0.0

- Initial release.
- Added all supplied individual item sprites.
- Added dynamic TM/HM sprite selection from the taught move's type.
- Added automatic row decoration for Modern UI, Modern Bag, Shop and PC item lists.
- Added non-invasive classic ListMenu thumbnails.
- Preserved original PNG files and full-colour rendering.
