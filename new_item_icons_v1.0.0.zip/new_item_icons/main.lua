-- NEW ITEM ICONS v1.0.0
--
-- Adds full-colour item artwork to item records and decorates item ListMenu
-- rows so Gen1 Modern UI / Modern Bag / Shop / PC item lists can render it.
-- The classic ListMenu also gets a tiny non-invasive 8x8 preview to the left
-- of the normal cursor, without moving or replacing any text.
--
-- TM/HM artwork is selected dynamically from the TYPE of the taught move.
-- This means a TM/HM added by another mod also receives the correct artwork
-- when its move type is one of the supplied type icons.

local VERSION = "1.0.0"

local INDIVIDUAL = {
  "antidote",
  "awakening",
  "bicycle",
  "bike-voucher",
  "burn-heal",
  "calcium",
  "carbos",
  "card-key",
  "coin-case",
  "dire-hit",
  "dome-fossil",
  "dowsing-machine",
  "elixir",
  "escape-rope",
  "ether",
  "exp-share",
  "fire-stone",
  "fresh-water",
  "full-heal",
  "full-restore",
  "gold-teeth",
  "good-rod",
  "great-ball",
  "guard-spec",
  "helix-fossil",
  "hp-up",
  "hyper-potion",
  "ice-heal",
  "iron",
  "leaf-stone",
  "lemonade",
  "lift-key",
  "master-ball",
  "max-elixir",
  "max-ether",
  "max-potion",
  "max-repel",
  "max-revive",
  "moon-stone",
  "nugget",
  "old-amber",
  "old-rod",
  "paralyze-heal",
  "parcel",
  "poke-ball",
  "poke-doll",
  "poke-flute",
  "potion",
  "pp-up",
  "protein",
  "rare-candy",
  "repel",
  "revive",
  "safari-ball",
  "secret-key",
  "silph-scope",
  "soda-pop",
  "ss-ticket",
  "super-potion",
  "super-repel",
  "super-rod",
  "thunder-stone",
  "town-map",
  "ultra-ball",
  "water-stone",
  "x-accuracy",
  "x-attack",
  "x-defense",
  "x-sp-atk",
  "x-speed",
}

local TYPE_ICONS = {
  "bug",
  "dark",
  "dragon",
  "electric",
  "fairy",
  "fighting",
  "fire",
  "flying",
  "ghost",
  "grass",
  "ground",
  "ice",
  "normal",
  "poison",
  "psychic",
  "rock",
  "steel",
  "water",
}

-- Gen I names/ids that intentionally use a more modern asset filename.
local ALIASES = {
  PARLYZ_HEAL = "paralyze-heal",
  PARALYZE_HEAL = "paralyze-heal",
  ITEMFINDER = "dowsing-machine",
  DOWSING_MACHINE = "dowsing-machine",
  EXP_ALL = "exp-share",
  EXP_SHARE = "exp-share",
  OAKS_PARCEL = "parcel",
  OAK_PARCEL = "parcel",
  PARCEL = "parcel",
  X_DEFEND = "x-defense",
  X_DEFENSE = "x-defense",
  X_SPECIAL = "x-sp-atk",
  X_SP_ATK = "x-sp-atk",
  S_S_TICKET = "ss-ticket",
  SS_TICKET = "ss-ticket",
}

local function lower(value)
  return string.lower(tostring(value or ""))
end

local function slugify(value)
  local s = tostring(value or "")
  s = s:gsub("É", "E"):gsub("é", "e")
  s = s:gsub("’", ""):gsub("'", "")
  s = s:gsub("[%.%/]", "")
  s = lower(s)
  s = s:gsub("[^%w]+", "-")
  s = s:gsub("^%-+", ""):gsub("%-+$", "")
  return s
end

return function(mod)
  local itemPaths, typePaths = {}, {}

  for _, slug in ipairs(INDIVIDUAL) do
    local rel = "assets/items/" .. slug .. ".png"
    if mod:read(rel) then
      itemPaths[slug] = mod.assets:path(rel)
    else
      mod.log:warn("NEW ITEM ICONS: missing asset %s", rel)
    end
  end

  for _, typeName in ipairs(TYPE_ICONS) do
    local rel = "assets/items/tm-hm/" .. typeName .. ".png"
    if mod:read(rel) then
      typePaths[string.upper(typeName)] = mod.assets:path(rel)
    else
      mod.log:warn("NEW ITEM ICONS: missing TM/HM type asset %s", rel)
    end
  end

  local function spriteFor(game, itemId, def)
    if type(def) ~= "table" then return nil end

    -- Machines always use the taught move's live type.
    local machine = def.machine
    if type(machine) == "table" and machine.move and game and game.data then
      local move = game.data.moves and game.data.moves[machine.move]
      local moveType = move and string.upper(tostring(move.type or ""))
      if moveType and typePaths[moveType] then
        return typePaths[moveType], moveType
      end
      -- Unknown/custom type: NORMAL is a safer visual fallback than no icon.
      if typePaths.NORMAL then return typePaths.NORMAL, moveType or "UNKNOWN" end
    end

    local alias = ALIASES[tostring(itemId or "")]
    if alias and itemPaths[alias] then return itemPaths[alias] end

    local byId = slugify(itemId)
    if itemPaths[byId] then return itemPaths[byId] end

    local byName = slugify(def.name)
    if itemPaths[byName] then return itemPaths[byName] end

    return nil
  end

  local function applyToItemDefs(game)
    if not (game and game.data and type(game.data.items) == "table") then
      return 0, 0
    end
    local assigned, machines = 0, 0
    for itemId, def in pairs(game.data.items) do
      if type(def) == "table" then
        local path, machineType = spriteFor(game, itemId, def)
        if path then
          -- These top-level presentation fields are intentionally redundant:
          -- Modern UI accepts image/icon, while other UI mods often look for
          -- one of the conventional aliases below.
          def.image = path
          def.icon = path
          def.itemSprite = path
          def.itemSpriteTrueColor = true
          def.itemSpriteSource = "new_item_icons"
          if machineType then
            def.itemSpriteMoveType = machineType
            machines = machines + 1
          end
          assigned = assigned + 1
        end
      end
    end
    return assigned, machines
  end

  local function decorateRows(game, state)
    if not (game and game.data and type(game.data.items) == "table"
        and type(state) == "table" and type(state.items) == "table") then
      return 0
    end
    local changed = 0
    for _, row in ipairs(state.items) do
      if type(row) == "table" then
        local itemId = row.value
        local def = itemId and game.data.items[itemId]
        if type(def) == "table" then
          local path = def.image or def.icon or def.itemSprite
          if path then
            -- Modern UI's generic ListMenu presenter reads image/icon directly
            -- from the live row. Modern Bag rebuilds these rows while changing
            -- pockets, so render.hud refreshes them again every frame.
            row.image = path
            row.icon = path
            row._newItemIcon = path
            changed = changed + 1
          end
        end
      end
    end
    return changed
  end

  local gameRef

  mod.events:on("game.ready", function(ev)
    gameRef = ev and ev.game or nil
    local assigned, machines = applyToItemDefs(gameRef)
    mod.log:info(
      "NEW ITEM ICONS %s: assigned %d item sprites (%d TM/HM entries use move-type art)",
      VERSION, assigned, machines)
  end, 200)

  mod.events:on("screen.pushed", function(ev)
    local state = ev and ev.state
    if gameRef and state then decorateRows(gameRef, state) end
  end, 200)

  -- Run before Gen1 Modern UI's render.hud wrapper (it uses priority 100).
  -- This is important for Modern Bag because its pocket rows are regenerated
  -- in-place after the state was originally pushed.
  mod.hooks:wrap("render.hud", function(next, game, viewport)
    if game and game.stack and type(game.stack.states) == "table" then
      for _, state in ipairs(game.stack.states) do
        decorateRows(game, state)
      end
    end
    return next(game, viewport)
  end, 250)

  -- Classic UI support: ListMenu has no native item-image column. Rather than
  -- replacing the whole menu and risking Bag/Shop/PC behavior, draw a compact
  -- 8x8 true-colour thumbnail in the unused strip left of the cursor.
  local okClassic, classicErr = pcall(function()
    local Assets = require("src.render.Assets")
    local ListMenu = require("src.ui.ListMenu")
    local PaletteFX = require("src.render.PaletteFX")

    ListMenu._newItemIconsCache = ListMenu._newItemIconsCache or {}

    if not ListMenu._newItemIconsCacheInvalidation then
      Assets.register(function()
        ListMenu._newItemIconsCache = {}
      end)
      ListMenu._newItemIconsCacheInvalidation = true
    end

    local function loadImage(path)
      local cache = ListMenu._newItemIconsCache
      local hit = cache[path]
      if hit ~= nil then return hit or nil end
      local ok, img = pcall(love.graphics.newImage, Assets.resolve(path))
      if ok and img then
        if img.setFilter then img:setFilter("nearest", "nearest") end
        cache[path] = img
        return img
      end
      cache[path] = false
      return nil
    end

    if not ListMenu._newItemIconsWrapped then
      ListMenu._newItemIconsOriginalDraw = ListMenu.draw
      ListMenu.draw = function(self, ...)
        local result = ListMenu._newItemIconsOriginalDraw(self, ...)
        if not (self and self.game and type(self.items) == "table") then
          return result
        end

        -- Rows are 16px tall. An 8px icon at x=0 leaves the native cursor
        -- (x=8) and item text (x=16) completely untouched.
        for rowNo = 1, self.rows or 7 do
          local index = (self.scroll or 0) + rowNo
          local row = self.items[index]
          local path = type(row) == "table" and row._newItemIcon or nil
          if path then
            local img = loadImage(path)
            if img then
              local iw, ih = img:getDimensions()
              if iw > 0 and ih > 0 then
                local scale = math.min(8 / iw, 8 / ih)
                local dw, dh = iw * scale, ih * scale
                local x = (8 - dw) / 2
                local y = 8 + rowNo * 16 + (8 - dh) / 2
                -- Protect authored RGB colours from the SGB/Advanced
                -- shade-remap pass.
                PaletteFX.markTrueColor(x, y, dw, dh)
                love.graphics.setColor(1, 1, 1, 1)
                love.graphics.draw(img, x, y, 0, scale, scale)
              end
            end
          end
        end
        return result
      end
      ListMenu._newItemIconsWrapped = true
    end
  end)

  if not okClassic then
    mod.log:warn("NEW ITEM ICONS: classic ListMenu thumbnails unavailable: %s",
      tostring(classicErr))
  end

  mod.exports.spriteForItem = function(game, itemId)
    local def = game and game.data and game.data.items and game.data.items[itemId]
    return spriteFor(game, itemId, def)
  end
  mod.exports.decorateRows = decorateRows
end
