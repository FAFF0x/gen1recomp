# Changelog

## 1.2.3
- Adds a hard full-`uiCanvas` restore for live `BATTLE_ART_VOXEL_FORK` staged battles.
- Detects the actual staged battle through `BattleState.dramaticShapeShot`, not just the 3D-BTL setting.
- Captures the source-owned transparent UI surface before Modern UI 0.9.x `render.compose` and restores it after downstream hooks.
- Restores status HUD, FIGHT/POKEMON/ITEM/RUN, move selection, dialogue, Party/Bag children and other native battle UI.
- Does not duplicate staged Pokémon because the voxel fork already removes flat battle pics from its UI layer.
- Keeps the public native-3D adapter and the non-voxel WIDE command-band fallback.

## 1.2.2
- Fixes Gen1 Modern UI 0.9.2 suppressing the entire battle HUD/menu while `BATTLE_ART_VOXEL_FORK` 3D battles are active.
- Registers `BATTLE_ART_VOXEL_FORK` through Modern UI's public compatibility API as a native 3D battle owner.
- Uses the fork's public `exports.lib -> OverworldBattle.enabled()` state instead of private file/class access.
- Makes Modern UI's existing `LEAVE 3D BATTLES ALONE` option work with the fork.
- Keeps voxel battle HUD, FIGHT/POKEMON/ITEM/RUN, move selection, dialogue, Party, Bag, choices and level-up UI native when the 3D bypass is enabled.
- Skips the v1.2.1 304x40 2D fallback while the voxel battle owner is active.
- Keeps the v1.2.1 fallback for ordinary non-voxel WIDE battles.

## 1.2.1
- Fixes Gen1 Modern UI 0.9.2's experimental `BATTLE UI (WIP)` making the battle command menu disappear.
- Captures the native WIDE bottom command band before Modern UI's `render.compose` scrub and restores it afterward as a fail-safe.
- Covers the main FIGHT / POKEMON / ITEM / RUN menu, move selection, and Mimic selection.
- Runs only on Modern UI 0.9.x with Battle UI and Hide Original UI enabled.
- Keeps the modern battle scene/status presenter active; battle logic and input remain fully engine-owned.
- Leaves 0.8.x behavior, Party/Bag child screens, battle messages, animations, authored-icon true-color handling, and Pokédex icon injection unchanged.

## 1.2.0
- Adds compatibility with Gen1 Modern UI 0.9.2 and the 0.9.x branch.
- Expands the dependency range to `>=0.8.1 <0.10.0`.
- Detects the installed Modern UI version at runtime.
- Keeps the battle Party opaque-boundary workaround only for Modern UI 0.8.x.
- Disables that obsolete opacity workaround on Modern UI 0.9.x, which has a newer battle-child suppression proof.
- Keeps the full-color authored Pokémon icon guard on both branches.
- Keeps stock Pokédex icon injection on both branches.
- Reports the detected Modern UI version and active compatibility mode through `mod.exports.modernUiIconFix`.

## 1.1.0
- Fixes the blank/white Party screen when selecting POKéMON during a battle with Gen1 Modern UI 0.8.x.
- Restores Battle PartyMenu as an opaque presentation boundary after Modern UI's screen and input visibility synchronization.
- Keeps the modern Party presenter active while preventing the disabled/WIP battle presenter from contaminating the visible stack.
- Covers normal voluntary switching, forced replacement and SHIFT free-switch PartyMenu flows.
- Keeps all v1.0.0 full-colour icon and stock Pokédex fixes.

## 1.0.0
- Initial compatibility patch for Gen1 Modern UI 0.8.x.
- Preserves full-colour table-valued Pokémon icons at render time.
- Adds authored icons to stock Pokédex rows without modifying Modern UI source files.
