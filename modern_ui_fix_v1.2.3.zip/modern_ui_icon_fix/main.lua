-- Modern UI Fix v1.2.3
--
-- Compatibility shim for Gen1 Modern UI 0.8.x and the retired 0.9.x branch.
-- It does NOT replace or modify Gen1 Modern UI files.
--
-- Fixes:
--   1) table-valued pokemon.icon artwork is treated as authored true-color
--      art even if Modern UI's shared image cache later associates the same
--      Image userdata with a species palette in another presenter;
--   2) stock/variant Pokédex ListMenu rows receive the live authored icon
--      descriptor beside seen/owned species names;
--   3) Gen1 Modern UI 0.9.x Battle UI cannot erase the native command/move
--      menu when its WIP battle presenter fails to paint the replacement;
--   4) BATTLE_ART_VOXEL_FORK is published to Modern UI as a native 3D battle
--      owner so the built-in "LEAVE 3D BATTLES ALONE" safety switch works.
--
-- The true-color fix is applied at the public render.hud hook boundary. The
-- wrapper temporarily observes images loaded by Modern UI and neutralizes a
-- palette shader only for images whose paths come from table-valued
-- pokemon.icon descriptors. Other Modern UI palettes and shaders are left
-- untouched.

local VERSION = "1.2.3"

local unpack = table.unpack or unpack
local function pack(...)
  return { n = select("#", ...), ... }
end

return function(mod)
  local modernUi = mod.find and mod.find("gen1_modern_ui") or nil
  local modernUiVersion = modernUi and tostring(modernUi.version or "") or ""
  local legacyBattlePartyFix = modernUiVersion:match("^0%.8%.") ~= nil
  local modernUi09 = modernUiVersion:match("^0%.9%.") ~= nil
  local currentGame = nil
  local voxelBridgeRegistered = false
  local voxelOwnerId = "BATTLE_ART_VOXEL_FORK"

  -- BATTLE_ART_VOXEL_FORK is a DramaticShape-derived fork whose public mod ID
  -- is not in Gen1 Modern UI 0.9.2's built-in DramaticShape owner list.
  -- Publish the fork through Modern UI's public compatibility API instead of
  -- reaching into Modern UI internals. This makes its own battle3dBypass
  -- option authoritative for the voxel battle.
  local function voxelBattleEnabled()
    if type(mod.find) ~= "function" then return false end
    local okFind, handle = pcall(mod.find, voxelOwnerId)
    local exports = okFind and type(handle) == "table" and handle.exports or nil
    local library = type(exports) == "table" and exports.lib or nil
    local requireModule = type(library) == "table" and library.require or nil
    if type(requireModule) ~= "function" then return false end

    local okModule, overworldBattle = pcall(requireModule, "OverworldBattle")
    if not okModule or type(overworldBattle) ~= "table" then
      okModule, overworldBattle = pcall(function()
        return requireModule(library, "OverworldBattle")
      end)
    end
    if not okModule or type(overworldBattle) ~= "table"
        or type(overworldBattle.enabled) ~= "function" then
      return false
    end

    local okEnabled, enabled = pcall(overworldBattle.enabled)
    if okEnabled then return enabled == true end
    okEnabled, enabled = pcall(overworldBattle.enabled, overworldBattle)
    return okEnabled and enabled == true or false
  end

  local function ensureVoxelModernUiBridge()
    if voxelBridgeRegistered or not modernUi09
        or type(mod.find) ~= "function" then
      return voxelBridgeRegistered
    end

    local okUi, uiHandle = pcall(mod.find, "gen1_modern_ui")
    local uiExports = okUi and type(uiHandle) == "table" and uiHandle.exports or nil
    if type(uiExports) ~= "table"
        or type(uiExports.registerAdapter) ~= "function" then
      return false
    end

    local okVoxel, voxelHandle = pcall(mod.find, voxelOwnerId)
    if not okVoxel or type(voxelHandle) ~= "table"
        or type(voxelHandle.exports) ~= "table" then
      return false
    end

    -- `extensions = {}` is deliberately empty: this adapter publishes no
    -- screens. It only declares battle ownership through the public
    -- battle.native3d callback.
    local spec = {
      owner = voxelOwnerId,
      version = tostring(voxelHandle.version
        or voxelHandle.exports.version or ""),
      contract = {
        apiVersion = 1,
        extensions = {},
        battle = {
          native3d = function(game, state)
            return voxelBattleEnabled()
          end,
        },
      },
    }

    local okRegister, registered, reason =
      pcall(uiExports.registerAdapter, spec)
    if okRegister and registered ~= false then
      voxelBridgeRegistered = true
      if mod.log then
        mod.log:info("Modern UI 0.9.x voxel battle bridge enabled for %s",
          voxelOwnerId)
      end
      return true
    end

    if mod.log then
      mod.log:warn("Could not register voxel battle bridge: %s",
        tostring(okRegister and reason or registered))
    end
    return false
  end

  local taggedImages = setmetatable({}, { __mode = "k" })
  local cachedIconsTable = nil
  local cachedPokemonTable = nil
  local authoredPaths = {}

  local function descriptorPath(entry)
    if type(entry) ~= "table" then return nil end
    local path = entry.image or entry.path or entry.texture or entry.asset
    return type(path) == "string" and path ~= "" and path or nil
  end

  local function rebuildAuthoredPaths(game)
    local data = game and game.data
    local icons = data and data.icons
    local pokemon = data and data.pokemon
    if icons == cachedIconsTable and pokemon == cachedPokemonTable then
      return authoredPaths
    end

    cachedIconsTable = icons
    cachedPokemonTable = pokemon
    authoredPaths = {}

    if type(icons) == "table" and type(icons.bySpecies) == "table" then
      for _, entry in pairs(icons.bySpecies) do
        local path = descriptorPath(entry)
        if path then authoredPaths[path] = true end
      end
    end
    if type(pokemon) == "table" then
      for _, def in pairs(pokemon) do
        local path = descriptorPath(type(def) == "table" and def.icon or nil)
        if path then authoredPaths[path] = true end
      end
    end
    return authoredPaths
  end

  local function iconDescriptor(game, species)
    local data = game and game.data
    local pokemon = data and data.pokemon
    if type(species) ~= "string" or type(pokemon) ~= "table"
        or type(pokemon[species]) ~= "table" then
      return nil
    end
    local icons = data.icons
    local entry = type(icons) == "table" and type(icons.bySpecies) == "table"
      and icons.bySpecies[species] or nil
    if type(entry) ~= "table" then entry = pokemon[species].icon end
    return descriptorPath(entry) and entry or nil
  end

  local function looksLikePokedex(state)
    if type(state) ~= "table" or type(state.items) ~= "table" then return false end
    if state.screenId == "PokedexMenu" then return true end
    local title = tostring(state.title or ""):upper()
    -- Covers custom stock-Pokédex replacements such as regional/variant
    -- lists while deliberately avoiding unrelated generic ListMenus.
    return title:find("DEX", 1, true) ~= nil
      and (title:find("POK", 1, true) ~= nil or title:find("DEX", 1, true) == 1)
  end

  local function decoratePokedexRows(game)
    local stack = game and game.stack
    local states = stack and stack.states
    if type(states) ~= "table" then return end
    for _, state in ipairs(states) do
      if looksLikePokedex(state) then
        for _, item in ipairs(state.items or {}) do
          local species = type(item) == "table" and item.value or nil
          local label = type(item) == "table" and tostring(item.label or "") or ""
          if type(species) == "string" and not label:find("-----", 1, true) then
            local descriptor = iconDescriptor(game, species)
            if descriptor then
              -- Do not add item.species here. Modern UI 0.8.x applies a
              -- species palette to explicit row images carrying source.species;
              -- keeping the row image descriptor-only preserves its RGB art.
              item.icon = descriptor
            end
          end
        end
      end
    end
  end

  local function runWithTrueColorGuard(game, callback)
    local graphics = love and love.graphics
    if not (graphics and type(graphics.draw) == "function"
        and type(graphics.newImage) == "function") then
      return callback()
    end

    local paths = rebuildAuthoredPaths(game)
    local originalNewImage = graphics.newImage
    local originalDraw = graphics.draw
    local originalSetShader = graphics.setShader
    local originalGetShader = graphics.getShader

    graphics.newImage = function(source, ...)
      local image = originalNewImage(source, ...)
      if type(source) == "string" and paths[source] then
        taggedImages[image] = true
      end
      return image
    end

    graphics.draw = function(drawable, ...)
      if taggedImages[drawable] and type(originalSetShader) == "function" then
        local previous = type(originalGetShader) == "function"
          and originalGetShader() or nil
        -- Full-colour authored icon: draw its RGB values directly. This only
        -- scopes to the one icon draw; the previous shader is restored before
        -- Modern UI continues drawing the row/panel.
        originalSetShader()
        local result = pack(pcall(originalDraw, drawable, ...))
        originalSetShader(previous)
        if not result[1] then error(result[2], 0) end
        return unpack(result, 2, result.n)
      end
      return originalDraw(drawable, ...)
    end

    local result = pack(pcall(callback))
    graphics.newImage = originalNewImage
    graphics.draw = originalDraw
    if not result[1] then error(result[2], 0) end
    return unpack(result, 2, result.n)
  end


  -- -----------------------------------------------------------------------
  -- Hard staged-voxel UI fail-safe.
  --
  -- BATTLE_ART_VOXEL_FORK marks a battle that is ACTUALLY being staged on
  -- the 3D map with BattleState.dramaticShapeShot. The fork's BattleState
  -- wrapper already removes the flat Pokemon pics from the UI layer and
  -- leaves that canvas transparent over the voxel scene, so preserving the
  -- complete UI canvas restores HUD/menus/dialogue without duplicating mons.
  local voxelUiCapture = nil
  local voxelUiCaptureW, voxelUiCaptureH = 0, 0

  local function activeVoxelBattleState(game)
    local states = game and game.stack and game.stack.states
    if type(states) ~= "table" then return nil end
    for i = #states, 1, -1 do
      local state = states[i]
      if type(state) == "table"
          and (state.isBattleState == true or state.isBattle == true)
          and type(state.dramaticShapeShot) == "table" then
        return state
      end
    end
    return nil
  end

  local function ensureVoxelUiCapture(w, h)
    local graphics = love and love.graphics
    if not (graphics and type(graphics.newCanvas) == "function") then return nil end
    if voxelUiCapture and voxelUiCaptureW == w and voxelUiCaptureH == h then
      return voxelUiCapture
    end
    local ok, canvas = pcall(graphics.newCanvas, w, h)
    if not ok or not canvas then return nil end
    if type(canvas.setFilter) == "function" then
      canvas:setFilter("nearest", "nearest")
    end
    voxelUiCapture = canvas
    voxelUiCaptureW, voxelUiCaptureH = w, h
    return canvas
  end

  local function captureVoxelUi(game, ctx)
    local battle = activeVoxelBattleState(game)
    local graphics = love and love.graphics
    local source = ctx and ctx.uiCanvas
    if not (battle and graphics and source
        and type(source.getDimensions) == "function"
        and type(graphics.setCanvas) == "function"
        and type(graphics.draw) == "function"
        and type(graphics.clear) == "function") then
      return nil
    end

    local w, h = source:getDimensions()
    local capture = ensureVoxelUiCapture(w, h)
    if not capture then return nil end

    graphics.push("all")
    graphics.setCanvas(capture)
    graphics.clear(0, 0, 0, 0)
    if type(graphics.setBlendMode) == "function" then
      graphics.setBlendMode("replace")
    end
    graphics.setColor(1, 1, 1, 1)
    graphics.draw(source, 0, 0)
    graphics.pop()

    return { canvas = capture, target = source, battle = battle }
  end

  local function restoreVoxelUi(snapshot, game, ctx)
    local graphics = love and love.graphics
    if not (snapshot and graphics and ctx
        and ctx.uiCanvas == snapshot.target
        and activeVoxelBattleState(game) == snapshot.battle
        and type(graphics.setCanvas) == "function"
        and type(graphics.draw) == "function") then
      return false
    end

    graphics.push("all")
    graphics.setCanvas(ctx.uiCanvas)
    graphics.origin()
    if type(graphics.setBlendMode) == "function" then
      -- Exact restoration, including transparent pixels.
      graphics.setBlendMode("replace")
    end
    graphics.setColor(1, 1, 1, 1)
    graphics.draw(snapshot.canvas, 0, 0)
    graphics.pop()
    return true
  end

  -- -----------------------------------------------------------------------
  -- Modern UI 0.9.x Battle UI menu safety fallback
  --
  -- The 0.9.x WIP battle presenter keeps the source BattleState as animation
  -- authority, then scrubs the native WIDE bottom band (304x40 at y=104)
  -- before drawing its modern action panel in render.hud. If the replacement
  -- action panel is skipped on a frame, the native menu has already been
  -- erased and the battle appears to have no controls even though input still
  -- belongs to BattleState.
  --
  -- Keep the modern battle scene/status presentation, but retain a copy of
  -- the source-owned command band and put it back after Modern UI's compose
  -- pass. This is intentionally limited to the interactive menu phases and
  -- Modern UI 0.9.x. It does not touch messages, animations, Party/Bag child
  -- screens, 0.8.x, or future 0.10+ branches.
  local battleMenuCapture = nil
  local battleMenuCaptureW = 0
  local battleMenuCaptureH = 0

  local function modernUiOption(game, key, default)
    local options = game and game.save and game.save.options
    local buckets = options and options.modOptions
    local bucket = type(buckets) == "table" and buckets.gen1_modern_ui or nil
    if type(bucket) == "table" and bucket[key] ~= nil then
      return bucket[key]
    end
    return default
  end

  local function isWideBattle(state)
    if type(state) ~= "table" then return false end
    for _, method in ipairs({ "wideLayout", "isWideBattleLayout" }) do
      if type(state[method]) == "function" then
        local ok, value = pcall(state[method], state)
        if ok then return value == true end
      end
    end
    local options = state.game and state.game.save and state.game.save.options
    return type(options) == "table" and options.battleLayout == "wide"
  end

  local function activeBattleMenuState(game)
    if not modernUi09 or not game then return nil end
    if voxelBattleEnabled() then return nil end
    if modernUiOption(game, "battleUiWip", false) ~= true then return nil end
    if modernUiOption(game, "hideOriginalUi", true) == false then return nil end

    local stack = game.stack
    local top = stack and type(stack.top) == "function" and stack:top() or nil
    if type(top) ~= "table" then return nil end
    if not (top.isBattleState == true or top.isBattle == true) then return nil end
    if not isWideBattle(top) then return nil end

    local phase = top.phase
    if phase ~= "menu" and phase ~= "moveSelect" and phase ~= "mimicSelect" then
      return nil
    end
    return top
  end

  local function ensureBattleMenuCapture(width, height)
    local graphics = love and love.graphics
    if not (graphics and type(graphics.newCanvas) == "function") then return nil end
    if battleMenuCapture
        and battleMenuCaptureW == width and battleMenuCaptureH == height then
      return battleMenuCapture
    end
    battleMenuCapture = graphics.newCanvas(width, height)
    if battleMenuCapture and type(battleMenuCapture.setFilter) == "function" then
      battleMenuCapture:setFilter("nearest", "nearest")
    end
    battleMenuCaptureW, battleMenuCaptureH = width, height
    return battleMenuCapture
  end

  local function captureBattleMenuBand(game, ctx)
    local state = activeBattleMenuState(game)
    local graphics = love and love.graphics
    local source = ctx and ctx.uiCanvas
    if not (state and graphics and source
        and type(graphics.setCanvas) == "function"
        and type(graphics.draw) == "function"
        and type(graphics.clear) == "function") then
      return nil
    end

    local canvasW, canvasH = source:getDimensions()
    local nativeW, nativeH = 304, 144
    local bandY, bandH = 104, 40
    if canvasW < nativeW or canvasH < nativeH then return nil end

    local offsetX = math.floor((canvasW - nativeW) / 2)
    local capture = ensureBattleMenuCapture(nativeW, bandH)
    if not capture then return nil end

    graphics.push("all")
    graphics.setCanvas(capture)
    graphics.clear(0, 0, 0, 0)
    if type(graphics.setBlendMode) == "function" then
      graphics.setBlendMode("replace")
    end
    graphics.setColor(1, 1, 1, 1)
    graphics.draw(source, -offsetX, -bandY)
    graphics.pop()

    return {
      canvas = capture,
      target = source,
      offsetX = offsetX,
      y = bandY,
      phase = state.phase,
      state = state,
    }
  end

  local function restoreBattleMenuBand(snapshot, ctx)
    local graphics = love and love.graphics
    if not (snapshot and graphics and snapshot.canvas
        and ctx and ctx.uiCanvas == snapshot.target
        and type(graphics.setCanvas) == "function"
        and type(graphics.draw) == "function") then
      return false
    end

    -- Recheck the state after downstream compose hooks. If input or a
    -- transition changed phase during the same frame, do not restore a stale
    -- command surface over the next battle state.
    local state = activeBattleMenuState(currentGame)
    if state ~= snapshot.state or state.phase ~= snapshot.phase then return false end

    graphics.push("all")
    graphics.setCanvas(ctx.uiCanvas)
    graphics.origin()
    if type(graphics.setBlendMode) == "function" then
      graphics.setBlendMode("replace")
    end
    graphics.setColor(1, 1, 1, 1)
    graphics.draw(snapshot.canvas, snapshot.offsetX, snapshot.y)
    graphics.pop()
    return true
  end

  if modernUi09 then
    -- render.compose does not receive Game. Cache the same live Game one stage
    -- earlier, before Modern UI performs its own zones/compose work.
    mod.hooks:wrap("render.zones", function(next, game, zones)
      currentGame = game
      return next(game, zones)
    end, 1000)

    -- Higher priority makes this wrapper outermost around Modern UI 0.9.x's
    -- render.compose hook (priority 100). Capture the native command strip
    -- before it is scrubbed, then restore it after Modern UI finishes.
    mod.hooks:wrap("render.compose", function(next, renderer, ctx)
      -- Staged voxel battle: preserve the ENTIRE transparent UI surface.
      -- Ordinary 2D WIDE battle: retain the narrower v1.2.1 menu-band fix.
      local voxelSnapshot = captureVoxelUi(currentGame, ctx)
      local menuSnapshot = not voxelSnapshot
        and captureBattleMenuBand(currentGame, ctx) or nil

      local result = pack(pcall(next, renderer, ctx))
      if result[1] then
        if voxelSnapshot then
          -- Do this regardless of Modern UI's suppression decision: the
          -- source-owned UI must survive in a live staged voxel battle.
          restoreVoxelUi(voxelSnapshot, currentGame, ctx)
        elseif result[2] ~= true then
          restoreBattleMenuBand(menuSnapshot, ctx)
        end
      end
      if not result[1] then error(result[2], 0) end
      return unpack(result, 2, result.n)
    end, 1000)
  end

  -- Register immediately when possible. Modern UI and the voxel fork both
  -- load before this priority-900 compatibility mod; game.ready retries for
  -- hot reload/order edge cases.
  ensureVoxelModernUiBridge()
  mod.events:on("game.ready", function(payload)
    currentGame = payload and payload.game or currentGame
    ensureVoxelModernUiBridge()
  end, -1000)

  -- Gen1 Modern UI 0.8.x deliberately makes supported menu states
  -- transparent in adaptive/floating layouts so the overworld can remain
  -- visible behind them. That rule is unsafe for PartyMenu while it sits on
  -- top of BattleState: the battle presenter is WIP/off by default, so making
  -- the party picker non-opaque expands the visible stack down into an
  -- unsupported battle layer. The result is the white/blank PKMN screen seen
  -- when choosing PKMN during a fight.
  --
  -- Keep the *battle* PartyMenu as the opaque boundary it is in the engine.
  -- Modern UI can still suppress its native pixels in render.compose and draw
  -- the modern Party presenter on top, but presentationStack now starts at the
  -- PartyMenu instead of including BattleState. Input/callback ownership stays
  -- entirely with the original PartyMenu, so voluntary switches, forced
  -- replacements and SHIFT free-switches all keep their normal behavior.
  local function isBattlePartyState(game, state)
    if type(state) ~= "table" or state.battle == nil
        or type(state.index) ~= "number" then
      return false
    end
    local party = state.party or (game and game.save and game.save.party)
    if type(party) ~= "table" then return false end
    -- Every battle PartyMenu is created with onSwitch. Requiring it keeps the
    -- patch narrowly scoped even if another screen happens to publish a
    -- field named `battle`.
    return type(state.onSwitch) == "function"
  end

  local function restoreBattlePartyOpaqueBoundary(game)
    local stack = game and game.stack
    local states = stack and stack.states
    if type(states) ~= "table" then return false end
    local restored = false
    for _, state in ipairs(states) do
      if isBattlePartyState(game, state) and state.isOpaque ~= true then
        state.isOpaque = true
        restored = true
      end
    end
    return restored
  end

  -- The opaque-boundary workaround is ONLY for Modern UI 0.8.x.
  -- Modern UI 0.9.x changed its suppression proof so battle child screens
  -- remain native whenever the battle presenter is inactive. Forcing
  -- PartyMenu.isOpaque on 0.9.x would fight that newer lifecycle system.
  if legacyBattlePartyFix then
    -- Modern UI 0.8.x's screen.pushed listener may immediately set
    -- PartyMenu.isOpaque=false. Run afterwards and restore the battle
    -- boundary before that newly-pushed screen gets its first rendered frame.
    mod.events:on("screen.pushed", function(payload)
      local state = payload and payload.state
      local game = state and state.game
      if game then restoreBattlePartyOpaqueBoundary(game) end
    end, -100)

    -- Modern UI 0.8.x repeats its world-visibility synchronization from
    -- input.step, so the fix must also repeat after that hook every logic
    -- tick. High priority makes this wrapper outermost.
    mod.hooks:wrap("input.step", function(next, game, dt)
      local result = pack(next(game, dt))
      restoreBattlePartyOpaqueBoundary(game)
      return unpack(result, 1, result.n)
    end, 1000)
  end

  -- Gen1 Modern UI registers render.hud at priority 100. A much higher
  -- priority makes this wrapper the outer guard, so all of Modern UI's HUD
  -- drawing happens inside the temporary true-colour interception.
  mod.hooks:wrap("render.hud", function(next, game, viewport)
    decoratePokedexRows(game)
    return runWithTrueColorGuard(game, function()
      return next(game, viewport)
    end)
  end, 1000)

  mod.exports = mod.exports or {}
  mod.exports.version = VERSION
  mod.exports.modernUiIconFix = {
    version = VERSION,
    modernUiVersion = modernUiVersion,
    trueColorAuthoredPokemonIcons = true,
    stockPokedexIcons = true,
    battlePartyOpaqueBoundary = legacyBattlePartyFix,
    modernUi09SuppressionCompatible = not legacyBattlePartyFix,
    modernUi09BattleMenuFallback = modernUi09,
    voxelBattleOwnerBridge = modernUi09,
    voxelBattleOwnerId = voxelOwnerId,
    hardVoxelUiCanvasRestore = modernUi09,
  }
end
