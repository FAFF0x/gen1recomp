# Battle UI 0.9.2 regression checklist

Target: Gen1 Modern UI 0.9.2 + Modern UI Fix 1.2.1

1. Set engine Battle Layout to WIDE.
2. Enable Modern UI -> BATTLE UI (WIP).
3. Keep HIDE ORIGINAL UI enabled.
4. Enter a normal wild/trainer battle.
5. Verify FIGHT / POKEMON / ITEM / RUN remains visible and selectable.
6. Choose FIGHT and verify the move selection remains visible.
7. Back out and verify the command menu returns.
8. Open POKEMON and ITEM and verify those child screens remain functional.
9. Disable BATTLE UI (WIP) and verify native battle rendering is unchanged.
10. Verify Modern UI 0.8.x still uses only the legacy Party opacity workaround.
