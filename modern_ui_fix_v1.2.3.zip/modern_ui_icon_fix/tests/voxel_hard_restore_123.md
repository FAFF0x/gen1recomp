# v1.2.3 staged voxel battle check
1. Modern UI 0.9.2: BATTLE UI (WIP) ON, HIDE ORIGINAL UI ON.
2. BATTLE ART VOXEL FORK: VOXEL/3D-BTL ON.
3. Enter an actually staged voxel battle.
4. Verify voxel Pokémon and scene remain visible.
5. Verify status HUD + FIGHT/POKEMON/ITEM/RUN are visible.
6. Verify move menu, dialogue, Party and Bag are visible.
7. Enter a non-staged battle and verify normal Modern UI behavior remains.
