# Modern UI 0.9.2 + BATTLE_ART_VOXEL_FORK regression

1. Enable BATTLE_ART_VOXEL_FORK and 3D-BTL.
2. In Gen1 Modern UI 0.9.2 set BATTLE UI (WIP) = ON.
3. Set LEAVE 3D BATTLES ALONE = ON.
4. Keep HIDE ORIGINAL UI = ON.
5. Enter a battle.
6. Verify the voxel scene and both Pokemon render.
7. Verify FIGHT / POKEMON / ITEM / RUN is visible.
8. Verify FIGHT -> move list remains visible.
9. Verify POKEMON, ITEM, dialogue and level-up children remain visible/native.
10. Turn 3D-BTL OFF and confirm the normal Modern UI WIDE battle path remains available.
