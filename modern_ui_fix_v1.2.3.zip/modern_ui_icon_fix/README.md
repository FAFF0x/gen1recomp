# Modern UI Fix

A runtime compatibility patch for **Gen1 Modern UI 0.8.x and 0.9.x**. It keeps the original Modern UI release from its creator completely unchanged.

## What it fixes

- On **Modern UI 0.8.x**, fixes the **blank/white POKéMON party screen during battles**. Modern UI 0.9.x has a newer battle-child suppression system, so this legacy opacity workaround is automatically disabled there.
- On **Modern UI 0.9.x / 0.9.2**, fixes the experimental **BATTLE UI (WIP)** making the in-battle command/move menu invisible. The fix preserves the native WIDE command strip as a fail-safe during FIGHT/POKÉMON/ITEM/RUN, move selection and Mimic selection while leaving the modern battle scene and status presentation enabled.
- Keeps the battle PartyMenu as the correct opaque boundary, so Modern UI can render the modern party picker without accidentally pulling the unsupported/WIP Battle presenter into the same presentation stack.
- Preserves normal battle-party input and callbacks: voluntary SWITCH, forced replacement, SHIFT free-switch, STATS and CANCEL continue to be owned by the engine's PartyMenu.
- Preserves the original RGB colours of table-valued `pokemon.icon` artwork such as **NEW ICONS**.
- Prevents Modern UI's species palette from tinting/recolouring authored icons after the same cached image has been used by Party, Box or another presenter.
- Adds authored icons beside known species names in the **stock Pokédex** (including compatible stock-Pokédex replacements/variant lists).
- Works with **Advanced Box System** and **Pokédex Plus** without editing Gen1 Modern UI itself.

## Requirements

- Gen1 Modern UI `>= 0.8.1 < 0.10.0` (including 0.9.2)
- NEW ICONS is optional.

## Installation

Keep the creator's original Gen1 Modern UI installed. Replace the previous Modern UI Fix with v1.2.0 and enable it together with Modern UI.

A full restart of gen1recomp is recommended after updating the patch. No new save is required.

## Modern UI 0.9.2 behavior

Modern UI 0.9.2 changed how visible/suppressed battle child screens are proven.
When its battle presenter is inactive, battle child screens now remain native
instead of relying on the older `PartyMenu.isOpaque` behavior.

For that reason Modern UI Fix v1.2.2 detects the installed Modern UI version:

- **0.8.x:** keeps the old battle Party opaque-boundary workaround.
- **0.9.x:** does **not** modify PartyMenu opacity.
- **Both branches:** keep the authored full-color icon guard and stock Pokédex
  icon injection used by replacement packs such as NEW ICONS.

This avoids marking 0.9.2 incompatible while also avoiding an obsolete patch
against its new screen-visibility logic.

## Battle UI 0.9.2 menu fallback

With Gen1 Modern UI 0.9.2, enabling **BATTLE UI (WIP)** can scrub the native
WIDE battle command band before the modern replacement menu is guaranteed to
draw. Input still belongs to the game, but the player can no longer see
FIGHT / POKÉMON / ITEM / RUN or the move list.

Modern UI Fix 1.2.2 adds a targeted fail-safe:

- only runs on Modern UI **0.9.x**;
- only runs when **BATTLE UI (WIP)** and **HIDE ORIGINAL UI** are enabled;
- only runs for the active **WIDE** BattleState;
- only preserves interactive `menu`, `moveSelect`, and `mimicSelect` phases;
- does not alter battle logic, cursor/input ownership, messages, animations,
  Party/Bag child screens, or Modern UI 0.8.x;
- if another compositor owns the frame, the fallback does nothing.

The result is that the experimental modern battle scene can stay enabled while
the battle controls always retain a visible native fallback.

## BATTLE ART VOXEL FORK / 3D battle fix

Gen1 Modern UI 0.9.2 already contains a **LEAVE 3D BATTLES ALONE** option, but
its built-in detector recognizes the upstream Dramatic Shape IDs and does not
recognize the fork ID `BATTLE_ART_VOXEL_FORK`.

When the fork is not recognized, enabling **BATTLE UI (WIP)** can make Modern
UI claim the 3D BattleState and suppress its native HUD/menu canvas. The voxel
scene and Pokémon remain visible, but FIGHT / POKÉMON / ITEM / RUN disappears.

Modern UI Fix 1.2.2 registers a public Modern UI compatibility adapter for
`BATTLE_ART_VOXEL_FORK` with a `battle.native3d` detector backed by the fork's
public `OverworldBattle.enabled()` export.

With the normal Modern UI setting **LEAVE 3D BATTLES ALONE = ON**:

- the voxel world/battle scene remains owned by BATTLE ART VOXEL FORK;
- the battle HUD and FIGHT / POKÉMON / ITEM / RUN remain native and visible;
- move selection, dialogue, Party, Bag, choice boxes and level-up interfaces
  remain native;
- the Modern UI Battle presenter does not scrub any of those layers;
- ordinary non-voxel WIDE battles can still use the Modern UI Battle UI.

The earlier 0.9.x 2D command-band fallback is retained for non-voxel battles.

## v1.2.3 hard voxel UI restore

For a live BATTLE ART VOXEL FORK battle, the reliable runtime marker is
`BattleState.dramaticShapeShot`. Version 1.2.3 no longer relies only on Modern
UI's 3D-owner detection.

While that marker is active, the fix saves the complete native `uiCanvas`
before Modern UI's `render.compose` hook and restores it afterward. BATTLE ART
already removes the flat Pokémon pictures from that UI layer while staging
them in the 3D world, so restoring the canvas brings back the source-owned HUD,
battle menu, move list, dialogue and child interfaces without duplicating the
Pokémon in the voxel scene.

The full restore runs only during an actually staged voxel battle. Normal
non-voxel battles keep the existing Modern UI behavior and the narrower v1.2.1
WIDE-menu fallback.
