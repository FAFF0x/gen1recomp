-- Move Learn Stats
-- Replaces only the visual layer of MoveLearnMenu. The original menu keeps
-- control of prompts, HM protection, cancellation and the actual move swap.

local Font = require("src.render.Font")
local Strings = require("src.core.Strings")
local VanillaMoveLearnMenu = require("src.ui.MoveLearnMenu")

local CURSOR = 0xED
local NAME_GLYPHS = 8

local function shortName(name, limit)
  name = tostring(name or "---")
  limit = limit or NAME_GLYPHS
  if #name <= limit then return name end
  return name:sub(1, limit)
end

local function moveStats(data, moveId)
  local def = data and data.moves and moveId and data.moves[moveId]
  if not def then
    return { name = "---", power = "---", pp = "---" }
  end
  local power = tonumber(def.power) or 0
  return {
    name = def.name or moveId,
    power = power > 0 and tostring(power) or "---",
    pp = tostring(tonumber(def.pp) or 0),
  }
end

local function drawColumn(x, heading, stats)
  Font.draw(Strings(heading), x, 13 * 8)
  Font.draw(shortName(stats.name), x, 14 * 8)
  Font.draw(Strings("PWR %s", stats.power), x, 15 * 8)
  Font.draw(Strings("PP  %s", stats.pp), x, 16 * 8)
end

local function drawMoveLearnComparison(self)
  if not self.selecting then return end

  -- Keep the vanilla single-spaced move list and CANCEL row.
  Font.drawBox(4, 5, 16, 7)
  love.graphics.setColor(0, 0, 0, 1)
  for i, mv in ipairs(self.mon.moves) do
    local def = self.game.data.moves[mv.id]
    Font.draw((def and def.name) or mv.id, 48, (5 + i) * 8)
  end
  Font.draw(Strings("CANCEL"), 48, (6 + #self.mon.moves) * 8)
  Font.drawCode(CURSOR, 40, (5 + self.index) * 8)

  -- Four interior rows: heading, move name, power, and maximum PP.
  Font.drawBox(0, 12, 20, 6)
  local selectedId
  if self.index <= #self.mon.moves then
    selectedId = self.mon.moves[self.index].id
  end
  drawColumn(8, "SELECTED", moveStats(self.game.data, selectedId))
  drawColumn(88, "LEARNING", moveStats(self.game.data, self.newMoveId))
  love.graphics.setColor(1, 1, 1, 1)
end

local function newMoveLearnMenu(game, mon, newMoveId, onDone)
  local screen = VanillaMoveLearnMenu.new(game, mon, newMoveId, onDone)
  screen.draw = drawMoveLearnComparison
  return screen
end

return function(mod)
  -- Data.screens wins over the built-in module while all other screens stay
  -- untouched. The factory still creates the original MoveLearnMenu instance.
  mod.content.screens:register("MoveLearnMenu", {
    new = newMoveLearnMenu,
  })

  -- Small public helpers make headless validation and compatibility checks
  -- possible without reaching into local functions.
  mod.exports.moveStats = moveStats
  mod.exports.shortName = shortName
  mod.exports.newScreen = newMoveLearnMenu
end
