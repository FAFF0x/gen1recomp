# Changelog

## v1.0.0

- Added a two-column comparison panel to the move-forgetting screen.
- Shows POWER and maximum PP for the highlighted old move.
- Shows POWER and maximum PP for the new move being learned.
- Displays `---` as the power of status moves.
- Preserves the original MoveLearnMenu behavior and HM restrictions.
