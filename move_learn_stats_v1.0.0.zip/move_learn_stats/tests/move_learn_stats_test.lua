-- Headless focused test for Move Learn Stats.

_G.love = { graphics = { setColor = function() end } }

local registered
local mod = {
  content = {
    screens = {
      register = function(_, id, record)
        assert(id == "MoveLearnMenu")
        registered = record
      end,
    },
  },
  exports = {},
}

package.preload["src.render.Font"] = function()
  return {
    draw = function() end,
    drawBox = function() end,
    drawCode = function() end,
  }
end
package.preload["src.core.Strings"] = function()
  return function(fmt, ...)
    if select("#", ...) > 0 then return string.format(fmt, ...) end
    return fmt
  end
end
package.preload["src.ui.MoveLearnMenu"] = function()
  return {
    new = function(game, mon, newMoveId, onDone)
      return {
        game = game,
        mon = mon,
        newMoveId = newMoveId,
        onDone = onDone,
        index = 1,
        selecting = true,
        vanillaMarker = true,
      }
    end,
  }
end

local entry = assert(loadfile("main.lua"))
entry()(mod)

assert(registered and type(registered.new) == "function")
assert(mod.exports.moveStats({ moves = {
  TACKLE = { name = "TACKLE", power = 40, pp = 35 },
  GROWL = { name = "GROWL", power = 0, pp = 40 },
}}, "TACKLE").power == "40")
assert(mod.exports.moveStats({ moves = {
  GROWL = { name = "GROWL", power = 0, pp = 40 },
}}, "GROWL").power == "---")
assert(mod.exports.moveStats({ moves = {
  GROWL = { name = "GROWL", power = 0, pp = 40 },
}}, "GROWL").pp == "40")
assert(mod.exports.shortName("DOUBLE-EDGE", 8) == "DOUBLE-E")

local game = { data = { moves = {
  TACKLE = { name = "TACKLE", power = 40, pp = 35 },
  BITE = { name = "BITE", power = 60, pp = 25 },
}} }
local mon = { moves = { { id = "TACKLE", pp = 4 } } }
local screen = registered.new(game, mon, "BITE", function() end)
assert(screen.vanillaMarker == true)
assert(screen.draw ~= nil)
assert(screen.mon == mon and screen.newMoveId == "BITE")
screen:draw()
screen.index = #mon.moves + 1
screen:draw() -- CANCEL keeps the learning column and blanks SELECTED

print("move_learn_stats_test: ok")
