_G.love = { graphics = {
  setColor = function() end,
  rectangle = function() end,
} }

local registered = {}
local hooks = {}
local events = {}
local adapterSpec
local modernExports = {
  compatibilityApiVersion = 1,
  registerAdapter = function(spec)
    adapterSpec = spec
    return true
  end,
}

local mod = {
  id = "moves_manager",
  exports = {},
  ui = {
    Font = {
      draw = function() end,
      drawCode = function() end,
    },
    Theme = { cursor = ">", cursorHollow = "o" },
    TextBox = { new = function(_, text) return { text = text } end },
    insertAfter = function(items, _, item)
      items[#items + 1] = item
      return items
    end,
    push = function() end,
  },
  content = {
    screens = { register = function(_, id, def) registered[id] = def end },
    type_chart = {
      get = function(_, id)
        if id == "NORMAL" then return { name = "NORMAL", category = "physical" } end
        if id == "DARK" then return { name = "DARK", category = "special" } end
        return { name = tostring(id), category = "physical" }
      end,
    },
    move_effects = {
      get = function(_, id) return { kind = id == "FLINCH_EFFECT" and "flinch" or "normal" } end,
    },
  },
  hooks = {
    wrap = function(_, name, fn) hooks[name] = fn end,
  },
  events = {
    on = function(_, name, fn) events[name] = fn end,
  },
  find = function(id)
    if id == "gen1_modern_ui" then return { exports = modernExports } end
    if id == "moves_manager" then return { exports = mod.exports } end
  end,
  log = { warn = function() end },
}

local entry = assert(loadfile("main.lua"))()
entry(mod)

assert(adapterSpec, "Modern UI adapter was not registered")
assert(adapterSpec.owner == "moves_manager", "wrong adapter owner")
assert(adapterSpec.version == "1.0.1", "wrong adapter version")
local contract = assert(mod.exports.gen1ModernUi, "missing Modern UI export")
assert(contract.apiVersion == 1, "wrong compatibility API")
local screenDesc = assert(contract.screens.moves_manager, "missing moves screen adapter")
assert(screenDesc.canSuppressNative == true, "native renderer cannot be suppressed")
assert(type(events["game.ready"]) == "function", "game.ready retry not registered")

local pops, pushes = 0, {}
local input = { wasPressed = function() return false end }
local game = {
  input = input,
  stack = {
    pop = function() pops = pops + 1 end,
    push = function(_, state) pushes[#pushes + 1] = state end,
  },
  data = {
    pokemon = {
      TESTMON = {
        id = "TESTMON",
        name = "TESTMON",
        level1Moves = { "TACKLE" },
        learnset = {
          { level = 5, move = "GROWL" },
          { level = 10, move = "BITE" },
        },
        evolutions = {},
      },
    },
    moves = {
      TACKLE = {
        id = "TACKLE", name = "TACKLE", type = "NORMAL", pp = 35,
        power = 40, accuracy = 100, priority = 0, index = 1,
        effect = "NORMAL_EFFECT",
      },
      GROWL = {
        id = "GROWL", name = "GROWL", type = "NORMAL", pp = 40,
        power = 0, accuracy = 100, priority = 0, index = 2,
        effect = "NORMAL_EFFECT",
      },
      BITE = {
        id = "BITE", name = "BITE", type = "DARK", pp = 25,
        power = 60, accuracy = 100, priority = 0, index = 3,
        effect = "FLINCH_EFFECT", highCrit = true,
      },
    },
  },
}

local mon = {
  species = "TESTMON",
  nickname = "BUDDY",
  level = 10,
  moves = {
    { id = "TACKLE", pp = 30 },
    { id = "GROWL", pp = 35 },
  },
}

local screen = assert(registered.MovesManager).new(game, mon)
assert(screen.screenId == "MovesManager", "screen id missing")
assert(screenDesc.match(screen), "Modern UI match failed")

local model = screenDesc.model(game, screen)
assert(model.title == "MOVES - BUDDY", model.title)
assert(#model.rows == 4, "known move rows mismatch")
assert(model.rows[1].label == "TACKLE", "first move label mismatch")
assert(model.rows[1].value == "PP 30/35", "PP model mismatch")
assert(model.rows[3].label == "EMPTY SLOT", "empty slot missing")

assert(screenDesc.actions.hover(game, screen, 2))
assert(screen.slot == 2, "hover did not move slot")
assert(screenDesc.actions.select(game, screen, 1))
assert(screen.slot == 1 and screen.mode == "current_detail",
  "select did not open current move detail")

local detail = screenDesc.model(game, screen)
assert(detail.title == "MOVE DETAILS 1/3", detail.title)
assert(detail.rows[2].label == "TYPE" and detail.rows[2].value == "NORMAL",
  "detail type missing")
assert(detail.rows[#detail.rows].label == "CHANGE MOVE",
  "detail action row missing")

assert(screenDesc.actions.right(game, screen))
assert(screen.detailPage == 2, "right did not change detail page")
assert(screenDesc.actions.left(game, screen))
assert(screen.detailPage == 1, "left did not change detail page")

assert(screenDesc.actions.select(game, screen, #detail.rows))
assert(screen.mode == "pool", "CHANGE MOVE did not open pool")
local pool = screenDesc.model(game, screen)
assert(#pool.rows == 1 and pool.rows[1].label == "BITE",
  "remembered pool reconstruction failed")
assert(pool.rows[1].value == "DARK", "pool type value mismatch")

assert(screenDesc.actions.select(game, screen, 1))
assert(screen.mode == "candidate_detail", "candidate detail did not open")
local candidate = screenDesc.model(game, screen)
assert(candidate.rows[1].label == "BITE", "candidate detail wrong")
assert(candidate.rows[#candidate.rows].label == "TEACH MOVE",
  "teach action row missing")

assert(screenDesc.actions.select(game, screen, #candidate.rows))
assert(screen.mode == "known", "teaching did not return to known moves")
assert(mon.moves[1].id == "BITE", "candidate move was not taught")
assert(#pushes == 1, "teach result TextBox was not pushed")

screen.swapSlot = 1
screen.slot = 2
assert(screenDesc.actions.select(game, screen, 2))
assert(screen.swapSlot == nil, "swap mode did not clear")
assert(mon.moves[1].id == "GROWL" and mon.moves[2].id == "BITE",
  "Modern UI select did not swap moves")

assert(screenDesc.actions.back(game, screen))
assert(pops == 1, "back did not close Moves Manager")

events["game.ready"]()
assert(adapterSpec.version == "1.0.1", "game.ready adapter retry failed")

print("moves manager modern ui compatibility ok")
