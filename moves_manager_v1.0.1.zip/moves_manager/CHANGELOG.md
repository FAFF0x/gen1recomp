# Changelog

## [1.0.1] - 2026-08-07

### Added

- Official Gen1 Modern UI compatibility using the `gen1ModernUi` API v1 contract.
- Responsive Modern UI models for current moves, remembered moves, and all three detail pages.
- Semantic pointer/mouse/touch actions while keeping move editing and navigation source-owned.
- `gen1_modern_ui` as an optional dependency with automatic native-UI fallback.

## [1.0.0] - 2026-07-30

### Added

- `MOVES` entry in the out-of-battle Pokémon submenu.
- Four-slot move overview with PP and SELECT-based reordering.
- Two-page detailed move statistics.
- Persistent reconstructed move memory.
- Legal move replacement with duplicate and HM protections.
- Compatibility with merged Pokémon, move, type and effect registries.
