package.preload["src.script.MapScripts"] = function()
  return { baseTalk = function() return function(_, _, _, done) done() end end }
end
local function registry()
  local r = { values = {} }
  function r:register(id, value) self.values[id] = value return true end
  return r
end
local saved, questDef = {}, nil
local quests = {
  register=function(def) questDef=def return true end,
  start=function() end, update=function() end, complete=function() end,
  get=function() return nil end,
}
local mod = {
  id="echoes_beyond_the_fog", path=".",
  content={ commands=registry(), tokens=registry(), trainers=registry(), tilesets=registry(), maps=registry(), map_scripts=registry() },
  save={ get=function(_,k,d) local v=saved[k]; if v==nil then return d end; return v end, set=function(_,k,v) saved[k]=v end },
  find=function(id) if id=="quest_system" then return {exports=quests} end end,
  events={on=function() end, emit=function() end}, exports={},
}
local chunk, err=loadfile("main.lua"); assert(chunk,err)
chunk()(mod)
assert(questDef and questDef.id=="echoes_beyond_the_fog.main")
local floors={
 "CAPE_SIGNAL_OBSERVATORY","CAPE_SIGNAL_ENGINE_ROOM","CAPE_SIGNAL_BEACON_DOME",
 "FOGBOUND_CAVERNS","FOGBOUND_RELAY_DEPTHS","FOGBOUND_DOCK_APPROACH",
 "BLACK_TIDE_HIDEOUT","BLACK_TIDE_LABS","BLACK_TIDE_CONTROL",
}
for _,id in ipairs(floors) do
  local map=assert(mod.content.maps.values[id], "missing map "..id)
  assert(map.width==18 and map.height==14 and #map.blocks==252, "bad geometry "..id)
  assert(mod.content.map_scripts.values[id], "missing script "..id)
  local hasMarker=false
  for _,b in ipairs(map.blocks) do if b==24 then hasMarker=true break end end
  assert(hasMarker, "missing visible quest marker in "..id)
end
for id,ts in pairs(mod.content.tilesets.values) do
  assert(ts.imageWidth==800 and ts.imageHeight==32 and ts.tilesPerRow==100, "bad atlas "..id)
  assert(#ts.blocks==25, "bad block count "..id)
  local f=assert(io.open(ts.image,"rb"), "missing image "..ts.image); f:close()
end
for _,area in ipairs({
 {"CAPE_SIGNAL_OBSERVATORY","CAPE_SIGNAL_ENGINE_ROOM","CAPE_SIGNAL_BEACON_DOME"},
 {"FOGBOUND_CAVERNS","FOGBOUND_RELAY_DEPTHS","FOGBOUND_DOCK_APPROACH"},
 {"BLACK_TIDE_HIDEOUT","BLACK_TIDE_LABS","BLACK_TIDE_CONTROL"},
}) do
  local used={}
  for _,id in ipairs(area) do for _,b in ipairs(mod.content.maps.values[id].blocks) do used[b]=true end end
  for b=0,24 do assert(used[b], "metatile "..b.." not used in area") end
end

local game={save={inventory={SOULBADGE=1},flags={EVENT_MET_BILL=true}},writeSave=function() end}
local queued=0
local ow={queueScript=function(_,rows) assert(type(rows)=="table" and #rows>0); queued=queued+1 end}
local triggerChecks={
 CAPE_SIGNAL_OBSERVATORY={{16,24},{6,6},{8,20},{28,4}},
 CAPE_SIGNAL_ENGINE_ROOM={{6,22},{16,14},{28,4}},
 CAPE_SIGNAL_BEACON_DOME={{6,22},{26,10},{28,4}},
 FOGBOUND_CAVERNS={{6,22},{6,18},{28,4}},
 FOGBOUND_RELAY_DEPTHS={{6,22},{16,14},{28,4}},
 FOGBOUND_DOCK_APPROACH={{6,22},{28,4}},
 BLACK_TIDE_HIDEOUT={{6,22},{6,18},{28,4}},
 BLACK_TIDE_LABS={{6,22},{6,8},{18,8},{30,8},{28,4}},
 BLACK_TIDE_CONTROL={{6,22},{26,8}},
}
for id,cells in pairs(triggerChecks) do
  local script=assert(mod.content.map_scripts.values[id])
  if script.onEnter then script.onEnter(game,ow) end
  for _,cell in ipairs(cells) do
    local handled=script.onStep(game,ow,cell[1],cell[2])
    assert(handled==true, "trigger not handled "..id.." at "..cell[1]..","..cell[2])
  end
end
assert(queued>0, "map scripts queued no guidance")

print("echoes_beyond_the_fog_test: ok")
