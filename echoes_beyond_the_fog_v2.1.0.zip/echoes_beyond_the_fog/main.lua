-- Echoes Beyond the Fog
-- An original lighthouse mystery quest for Gen1Recomp.
-- Requires Quest System v1.0.3 or newer.

local MapScripts = require("src.script.MapScripts")

local QUEST_ID = "echoes_beyond_the_fog.main"
local OBSERVATORY_MAP = "CAPE_SIGNAL_OBSERVATORY"
local OBSERVATORY_2F = "CAPE_SIGNAL_ENGINE_ROOM"
local OBSERVATORY_3F = "CAPE_SIGNAL_BEACON_DOME"
local CAVERN_MAP = "FOGBOUND_CAVERNS"
local CAVERN_2F = "FOGBOUND_RELAY_DEPTHS"
local CAVERN_3F = "FOGBOUND_DOCK_APPROACH"
local HIDEOUT_MAP = "BLACK_TIDE_HIDEOUT"
local HIDEOUT_2F = "BLACK_TIDE_LABS"
local HIDEOUT_3F = "BLACK_TIDE_CONTROL"
local BILL_MAP = "BILLS_HOUSE"
local BILL_TALK_POST = "TEXT_BILLSHOUSE_BILL_CHECK_OUT_MY_RARE_POKEMON"
local BILL_TALK_TICKET = "TEXT_BILLSHOUSE_BILL_SS_TICKET"
local REQUIRED_BADGE = "SOULBADGE"
local REWARD_LEVEL = 50

local CLASS_SCOUT = "OPP_BLACK_TIDE_SCOUT"
local CLASS_CAPTAIN = "OPP_BLACK_TIDE_CAPTAIN"

local function hasSoulBadge(save)
  local inventory = save and save.inventory or {}
  return (inventory[REQUIRED_BADGE] or 0) > 0
end

local function helpedBill(save)
  local flags = save and save.flags or {}
  -- Different game versions and imported saves may reach Bill's completed
  -- state through different permanent flags.  Any of these means the cell
  -- separator event has been resolved and the human Bill is available.
  return flags.EVENT_USED_CELL_SEPARATOR_ON_BILL
    or flags.EVENT_GOT_SS_TICKET
    or flags.EVENT_LEFT_BILLS_HOUSE_AFTER_HELPING
    or flags.EVENT_MET_BILL_2
    or flags.EVENT_MET_BILL
    or false
end

local function sameCell(x, y, cells)
  for _, cell in ipairs(cells) do
    if x == cell[1] and y == cell[2] then return true end
  end
  return false
end

local CUSTOM_TILES_PER_ROW = 100
local CUSTOM_BLOCK_COUNT = 25

-- Each bundled atlas contains twenty-five 32x32 metatiles arranged in one
-- horizontal strip. Gen1Recomp draws native 8x8 tiles, so every metatile
-- expands to sixteen atlas indices. Tile 24 is the visible quest marker.
local function metatileBlock(index)
  local block = {}
  local startX = index * 4
  for y = 0, 3 do
    for x = 0, 3 do
      block[#block + 1] = y * CUSTOM_TILES_PER_ROW + startX + x
    end
  end
  return block
end

local function allMetatileBlocks()
  local blocks = {}
  for index = 0, CUSTOM_BLOCK_COUNT - 1 do
    blocks[#blocks + 1] = metatileBlock(index)
  end
  return blocks
end

local function addCollisionFeet(out, blockIndex, lowerOnly)
  local block = metatileBlock(blockIndex)
  -- A 32x32 metatile contains four 16x16 movement cells. Collision reads
  -- each cell's bottom-left 8x8 tile: 5, 7, 13 and 15 in Lua indexing.
  local positions = lowerOnly and { 13, 15 } or { 5, 7, 13, 15 }
  for _, pos in ipairs(positions) do out[#out + 1] = block[pos] end
end

local function customWalkable()
  local out = {}
  -- Only structural floor, route, stair, door and quest-marker blocks are
  -- walkable. Props and hazards stay solid so rooms read clearly.
  for _, blockIndex in ipairs({ 0, 3, 4, 5, 14, 15, 24 }) do
    addCollisionFeet(out, blockIndex, false)
  end
  return out
end

local function cellsForBlock(bx, by)
  local cells = {}
  for y = by * 2, by * 2 + 1 do
    for x = bx * 2, bx * 2 + 1 do
      cells[#cells + 1] = { x, y }
    end
  end
  return cells
end

local function lowerCellsForBlock(bx, by)
  return { { bx * 2, by * 2 + 1 }, { bx * 2 + 1, by * 2 + 1 } }
end

return function(mod)
  local journal = assert(mod.find("quest_system"),
    "Echoes Beyond the Fog requires Quest System v1.0.3 or newer")
  local quests = assert(type(journal.exports) == "table" and journal.exports,
    "Quest System exports are unavailable")
  for _, method in ipairs({ "register", "start", "update", "complete", "get" }) do
    assert(type(quests[method]) == "function",
      "Quest System is missing the required '" .. method .. "' export")
  end

  local function state(key, default)
    return mod.save:get(key, default)
  end

  local function setState(key, value)
    mod.save:set(key, value)
  end

  local function available(game)
    local save = game and game.save
    return helpedBill(save) and hasSoulBadge(save)
  end

  local function completed(game)
    -- reward_mon is historical and must stay true after a replay starts.
    -- replay_active prevents that preserved reward from immediately marking
    -- the restarted quest completed again.
    if state("done", false) then return true end
    if state("replay_active", false) then return false end
    if state("reward_mon", false) then return true end
    local snapshot = quests.get(QUEST_ID, game)
    return snapshot and snapshot.status == "completed" or false
  end

  local function anchorCount()
    local count = 0
    for _, key in ipairs({ "anchor_a", "anchor_b", "anchor_c" }) do
      if state(key, false) then count = count + 1 end
    end
    return count
  end

  local function anchorsDisabled()
    return anchorCount() == 3
  end

  local function stage()
    if completed() then return 12 end
    if state("boss_defeated", false) then return 11 end
    if anchorsDisabled() then return 10 end
    if state("scout_defeated", false) then return 7 end
    if state("relay_decoded", false) then return 6 end
    if state("horn_tuned", false) then return 5 end
    if state("lens_fixed", false) then return 4 end
    if state("log_read", false) then return 3 end
    if state("entered", false) then return 2 end
    if state("started", false) then return 1 end
    return 0
  end

  local function progress()
    local current = 0
    for _, key in ipairs({
      "started", "entered", "log_read", "lens_fixed",
      "horn_tuned", "relay_decoded", "scout_defeated",
      "anchor_a", "anchor_b", "anchor_c", "boss_defeated", "done",
    }) do
      if state(key, false) then current = current + 1 end
    end
    return current
  end

  local function syncJournal(game)
    local snapshot = quests.get(QUEST_ID, game)
    if completed(game) then
      if not snapshot or snapshot.status ~= "completed" then
        quests.complete(QUEST_ID, { stage = 12, current = 12, total = 12 })
      end
      return
    end
    if not state("started", false) then return end
    local patch = { stage = stage(), current = progress(), total = 12 }
    if snapshot and snapshot.status == "active" then
      quests.update(QUEST_ID, patch)
    else
      quests.start(QUEST_ID, patch)
    end
  end

  local registered, registerError = quests.register({
    id = QUEST_ID,
    title = "Echoes Beyond the Fog",
    source = "Echoes Beyond the Fog",
    sort = 420,
    hidden = function(game)
      return not available(game)
        and not state("started", false)
        and not state("done", false)
    end,
    description = "Years after the giant Dragonite answered Bill's lighthouse call, the same lonely voice returns. Restore the beacon, follow a stolen recording through the cape and stop Black Tide from repeating Team Rocket's mistake.",
    objective = function()
      if completed() then
        return "The giant Dragonite remains free, the false call is silent and the mystery of the lighthouse endures."
      elseif not state("started", false) then
        return "Visit Bill at the Sea Cottage after obtaining the Soul Badge."
      elseif not state("entered", false) then
        return "Use Bill's transport route to reach the Cape Signal Observatory."
      elseif not state("log_read", false) then
        return "Follow the yellow marker and read Bill's field log in the observatory study."
      elseif not state("lens_fixed", false) then
        return "Restore the engine-room generator using Bill's breaker order."
      elseif not state("horn_tuned", false) then
        return "Recreate the authentic LOW-HIGH-LOW lighthouse call."
      elseif not state("relay_decoded", false) then
        return "Reach the cavern relay and determine the meaning of the giant Dragonite's call."
      elseif not state("scout_defeated", false) then
        return "Defeat the Black Tide scout guarding the relay and obtain the MAG-KEY."
      elseif not anchorsDisabled() then
        return ("Disable the three resonance anchors in the Black Tide labs (%d/3 offline)."):format(anchorCount())
      elseif not state("boss_defeated", false) then
        return "Reach the control deck and stop Captain Morrow's final transmitter."
      end
      return "Return to Bill at the Sea Cottage and help the rescued Dragonite."
    end,
    location = function()
      if not state("started", false) or state("boss_defeated", false) then
        return "Sea Cottage"
      elseif not state("entered", false) then
        return "Sea Cottage"
      elseif not state("horn_tuned", false) then
        return "Cape Signal Observatory"
      elseif not state("scout_defeated", false) then
        return "Fogbound Caverns"
      elseif not state("boss_defeated", false) then
        return "Black Tide Hideout"
      end
      return "Sea Cottage"
    end,
    reward = "A rescued level 50 Dragonite with maximum DVs and Stat Exp",
    progress = function()
      return { current = progress(), total = 12 }
    end,
    markers = {
      {
        map = BILL_MAP,
        npc = "BILLSHOUSE_BILL2",
        when = function(game)
          if completed(game) then return false end
          if not available(game)
             and not state("started", false) then
            return false
          end
          if state("boss_defeated", false) then return "turnin" end
          if not state("started", false) then return "available" end
          return "active"
        end,
      },
    },
  })
  assert(registered, registerError or
    "Echoes Beyond the Fog quest registration failed")

  mod.content.commands:register("fog:check", function(ctx, key)
    ctx.lastCheck = state(key, false) and true or false
  end)

  mod.content.commands:register("fog:set", function(ctx, key, value)
    setState(key, value)
    syncJournal(ctx and ctx.game)
  end)

  local function returnPoint()
    return state("return_point", nil) or {
      map = BILL_MAP, x = 4, y = 7, facing = "up",
    }
  end

  mod.content.commands:register("fog:enter", {
    foreground = true,
    fn = function(ctx)
      local ow = ctx and ctx.overworld
      local player = ow and ow.player
      if not ow or not player then
        ctx.lastCheck = false
        return
      end
      setState("return_point", {
        map = ow.map and ow.map.id or BILL_MAP,
        x = player.cellX,
        y = player.cellY,
        facing = player.facing or "up",
      })
      setState("entered", true)
      syncJournal(ctx.game)
      local runner = ctx.runner
      ow:startWarpTo(OBSERVATORY_MAP, 17, 22, "up", function()
        runner:resume()
      end)
      runner:yield()
    end,
  })

  mod.content.commands:register("fog:return", {
    foreground = true,
    fn = function(ctx)
      local ow = ctx and ctx.overworld
      if not ow then return end
      local point = returnPoint()
      local runner = ctx.runner
      ow:startWarpTo(point.map or BILL_MAP,
        tonumber(point.x) or 4, tonumber(point.y) or 7,
        point.facing or "up", function()
          runner:resume()
        end)
      runner:yield()
    end,
  })

  mod.content.commands:register("fog:warp", {
    foreground = true,
    fn = function(ctx, mapId, x, y, facing)
      local ow = ctx and ctx.overworld
      if not ow then return end
      local runner = ctx.runner
      ow:startWarpTo(mapId, tonumber(x) or 0, tonumber(y) or 0, facing or "up", function()
        runner:resume()
      end)
      runner:yield()
    end,
  })

  local function maximizeMon(game, mon)
    local Stats = require("src.pokemon.Stats")
    mon.dvs = {
      hp = 15, attack = 15, defense = 15, speed = 15, special = 15,
    }
    mon.statExp = {
      hp = 65535, attack = 65535, defense = 65535,
      speed = 65535, special = 65535,
    }
    mon.stats = Stats.calc(
      game.data.pokemon[mon.species], mon.level, mon.dvs, mon.statExp)
    mon.hp = mon.stats.hp
  end

  local rewardResultText = ""

  local function givePerfectDragonite(ctx)
    if state("reward_mon", false) then return true, nil, false end
    local Pokemon = require("src.pokemon.Pokemon")
    local Party = require("src.pokemon.Party")
    local Boxes = require("src.pokemon.Boxes")
    local BattleState = require("src.battle.BattleState")

    local mon = Pokemon.new(ctx.game.data, "DRAGONITE", REWARD_LEVEL)
    maximizeMon(ctx.game, mon)
    BattleState.stampOT(ctx.save, mon)

    local addedToParty = Party.add(ctx.save.party, mon)
    local boxNum
    if not addedToParty then
      boxNum = Boxes.deposit(ctx.save, mon)
      if not boxNum then return false, nil, false end
    end

    local dex = ctx.save.pokedex
    if dex then
      dex.seen = dex.seen or {}
      dex.owned = dex.owned or {}
      dex.seen.DRAGONITE = true
      dex.owned.DRAGONITE = true
    end

    setState("reward_mon", true)
    return true, boxNum, true
  end

  mod.content.commands:register("fog:claim_reward", function(ctx)
    local lines = {}
    local ok, boxNum, isNew = givePerfectDragonite(ctx)
    if ok then
      if isNew then
        if boxNum then
          lines[#lines + 1] = ("DRAGONITE was sent\nto BOX %d."):format(boxNum)
        else
          lines[#lines + 1] = "Received DRAGONITE!"
        end
      end
      local wasDone = state("done", false)
      setState("done", true)
      setState("replay_active", false)
      lines[#lines + 1] = "Its DVs and\nStat Exp are fully\nmaxed out."
      if not wasDone then
        mod.events:emit("mod.echoes_beyond_the_fog.completed", {
          pokemon = "DRAGONITE",
          level = REWARD_LEVEL,
          perfectDVs = true,
          perfectStatExp = true,
        })
      end
    else
      lines[#lines + 1] = "No room for\nDRAGONITE.\fFree a PARTY or\nBOX slot."
      lines[#lines + 1] = "BILL will guard it\nuntil you return."
    end

    rewardResultText = table.concat(lines, "\f")
    syncJournal(ctx.game)
    if ctx.game.writeSave then ctx.game:writeSave() end
    ctx.lastCheck = state("done", false)
  end)

  mod.content.tokens:register("FOG_REWARD_RESULT", function()
    return rewardResultText
  end)

  mod.content.trainers:register(CLASS_SCOUT, {
    id = CLASS_SCOUT,
    name = "BLACK TIDE SCOUT",
    basePic = "OPP_ROCKET",
    baseMoney = 44,
    parties = { {
      { species = "GOLBAT", level = 43 },
      { species = "SEADRA", level = 44 },
      { species = "MAGNETON", level = 45 },
      { species = "TENTACRUEL", level = 46 },
    } },
  })

  mod.content.trainers:register(CLASS_CAPTAIN, {
    id = CLASS_CAPTAIN,
    name = "CAPTAIN MORROW",
    basePic = "OPP_SCIENTIST",
    baseMoney = 60,
    parties = { {
      { species = "PERSIAN", level = 47 },
      { species = "CLOYSTER", level = 48 },
      { species = "GENGAR", level = 49 },
      { species = "RHYDON", level = 50 },
      { species = "DRAGONAIR", level = 52 },
    } },
  })



  local MAP_W, MAP_H = 18, 14
  local TILE = {
    ["#"] = 1, Q = 2, ["."] = 0, [","] = 3, ["="] = 14, ["+"] = 15,
    S = 4, D = 5, G = 6, L = 7, R = 8, C = 9, O = 10, l = 11,
    B = 12, H = 13, P = 16, T = 17, X = 18, W = 19,
    A = 20, V = 21, N = 22, M = 23, ["!"] = 24,
  }

  local function mapFromRows(rows)
    assert(#rows == MAP_H, "Echoes Beyond the Fog map height mismatch")
    local blocks = {}
    for y, row in ipairs(rows) do
      assert(#row == MAP_W,
        ("Echoes Beyond the Fog map row %d has width %d, expected %d")
          :format(y, #row, MAP_W))
      for x = 1, #row do
        local ch = row:sub(x, x)
        local tile = TILE[ch]
        assert(tile ~= nil,
          ("Echoes Beyond the Fog unknown map symbol %q at %d,%d")
            :format(ch, x, y))
        blocks[#blocks + 1] = tile
      end
    end
    return blocks
  end

  local function registerTileset(id, filename)
    mod.content.tilesets:register(id, {
      id = id,
      image = mod.path .. "/assets/tilesets/" .. filename,
      imageWidth = 800, imageHeight = 32, tilesPerRow = CUSTOM_TILES_PER_ROW,
      blocks = allMetatileBlocks(),
      walkable = customWalkable(),
      waterTiles = {}, shoreTiles = {}, trueColor = true,
    })
  end

  registerTileset("CAPE_SIGNAL_TILES", "cape_signal_tiles.png")
  registerTileset("FOGBOUND_CAVERN_TILES", "fogbound_cavern_tiles.png")
  registerTileset("BLACK_TIDE_TILES", "black_tide_hideout_tiles.png")

  local OBS1_ROWS = {
      "##################",
      "#.H.H.Q....QBB...#",
      "#..L..Q.=..Q..!S.#",
      "#..!..Q.=..Q.N...#",
      "#.+++...=......M.#",
      "#QQQQ.Q.=..Q.QQQQ#",
      "#......l=l.......#",
      "#...AV..=....T.X.#",
      "#......l=l.....W.#",
      "#..============..#",
      "#..G!...=.,......#",
      "#.......=........#",
      "#.......S........#",
      "##################",
    }
  local OBS2_ROWS = {
      "##################",
      "#................#",
      "#.H.....=.....!S.#",
      "#..l....=....l...#",
      "#....QQQ=QQQ.....#",
      "#....QP.=.PQ..A..#",
      "#.......R........#",
      "#..B.QP.!.PQ.....#",
      "#....QQQ=QQQ..B..#",
      "#.......=........#",
      "#.==============.#",
      "#.S!....=........#",
      "#................#",
      "##################",
    }
  local OBS3_ROWS = {
      "##################",
      "#................#",
      "#..T....=.....!D.#",
      "#....QQQ=QQQ.....#",
      "#....Q..=..Q.C...#",
      "#..H...lOl...!...#",
      "#....Q..O..Q.....#",
      "#....Q..=..Q..N..#",
      "#..M.QQQ=QQQ.....#",
      "#.......=........#",
      "#.==============.#",
      "#.S!....=........#",
      "#................#",
      "##################",
    }
  local CAV1_ROWS = {
      "##################",
      "#................#",
      "#...T.....T.H.!S.#",
      "#....WWWW.....=..#",
      "#....WWWB.....=..#",
      "#..l....===N===..#",
      "#.....V.=.....=..#",
      "#.......=.XXXX=..#",
      "#.......=.XXXX=..#",
      "#.G!.A..+...M.=..#",
      "#.==,========l==.#",
      "#.S!.............#",
      "#................#",
      "##################",
    }
  local CAV2_ROWS = {
      "##################",
      "#................#",
      "#.......=.....!S.#",
      "#..P.QQQ=QQQ.....#",
      "#....QT.L.TQ.....#",
      "#....Q..O..Q..N..#",
      "#.......R........#",
      "#....Ql.!.lQ.....#",
      "#..B.QQQ=QQQ.....#",
      "#.......=.....M..#",
      "#.==============.#",
      "#.S!....=........#",
      "#................#",
      "##################",
    }
  local CAV3_ROWS = {
      "##################",
      "#................#",
      "#.............!D.#",
      "#...T.WWWWWW..=..#",
      "#.....WWWWWW.l=..#",
      "#.....WWWWWW..=..#",
      "#....V======V.=..#",
      "#..B..WWWWWW..=..#",
      "#.....WWWWWW.N=..#",
      "#...C.........=..#",
      "#.===A====M====..#",
      "#.S!..........=..#",
      "#................#",
      "##################",
    }
  local HID1_ROWS = {
      "##################",
      "#................#",
      "#..M.B.N.B.A.B!S.#",
      "#....B...B...B=..#",
      "#.l..B...B...B=..#",
      "#.............D..#",
      "#..B.B.B.B.B.B=..#",
      "#....B...B...Bl..#",
      "#....B...B...B=..#",
      "#.G!..V...V...=..#",
      "#.====,=========.#",
      "#.S!.............#",
      "#................#",
      "##################",
    }
  local HID2_ROWS = {
      "##################",
      "#.....Q.....Q....#",
      "#.....Q.....Q.!S.#",
      "#..C..Q..R..Q..A.#",
      "#..!..Q..!..Q..!.#",
      "#................#",
      "#.TXT.Q.P.P.Q.TW.#",
      "#.....Q.....Q....#",
      "#.H...Q.N...Q.M..#",
      "#QQ.QQQQQ.QQQQQ.Q#",
      "#.=====+l=l=====.#",
      "#.S!.............#",
      "#................#",
      "##################",
    }
  local HID3_ROWS = {
      "##################",
      "#................#",
      "#....LQCQCQCQCQ..#",
      "#..A..Q......C...#",
      "#.....Q.OO...!...#",
      "#.......OO.......#",
      "#..P..Q.=........#",
      "#.....Q.=.....N..#",
      "#..M....=........#",
      "#.......=.....l..#",
      "#.==============.#",
      "#.S!.............#",
      "#................#",
      "##################",
    }

  local function registerFloor(id, label, index, tileset, rows, palette)
    mod.content.maps:register(id, {
      id = id, label = label, index = index, tileset = tileset,
      width = MAP_W, height = MAP_H, blocks = mapFromRows(rows),
      borderBlock = 1, warps = {}, signs = {}, objects = {}, connections = {},
      outdoor = false, palette = palette,
    })
  end

  registerFloor(OBSERVATORY_MAP, "CapeSignalObservatory", 1008,
    "CAPE_SIGNAL_TILES", OBS1_ROWS)
  registerFloor(OBSERVATORY_2F, "CapeSignalEngineRoom", 1009,
    "CAPE_SIGNAL_TILES", OBS2_ROWS)
  registerFloor(OBSERVATORY_3F, "CapeSignalBeaconDome", 1010,
    "CAPE_SIGNAL_TILES", OBS3_ROWS)
  registerFloor(CAVERN_MAP, "FogboundCaverns", 1011,
    "FOGBOUND_CAVERN_TILES", CAV1_ROWS)
  registerFloor(CAVERN_2F, "FogboundRelayDepths", 1012,
    "FOGBOUND_CAVERN_TILES", CAV2_ROWS)
  registerFloor(CAVERN_3F, "FogboundDockApproach", 1013,
    "FOGBOUND_CAVERN_TILES", CAV3_ROWS)
  registerFloor(HIDEOUT_MAP, "BlackTideWarehouse", 1014,
    "BLACK_TIDE_TILES", HID1_ROWS, "ROCKET")
  registerFloor(HIDEOUT_2F, "BlackTideResonanceLabs", 1015,
    "BLACK_TIDE_TILES", HID2_ROWS, "ROCKET")
  registerFloor(HIDEOUT_3F, "BlackTideControl", 1016,
    "BLACK_TIDE_TILES", HID3_ROWS, "ROCKET")

  local function warpRows(text, mapId, x, y, facing, yesLabel)
    return {
      { "show_text", text },
      { "choice", { yesLabel or "ENTER", "STAY" } },
      { "jump_if_false", "end" },
      { "fog:warp", mapId, x, y, facing or "up" },
    }
  end

  local function enterOnce(game, ow, key, rows)
    if not state(key, false) then
      setState(key, true)
      ow:queueScript(rows)
    end
    syncJournal(game)
  end

  local OBS1_EXIT = cellsForBlock(8, 12)
  local OBS1_LOG = cellsForBlock(3, 3)
  local OBS1_GUIDE = cellsForBlock(4, 10)
  local OBS1_UP = cellsForBlock(14, 2)

  local OBS2_DOWN = cellsForBlock(3, 11)
  local OBS2_ENGINE = cellsForBlock(8, 7)
  local OBS2_UP = cellsForBlock(14, 2)

  local OBS3_DOWN = cellsForBlock(3, 11)
  local OBS3_HORN = cellsForBlock(13, 5)
  local OBS3_GATE = cellsForBlock(14, 2)

  local CAV1_RETURN = cellsForBlock(3, 11)
  local CAV1_GUIDE = cellsForBlock(3, 9)
  local CAV1_DOWN = cellsForBlock(14, 2)

  local CAV2_UP = cellsForBlock(3, 11)
  local CAV2_RELAY = cellsForBlock(8, 7)
  local CAV2_DOWN = cellsForBlock(14, 2)

  local CAV3_UP = cellsForBlock(3, 11)
  local CAV3_GATE = cellsForBlock(14, 2)

  local HID1_RETURN = cellsForBlock(3, 11)
  local HID1_GUIDE = cellsForBlock(3, 9)
  local HID1_UP = cellsForBlock(14, 2)

  local HID2_DOWN = cellsForBlock(3, 11)
  local HID2_ANCHOR_A = cellsForBlock(3, 4)
  local HID2_ANCHOR_B = cellsForBlock(9, 4)
  local HID2_ANCHOR_C = cellsForBlock(15, 4)
  local HID2_UP = cellsForBlock(14, 2)

  local HID3_DOWN = cellsForBlock(3, 11)
  local HID3_BOSS = cellsForBlock(13, 4)

  mod.content.map_scripts:register(OBSERVATORY_MAP, {
    onEnter = function(game, ow)
      enterOnce(game, ow, "observatory_intro", {
        { "show_text", "CAPE SIGNAL OBSERVATORY\nThe old lighthouse is\nlarger than Bill described." },
        { "show_text", "YELLOW ! markers show\nthe exact interaction\ntile. Step onto them." },
        { "show_text", "FIRST OBJECTIVE:\nRead BILL'S FIELD LOG\nin the north-west study." },
      })
    end,
    onStep = function(game, ow, x, y)
      if sameCell(x, y, OBS1_GUIDE) then
        local text = state("log_read", false)
          and "ROUTE BOARD:\nThe engine room stair is\nin the north-east tower."
          or "ROUTE BOARD:\nThe marked desk in the\nnorth-west holds Bill's log."
        ow:queueScript({ { "show_text", text } })
        return true
      end
      if sameCell(x, y, OBS1_EXIT) then
        ow:queueScript({
          { "show_text", "Bill's transport platform\nreturns to the Sea Cottage." },
          { "choice", { "RETURN", "STAY" } },
          { "jump_if_false", "end" },
          { "fog:return" },
        })
        return true
      end
      if sameCell(x, y, OBS1_LOG) then
        if state("log_read", false) then
          ow:queueScript({ { "show_text",
            "BILL'S FIELD LOG remains\nopen on the final entry:\nTHE CALL WAS A GREETING." } })
        else
          ow:queueScript({
            { "show_text", "BILL'S FIELD LOG - ENTRY 27\nYears ago, a gigantic\nDRAGONITE came through fog." },
            { "show_text", "It followed the lighthouse\nbecause the horn sounded\nlike another of its kind." },
            { "show_text", "It did not attack.\nIt was alone, and it\nbelieved someone answered." },
            { "show_text", "TEAM ROCKET fired rockets.\nThe frightened DRAGONITE\nvanished before Bill replied." },
            { "show_text", "The original signal cylinder\nis missing. Scratches lead\ntoward the engine tower." },
            { "fog:set", "log_read", true },
            { "show_text", "NEXT OBJECTIVE:\nClimb north-east and restore\nthe lighthouse generator." },
          })
        end
        return true
      end
      if sameCell(x, y, OBS1_UP) then
        ow:queueScript(warpRows(
          "The marked stair climbs to\nthe lighthouse engine room.",
          OBSERVATORY_2F, 5, 22, "up", "CLIMB"))
        return true
      end
      return false
    end,
  })

  mod.content.map_scripts:register(OBSERVATORY_2F, {
    onEnter = function(game, ow)
      enterOnce(game, ow, "observatory_2_intro", {
        { "show_text", "ENGINE ROOM\nThe main dynamo is silent.\nOld impact damage scars it." },
        { "show_text", "A Rocket insignia is fused\nto one panel. Someone reused\nthe wreckage from that night." },
        { "show_text", "OBJECTIVE:\nUse the yellow ! at the\ncentral generator." },
      })
    end,
    onStep = function(game, ow, x, y)
      if sameCell(x, y, OBS2_DOWN) then
        ow:queueScript(warpRows(
          "The marked stair returns to\nthe observatory study.",
          OBSERVATORY_MAP, 31, 5, "down", "DESCEND"))
        return true
      end
      if sameCell(x, y, OBS2_ENGINE) then
        if not state("log_read", false) then
          ow:queueScript({ { "show_text",
            "The breaker labels make no\nsense without Bill's field log." } })
        elseif state("lens_fixed", false) then
          ow:queueScript({ { "show_text",
            "The generator now powers the\nlens and beacon horn above." } })
        else
          ow:queueScript({
            { "show_text", "BILL'S MAINTENANCE NOTE:\nRestore SEA, then LENS,\nthen HORN." },
            { "choice", { "SEA-LENS-HORN", "HORN-SEA-LENS" } },
            { "jump_if_false", "wrong" },
            { "show_text", "The final breaker closes.\nA MAGNETON nest erupts from\nthe damaged dynamo!" },
            { "start_battle", "wild", "MAGNETON", 44 },
            { "check_battle_result", "win", "caught" },
            { "jump_if_false", "end" },
            { "fog:set", "lens_fixed", true },
            { "show_text", "Power restored.\nA stolen transmission is\nbeing repeated from below." },
            { "show_text", "NEXT OBJECTIVE:\nClimb to the beacon dome\nand answer the sea call." },
            { "jump", "end" },
            { "label", "wrong" },
            { "show_text", "The dynamo overloads and\nresets. The correct order is\nSEA, LENS, then HORN." },
          })
        end
        return true
      end
      if sameCell(x, y, OBS2_UP) then
        ow:queueScript(warpRows(
          "The marked spiral stair rises\nto the beacon dome.",
          OBSERVATORY_3F, 5, 22, "up", "CLIMB"))
        return true
      end
      return false
    end,
  })

  mod.content.map_scripts:register(OBSERVATORY_3F, {
    onEnter = function(game, ow)
      enterOnce(game, ow, "observatory_3_intro", {
        { "show_text", "BEACON DOME\nThe repaired lens sweeps\nacross the fog." },
        { "show_text", "The horn console contains a\nsecond transmitter not built\nby Bill." },
        { "show_text", "OBJECTIVE:\nUse the yellow ! beside the\nhorn console in the east." },
      })
    end,
    onStep = function(game, ow, x, y)
      if sameCell(x, y, OBS3_DOWN) then
        ow:queueScript(warpRows(
          "The marked stair descends to\nthe engine room.",
          OBSERVATORY_2F, 31, 5, "down", "DESCEND"))
        return true
      end
      if sameCell(x, y, OBS3_HORN) then
        if not state("lens_fixed", false) then
          ow:queueScript({ { "show_text",
            "The beacon console has no power.\nRestore the engine room first." } })
        elseif state("horn_tuned", false) then
          ow:queueScript({ { "show_text",
            "The authentic LOW-HIGH-LOW call\ntravels beyond the cape." } })
        else
          ow:queueScript({
            { "show_text", "The console can broadcast\nBill's archived signal.\nChoose the remembered call." },
            { "choice", { "LOW-HIGH-LOW", "HIGH-LOW-HIGH" } },
            { "jump_if_false", "wrong" },
            { "fog:set", "horn_tuned", true },
            { "show_text", "A vast silhouette answers\nfrom far beyond the fog." },
            { "show_text", "A second, mechanical echo\nanswers from UNDER the cape.\nSomeone is baiting it." },
            { "show_text", "The cliff gate unlocks.\nFollow the marked gate into\nthe Fogbound Caverns." },
            { "jump", "end" },
            { "label", "wrong" },
            { "show_text", "The false call fades.\nBill's log recorded\nLOW-HIGH-LOW." },
          })
        end
        return true
      end
      if sameCell(x, y, OBS3_GATE) then
        if not state("horn_tuned", false) then
          ow:queueScript({ { "show_text",
            "The cliff gate remains sealed.\nThe authentic call must sound." } })
        else
          ow:queueScript(warpRows(
            "The marked cliff gate descends\ninto the Fogbound Caverns.",
            CAVERN_MAP, 5, 22, "up", "ENTER"))
        end
        return true
      end
      return false
    end,
  })

  mod.content.map_scripts:register(CAVERN_MAP, {
    onEnter = function(game, ow)
      enterOnce(game, ow, "cavern_intro", {
        { "show_text", "FOGBOUND CAVERNS\nMineral chambers amplify\nevery sound from the sea." },
        { "show_text", "Fresh cables follow the old\nbridges toward a relay deeper\nunder the cape." },
        { "show_text", "OBJECTIVE:\nFollow the open route to the\nmarked stair in the north-east." },
      })
    end,
    onStep = function(game, ow, x, y)
      if sameCell(x, y, CAV1_GUIDE) then
        ow:queueScript({ { "show_text",
          "CAVE MARKER:\nThe worked bridge and cyan\nfungus lead north-east." } })
        return true
      end
      if sameCell(x, y, CAV1_RETURN) then
        ow:queueScript(warpRows(
          "The marked stair climbs back to\nthe lighthouse beacon dome.",
          OBSERVATORY_3F, 31, 5, "down", "CLIMB"))
        return true
      end
      if sameCell(x, y, CAV1_DOWN) then
        ow:queueScript(warpRows(
          "The marked steps descend toward\nthe natural resonance relay.",
          CAVERN_2F, 5, 22, "up", "DESCEND"))
        return true
      end
      return false
    end,
  })

  mod.content.map_scripts:register(CAVERN_2F, {
    onEnter = function(game, ow)
      enterOnce(game, ow, "cavern_2_intro", {
        { "show_text", "RELAY DEPTHS\nAn ancient stone chamber has\nbeen wired into modern gear." },
        { "show_text", "The rock itself repeats the\nDragonite call, but the rhythm\ncontains an older meaning." },
        { "show_text", "OBJECTIVE:\nUse the yellow ! at the\ncentral relay altar." },
      })
    end,
    onStep = function(game, ow, x, y)
      if sameCell(x, y, CAV2_UP) then
        ow:queueScript(warpRows(
          "The marked stair climbs to the\nupper caverns.",
          CAVERN_MAP, 31, 5, "down", "ASCEND"))
        return true
      end
      if sameCell(x, y, CAV2_RELAY) then
        if not state("relay_decoded", false) then
          ow:queueScript({
            { "show_text", "The relay separates the call\nfrom the machinery around it." },
            { "show_text", "It is not a roar or challenge.\nWhat did the giant Dragonite\nmean at Bill's lighthouse?" },
            { "choice", { "A GREETING", "A WARNING" } },
            { "jump_if_false", "wrong" },
            { "fog:set", "relay_decoded", true },
            { "show_text", "The stone answers softly.\nIt was searching for another\nvoice, not seeking a fight." },
            { "show_text", "BLACK TIDE SCOUT:\nStop touching the relay!\nCaptain Morrow needs that call!" },
            { "start_battle", "trainer", CLASS_SCOUT, 1 },
            { "check_battle_result", "win" },
            { "jump_if_false", "end" },
            { "fog:set", "scout_defeated", true },
            { "show_text", "The scout drops a MAG-KEY\nand a map of three RESONANCE\nANCHORS in the hidden base." },
            { "show_text", "NEXT OBJECTIVE:\nDescend north-east and follow\nthe dock route to Black Tide." },
            { "jump", "end" },
            { "label", "wrong" },
            { "show_text", "The chamber rejects the answer.\nBill's notes said the giant\ncame because it felt alone." },
          })
        elseif not state("scout_defeated", false) then
          ow:queueScript({
            { "show_text", "The decoded relay is a greeting.\nThe Black Tide scout attacks!" },
            { "start_battle", "trainer", CLASS_SCOUT, 1 },
            { "check_battle_result", "win" },
            { "jump_if_false", "end" },
            { "fog:set", "scout_defeated", true },
            { "show_text", "The scout drops a MAG-KEY\nand a map of three anchors." },
          })
        else
          ow:queueScript({ { "show_text",
            "The relay repeats one meaning:\nI AM HERE. ARE YOU THERE?" } })
        end
        return true
      end
      if sameCell(x, y, CAV2_DOWN) then
        if not state("scout_defeated", false) then
          ow:queueScript({ { "show_text",
            "The lower route is locked by a\nBlack Tide magnetic seal.\nThe scout carries its key." } })
        else
          ow:queueScript(warpRows(
            "The MAG-KEY opens the marked\nroute to the dock approach.",
            CAVERN_3F, 5, 22, "up", "DESCEND"))
        end
        return true
      end
      return false
    end,
  })

  mod.content.map_scripts:register(CAVERN_3F, {
    onEnter = function(game, ow)
      enterOnce(game, ow, "cavern_3_intro", {
        { "show_text", "DOCK APPROACH\nBlack Tide built a freight\nroute through a flooded cave." },
        { "show_text", "The stolen signal travels into\na reinforced gate in the\nnorth-east wall." },
        { "show_text", "OBJECTIVE:\nCross the bridge and use the\nyellow ! beside the gate." },
      })
    end,
    onStep = function(game, ow, x, y)
      if sameCell(x, y, CAV3_UP) then
        ow:queueScript(warpRows(
          "The marked stair climbs to the\nrelay depths.",
          CAVERN_2F, 31, 5, "down", "ASCEND"))
        return true
      end
      if sameCell(x, y, CAV3_GATE) then
        if not state("scout_defeated", false) then
          ow:queueScript({ { "show_text",
            "The reinforced gate requires the\nBlack Tide MAG-KEY." } })
        else
          ow:queueScript(warpRows(
            "The MAG-KEY opens the hidden\nBlack Tide warehouse.",
            HIDEOUT_MAP, 5, 22, "up", "ENTER"))
        end
        return true
      end
      return false
    end,
  })

  mod.content.map_scripts:register(HIDEOUT_MAP, {
    onEnter = function(game, ow)
      enterOnce(game, ow, "hideout_intro", {
        { "show_text", "BLACK TIDE WAREHOUSE\nRocket wreckage, capture nets\nand stolen research fill it." },
        { "show_text", "The group rebuilt the original\nattack into a trap for the\nsame giant Dragonite." },
        { "show_text", "OBJECTIVE:\nTake the marked lift in the\nnorth-east to the labs." },
      })
    end,
    onStep = function(game, ow, x, y)
      if sameCell(x, y, HID1_GUIDE) then
        ow:queueScript({ { "show_text",
          "SECURITY DIRECTORY:\nWAREHOUSE -> RESONANCE LABS\n-> CONTROL DECK." } })
        return true
      end
      if sameCell(x, y, HID1_RETURN) then
        ow:queueScript(warpRows(
          "The marked freight route returns\nto the dock caverns.",
          CAVERN_3F, 31, 5, "down", "RETURN"))
        return true
      end
      if sameCell(x, y, HID1_UP) then
        ow:queueScript(warpRows(
          "The marked service lift rises to\nthe resonance laboratories.",
          HIDEOUT_2F, 5, 22, "up", "ASCEND"))
        return true
      end
      return false
    end,
  })

  local function queueAnchor(ow, key, label)
    if state(key, false) then
      ow:queueScript({ { "show_text", label .. "\nis already OFFLINE." } })
      return
    end
    ow:queueScript({
      { "show_text", label .. "\nThis anchor is broadcasting\nBill's stolen Dragonite call." },
      { "choice", { "SHUT DOWN", "LEAVE" } },
      { "jump_if_false", "end" },
      { "fog:set", key, true },
      { "show_text", label .. "\nOFFLINE. The artificial call\nloses part of its strength." },
    })
  end

  mod.content.map_scripts:register(HIDEOUT_2F, {
    onEnter = function(game, ow)
      enterOnce(game, ow, "hideout_2_intro", {
        { "show_text", "RESONANCE LABS\nThree anchor consoles are\ntriangulating the sea signal." },
        { "show_text", "Each anchor has its own yellow\n! marker. Disable all three\nto unlock the control deck." },
      })
    end,
    onStep = function(game, ow, x, y)
      if sameCell(x, y, HID2_DOWN) then
        ow:queueScript(warpRows(
          "The marked lift descends to the\nwarehouse.",
          HIDEOUT_MAP, 31, 5, "down", "DESCEND"))
        return true
      end
      if sameCell(x, y, HID2_ANCHOR_A) then
        queueAnchor(ow, "anchor_a", "ANCHOR A - CALL ARCHIVE")
        return true
      end
      if sameCell(x, y, HID2_ANCHOR_B) then
        queueAnchor(ow, "anchor_b", "ANCHOR B - SEA AMPLIFIER")
        return true
      end
      if sameCell(x, y, HID2_ANCHOR_C) then
        queueAnchor(ow, "anchor_c", "ANCHOR C - CAPTURE BEACON")
        return true
      end
      if sameCell(x, y, HID2_UP) then
        if not anchorsDisabled() then
          ow:queueScript({ { "show_text",
            ("CONTROL DECK LOCKED\nANCHORS OFFLINE: %d/3\nFind every yellow ! marker.")
              :format(anchorCount()) } })
        else
          ow:queueScript(warpRows(
            "All three anchors are offline.\nThe control stair unlocks.",
            HIDEOUT_3F, 5, 22, "up", "ASCEND"))
        end
        return true
      end
      return false
    end,
  })

  mod.content.map_scripts:register(HIDEOUT_3F, {
    onEnter = function(game, ow)
      enterOnce(game, ow, "hideout_3_intro", {
        { "show_text", "CONTROL DECK\nThe false call is weakening,\nbut one transmitter remains." },
        { "show_text", "A giant silhouette is already\nmoving through the fog toward\nthe cape." },
        { "show_text", "OBJECTIVE:\nUse the yellow ! at Captain\nMorrow's eastern console." },
      })
    end,
    onStep = function(game, ow, x, y)
      if sameCell(x, y, HID3_DOWN) then
        ow:queueScript(warpRows(
          "The marked stair descends to the\nresonance labs.",
          HIDEOUT_2F, 31, 5, "down", "DESCEND"))
        return true
      end
      if sameCell(x, y, HID3_BOSS) then
        if not anchorsDisabled() then
          ow:queueScript({ { "show_text",
            "The final console is shielded.\nDisable all three resonance\nanchors in the labs." } })
        elseif not state("boss_defeated", false) then
          ow:queueScript({
            { "show_text", "CAPTAIN MORROW:\nBill let the greatest discovery\nin history disappear." },
            { "show_text", "MORROW:\nTeam Rocket failed because they\nused fear. I perfected the call." },
            { "show_text", "MORROW:\nWhen the giant reaches shore,\nBlack Tide will own the last\nwonder of the Kanto sea!" },
            { "start_battle", "trainer", CLASS_CAPTAIN, 1 },
            { "check_battle_result", "win" },
            { "jump_if_false", "end" },
            { "fog:set", "boss_defeated", true },
            { "show_text", "The final transmitter breaks.\nThe artificial call falls silent." },
            { "show_text", "Beyond the windows, the giant\nDRAGONITE answers Bill's real\nhorn once from inside the fog." },
            { "show_text", "No net closes around it.\nIt turns toward the open sea\nand remains a mystery." },
            { "show_text", "A normal DRAGONITE held in a\nlab tank breaks free and follows\nthe transport signal to Bill." },
            { "show_text", "Return to the Sea Cottage." },
            { "fog:return" },
          })
        else
          ow:queueScript({ { "show_text",
            "The screens show an empty sea.\nThe giant Dragonite is free.\nReturn to Bill." } })
        end
        return true
      end
      return false
    end,
  })

  -- Bill's post-event conversation is a single-winner talk handler.  The
  -- quest owns it only while it has something to offer or advance; every
  -- other branch explicitly hands control back to the complete vanilla
  -- conversation through MapScripts.baseTalk.
  mod.content.commands:register("fog:base_bill_chat", {
    foreground = true,
    fn = function(ctx, talkId)
      local base = MapScripts.baseTalk(BILL_MAP, talkId or BILL_TALK_POST)
      if not base then return end
      local runner = ctx.runner
      base(ctx.game, ctx.overworld, ctx.npc, function()
        runner:resume()
      end)
      runner:yield()
    end,
  })

  mod.content.commands:register("fog:reset_replay", function(ctx)
    -- Reset only quest progression.  The original reward flag is preserved
    -- so replaying the story cannot duplicate the perfect DRAGONITE.
    for _, key in ipairs({
      "done", "boss_defeated", "scout_defeated", "relay_decoded",
      "anchor_a", "anchor_b", "anchor_c", "horn_tuned",
      "lens_fixed", "log_read", "entered", "observatory_intro",
      "cavern_intro", "hideout_intro", "return_point",
      "observatory_2_intro", "observatory_3_intro",
      "cavern_2_intro", "cavern_3_intro",
      "hideout_2_intro", "hideout_3_intro",
    }) do
      setState(key, false)
    end
    setState("replay_offer_seen_v122", true)
    setState("replay_active", true)
    setState("started", true)
    setState("replay_count", state("replay_count", 0) + 1)
    syncJournal(ctx and ctx.game)
    if ctx and ctx.game and ctx.game.writeSave then ctx.game:writeSave() end
    ctx.lastCheck = true
  end)

  mod.content.commands:register("fog:available", function(ctx)
    ctx.lastCheck = available(ctx and ctx.game) and true or false
  end)

  mod.content.commands:register("fog:completed", function(ctx)
    ctx.lastCheck = completed(ctx and ctx.game) and true or false
  end)

  local function billQuestTalk(talkId)
    return {
      { "fog:completed" },
      { "jump_if_true", "replay" },

      { "fog:check", "boss_defeated" },
      { "jump_if_true", "turnin" },

      { "fog:check", "started" },
      { "jump_if_true", "resume" },

      { "fog:available" },
      { "jump_if_false", "vanilla" },

      { "show_text", "BILL: Years ago, a\ngigantic DRAGONITE\nanswered my lighthouse." },
      { "show_text", "It thought the horn\nwas another of its kind\ncalling through the fog." },
      { "show_text", "TEAM ROCKET attacked it.\nThe Dragonite escaped,\nand the mystery remained." },
      { "show_text", "Tonight the same call\nreturned from BELOW\nthe abandoned lighthouse." },
      { "show_text", "Will you investigate\nCape Signal Observatory?" },
      { "choice", { "HELP BILL", "NOT YET" } },
      { "jump_if_false", "decline" },
      { "fog:set", "started", true },
      { "show_text", "BILL: The tunnel\nstill works.\fFollow it to the\nbeacon." },
      { "fog:enter" },
      { "jump", "end" },

      { "label", "decline" },
      { "show_text", "BILL: I will keep\nthe receiver on.\fReturn when ready." },
      { "jump", "end" },

      { "label", "resume" },
      { "show_text", "BILL: The voice\nstill calls from\nthe fog." },
      { "show_text", "Return to the Cape\nObservatory?" },
      { "choice", { "GO NOW", "NOT YET" } },
      { "jump_if_false", "end" },
      { "fog:enter" },
      { "jump", "end" },

      { "label", "turnin" },
      { "show_text", "BILL: I saw the giant\nthrough the restored\nlighthouse camera." },
      { "show_text", "It answered once, then\nreturned to the open sea.\nNo cage closed around it." },
      { "show_text", "That is what I failed to\nunderstand years ago:\ndiscovery is not ownership." },
      { "show_text", "The DRAGONITE rescued\nfrom Black Tide refuses\nto leave the transport room." },
      { "show_text", "It chose the Trainer who\nstopped the false call." },
      { "fog:claim_reward" },
      { "show_text", "{FOG_REWARD_RESULT}" },
      { "jump_if_false", "pending" },
      { "show_text", "BILL: Treat it as a\ncompanion, never as\na specimen." },
      { "jump", "end" },

      { "label", "pending" },
      { "show_text", "Make room and\nreturn.\fDRAGONITE will\nwait here safely." },
      { "jump", "end" },

      { "label", "replay" },
      { "show_text", "BILL: The cape is\nquiet now, but the\nold route still works." },
      { "show_text", "Would you like to\nrevisit the entire\nincident from the start?" },
      { "choice", { "REPLAY QUEST", "NOT NOW" } },
      { "jump_if_false", "vanilla" },
      { "fog:reset_replay" },
      { "show_text", "BILL: The archive, relays\nand resonance anchors\nhave been reset.\fYour DRAGONITE stays\nwith you. No duplicate\nreward is awarded." },
      { "fog:enter" },
      { "jump", "end" },

      { "label", "vanilla" },
      { "fog:base_bill_chat", talkId },
    }
  end

  mod.content.map_scripts:register(BILL_MAP, {
    -- The one-time entry prompt is a recovery path for completed saves whose
    -- Bill object toggle points at a different human Bill dialogue. Talking
    -- to either human Bill remains the normal replay entry point.
    onEnter = function(game, ow)
      syncJournal(game)
      if completed(game) and not state("replay_offer_seen_v122", false) then
        setState("replay_offer_seen_v122", true)
        ow:queueScript({
          { "show_text", "BILL: I preserved the\nCape Signal archive.\fThe complete incident\ncan be reconstructed." },
          { "show_text", "Replay ECHOES BEYOND\nTHE FOG from the start?" },
          { "choice", { "REPLAY QUEST", "NOT NOW" } },
          { "jump_if_false", "end" },
          { "fog:reset_replay" },
          { "show_text", "All three quest areas\nhave been reset.\fYour original DRAGONITE\nand reward remain safe." },
          { "fog:enter" },
        })
      end
    end,

    talk = {
      [BILL_TALK_POST] = billQuestTalk(BILL_TALK_POST),
      [BILL_TALK_TICKET] = billQuestTalk(BILL_TALK_TICKET),
    },
  })

  mod.events:on("game.ready", function(payload)
    local game = payload and payload.game or payload
    if game and game.save then syncJournal(game) end
  end)

  mod.exports = mod.exports or {}
  mod.exports.questId = QUEST_ID
  mod.exports.observatoryMap = OBSERVATORY_MAP
  mod.exports.observatoryFloors = { OBSERVATORY_MAP, OBSERVATORY_2F, OBSERVATORY_3F }
  mod.exports.cavernMap = CAVERN_MAP
  mod.exports.cavernFloors = { CAVERN_MAP, CAVERN_2F, CAVERN_3F }
  mod.exports.hideoutMap = HIDEOUT_MAP
  mod.exports.hideoutFloors = { HIDEOUT_MAP, HIDEOUT_2F, HIDEOUT_3F }
  mod.exports.reward = {
    species = "DRAGONITE",
    level = REWARD_LEVEL,
    dvs = 15,
    statExp = 65535,
  }
end
