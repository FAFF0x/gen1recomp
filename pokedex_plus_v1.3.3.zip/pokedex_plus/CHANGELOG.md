# Changelog

## 1.3.3

- Pokédex Plus now exposes each visible row's species id to Gen1 Modern UI.
- With Modern UI 0.8.4+, the live `pokemon.icon` image is shown beside each Pokémon name.
- NEW ICONS full-color animated descriptors are used directly; hidden `-----` rows do not reveal icons.


## 1.3.2

- Added official Gen1 Modern UI compatibility using `gen1ModernUi` API v1.
- Added responsive Modern UI models for the main Pokédex+ list, STATS, HABITAT and name-search screens.
- Added source-owned semantic pointer actions for search, habitat navigation, page changes and back/selection behavior.
- Gen1 Modern UI 0.8.1+ is now an optional dependency; native Pokédex Plus rendering remains the fallback.
- Existing saves and the 95C regional-style numbering support are unchanged.

## 1.3.1

- Added generic regional/variant Pokédex-number support for modded species.
- New optional Pokémon metadata: `dexDisplay`, `dexVariant`, and `dexVariantOrder`.
- Variants sharing a display number are sorted directly beneath their base species without assigning duplicate internal numeric dex IDs.
- Main and search lists now render suffix numbers such as **95C**.
- The DATA page renders the same variant number, for example **No.95C**.
- Exported `getDexRows` and `formatDexNumber` for integrations and tests.

## 1.3.0

- Added a START-button search menu to the main Pokédex list.
- Added partial-name search with an on-screen keyboard.
- Added dynamic filtering by Pokémon type, including dual types.
- Search results preserve caught indicators and open the normal Pokédex Plus details.
- Search respects the REVEAL UNSEEN DATA option.

## 1.2.0

- Replaced the STATS text box with a dedicated static screen.
- All base-stat information is visible at once with no scrolling or page changes.
- Rebuilt HABITAT as a dedicated three-entry paged screen.
- Area name, encounter method, chance and level range now use separate lines.
- Long habitat text is safely truncated instead of overlapping other fields.
- START opens the species area map directly from HABITAT.

## 1.1.0

- Removed the COLLECTION tab.
- Reduced the main-list status display to caught only.
- Added automatic party and PC Box caught-status scanning.
- Added the STATS tab with base stats and total.
- Moved evolution methods to separate detail pages to prevent overlap.

## 1.0.0

- Initial release.
