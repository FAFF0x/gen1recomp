# Changelog

## 1.0.0

- Added the complete Whispers Beneath Cerulean quest.
- Added Cascade Badge activation and Quest System journal integration.
- Added a custom drainage-channel dungeon beneath Cerulean City.
- Added three water-control valve objectives.
- Added contaminated Poliwag, Goldeen, Psyduck and Seaking encounters.
- Added a guaranteed shiny Staryu reward at level 20.
