-- Compatibility fragment for Dramaless Shape 1.6.4.
--
-- Dramaless is based on the older 1.6-era renderer and intentionally omits
-- Dramatic Shape's later ForestAtmos module. Kanto Dynamic Weather only used
-- two parts of it: a monotonically increasing atmospheric clock and a small
-- day/night colour ramp. Recreate those two inputs locally; no Dramaless files
-- are modified and no legacy ForestAtmos geometry is redistributed.
local W = ...
local DayNight = W.require("DayNight")

local F = { time = 0 }

local BASE_FOG = { 0.78, 0.86, 0.76 }
local BASE_RAY = { 1.00, 0.93, 0.72 }

local function phase(name)
  local t = (DayNight.TINTS and DayNight.TINTS[name]) or { 255, 255, 255 }
  local k = { (t[1] or 255) / 255, (t[2] or 255) / 255, (t[3] or 255) / 255 }
  return {
    fog = { BASE_FOG[1] * k[1], BASE_FOG[2] * k[2], BASE_FOG[3] * k[3] },
    ray = { BASE_RAY[1] * k[1], BASE_RAY[2] * k[2], BASE_RAY[3] * k[3] },
  }
end

F.RAMP = {
  day = phase("day"),
  golden = phase("golden"),
  dawn = phase("dawn"),
  dusk = phase("dusk"),
  violet = phase("violet"),
  night = phase("night"),
}

function F.update(dt)
  F.time = F.time + math.max(0, tonumber(dt) or 0)
end

return F
