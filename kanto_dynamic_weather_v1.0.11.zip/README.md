# Kanto Dynamic Weather

A dynamic 3D weather and atmosphere add-on for **Pokémon Gen1Recomp** and **Dramaless Shape**.

Kanto Dynamic Weather turns Dramaless Shape's voxel overworld into a living weather system: world-space cloud fields, rolling fog, volumetric-looking sunlight, rain and thunderstorms, persistent puddles, atmospheric particles, upgraded celestial rendering, and a distant horizon that makes the map feel like part of a larger world.

**Author:** Campo (`1-Camp0-1`)

## Requirements

- Pokémon Gen1Recomp compatible with mod API 2 (`>=0.1.37 <2.0.0`; the development version is also accepted by the manifest)
- **Dramaless Shape 1.6.4**
- VOXEL rendering enabled in Dramaless Shape

The installable ZIP does **not** contain Dramaless Shape. The mod declares `DRAMALESS_SHAPE@>=1.6.4 <1.6.5` as a hard dependency, so Gen1Recomp loads Dramaless Shape first and blocks this add-on cleanly when the dependency is absent or outside the source-verified version.

## Installation

1. Install and enable Dramaless Shape 1.6.4.
2. Download `kanto_dynamic_weather-1.0.11.zip` from Releases.
3. Install the ZIP through Gen1Recomp's mod manager.
4. Enable **Kanto Dynamic Weather**.
5. Use a Dramaless Shape **VOXEL** camera mode.

Do not replace the Dramaless Shape ZIP with this add-on. They are separate mods and should both remain installed.

## Weather presets

The OPTIONS menu adds:

- **DYNAMIC** — automatic branching weather simulation; new sessions begin at **MOSTLY CLOUDY**
- **CLEAR**
- **PARTLY CLOUDY** — the calibrated ~25% cloud-cover reference
- **MOSTLY CLOUDY** — ~75% apparent coverage
- **CLOUDY** — ~90–95% broken cover
- **OVERCAST** — closed 100% cloud ceiling
- **RAINING**
- **THUNDERSTORM**

Dynamic weather does not simply march up and down one severity ladder. Cloud cover evolves through Clear / Partly / Mostly / Cloudy / Overcast, while rain can branch from Cloudy or Overcast, intensify into a Thunderstorm, or clear back toward Cloudy/Overcast.

### Weather speed

- **SLOW** — long-lived weather systems
- **NORMAL** — intended gameplay pacing
- **FAST** — approximately half-length systems
- **VERY FAST** — testing mode; each recognisable state holds for about two minutes before a short transition

## Atmosphere controls

- **ATMOSPHERE:** FULL / LOW / OFF — defaults to **FULL on Android/iOS** and **LOW on desktop**
- **LIGHT INTENSITY:** 1–10 (default 5)
- **PARTICLE DENSITY:** 1–10 (default 6)
- **PARTICLE SCALE:** 1–10 (default 8)

Rain calibration is authored by preset rather than exposed as extra sliders:

- Raining: size 3 / density 4
- Thunderstorm: size 3 / density 6, with faster fall and stronger wind

Ambient spores/motes are suppressed completely while Raining or Thunderstorm is active.

## Features

### 3D clouds and lighting

Cloud formations occupy real world-space depth rather than a screen overlay. Near, middle and distant formations provide parallax, move with a persistent wind field, and attenuate Dramaless Shape's volumetric light shafts. Dense cloud cores can heavily suppress direct beams while gaps allow sunlight through.

### Fog

Ground fog is depth-tested world geometry with moving density, rolling crests and aspect-ratio compensation so portrait and landscape do not represent different weather intensities.

### Rain and thunderstorms

Rain drops are real 3D streaks distributed through the voxel scene. Buildings, trees and terrain can occlude them naturally. Thunderstorms increase density, speed and wind and add irregular atmospheric lightning flashes that illuminate sky, clouds, fog, rain and terrain together.

### Persistent puddles

Rain forms stylised world-space puddles. They remain at full size immediately after rain and shrink on subsequent dry weather transitions until they evaporate. New rain refills them. Character reflections conceptually exist beneath the map and puddles act as masks that reveal the reflected sprite, avoiding touch-triggered reflection popping.

### Sun, moon and distant world

The original pixel celestial discs are replaced by smoother atmospheric bodies tied to the same day/night lighting direction. A low-detail continuation world, forest belts, foothills and mountain ridges extend beyond the loaded map so the sun and moon can visually set behind distant terrain instead of an empty blue void.

## Dramaless Shape compatibility

Version 1.0.11 is a dedicated port for **Dramaless Shape 1.6.4**. Dramaless still exports the library namespace Kanto Dynamic Weather needs, but its renderer is based on the earlier 1.6.1-era code and intentionally omits the later Forest/Fog FX path. The bridge therefore restores only the interfaces Kanto Dynamic Weather needs, using independent KDW code rather than bundling or overwriting Dramaless source.

Three Dramaless renderer modules receive small **in-memory** patches while the game starts:

- `Sky.lua`
- `Voxel3D.lua`
- `VoxelScene.lua`

Those patches restore KDW's weather sky blending, lightning illumination, distance haze input, moving cloud shadows, puddle masks, HD sun/moon glow, distant Kanto and horizon-apron draw hooks. A local compatibility clock/colour ramp replaces the missing atmospheric timing interface. Dramaless files are never changed on disk.

The dependency is intentionally pinned to `>=1.6.4 <1.6.5`, and the bridge is source-anchored to the exact 1.6.4 renderer supplied for this port. If a later Dramaless release moves a required integration point, KDW fails closed with an explicit compatibility error rather than silently drawing the weather incorrectly.

### Visual parity with KDW 1.0.10

The actual Kanto Dynamic Weather presentation modules and audio assets are carried over unchanged from 1.0.10: weather tuning, clouds, shafts, rolling fog geometry, rain, puddles, ripples, walking water particles, lightning, thunder, celestial presentation and distant-world code all retain their 1.0.10 values. The adapter reconstructs the missing host-renderer fog/cloud-shadow hooks so those systems receive the same KDW inputs on Dramaless.

Dramaless itself is not byte-for-byte the old Dramatic Shape 1.8.1 renderer, so the underlying voxel world's own rendering changes cannot be made pixel-identical by a companion mod. The goal of this port is **Kanto Dynamic Weather visual parity** on top of Dramaless, without reintroducing the removed upstream subsystem.

## Performance

The system was designed around Android constraints:

- fog, clouds, motes and rain use ordinary depth-tested geometry rather than requiring a readable scene-depth texture;
- cloud/light interaction reuses Dramaless Shape's existing shadow information;
- distant scenery is deliberately low-detail;
- **ATMOSPHERE LOW** reduces atmospheric volume cost while retaining the complete weather model.

Performance still depends on device, viewport resolution, Dramaless Shape anti-aliasing and camera settings.

## Known limitations

- The compatibility bridge is source-verified against Dramaless Shape 1.6.4 only. A later Dramaless update requires a compatibility check before the dependency range is widened.
- Weather is a presentation system; it does not currently change Pokémon encounters, moves, damage or gameplay mechanics.
- The stylised puddle reflection system intentionally favours a Pokémon-like readable reflection over physically complete scene reflection.

## Development / release structure

The repository contains only this add-on's code and compatibility bridge. For a GitHub Release, package the mod files so `manifest.json` and `main.lua` are at the root of the installable ZIP (not inside an extra enclosing folder).

The release asset for this version is:

```text
kanto_dynamic_weather-1.0.11.zip
```

## Credits

- **Campo (`1-Camp0-1`)** — Kanto Dynamic Weather design and project owner
- **Stahltier / Dramaless Shape contributors** — Dramaless Shape Voxel Mod, required dependency
- **DramaticShape** — original voxel renderer lineage on which Dramaless is based
- **Gen1Recomp contributors** — mod API and game runtime

Pokémon is a trademark of Nintendo / Creatures Inc. / GAME FREAK. This is an unofficial fan-made modification.


### Thunder audio
Lightning events in the THUNDERSTORM state trigger one of three rotating thunder-rumble SFX variants. Multi-pulse flicker is treated as one strike, and playback follows the game SFX volume setting.
