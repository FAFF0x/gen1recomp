# Compatibility

Kanto Dynamic Weather 1.0.11 is built specifically for **Dramaless Shape 1.6.4** (`DRAMALESS_SHAPE`).

The mod applies its renderer integration **in memory** through Dramaless Shape's exported `mod.exports.lib` namespace. Dramaless files are not replaced on disk.

## Visual-parity port

Dramaless Shape 1.6.4 is based on the older 1.6-era renderer and does not contain the later `ForestAtmos`/distance-fog path that Kanto Dynamic Weather 1.0.10 used under Dramatic Shape. The 1.0.11 bridge restores the KDW-facing pieces locally: distance haze, world-space cloud-shadow uniforms, puddle masks, atmospheric timing, weather sky/tint integration, HD celestial glow, and the distant-world/horizon-apron hooks.

The Kanto Dynamic Weather feature/tuning code itself is retained from 1.0.10.

The dependency is intentionally pinned to `>=1.6.4 <1.6.5`. A later Dramaless renderer should be source-checked before widening the range.
