-- Kanto Dynamic Weather
-- Standalone companion add-on for Dramaless Shape 1.6.4.
local mod = ...

local ds = mod.find and mod.find("DRAMALESS_SHAPE") or nil
if not ds then
  error("KANTO_DYNAMIC_WEATHER: Dramaless Shape 1.6.4 is required", 0)
end
if not (ds.exports and ds.exports.lib) then
  error("KANTO_DYNAMIC_WEATHER: installed Dramaless Shape does not expose mod.exports.lib", 0)
end

local baseV = ds.exports.lib
local W = { mod=mod, ds=ds, baseV=baseV, path=mod.path }
local own = {}

local function chunkFor(rel)
  local source = mod:read(rel)
  if not source then error("KANTO_DYNAMIC_WEATHER: missing " .. rel, 0) end
  local chunk, err = load(source, "@" .. mod.path .. "/" .. rel)
  if not chunk then error("KANTO_DYNAMIC_WEATHER: " .. rel .. " did not compile: " .. tostring(err), 0) end
  return chunk
end

local bridge
local compatBridge
function W.require(name)
  if own[name] ~= nil then return own[name] end
  if name == "CinematicAtmos" or name == "DistantWorld"
      or name == "HorizonApron" or name == "WeatherSetting"
      or name == "ForestAtmos" then
    own[name] = false
    local rel = (name == "ForestAtmos") and "lib/ForestAtmosCompat.lua" or ("lib/" .. name .. ".lua")
    local value = chunkFor(rel)(W)
    if value == nil then error("KANTO_DYNAMIC_WEATHER: " .. name .. " returned nil", 0) end
    own[name] = value
    return value
  end
  if name == "Voxel3D" or name == "VoxelScene" or name == "Sky" then
    if bridge and bridge[name] then return bridge[name] end
    if compatBridge then return compatBridge.requirePatched(name) end
  end
  return baseV.require(name)
end
W.data = baseV.data

compatBridge = chunkFor("compat/dramaless_shape_1_6.lua")(W)
bridge = compatBridge.load()

local CinematicAtmos = W.require("CinematicAtmos")

-- Thunder is a native file-backed SFX set, so it follows Gen1Recomp's SFX
-- volume control and audio cache rather than opening raw LOVE sources here.
local THUNDER_SFX = {
  "KDW_THUNDER_LOW_RUMBLE",
  "KDW_THUNDER_RUMBLE_HD",
  "KDW_THUNDER_RUMBLE",
}
local THUNDER_FILES = {
  "assets/audio/thunder_low_rumble.ogg",
  "assets/audio/thunder_rumble_hd.ogg",
  "assets/audio/thunder_rumble.ogg",
}
for i, id in ipairs(THUNDER_SFX) do
  mod.content.sfx:register(id, { file = mod.assets:path(THUNDER_FILES[i]) })
end

local Sound = require("src.core.Sound")
local Game = require("src.core.Game")
local thunderState = { lastFlash = 0, cooldown = 0, nextVariant = 1 }
local THUNDER_TRIGGER = 0.11
local THUNDER_EVENT_LOCK = 1.05

local function updateThunder(dt)
  thunderState.cooldown = math.max(0, thunderState.cooldown - (dt or 0))
  local flash = CinematicAtmos.lightningFlash() or 0
  if flash >= THUNDER_TRIGGER
      and thunderState.lastFlash < THUNDER_TRIGGER
      and thunderState.cooldown <= 0 then
    local id = THUNDER_SFX[thunderState.nextVariant]
    if Game and Game.data and id then pcall(Sound.play, Game.data, id) end
    thunderState.nextVariant = thunderState.nextVariant % #THUNDER_SFX + 1
    -- One authored lightning event can flicker two or three times in under a
    -- second. Treat that cluster as one strike, so a single rumble answers it.
    thunderState.cooldown = THUNDER_EVENT_LOCK
  end
  thunderState.lastFlash = flash
end
local Voxel3D = bridge.Voxel3D
local VoxelScene = bridge.VoxelScene
local AntiAlias = baseV.require("AntiAlias")
local VR = baseV.require("VR")

-- Anything inside Dramaless Shape that holds the VoxelScene TABLE (not a
-- copied function) now sees the weather-aware renderer too.  This particularly
-- keeps the VR eye path coherent without altering Dramaless Shape on disk.
local baseVoxelScene = baseV.require("VoxelScene")
local originalRender = baseVoxelScene.render
baseVoxelScene.render = VoxelScene.render

local pipelines = mod.content.render_pipelines
local basePipeline = pipelines:get("voxel")
if not basePipeline then
  error("KANTO_DYNAMIC_WEATHER: Dramaless Shape did not register the voxel pipeline", 0)
end
local baseUpdate = basePipeline.update
local baseInvalidate = basePipeline.invalidate
local ForestAtmos = W.require("ForestAtmos")

local function sceneSize(ctx)
  if love.graphics and love.graphics.getPixelDimensions then
    local pw, ph = love.graphics.getPixelDimensions()
    if pw and ph and pw > 0 and ph > 0 then return pw, ph end
  end
  return ctx.width, ctx.height
end

local function drawWorld(ctx)
  VR.paletteFor = ctx.paletteFor
  if VR.active() then
    local sw, sh = sceneSize(ctx)
    local mirror = VR.mirror(sw, sh)
    if mirror then return mirror end
  end

  local sw, sh = sceneSize(ctx)
  local rw, rh = AntiAlias.expand(sw, sh)
  local canvas = VoxelScene.render(ctx.state, rw, rh, ctx.vw, ctx.vh, ctx.paletteFor)
  if not canvas then return nil end
  if Voxel3D.beginOverlay() then
    ctx.drawFx(function(wx, wy) return Voxel3D.project(wx, 0, wy) end,
               ctx.scale * AntiAlias.factor())
    Voxel3D.endOverlay()
  end
  return AntiAlias.resolve(canvas, sw, sh, "world")
end

pipelines:patch("voxel", {
  update = function(dt, level)
    if baseUpdate then baseUpdate(dt, level) end
    ForestAtmos.update(dt)
    CinematicAtmos.update(dt)
    updateThunder(dt)
  end,
  drawWorld = drawWorld,
  invalidate = function()
    if baseInvalidate then baseInvalidate() end
    pcall(Voxel3D.invalidate)
    pcall(CinematicAtmos.invalidate)
    thunderState.lastFlash, thunderState.cooldown = 0, 0
  end,
})

local SETTINGS = {
  { CinematicAtmos.atmosphereSetting,
    "Global 3D atmosphere. FULL is the production look; LOW keeps the full weather model with fewer volumes; OFF disables the companion atmosphere." },
  { CinematicAtmos.weatherSetting,
    "DYNAMIC follows a branching weather graph. Manual CLEAR, PARTLY CLOUDY, MOSTLY CLOUDY, CLOUDY, OVERCAST, RAINING and THUNDERSTORM presets are also available." },
  { CinematicAtmos.weatherSpeedSetting,
    "Dynamic-weather pacing. NORMAL is intended for play; VERY FAST holds each state for two minutes for testing." },
  { CinematicAtmos.lightSetting,
    "Volumetric sunlight strength from 1 to 10. Level 5 is the calibrated reference." },
  { CinematicAtmos.particleDensitySetting,
    "Ambient mote density from 1 to 10. Rain and thunderstorms suppress these particles automatically." },
  { CinematicAtmos.particleScaleSetting,
    "Ambient mote scale from 1 to 10. The calibrated default is 8." },
}

local schema = {}
for _, entry in ipairs(SETTINGS) do
  schema[#schema + 1] = entry[1]:schema(entry[2])
end
mod.options:define(schema)

mod.hooks:wrap("ui.options.rows", function(next, game, rows)
  local out = next(game, rows)
  if type(out) ~= "table" then return out end
  for _, entry in ipairs(SETTINGS) do out[#out + 1] = entry[1]:row() end
  return out
end)

mod.events:on("mod.options_changed", function(payload)
  if not (payload and payload.mod == mod.id) then return end
  for _, entry in ipairs(SETTINGS) do
    if payload.key == entry[1].key then entry[1]:sync(payload.value) end
  end
end)

mod.events:on("map.reloaded", function()
  pcall(CinematicAtmos.invalidate)
end)

mod.exports.version = "1.0.11"
mod.exports.compatibility = {
  dramalessShape = tostring(ds.version or "unknown"),
  bridge = "dramaless-1.6.4",
  presentation = "KDW-1.0.10",
}
