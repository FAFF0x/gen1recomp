# Changelog

## 1.0.11

### Dramaless Shape 1.6.4 compatibility port
- Replaced the discontinued Dramatic Shape dependency with `DRAMALESS_SHAPE >=1.6.4 <1.6.5`.
- Added a dedicated in-memory bridge for Dramaless Shape 1.6.4; no Dramaless files are overwritten.
- Restored the later distance-fog/cloud-shadow shader inputs that v1.0.10 used but the Dramaless 1.6-era base does not contain.
- Preserved v1.0.10 weather tuning, clouds, light shafts, rolling fog, rain, puddles, rain ripples, water-particle splashes, lightning and synchronised thunder audio.
- Preserved the HD sun/moon and distant Kanto/horizon-apron presentation.
- Added a local atmospheric clock/colour compatibility shim because Dramaless 1.6.4 does not ship the later `ForestAtmos` module.
- Pinned this release to Dramaless Shape 1.6.4 so future renderer changes fail closed instead of silently changing the look.

## 1.0.10

### Thunder audio
- Added three user-supplied thunder recordings as native file-backed Gen1Recomp SFX.
- Every authored lightning event in THUNDERSTORM now triggers one thunder rumble.
- Multi-pulse lightning flicker is debounced as one strike, preventing duplicate thunder during the same flash cluster.
- Thunder rotates through the three variants and follows the game's SFX volume setting.
- Audio assets are packaged as OGG for reliable LÖVE/Gen1Recomp playback.
- Preserved Dramatic Shape 1.8.1 compatibility, rain ripples, puddles and water-particle walking splashes.

## 1.0.9

### Splash presentation revision
- Replaced the previous splash crown with a lighter water-particle burst effect.
- Footstep splashes now render as small 3D spray particles instead of flat decals or volumetric sheet crowns.
- Retained rain ripples in puddles and the existing wetness system.
- Preserved Dramatic Shape 1.8.1 compatibility.

## 1.0.8

### Splash presentation revision
- Replaced the flat puddle-splash decal with a world-space volumetric-style splash crown.
- Each step splash now renders as multiple intersecting 3D spray sheets plus a central jet, instead of a single ground billboard.
- Kept the rain ripple animation in puddles.
- Preserved Dramatic Shape 1.8.1 compatibility and the existing wetness/puddle systems.

## 1.0.7

### Wet-surface effects
- Added visible animated rain ripples across puddles while it is raining.
- Added walking splash decals when the player or NPCs move through puddles.
- Splash bursts inherit current wetness/rain strength so they read softly after rain and more actively during showers.
- Preserved Dramatic Shape 1.8.1 compatibility and existing puddle/reflection behaviour.

## 1.0.6

### Dramatic Shape 1.8.1 compatibility
- Expanded the declared Dramatic Shape range to `>=1.7.2 <1.8.2` after source-verifying the `v1.8.1` tag.
- Verified the 1.8.0 → 1.8.1 upstream diff: `Sky.lua` and `VoxelScene.lua` are unchanged.
- Verified the only relevant upstream file change, `Voxel3D.lua`, is limited to high-DPI depth/water canvas allocation in `newDepth()` and `beginWater()`.
- Those changes do not overlap Kanto Dynamic Weather's shader, fog, puddle-mask or horizon integration anchors, so the existing semantic 1.8.0 bridge remains valid for 1.8.1.
- Updated compatibility diagnostics and exported bridge metadata to report 1.8.1 support.

## 1.0.5

### Dramatic Shape 1.8.0 compatibility
- Expanded the declared Dramatic Shape range to `>=1.7.2 <1.8.1` after source-verifying 1.8.0.
- Added a semantic shader insertion for the new 1.8.0 firefly declarations around the `vFog` patch boundary.
- Added a semantic `puddleMask()` insertion that coexists with 1.8.0's new `Voxel3D.grassWind()` API.
- Preserves Dramatic Shape's 1.8.0 firefly and grass-wind code rather than replacing either block.
- Sky, VoxelScene, world-disc, fog and scene-lighting integration anchors remain compatible with 1.8.0.

## 1.0.4
- Fixed the horizon/land continuation apron showing through transparent water tiles as solid green terrain.
- Replaced the oversized neighbourhood bounding-box clip with exact per-map rectangles, so the continuation conforms to irregular loaded map edges instead of leaving empty corner gaps.
- Tightened the terrain join with finer edge tessellation and a near-zero edge offset while retaining the same globe curvature beyond the map.
- New-install ATMOSPHERE default is now **FULL on Android/iOS** and **LOW on desktop**. Existing saved user choices are preserved.
- WEATHER remains **DYNAMIC** by default, with a fresh dynamic session now starting at **MOSTLY CLOUDY** before following the normal branching weather graph.
- Cloud, fog, rain, lightning and Dramatic Shape 1.7.2 bridge behaviour are otherwise unchanged.

## 1.0.3
- Fixed Dramatic Shape 1.7.2 Voxel3D compatibility check failing at hunk 10.
- Fog/cloud-shadow integration now uses a minimal stable anchor instead of depending on 1.7.0 viewport comments.
- Compatibility bridge now accepts already-applied hunks and includes a semantic Voxel3D fog fallback for compatible 1.7.x builds.
- No weather visuals or tuning changed from 1.0.2.
- Added public GitHub repository metadata for `1-Camp0-1/Kanto-Dynamic-Weather` and cleaned release documentation.

## 1.0.2 - Pre-repository import hotfix

- Removed the optional manifest `github` field from the installable build until the public repository exists.
- Retains Dramatic Shape 1.7.2+ / 1.7.x dependency and compatibility bridge from 1.0.1.

All notable changes to Kanto Dynamic Weather are documented here.

## 1.0.1 — 2026-08-08

### Dramatic Shape 1.7.2 compatibility
- Raised the tested dependency baseline to Dramatic Shape 1.7.2.
- Updated the VoxelScene compatibility anchor for Dramatic Shape 1.7.2's `ViewBox.stop()` cleanup path.
- Preserves the 1.7.2 render-distance / viewport cleanup while clearing Kanto Dynamic Weather's temporary renderer state.
- Retains fail-closed compatibility checking for later 1.7.x releases.

## 1.0.0 — 2026-08-08

### Production split
- Separated the weather system from the modified Dramatic Shape development build.
- New permanent mod ID: `kanto_dynamic_weather`.
- Declared Dramatic Shape `>=1.7.0 <1.8.0` as a required dependency.
- Added a fail-closed 1.7.x compatibility bridge using Dramatic Shape's exported library namespace.
- Dramatic Shape is no longer bundled or modified on disk.

### Weather
- Branching Dynamic weather simulation.
- Clear, Partly Cloudy, Mostly Cloudy, Cloudy, Overcast, Raining and Thunderstorm presets.
- Slow, Normal, Fast and Very Fast transition speeds.
- Smooth cloud, sky, fog, light and precipitation interpolation.
- Rain and Thunderstorm suppress ambient atmospheric spores.

### Atmosphere
- Android-safe world-space rolling fog.
- Depth-tested atmospheric motes with Density and Scale controls.
- Broad volumetric-looking sunlight with Light Intensity 1–10.
- World-space volumetric-style clouds with parallax and weather-dependent coverage.
- Clouds attenuate sunlight shafts and cast moving atmospheric shadowing.

### Rain / storms
- 3D rain particles with authored Raining and Thunderstorm calibrations.
- Fixed monotonic rain animation during weather-speed transitions.
- Irregular atmospheric lightning bursts for thunderstorms.

### Wet weather
- Persistent stylised puddles during/after rain.
- Puddles shrink over successive dry weather transitions and refill when rain returns.
- Continuous under-map character reflections revealed by puddle masks.

### World presentation
- Smooth sun/moon rendering integrated with the lighting direction.
- Procedural distant forests, hills and mountain ridges.
- Curved continuation terrain hides the hard edge/underside of loaded maps.
