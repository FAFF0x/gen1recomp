-- Kanto Dynamic Weather compatibility bridge for Dramaless Shape 1.6.4.
-- Applies three small renderer patches in memory; Dramaless remains untouched.
local W = ...
local mod, baseV = W.mod, W.baseV
local Bridge = {}

local function normalise(text)
  text = tostring(text or "")
  text = text:gsub("^\239\187\191", "")
  return text:gsub("\r\n", "\n"):gsub("\r", "\n")
end

local function linesOf(text)
  text = normalise(text)
  if text:sub(-1) ~= "\n" then text = text .. "\n" end
  local out = {}
  for line in text:gmatch("(.-)\n") do out[#out + 1] = line end
  return out
end

local function blockMatches(lines, at, block)
  if at < 1 or at + #block - 1 > #lines then return false end
  for i = 1, #block do if lines[at + i - 1] ~= block[i] then return false end end
  return true
end

local function findBlock(lines, block, hint)
  if #block == 0 then return math.max(1, math.min(#lines + 1, hint or 1)) end
  hint = math.max(1, math.min(#lines, hint or 1))
  if blockMatches(lines, hint, block) then return hint end
  for radius = 1, 220 do
    local a, b = hint - radius, hint + radius
    if blockMatches(lines, a, block) then return a end
    if blockMatches(lines, b, block) then return b end
  end
  for i = 1, #lines - #block + 1 do if blockMatches(lines, i, block) then return i end end
  return nil
end

local function parsePatch(patch)
  local raw = linesOf(patch)
  local hunks, i = {}, 1
  while i <= #raw do
    local oldStart, oldCount, newStart, newCount = raw[i]:match(
      "^@@ %-(%d+),?(%d*) %+([0-9]+),?(%d*) @@")
    if oldStart then
      local h = { oldStart=tonumber(oldStart), old={}, new={} }
      i = i + 1
      while i <= #raw and raw[i]:sub(1,2) ~= "@@" do
        local line, prefix = raw[i], raw[i]:sub(1,1)
        local body = line:sub(2)
        if prefix == " " then h.old[#h.old+1]=body; h.new[#h.new+1]=body
        elseif prefix == "-" then h.old[#h.old+1]=body
        elseif prefix == "+" then h.new[#h.new+1]=body
        elseif prefix ~= "\\" then break end
        i = i + 1
      end
      hunks[#hunks+1] = h
    else i = i + 1 end
  end
  return hunks
end

local function applyPatch(source, patch, label)
  local lines, delta = linesOf(source), 0
  for n, h in ipairs(parsePatch(patch)) do
    local hint = h.oldStart + delta
    local at = findBlock(lines, h.old, hint)
    if not at then
      if findBlock(lines, h.new, hint) then
        at = false
      else
        error(("KANTO_DYNAMIC_WEATHER: Dramaless Shape 1.6.4 %s hunk %d no longer matches; update KDW before enabling this Dramaless build")
          :format(label, n), 0)
      end
    end
    if at then
      for _ = 1, #h.old do table.remove(lines, at) end
      for i = #h.new, 1, -1 do table.insert(lines, at, h.new[i]) end
      delta = delta + #h.new - #h.old
    end
  end
  return table.concat(lines, "\n") .. "\n"
end

local patched, proxy = {}, nil
local function readDependency(rel)
  local owner = baseV and baseV.mod
  local source = owner and owner.read and owner:read(rel)
  if not source then error("KANTO_DYNAMIC_WEATHER: Dramaless Shape is missing " .. rel, 0) end
  return source
end

local function compilePatched(name)
  if patched[name] ~= nil then return patched[name] end
  local source = readDependency("lib/" .. name .. ".lua")
  local patch = mod:read("compat/patches/dramaless-1.6.4/" .. name .. ".patch")
  if not patch then error("KANTO_DYNAMIC_WEATHER: Dramaless compatibility patch missing for " .. name, 0) end
  local merged = applyPatch(source, patch, name)
  local chunk, err = load(merged, "@" .. tostring(mod.path) .. "/compat/runtime/" .. name .. ".lua")
  if not chunk then error("KANTO_DYNAMIC_WEATHER: patched " .. name .. " did not compile: " .. tostring(err), 0) end
  patched[name] = false
  local value = chunk(proxy)
  if value == nil then error("KANTO_DYNAMIC_WEATHER: patched " .. name .. " returned nil", 0) end
  patched[name] = value
  return value
end

proxy = { mod=baseV.mod, path=baseV.path, data=baseV.data }
function proxy.require(name)
  if name == "Voxel3D" or name == "VoxelScene" or name == "Sky" then
    local hit = patched[name]
    if hit == false then error("KANTO_DYNAMIC_WEATHER: circular Dramaless compatibility load at " .. name, 0) end
    return hit or compilePatched(name)
  end
  if name == "CinematicAtmos" or name == "DistantWorld" or name == "HorizonApron"
      or name == "WeatherSetting" or name == "ForestAtmos" then
    return W.require(name)
  end
  return baseV.require(name)
end

function Bridge.requirePatched(name)
  return patched[name] or compilePatched(name)
end
function Bridge.load()
  return { Sky=compilePatched("Sky"), Voxel3D=compilePatched("Voxel3D"), VoxelScene=compilePatched("VoxelScene") }
end
return Bridge
