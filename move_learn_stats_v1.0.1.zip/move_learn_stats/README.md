# Move Learn Stats

A quality-of-life mod for Gen1Recomp.

When a Pokémon already knows four moves and is trying to learn another one,
the move-forgetting screen compares the highlighted old move with the new move.

## Displayed information

- Selected old move
- New move being learned
- POWER
- Maximum PP

Status moves display `---` for POWER. The PP value is the move's maximum base
PP, not the Pokémon's remaining current PP.

The original behavior is preserved:

- HM moves still cannot be forgotten.
- CANCEL and the B button still use the normal abandon-learning confirmation.
- The normal learning and replacement messages are unchanged.

## Gen1 Modern UI compatibility

Version 1.0.1 publishes the official `gen1ModernUi` compatibility contract
(API v1). With **Gen1 Modern UI 0.8.2 or newer** enabled, the move-forgetting
screen is rendered with the active Modern UI theme, frame, scaling and density.

The new move stays visible at the top with POWER and maximum PP, while every
old move is a large selectable Modern UI row showing the same statistics.
Mouse/touch selection is supported and follows the same HM protection, CANCEL
flow and replacement behavior as the original menu.

Modern UI is optional. Without it, Move Learn Stats keeps its original classic
two-column comparison panel.

## Installation

Extract the `move_learn_stats` folder into the Gen1Recomp mods directory and
enable **Move Learn Stats** in the mod manager.
