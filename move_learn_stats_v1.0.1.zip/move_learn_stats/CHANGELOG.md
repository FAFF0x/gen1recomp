# Changelog

## v1.0.1

- Added official Gen1 Modern UI compatibility using the `gen1ModernUi` API v1 contract.
- The Modern UI screen shows the new move and all old moves with POWER and maximum PP.
- Added pointer/mouse/touch selection through Modern UI semantic actions.
- Preserved HM move protection and the normal abandon-learning confirmation flow.
- Modern UI remains optional; the original classic comparison is used as fallback.

## v1.0.0

- Added a two-column comparison panel to the move-forgetting screen.
- Shows POWER and maximum PP for the highlighted old move.
- Shows POWER and maximum PP for the new move being learned.
- Displays `---` as the power of status moves.
- Preserves the original MoveLearnMenu behavior and HM restrictions.
