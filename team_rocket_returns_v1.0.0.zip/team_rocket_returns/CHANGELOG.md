# Changelog

## 1.0.0

- Aggiunta quest Team Rocket post-Giovanni su cinque mappe.
- Aggiunto ROCKET CASE nel menu Start.
- Aggiunti tre documenti, Black Pass e Rocket Core.
- Aggiunti sei nuovi Allenatori e scaling dinamico.
- Aggiunto laboratorio clandestino con quattro checkpoint.
- Aggiunte ricompense Porygon, Master Ball e Rocket Core.
