# Changelog

## 1.4.1

- Fixed report export on current sandboxed Gen1Recomp builds.
- Replaced blocked `love.filesystem` output with public `mod.storage.writeBytes`.
- Report is now saved under the mod's `mod_storage` playthrough directory.
- Main shareable file is `exports/performance_report_latest_json.bin`.
- The `.bin` file contains plain UTF-8 JSON and can be uploaded directly.
- Overlay now shows the storage-relative export path.
- Removed the obsolete `filesystem` manifest permission.

## 1.4.0

- Added sandbox-safe **Provenance Callback Profiler (PROV)**.
- No longer depends on Lua `debug` for registry/export callback attribution.
- Instruments mod-authored callback functions using Gen1Recomp registry owner provenance.
- Instruments cross-mod exported callback functions.
- Added exclusive nested callback timing to reduce double attribution.
- Preserved hook `next(...)` exclusion.
- F8 now reports `DEEP`, `PROV`, or `DIRECT` as the active diagnostic backend.
- Reports the number of provenance callbacks instrumented.
- Reworded unavailable-deep status so a sandboxed debug API is not shown as a
  broken diagnostic when PROV is active.
- Fixed verdict logic: deep sample percentage alone now produces `ACTV`, not
  `HIGH`/`MED`, unless real CPU/stutter evidence also exists.
- JSON report now records provenance-profiler availability and callback count.

## 1.3.0

- Added automatic diagnostic export when an F8 capture finishes.
- Added F9 to re-export the frozen report.
- Added `performance_report_latest.json` for easy sharing.
- Added matching human-readable `performance_report_latest.txt`.
- Added timestamped report archives under `performance_reports/`.
- Added engine/game/LÖVE/OS/renderer/window metadata.
- Added exact loaded-mod versions, priorities, dependencies and load order.
- Added full F8 frame-time series and diagnostic-specific frame distribution:
  median, P95, P99, worst, 1% low and missed 16.67 ms budget.
- Added detailed slow-frame records with direct/deep contributors, state/map and
  render counters.
- Added 4 Hz capture time series for FPS, Logic/s, memory and renderer workload.
- Added logic-step totals for the diagnostic interval.
- Added machine-readable report schema (`gen1recomp-performance-report`, v1).
- Added `filesystem` permission for report export.
- Report intentionally excludes player/save progress and absolute paths.

## 1.2.0

- Added slow-frame correlation and deep Lua diagnostics.
- Added HIGH/MED/LOW fluidity-impact verdicts.
- Added direct render-work attribution and explicit unattributed slow frames.

## 1.1.0

- Added per-mod exclusive hook/event CPU profiling.

## 1.0.0

- Initial FPS/frame-time/renderer/memory monitor.
