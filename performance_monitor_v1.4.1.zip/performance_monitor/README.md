# Performance Monitor v1.4.1

This build fixes report export on current Gen1Recomp.

## Important change

Current Gen1Recomp sandboxes mods and does not expose `love.filesystem`.
Performance Monitor v1.3/v1.4 still tried to write reports through that old
path, so F8 could finish while the report file never appeared.

v1.4.1 exports through Gen1Recomp's public **`mod.storage`** API instead.

## Where the report is saved

After F8, look inside Gen1Recomp's normal save folder, then:

`mod_storage/<game>/<playthrough-id>/performance_monitor/exports/`

The main file to upload is:

`performance_report_latest_json.bin`

Despite the `.bin` extension, its contents are plain UTF-8 JSON. You can upload
that file directly here.

There is also:

`performance_report_latest_txt.bin`

and timestamped historical reports under the mod's `reports/` directory.

The exact relative path is printed by the overlay after a successful export.

## Controls

- **F3** show/hide
- **F4** compact/detailed
- **F6** reset rolling samples
- **F8** 10-second diagnostic capture + automatic export
- **F9** re-export the frozen report

## Attribution

v1.4.1 keeps the sandbox-safe PROV callback profiler introduced in v1.4.0,
plus Runtime hook/event timing and slow-frame correlation. If Lua `debug` is
available, the optional deep sampler is used too.
