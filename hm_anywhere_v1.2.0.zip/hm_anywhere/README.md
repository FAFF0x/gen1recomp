# HM Anywhere

HM Anywhere permette di usare una MN posseduta nello zaino **senza doverla insegnare a un Pokémon**.

## v1.2.0: azioni contestuali opzionali

Ora tutte le MN da campo possedute sono disponibili da:

**Start -> HM**

Il menu può mostrare:

- **CUT**
- **FLY**
- **SURF**
- **STR**
- **FLSH**
- **CTX ON / CTX OFF**

`CTX ON/OFF` attiva o disattiva le azioni contestuali con il tasto **A**.

### CTX ON

- A davanti a un albero: CUT.
- A davanti all'acqua: SURF.
- A verso terra mentre surfi: scendi.
- A davanti a un masso: STRENGTH.

### CTX OFF

Il tasto **A** torna a essere completamente dedicato alle normali interazioni del gioco.
Le MN continuano comunque a funzionare senza essere insegnate: basta usare **Start -> HM**.

La scelta CTX viene salvata nel salvataggio.

## Fix SURF / nuotatori

In v1.1.0, mentre si usava SURF, premere A davanti a un nuotatore poteva far partire
prima il controllo di discesa e mostrare:

`There's no place to get off!`

impedendo di parlare al PNG.

In v1.2.0 un PNG direttamente davanti al giocatore ha priorità sull'azione SURF
contestuale. I nuotatori possono quindi essere parlati normalmente anche con `CTX ON`.

## Regole

Le medaglie originali restano necessarie. FLY funziona soltanto nei luoghi esterni
compatibili; FLASH soltanto nelle mappe buie. Le MN restano insegnabili e utilizzabili
in battaglia.

La mod riconosce dinamicamente le MN tramite `machine.kind = "HM"` e `machine.move`.
