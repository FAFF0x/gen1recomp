# Changelog

## 1.2.0

- Aggiunto **CTX ON / CTX OFF** nel menu `Start -> HM`.
- Le azioni contestuali CUT/SURF/STRENGTH possono ora essere disattivate senza
  perdere la funzione principale della mod.
- `Start -> HM` ora espone tutte le MN da campo possedute: CUT, FLY, SURF,
  STRENGTH e FLASH.
- La preferenza delle azioni contestuali viene salvata per salvataggio.
- Corretto il bug di SURF che mostrava "There's no place to get off!" davanti
  ai nuotatori e impediva di parlare con loro.
- Con CTX ON, i PNG direttamente davanti al giocatore hanno ora priorità su
  SURF; i massi spingibili conservano la priorità di STRENGTH.
- La voce HM nel menu Start compare con qualunque MN da campo posseduta.

## 1.1.0

- Rimossa l'attivazione fragile di FLASH premendo A su uno spazio vuoto.
- Aggiunta la voce **HM** nel menu Start.
- Aggiunto il sottomenu dinamico **FLSH / FLY** in base alle MN possedute.
- FLASH ora viene attivato direttamente dal sottomenu HM.
- FLY è stato spostato dalla voce Start dedicata al sottomenu HM.
- Conservati i controlli contestuali con A per CUT, SURF e STRENGTH.
- Conservati requisiti delle medaglie e restrizioni originali delle mappe.

## 1.0.0

- Added inventory-based CUT, SURF, STRENGTH, FLASH and FLY field actions.
- Added contextual A-button activation for CUT, SURF, STRENGTH and FLASH.
- Added an outdoor FLY entry to the Start menu.
- Preserved badge requirements and normal field restrictions.
- Removed redundant HM field-action rows from Pokemon submenus.
