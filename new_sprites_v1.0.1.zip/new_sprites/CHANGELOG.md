# Changelog

## 1.0.1

- Slowed sprite animation playback from 60 Hz to 30 Hz.
- Animations now run at 50% of the previous speed while preserving the original frame sequence and image quality.

## 1.0.0

- Initial NEW SPRITES release.
- Added all 151 Kanto front Gen 5 animation atlases.
- Added all 151 Kanto back Gen 5 animation atlases.
- Added 60 Hz repeated-cell timeline playback.
- Added lossless per-species frame deduplication.
- Added full-color true-color rendering through `pokemon.sprite`.
- Added Advanced Box System / Modern UI selected-Pokemon preview support.
- Native battle images are intentionally left untouched because BattleState caches them at battle start.
