# Changelog

## 1.0.0

- Initial release.
- Adds RARE CANDY to every standard Poké Mart.
- Sets RARE CANDY purchase price to ¥0.
- Preserves the stock ShopMenu for maximum compatibility with UI mods.
