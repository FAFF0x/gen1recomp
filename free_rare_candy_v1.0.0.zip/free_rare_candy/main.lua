return function(mod)
  local ITEM_ID = "RARE_CANDY"

  -- The stock ShopMenu reads the item's live `price` field for both the
  -- displayed price and the amount deducted from the player's money.
  -- A zero price is valid in Gen1Recomp (other zero-price items already
  -- exist), so this keeps the normal shop flow while making the purchase
  -- truly free.
  local candy = mod.content.items:get(ITEM_ID)
  if not candy then
    mod.log:error("RARE_CANDY is missing from the item registry")
    return
  end
  mod.content.items:patch(ITEM_ID, { price = 0 })

  -- Mart inventories are stored on the extracted text-pointer entries rather
  -- than in a standalone content registry.  game.ready fires after all mod
  -- registries have been merged and before normal play begins, so updating
  -- these live stock lists here makes the item appear in every standard mart
  -- without replacing ShopMenu or any Modern UI presenter.
  mod.events:on("game.ready", function(ev)
    local game = ev and ev.game
    local pointers = game and game.data and game.data.text_pointers
    if type(pointers) ~= "table" then
      mod.log:warn("text_pointers unavailable; no marts were changed")
      return
    end

    local martsChanged = 0
    for _, perMap in pairs(pointers) do
      if type(perMap) == "table" then
        for _, entry in pairs(perMap) do
          local stock = type(entry) == "table" and entry.mart or nil
          if type(stock) == "table" then
            local found = false
            for _, id in ipairs(stock) do
              if id == ITEM_ID then
                found = true
                break
              end
            end
            if not found then
              stock[#stock + 1] = ITEM_ID
              martsChanged = martsChanged + 1
            end
          end
        end
      end
    end

    mod.log:info("RARE CANDY set to ¥0 and added to %d mart stock list(s)", martsChanged)
  end, 100)
end
