-- Crystal Onix: The Living Crystal
-- gen1recomp Mod API 2
--
-- Adds a separate Crystal Onix species, a multi-stage quest, custom artwork,
-- a true Rock/Ice typing, Generation I-compatible Special, and a guaranteed
-- perfect reward (15 DVs, 65535 Stat EXP in every stat).

local SPECIES = "CRYSTAL_ONIX"

local FLAG_STARTED    = "CRYSTAL_ONIX_STARTED"
local FLAG_ARTISAN    = "CRYSTAL_ONIX_ARTISAN_CLUE"
local FLAG_RESEARCH   = "CRYSTAL_ONIX_RESEARCH_CLUE"
local FLAG_SHARD      = "CRYSTAL_ONIX_SHARD_FOUND"
local FLAG_CHARM      = "CRYSTAL_ONIX_TIDAL_CHARM"
local FLAG_DEFEATED   = "CRYSTAL_ONIX_DEFEATED"
local FLAG_REWARDED   = "CRYSTAL_ONIX_REWARDED"
local FLAG_CAPTURED   = "CRYSTAL_ONIX_CAPTURE_STORED"

local TEXT_SAILOR     = "TEXT_CRYSTAL_ONIX_SAILOR"
local TEXT_ARTISAN    = "TEXT_CRYSTAL_ONIX_ARTISAN"
local TEXT_RESEARCHER = "TEXT_CRYSTAL_ONIX_RESEARCHER"
local TEXT_SHARD      = "TEXT_CRYSTAL_ONIX_SHARD"
local TEXT_BOSS       = "TEXT_CRYSTAL_ONIX_BOSS"
local TEXT_DEX        = "TEXT_CRYSTAL_ONIX_DEX"

local function flag(save, name)
  return save and save.flags and save.flags[name] == true
end

local function cloneList(list)
  local out = {}
  for i, value in ipairs(list or {}) do out[i] = value end
  return out
end

return function(mod)
  ---------------------------------------------------------------------------
  -- Quest System integration.
  --
  -- Quest System is a required dependency from v1.0.1 onward. The journal
  -- reads the source quest flags dynamically, so existing saves immediately
  -- show the correct stage without duplicating progression state.
  ---------------------------------------------------------------------------
  local questHandle = assert(mod.find("quest_system"),
    "Crystal Onix requires Quest System v1.0.3 or newer")
  local quests = assert(type(questHandle.exports) == "table" and questHandle.exports,
    "Quest System exports are unavailable")

  local function qflag(game, name)
    return flag(game and game.save, name)
  end

  local function questObjective(game)
    if not qflag(game, FLAG_STARTED) then
      return "Speak with the old sailor near Vermilion Harbor."
    elseif not qflag(game, FLAG_ARTISAN) then
      return "Ask the crystal artisan on Cinnabar Island about the legend."
    elseif not qflag(game, FLAG_RESEARCH) then
      return "Consult the marine researcher in Fuchsia City."
    elseif not qflag(game, FLAG_SHARD) then
      return "Recover the Luminous Shard on Seafoam Islands B4F."
    elseif not qflag(game, FLAG_CHARM) then
      return "Return the Luminous Shard to the old sailor in Vermilion."
    elseif not qflag(game, FLAG_DEFEATED) then
      return "Use the Tidal Charm to face Crystal Onix on Seafoam B4F."
    elseif not qflag(game, FLAG_REWARDED) then
      return "Return to the old sailor in Vermilion City."
    end
    return "The legend has chosen a new guardian."
  end

  local function questLocation(game)
    if not qflag(game, FLAG_STARTED) then return "Vermilion City" end
    if not qflag(game, FLAG_ARTISAN) then return "Cinnabar Island" end
    if not qflag(game, FLAG_RESEARCH) then return "Fuchsia City" end
    if not qflag(game, FLAG_SHARD) then return "Seafoam Islands B4F" end
    if not qflag(game, FLAG_CHARM) then return "Vermilion City" end
    if not qflag(game, FLAG_DEFEATED) then return "Seafoam Islands B4F" end
    if not qflag(game, FLAG_REWARDED) then return "Vermilion City" end
    return "Completed"
  end

  local questFlags = {
    FLAG_STARTED, FLAG_ARTISAN, FLAG_RESEARCH, FLAG_SHARD,
    FLAG_CHARM, FLAG_DEFEATED, FLAG_REWARDED,
  }

  local registered, registerErr = quests.register({
    id = "crystal_onix.living_crystal",
    title = "The Living Crystal",
    source = "Crystal Onix",
    sort = 130,
    status = function(game)
      if qflag(game, FLAG_REWARDED) then return "completed" end
      if qflag(game, FLAG_STARTED) then return "active" end
      return "available"
    end,
    description =
      "Follow an old sailor's legend across Kanto and discover the rare "
      .. "Rock/Ice Crystal Onix hidden beneath Seafoam Islands.",
    objective = questObjective,
    location = questLocation,
    reward = "Lv.45 Crystal Onix with perfect DVs and maximum Stat EXP.",
    progress = function(game)
      local current = 0
      for _, questFlag in ipairs(questFlags) do
        if qflag(game, questFlag) then current = current + 1 end
      end
      return { current = current, total = #questFlags }
    end,
    markers = {
      {
        map = "VERMILION_CITY", npc = "CRYSTAL_ONIX_SAILOR",
        when = function(game)
          if not qflag(game, FLAG_STARTED) then return "available" end
          if qflag(game, FLAG_SHARD) and not qflag(game, FLAG_CHARM) then
            return "turnin"
          end
          if qflag(game, FLAG_DEFEATED) and not qflag(game, FLAG_REWARDED) then
            return "turnin"
          end
          return false
        end,
      },
      {
        map = "CINNABAR_ISLAND", npc = "CRYSTAL_ONIX_ARTISAN",
        when = function(game)
          return qflag(game, FLAG_STARTED) and not qflag(game, FLAG_ARTISAN)
            and "active" or false
        end,
      },
      {
        map = "FUCHSIA_CITY", npc = "CRYSTAL_ONIX_RESEARCHER",
        when = function(game)
          return qflag(game, FLAG_ARTISAN) and not qflag(game, FLAG_RESEARCH)
            and "active" or false
        end,
      },
      {
        map = "SEAFOAM_ISLANDS_B4F", npc = "CRYSTAL_ONIX_SHARD",
        when = function(game)
          return qflag(game, FLAG_RESEARCH) and not qflag(game, FLAG_SHARD)
            and "active" or false
        end,
      },
      {
        map = "SEAFOAM_ISLANDS_B4F", npc = "CRYSTAL_ONIX_BOSS",
        when = function(game)
          return qflag(game, FLAG_CHARM) and not qflag(game, FLAG_DEFEATED)
            and "active" or false
        end,
      },
    },
  })
  if not registered then
    error("Could not register Crystal Onix quest: " .. tostring(registerErr), 0)
  end

  ---------------------------------------------------------------------------
  -- Species
  ---------------------------------------------------------------------------
  local onix = mod.content.pokemon:get("ONIX")
  local tmhm = onix and cloneList(onix.tmhm) or {}

  -- Keep every TM/HM normal Onix can already use, then add every machine
  -- whose move is Ice, Ground, or Rock.  each() reads the merged registry,
  -- so compatible TM/HM moves added by earlier-loaded mods are picked up too.
  local tmhmSeen = {}
  for _, moveId in ipairs(tmhm) do tmhmSeen[moveId] = true end

  local crystalMachineTypes = {
    ICE = true,
    GROUND = true,
    ROCK = true,
  }

  for _, item in mod.content.items:each() do
    local machine = item and item.machine
    if machine and (machine.kind == "TM" or machine.kind == "HM") then
      local moveId = machine.move
      local moveDef = moveId and mod.content.moves:get(moveId)
      if moveDef and crystalMachineTypes[moveDef.type] and not tmhmSeen[moveId] then
        tmhm[#tmhm + 1] = moveId
        tmhmSeen[moveId] = true
      end
    end
  end

  -- DexEntryMenu expects dexEntry.text to reference an entry in Data.text.
  -- Supplying the prose directly makes the stock Pokédex fall back to
  -- "Data unknown.", so the Crystal Onix origin story is registered here.
  mod.content.text:register(TEXT_DEX,
    "An ONIX lived for\nyears in a frozen\nsea cave. Cold,\npressure and rare\nminerals slowly\ncrystallized its\nrocky body.")

  local speciesDef = {
    id = SPECIES,
    name = "CRYSTAL ONIX",

    -- Keep a unique internal numeric dex id so engine systems that assume
    -- one species per number never collide with normal ONIX. The stock
    -- Pokédex override below reads this display metadata and presents the
    -- regional-style sub-entry 95C directly beneath #095 ONIX.
    dex = 152,
    dexDisplay = 95,
    dexVariant = "C",
    dexVariantOrder = 1,

    types = { "ROCK", "ICE" },

    -- Generation I uses one Special stat for both offense and defense.
    baseStats = {
      hp = 100,
      attack = 100,
      defense = 200,
      speed = 100,
      special = 80,
    },

    catchRate = 45,
    baseExp = 180,
    growthRate = "MEDIUM_FAST",
    level1Moves = { "TACKLE", "SCREECH" },
    learnset = {
      { level = 7,  move = "BIND" },
      { level = 13, move = "ROCK_THROW" },
      { level = 19, move = "HARDEN" },
      { level = 25, move = "ICE_BEAM" },
      { level = 31, move = "SLAM" },
      { level = 37, move = "ROCK_SLIDE" },
      { level = 45, move = "REST" },
    },
    evolutions = {},

    spriteFront = mod.assets:path("assets/front.png"),
    spriteBack = mod.assets:path("assets/back.png"),
    frontSize = 7,
    battleScaleBack = 1.0,
    trueColor = true,

    dexEntry = {
      kind = "CRYSTAL SNAKE",
      heightFt = 28,
      heightIn = 10,
      weight = 463.0,
      text = TEXT_DEX,
    },
  }
  speciesDef.tmhm = tmhm
  mod.content.pokemon:register(SPECIES, speciesDef)

  mod.content.icons:register(SPECIES, {
    image = mod.assets:path("assets/icon.png"),
    frames = 2,
    trueColor = true,
  })

  mod.content.cries:register(SPECIES, {
    base = "ONIX",
    pitch = 225,
  })

  mod.content.sprites:register("SPRITE_CRYSTAL_ONIX", {
    image = mod.assets:path("assets/overworld.png"),
    frames = 1,
    trueColor = true,
  })

  ---------------------------------------------------------------------------
  -- Stock Pokédex integration: #095 ONIX + #95C CRYSTAL ONIX.
  --
  -- The engine's built-in PokedexMenu indexes one species per numeric dex
  -- number (`byDex[def.dex] = def`), so assigning both forms `dex = 95`
  -- makes one overwrite the other.  Keep Crystal Onix internally unique at
  -- 152, but replace ONLY the stock PokedexMenu screen with a faithful copy
  -- that understands dexDisplay/dexVariant metadata.  This means the normal
  -- START -> POKéDEX list itself shows the variant directly under ONIX; no
  -- Pokédex Plus dependency or extra menu is required.
  ---------------------------------------------------------------------------
  local CRYSTAL_DEX_SCREEN = "CrystalOnixDexEntry"

  local function displayDexNo(def, fallback)
    local n = tonumber(def and (def.dexDisplay or def.dex)) or fallback or 0
    local suffix = def and def.dexVariant
    if suffix and tostring(suffix) ~= "" then
      return tostring(n) .. tostring(suffix)
    end
    return ("%03d"):format(n)
  end

  local CrystalDexEntry = {}
  CrystalDexEntry.__index = CrystalDexEntry
  CrystalDexEntry.isOpaque = true

  function CrystalDexEntry:sgbPalettes(game)
    local P = require("src.render.PaletteFX")
    local base = P.pal(game.data, "BROWNMON")
    if not base then return nil end
    return { P.whole(base),
             P.zone(P.monPal(game.data, self.def and self.def.id), 1, 1, 8, 8) }
  end

  function CrystalDexEntry.new(game, speciesOrOpts, onDone)
    local species, forceOwned
    if type(speciesOrOpts) == "table" then
      species = speciesOrOpts.species or speciesOrOpts[1]
      forceOwned = speciesOrOpts.forceOwned and true or false
    else
      species = speciesOrOpts
      forceOwned = false
    end

    local self = setmetatable({
      game = game,
      forceOwned = forceOwned,
      onDone = onDone,
      def = game.data.pokemon[species],
    }, CrystalDexEntry)

    local path, trueColor = require("src.pokemon.Sprites").path(
      game.data, species, "front", { kind = "dex" })
    local ok, img = false, nil
    if path then ok, img = pcall(love.graphics.newImage, path) end
    self.sprite = ok and img or nil
    self.spriteTrueColor = self.sprite and trueColor or false
    require("src.core.Sound").playCry(game.data, species)
    return self
  end

  function CrystalDexEntry:update(dt)
    local input = self.game.input
    if input:wasPressed("a") or input:wasPressed("b") then
      self.game.stack:pop()
      if self.onDone then self.onDone() end
    end
  end

  function CrystalDexEntry:draw()
    local game, def, sprite = self.game, self.def, self.sprite
    local Font = mod.ui.Font
    local Strings = require("src.core.Strings")

    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.rectangle("fill", 0, 0, 160, 144)
    if sprite then
      local y = math.max(0, 60 - sprite:getHeight())
      love.graphics.draw(sprite, 8, y)
      if self.spriteTrueColor then
        require("src.render.PaletteFX").markTrueColor(
          8, y, sprite:getDimensions())
      end
    end

    love.graphics.setColor(0, 0, 0, 1)
    Font.draw(def.name, 72, 8)
    local e = def.dexEntry or {}
    Font.draw(e.kind or "?", 72, 20)
    Font.draw("No." .. displayDexNo(def, 95), 72, 32)

    local owned = self.forceOwned
      or (game.save.pokedex and game.save.pokedex.owned[def.id])
    if owned and e.heightFt then
      if e.heightM then
        Font.draw((("GR. %.1fm"):format(e.heightM):gsub("(%d)%.(%d)", "%1,%2")), 64, 44)
        Font.draw((("GEW. %.1fkg"):format(e.weightKg or 0):gsub("(%d)%.(%d)", "%1,%2")), 64, 54)
      else
        Font.draw(Strings("HT %d′%02d″", e.heightFt, e.heightIn or 0), 72, 44)
        Font.draw(Strings("WT %.1flb", (e.weight or 0) / 10), 72, 54)
      end
    end

    local text = owned and e.text and game.data.text[e.text] or nil
    local y = 72
    if text then
      for line in (text:gsub("\v", "\n"):gsub("\f", "\n") .. "\n"):gmatch("(.-)\n") do
        if y > 132 then break end
        Font.draw(line, 8, y)
        y = y + 10
      end
    else
      Font.draw(Strings("Data unknown."), 8, y)
    end
    love.graphics.setColor(1, 1, 1, 1)
  end

  mod.content.screens:register(CRYSTAL_DEX_SCREEN, {
    new = function(game, speciesOrOpts, onDone)
      return CrystalDexEntry.new(game, speciesOrOpts, onDone)
    end,
  })

  mod.content.screens:register("PokedexMenu", {
    new = function(game, opts)
      opts = opts or {}
      local Strings = require("src.core.Strings")
      local dex = game.save.pokedex or { seen = {}, owned = {} }
      local constants = game.data.constants or {}
      local dexSize = constants.dexSize or 151
      local digits = constants.dexDigits or 3
      local numFmt = ("%%0%dd"):format(digits)

      -- Base forms remain one row per Kanto number.  Variant forms are kept
      -- separately and inserted immediately after their parent number.
      local baseByDex, variantsByDex = {}, {}
      for species, def in pairs(game.data.pokemon) do
        local n = tonumber(def.dexDisplay or def.dex)
        if n and n >= 1 and n <= dexSize then
          if def.dexVariant and tostring(def.dexVariant) ~= "" then
            variantsByDex[n] = variantsByDex[n] or {}
            variantsByDex[n][#variantsByDex[n] + 1] = def
          elseif not baseByDex[n] or def.dex == n then
            baseByDex[n] = def
          end
        end
      end
      for _, variants in pairs(variantsByDex) do
        table.sort(variants, function(a, b)
          local ao = tonumber(a.dexVariantOrder) or 9999
          local bo = tonumber(b.dexVariantOrder) or 9999
          if ao ~= bo then return ao < bo end
          return tostring(a.id) < tostring(b.id)
        end)
      end

      local items = {}
      local seen, owned = 0, 0

      local function appendDexRow(def, n, variant)
        if not def then return end
        local number = variant
          and (tostring(n) .. tostring(def.dexVariant))
          or numFmt:format(n)
        local known = dex.owned[def.id] or dex.seen[def.id]
        local label = number .. " " .. (known and def.name or "-----")
        if dex.owned[def.id] then
          owned = owned + 1
          seen = seen + 1
        elseif dex.seen[def.id] then
          seen = seen + 1
        end
        items[#items + 1] = {
          label = label,
          ball = dex.owned[def.id] or nil,
          value = known and def.id or nil,
        }
      end

      for n = 1, dexSize do
        appendDexRow(baseByDex[n], n, false)
        for _, def in ipairs(variantsByDex[n] or {}) do
          appendDexRow(def, n, true)
        end
      end

      local list
      list = mod.ui.ListMenu.new(game, "POKéDEX", items, {
        footer = Strings("SEEN %3d  OWN %3d", seen, owned),
        pageJump = true,
        onCancel = opts.onCancel,
        onChoose = function(item, dexList)
          if not item.value then return end
          local species = item.value
          local Menu = mod.ui.Menu
          local entries = {
            { label = Strings("DATA"), onSelect = function()
                if species == SPECIES then
                  mod.ui.push(game, CRYSTAL_DEX_SCREEN, species)
                else
                  mod.ui.push(game, "DexEntryMenu", species)
                end
              end },
            { label = Strings("CRY"), keepOpen = true, onSelect = function()
                require("src.core.Sound").playCry(game.data, species)
              end },
            { label = Strings("AREA"), onSelect = function()
                mod.ui.push(game, "TownMap", { nestSpecies = species })
              end },
          }

          -- Preserve Yellow's PRNT row from the stock Pokédex.
          if require("src.core.GameVersion").isYellow() then
            entries[#entries + 1] = { label = Strings("PRNT"), onSelect = function()
              local Printer = require("src.core.Printer")
              local TextBox = mod.ui.TextBox
              local def = game.data.pokemon[species]
              local path = require("src.pokemon.Sprites").path(
                game.data, species, "front", { kind = "dex" })
              local ok, sprite = false, nil
              if path then ok, sprite = pcall(love.graphics.newImage, path) end
              local saved, err
              if species == SPECIES then
                saved, err = Printer.save("dex_" .. species, 160, 144, function()
                  -- Printer output uses the same Crystal entry renderer.
                  local fake = setmetatable({
                    game = game, def = def, sprite = ok and sprite or nil,
                    spriteTrueColor = false, forceOwned = false,
                  }, CrystalDexEntry)
                  fake:draw()
                end)
              else
                local DexEntryMenu = require("src.ui.DexEntryMenu")
                saved, err = Printer.save("dex_" .. species, 160, 144, function()
                  DexEntryMenu.render(game, def, ok and sprite or nil, false)
                end)
              end
              game.stack:push(TextBox.new(game, saved
                and Strings("Printed %s's\ndata!\fSaved as\n%s\vin the save\nfolder.",
                            def.name, saved)
                or Strings("Printer error!\n%s", tostring(err))))
            end }
          end

          entries[#entries + 1] = { label = Strings("QUIT"), onSelect = function()
            dexList:close()
            if opts.onCancel then opts.onCancel() end
          end }
          game.stack:push(Menu.new(game, entries,
            { tx = 12, ty = 8, tw = 8, th = #entries * 2 + 2 }))
        end,
      })

      -- Match the stock Pokédex SGB palette rather than ListMenu's generic one.
      list.sgbPalettes = function(_, g)
        return require("src.render.PaletteFX").wholeNamed(g.data, "BROWNMON")
      end
      return list
    end,
  })

  ---------------------------------------------------------------------------
  -- Generation I stat support.
  --
  -- Crystal Onix now uses a single base Special stat of 80 for both outgoing
  -- and incoming special damage, matching the original battle system.
  ---------------------------------------------------------------------------
  local Stats = require("src.pokemon.Stats")

  ---------------------------------------------------------------------------
  -- Perfect reward helper.
  --
  -- The engine's normal give_pokemon command handles party/box placement,
  -- OT data, Pokédex ownership, and full-storage failure. The following
  -- command then perfects the newest matching mon without using internals.
  ---------------------------------------------------------------------------
  local function perfectCrystalMon(mon, game)
    if not mon or mon.species ~= SPECIES then return false end

    mon.dvs = {
      hp = 15,
      attack = 15,
      defense = 15,
      speed = 15,
      special = 15,
    }
    mon.statExp = {
      hp = 65535,
      attack = 65535,
      defense = 65535,
      speed = 65535,
      special = 65535,
    }
    mon.stats = Stats.calc(
      game.data.pokemon[SPECIES],
      mon.level or 45,
      mon.dvs,
      mon.statExp
    )
    mon.hp = mon.stats.hp
    mon.status = nil
    return true
  end

  -- Recalculate Crystal Onix instances created by older mod versions. This
  -- preserves the amount of HP already lost while applying the new base HP.
  local function refreshCrystalStats(game)
    if not game or not game.save or not game.data
        or not game.data.pokemon or not game.data.pokemon[SPECIES] then
      return
    end

    local function refresh(mon)
      if not mon or mon.species ~= SPECIES then return end
      local oldMax = mon.stats and mon.stats.hp
      local oldHp = mon.hp
      local newStats = Stats.calc(
        game.data.pokemon[SPECIES],
        mon.level or 1,
        mon.dvs or {},
        mon.statExp or {}
      )
      mon.stats = newStats
      if type(oldHp) == "number" and type(oldMax) == "number" then
        mon.hp = math.max(0, math.min(newStats.hp,
          oldHp + (newStats.hp - oldMax)))
      else
        mon.hp = newStats.hp
      end
    end

    for _, mon in ipairs(game.save.party or {}) do refresh(mon) end
    for _, box in ipairs(game.save.boxes or {}) do
      for _, mon in ipairs(box or {}) do refresh(mon) end
    end
  end

  mod.commands:register("perfect_latest_crystal_onix", function(ctx)
    local party = ctx.save.party or {}
    for i = #party, 1, -1 do
      local mon = party[i]
      if mon.species == SPECIES and
          (not mon.statExp or mon.statExp.hp ~= 65535) then
        ctx.lastCheck = perfectCrystalMon(mon, ctx.game)
        return
      end
    end

    local boxes = ctx.save.boxes or {}
    for b = #boxes, 1, -1 do
      local box = boxes[b] or {}
      for i = #box, 1, -1 do
        local mon = box[i]
        if mon.species == SPECIES and
            (not mon.statExp or mon.statExp.hp ~= 65535) then
          ctx.lastCheck = perfectCrystalMon(mon, ctx.game)
          return
        end
      end
    end

    ctx.lastCheck = false
  end)

  ---------------------------------------------------------------------------
  -- Story NPCs.
  ---------------------------------------------------------------------------
  mod.content.maps:patch("VERMILION_CITY", {
    objects = { __append = {
      {
        index = 90, x = 21, y = 27,
        sprite = "SPRITE_SAILOR",
        movement = "STAY", range = "DOWN",
        text = TEXT_SAILOR, name = "CRYSTAL_ONIX_SAILOR",
      },
    } },
  })

  mod.content.maps:patch("CINNABAR_ISLAND", {
    objects = { __append = {
      {
        index = 90, x = 10, y = 7,
        sprite = "SPRITE_GAMBLER",
        movement = "STAY", range = "NONE",
        text = TEXT_ARTISAN, name = "CRYSTAL_ONIX_ARTISAN",
      },
    } },
  })

  mod.content.maps:patch("FUCHSIA_CITY", {
    objects = { __append = {
      {
        index = 90, x = 18, y = 17,
        sprite = "SPRITE_SCIENTIST",
        movement = "STAY", range = "NONE",
        text = TEXT_RESEARCHER, name = "CRYSTAL_ONIX_RESEARCHER",
      },
    } },
  })

  ---------------------------------------------------------------------------
  -- Dialogue and quest progression.
  ---------------------------------------------------------------------------
  mod.content.map_scripts:register("VERMILION_CITY", {
    talk = {
      [TEXT_SAILOR] = {
        { "face_player" },

        { "check_flag", FLAG_REWARDED },
        { "jump_if_true", "finished" },

        { "check_flag", FLAG_DEFEATED },
        { "jump_if_true", "reward" },

        { "check_flag", FLAG_CHARM },
        { "jump_if_true", "go_cave" },

        { "check_flag", FLAG_SHARD },
        { "jump_if_true", "make_charm" },

        { "check_flag", FLAG_RESEARCH },
        { "jump_if_true", "find_shard" },

        { "check_flag", FLAG_ARTISAN },
        { "jump_if_true", "find_researcher" },

        { "check_flag", FLAG_STARTED },
        { "jump_if_true", "find_artisan" },

        { "ask",
          "Old Sailor: Have\n you heard of the\n CRYSTAL ONIX?" },
        { "jump_if_false", "declined" },
        { "set_flag", FLAG_STARTED },
        { "show_text",
          "I saw its blue\n reflection beneath\n SEAFOAM long ago.\n\nFind the crystal\n artisan on CINNABAR.\n He knows the legend." },
        { "jump", "end" },

        { "label", "declined" },
        { "show_text",
          "Come back when the\n sea's mysteries call\n to you." },
        { "jump", "end" },

        { "label", "find_artisan" },
        { "show_text",
          "The artisan waits\n on CINNABAR ISLAND.\n Ask about stone that\n shines without fire." },
        { "jump", "end" },

        { "label", "find_researcher" },
        { "show_text",
          "Good. Now seek the\n marine researcher in\n FUCHSIA CITY.\n\nShe studies SEAFOAM's\n frozen minerals." },
        { "jump", "end" },

        { "label", "find_shard" },
        { "show_text",
          "A LUMINOUS SHARD\n rests on SEAFOAM's\n lowest floor, near a\n warning sign." },
        { "jump", "end" },

        { "label", "make_charm" },
        { "play_sound", "Get_Item1" },
        { "set_flag", FLAG_CHARM },
        { "show_text",
          "The sailor binds the\n shard with an old\n tidal cord.\n\nYou received the\n TIDAL CHARM!" },
        { "show_text",
          "Carry it to SEAFOAM\n B4F. The living\n crystal will sense\n that you mean no harm." },
        { "jump", "end" },

        { "label", "go_cave" },
        { "show_text",
          "SEAFOAM B4F.\n Follow the cold blue\n light. The TIDAL\n CHARM will guide you." },
        { "jump", "end" },

        { "label", "reward" },
        { "show_text",
          "You faced the legend\n and earned its trust.\n It has chosen you." },
        { "give_pokemon", SPECIES, 45, true },
        { "jump_if_false", "storage_full" },
        { "perfect_latest_crystal_onix" },
        { "jump_if_false", "storage_full" },
        { "set_flag", FLAG_REWARDED },
        { "show_text",
          "CRYSTAL ONIX joined\n you with perfect DVs\n and maximum Stat EXP!" },
        { "jump", "end" },

        { "label", "storage_full" },
        { "show_text",
          "Your party and every\n PC BOX are full.\n Make room, then speak\n to me again." },
        { "jump", "end" },

        { "label", "finished" },
        { "show_text",
          "The sea chose well.\n Guard CRYSTAL ONIX,\n and its light will\n never fade." },
      },
    },
  })

  mod.content.map_scripts:register("CINNABAR_ISLAND", {
    talk = {
      [TEXT_ARTISAN] = {
        { "face_player" },
        { "check_flag", FLAG_STARTED },
        { "jump_if_false", "not_started" },
        { "check_flag", FLAG_ARTISAN },
        { "jump_if_true", "repeat" },

        { "show_text",
          "Crystal Artisan: The\n legend is true.\n\nAn ONIX slept where\n volcanic glass met\n ancient sea ice." },
        { "show_text",
          "Its stone body drank\n the mineral light and\n became transparent,\n colder than snow." },
        { "set_flag", FLAG_ARTISAN },
        { "show_text",
          "A researcher in\n FUCHSIA can identify\n the mineral resonance." },
        { "jump", "end" },

        { "label", "repeat" },
        { "show_text",
          "FUCHSIA's researcher\n studies the frozen\n minerals of SEAFOAM." },
        { "jump", "end" },

        { "label", "not_started" },
        { "show_text",
          "I shape ordinary\n stone. Yet somewhere,\n stone itself learned\n to shine..." },
      },
    },
  })

  mod.content.map_scripts:register("FUCHSIA_CITY", {
    talk = {
      [TEXT_RESEARCHER] = {
        { "face_player" },
        { "check_flag", FLAG_ARTISAN },
        { "jump_if_false", "not_ready" },
        { "check_flag", FLAG_RESEARCH },
        { "jump_if_true", "repeat" },

        { "show_text",
          "Marine Researcher:\n This resonance can\n only come from the\n deepest SEAFOAM ice." },
        { "show_text",
          "Find a LUMINOUS\n SHARD on B4F, near\n the old danger sign.\n Do not break it." },
        { "set_flag", FLAG_RESEARCH },
        { "jump", "end" },

        { "label", "repeat" },
        { "show_text",
          "SEAFOAM B4F. Search\n near the danger sign\n for a blue shard." },
        { "jump", "end" },

        { "label", "not_ready" },
        { "show_text",
          "These Pokémon prefer\n cold water. I also\n study unusual mineral\n life-forms." },
      },
    },
  })

  mod.content.map_scripts:register("SEAFOAM_ISLANDS_B4F", {
    talk = {
      [TEXT_SHARD] = {
        { "check_flag", FLAG_RESEARCH },
        { "jump_if_false", "dull" },
        { "check_flag", FLAG_SHARD },
        { "jump_if_true", "empty" },
        { "play_sound", "Get_Item1" },
        { "set_flag", FLAG_SHARD },
        { "show_text",
          "A blue shard hums\n beneath the ice.\n\nYou found the\n LUMINOUS SHARD!" },
        { "show_text",
          "Return it to the old\n sailor in VERMILION." },
        { "jump", "end" },

        { "label", "dull" },
        { "show_text",
          "A pale mineral is\n frozen here, but you\n do not know how to\n handle it safely." },
        { "jump", "end" },

        { "label", "empty" },
        { "show_text",
          "Only a shallow mark\n remains in the ice." },
      },

      [TEXT_BOSS] = {
        { "check_flag", FLAG_CHARM },
        { "jump_if_false", "sealed" },
        { "check_flag", FLAG_DEFEATED },
        { "jump_if_true", "calm" },

        { "face_npc" },
        { "play_cry", SPECIES },
        { "show_text",
          "The cavern flashes!\n CRYSTAL ONIX rises\n from the frozen sea!" },
        { "start_battle", "wild", SPECIES, 45 },

        { "check_battle_result", "caught" },
        { "jump_if_true", "caught" },
        { "check_battle_result", "win" },
        { "jump_if_true", "won" },

        { "show_text",
          "CRYSTAL ONIX slips\n back beneath the ice.\n The TIDAL CHARM still\n glows. Try again." },
        { "jump", "end" },

        { "label", "caught" },
        { "check_flag", FLAG_CAPTURED },
        { "jump_if_true", "caught_stored" },
        { "show_text",
          "Every PC BOX was\n full, so the capture\n could not be stored.\n Make room and try again." },
        { "jump", "end" },

        { "label", "caught_stored" },
        { "set_flag", FLAG_DEFEATED },
        { "set_flag", FLAG_REWARDED },
        { "show_text",
          "The captured CRYSTAL\n ONIX accepts you.\n Its DVs and Stat EXP\n have reached maximum!" },
        { "jump", "end" },

        { "label", "won" },
        { "set_flag", FLAG_DEFEATED },
        { "show_text",
          "CRYSTAL ONIX bows,\n then vanishes into\n the light.\n\nSpeak to the old\n sailor in VERMILION." },
        { "jump", "end" },

        { "label", "sealed" },
        { "show_text",
          "A vast shape moves\n under the ice, but a\n strange current keeps\n you away." },
        { "jump", "end" },

        { "label", "calm" },
        { "show_text",
          "The crystal chamber\n is peaceful now." },
      },
    },
  })

  ---------------------------------------------------------------------------
  -- Live world state: spawn quest-only objects on Seafoam B4F.
  ---------------------------------------------------------------------------
  local gameRef
  local SEAFOAM_MAP = "SEAFOAM_ISLANDS_B4F"

  -- Runtime quest actors are appended to Data.maps by WorldAPI. They therefore
  -- survive leaving and re-entering the map for the duration of the current
  -- game session.  v1.0.2 spawned the shard and later the boss on the same
  -- cell without removing the old shard object, so the POKE BALL could sit
  -- on top of Crystal Onix and steal the interaction.
  --
  -- Remove every live/runtime actor with the quest names before rebuilding
  -- the correct stage.  Looking them up by name also cleans stale objects
  -- created by an older version during a hot reload, not only ids spawned by
  -- this exact Lua instance.
  local function removeSeafoamActor(name)
    while true do
      local npc = mod.world:npc(SEAFOAM_MAP, name)
      if not npc then break end
      local ok = mod.world:removeNpc(npc.id)
      if not ok then break end
    end
  end

  local function spawnSeafoamActors()
    if not gameRef or not gameRef.save then return end
    local save = gameRef.save

    removeSeafoamActor("CRYSTAL_ONIX_SHARD")
    removeSeafoamActor("CRYSTAL_ONIX_BOSS")

    if flag(save, FLAG_RESEARCH) and not flag(save, FLAG_SHARD) then
      mod.world:spawnNpc(SEAFOAM_MAP, {
        x = 23, y = 3,
        sprite = "SPRITE_POKE_BALL",
        movement = "STAY", range = "NONE",
        text = TEXT_SHARD, name = "CRYSTAL_ONIX_SHARD",
      })
    elseif flag(save, FLAG_CHARM) and not flag(save, FLAG_DEFEATED) then
      mod.world:spawnNpc(SEAFOAM_MAP, {
        x = 23, y = 3,
        sprite = "SPRITE_CRYSTAL_ONIX",
        movement = "STAY", range = "DOWN",
        text = TEXT_BOSS, name = "CRYSTAL_ONIX_BOSS",
      })
    end
  end

  mod.events:on("game.ready", function(ev)
    gameRef = ev.game
    refreshCrystalStats(ev.game)
  end)

  mod.events:on("map.entered", function(ev)
    if ev.mapId == SEAFOAM_MAP then
      spawnSeafoamActors()
    end
  end)

  ---------------------------------------------------------------------------
  -- A caught quest Crystal Onix is perfected in-place, avoiding a duplicate
  -- gift when the player catches rather than defeats the encounter.
  ---------------------------------------------------------------------------
  mod.events:on("pokemon.caught", function(ev)
    if ev.species ~= SPECIES or not ev.mon or not ev.game then return end
    local save = ev.game.save
    if not flag(save, FLAG_CHARM) or flag(save, FLAG_REWARDED) then return end

    local stored = false
    for _, mon in ipairs(save.party or {}) do
      if mon == ev.mon then stored = true break end
    end
    if not stored then
      for _, box in ipairs(save.boxes or {}) do
        for _, mon in ipairs(box or {}) do
          if mon == ev.mon then stored = true break end
        end
        if stored then break end
      end
    end
    if not stored then return end

    perfectCrystalMon(ev.mon, ev.game)
    save.flags = save.flags or {}
    save.flags[FLAG_CAPTURED] = true
  end)
end
