# Changelog

## v1.0.0

- Added a universal TM Shop choice to every standard Poké Mart clerk.
- Added all 50 Generation I TMs at no cost.
- Kept normal local shop inventories in a separate menu.
- Removed TMs from normal shop stock so the new section remains dedicated.
- Set TM sell value to zero to prevent free-money exploits.
- Increased Bag capacity to 255 slots.
