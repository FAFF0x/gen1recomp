local pushed = {}

local Bag = {}
function Bag.add(save, id, qty)
  save.inventory[id] = (save.inventory[id] or 0) + qty
  return save.inventory[id] <= 99
end
package.preload["src.inventory.Bag"] = function() return Bag end

local function makeClass(name)
  return {
    new = function(game, ...)
      local obj = { class = name, args = { ... } }
      if name == "ListMenu" then
        local title, items, opts = ...
        obj.title, obj.items, obj.opts = title, items, opts
        obj.footer = opts.footer
      elseif name == "Menu" then
        local items, opts = ...
        obj.items, obj.opts = items, opts
      elseif name == "QuantityBox" or name == "ChoiceBox" then
        obj.opts = select(1, ...)
      end
      return obj
    end,
  }
end

package.preload["src.ui.ChoiceBox"] = function() return makeClass("ChoiceBox") end
package.preload["src.ui.ListMenu"] = function() return makeClass("ListMenu") end
package.preload["src.ui.Menu"] = function() return makeClass("Menu") end
package.preload["src.ui.QuantityBox"] = function() return makeClass("QuantityBox") end
package.preload["src.core.Strings"] = function()
  return function(fmt, ...)
    if select("#", ...) == 0 then return fmt end
    return string.format(fmt, ...)
  end
end
package.preload["src.core.Sound"] = function()
  return { play = function() end }
end
package.preload["src.ui.ShopMenu"] = function()
  return { new = function(game, stock, onQuit)
    return { class = "VanillaShop", stock = stock, onQuit = onQuit }
  end }
end

local items = { POTION = { name = "POTION", price = 300 } }
local moves = {}
for i = 1, 50 do
  local id = ("TM_MOVE_%02d"):format(i)
  local move = ("MOVE_%02d"):format(i)
  items[id] = {
    name = ("TM%02d"):format(i),
    price = i * 100,
    machine = { kind = "TM", number = i, move = move },
  }
  moves[move] = { name = ("MOVE %02d"):format(i) }
end
items.HM_CUT = {
  name = "HM01", price = 0,
  machine = { kind = "HM", number = 1, move = "CUT" },
}

local itemRegistry = { patches = {} }
function itemRegistry:each()
  return next, items, nil
end
function itemRegistry:patch(id, patch)
  self.patches[id] = patch
  for k, v in pairs(patch) do items[id][k] = v end
end
local constants = { patches = {} }
function constants:patch(id, value) self.patches[id] = value end
local screens = { values = {} }
function screens:register(id, value) self.values[id] = value end

local mod = {
  content = { items = itemRegistry, constants = constants, screens = screens },
  exports = {},
}

local chunk, err = loadfile("main.lua")
assert(chunk, err)
chunk()(mod)

assert(constants.patches.bagSize == 255)
assert(mod.exports.tmCount == 50)
assert(items.TM_MOVE_01.price == 0 and items.TM_MOVE_50.price == 0)
assert(items.HM_CUT.price == 0)

local list = mod.exports.listTMs({ items = items })
assert(#list == 50)
assert(list[1].number == 1 and list[50].number == 50)
local filtered = mod.exports.normalStock({ data = { items = items } },
  { "POTION", "TM_MOVE_01", "HM_CUT", "TM_MOVE_50" })
assert(#filtered == 2 and filtered[1] == "POTION" and filtered[2] == "HM_CUT")

local game = {
  data = { items = items, moves = moves },
  save = { inventory = {}, money = 0 },
  stack = {
    push = function(_, obj) pushed[#pushed + 1] = obj end,
  },
}
local screen = assert(screens.values.ShopMenu)
local chooser = screen.new(game, { "POTION", "TM_MOVE_01" }, function() end)
assert(chooser.class == "Menu")
assert(chooser.items[1].label == "NORMAL SHOP")
assert(chooser.items[2].label == "TM SHOP")
assert(chooser.items[3].label == "LEAVE")

chooser.items[1].onSelect()
assert(pushed[#pushed].class == "VanillaShop")
assert(#pushed[#pushed].stock == 1 and pushed[#pushed].stock[1] == "POTION")

chooser.items[2].onSelect()
local tmShop = pushed[#pushed]
assert(tmShop.class == "ListMenu" and tmShop.title == "TM SHOP")
assert(#tmShop.items == 50)
assert(tmShop.items[1].label == "TM01 MOVE 01")
assert(tmShop.items[50].label == "TM50 MOVE 50")
assert(tmShop.opts.pageJump and tmShop.opts.keyRepeat)

-- Buying from the free catalogue uses the quantity and confirmation flow.
tmShop.opts.onChoose(tmShop.items[1])
local quantity = pushed[#pushed]
assert(quantity.class == "QuantityBox")
assert(quantity.opts.max == 99 and quantity.opts.unitPrice == 0)
quantity.opts.onDone(3)
local confirm = pushed[#pushed]
assert(confirm.class == "ChoiceBox")
confirm.opts(true)
assert(game.save.inventory.TM_MOVE_01 == 3)
assert(tmShop.footer:find("TM01", 1, true))

-- The catalogue refuses another purchase once the stack reaches 99.
game.save.inventory.TM_MOVE_01 = 99
tmShop.opts.onChoose(tmShop.items[1])
assert(tmShop.footer:find("99", 1, true))

print("all_tm_shop_test: ok")
