# Changelog

## 1.1.0
- Added **START = MAX ALL** for the Pokémon currently open in the DV/EV Editor.
- Sets all editable DVs to 15; derived HP DV consequently becomes 15.
- Sets all five Gen I Stat EXP values to 65535.
- Recalculates actual stats immediately through the existing `Stats.calc` path.
- Preserves the editor's existing HP behavior: missing HP remains missing and fainted Pokémon remain fainted.
- START works on either page and even while manual digit editing is active.
- Updated native and Gen1 Modern UI footers to advertise `START MAX ALL`.
- Added a short on-screen confirmation after maximizing.
- Exported `maximizeDvEv` and `startMaxShortcut` for compatibility/diagnostics.

## 1.0.1
- Added optional Gen1 Modern UI 0.8.1 compatibility through API v1.
- Added Modern UI models for both the DV and Stat EXP pages.
- Added semantic pointer/touch actions for row selection, page switching, digit selection, value editing, confirm and back.
- Preserved the original editor as the automatic fallback when Modern UI is unavailable.
- Kept all existing save data and stat-recalculation behavior unchanged.

## 1.0.0
- Added a DV/EV entry to the out-of-battle party submenu.
- Added exact editing for four DVs and five Stat EXP values.
- Added automatic HP DV derivation and immediate stat recalculation.
- Added display of effective Gen I EV contribution and resulting stats.
