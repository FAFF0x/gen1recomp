-- Modern UI Icon Fix v1.0.0
--
-- Compatibility shim for the released Gen1 Modern UI 0.8.x branch.
-- It does NOT replace or modify Gen1 Modern UI files.
--
-- Fixes:
--   1) table-valued pokemon.icon artwork is treated as authored true-color
--      art even if Modern UI's shared image cache later associates the same
--      Image userdata with a species palette in another presenter;
--   2) stock/variant Pokédex ListMenu rows receive the live authored icon
--      descriptor beside seen/owned species names.
--
-- The true-color fix is applied at the public render.hud hook boundary. The
-- wrapper temporarily observes images loaded by Modern UI and neutralizes a
-- palette shader only for images whose paths come from table-valued
-- pokemon.icon descriptors. Other Modern UI palettes and shaders are left
-- untouched.

local VERSION = "1.0.0"

local unpack = table.unpack or unpack
local function pack(...)
  return { n = select("#", ...), ... }
end

return function(mod)
  local taggedImages = setmetatable({}, { __mode = "k" })
  local cachedIconsTable = nil
  local cachedPokemonTable = nil
  local authoredPaths = {}

  local function descriptorPath(entry)
    if type(entry) ~= "table" then return nil end
    local path = entry.image or entry.path or entry.texture or entry.asset
    return type(path) == "string" and path ~= "" and path or nil
  end

  local function rebuildAuthoredPaths(game)
    local data = game and game.data
    local icons = data and data.icons
    local pokemon = data and data.pokemon
    if icons == cachedIconsTable and pokemon == cachedPokemonTable then
      return authoredPaths
    end

    cachedIconsTable = icons
    cachedPokemonTable = pokemon
    authoredPaths = {}

    if type(icons) == "table" and type(icons.bySpecies) == "table" then
      for _, entry in pairs(icons.bySpecies) do
        local path = descriptorPath(entry)
        if path then authoredPaths[path] = true end
      end
    end
    if type(pokemon) == "table" then
      for _, def in pairs(pokemon) do
        local path = descriptorPath(type(def) == "table" and def.icon or nil)
        if path then authoredPaths[path] = true end
      end
    end
    return authoredPaths
  end

  local function iconDescriptor(game, species)
    local data = game and game.data
    local pokemon = data and data.pokemon
    if type(species) ~= "string" or type(pokemon) ~= "table"
        or type(pokemon[species]) ~= "table" then
      return nil
    end
    local icons = data.icons
    local entry = type(icons) == "table" and type(icons.bySpecies) == "table"
      and icons.bySpecies[species] or nil
    if type(entry) ~= "table" then entry = pokemon[species].icon end
    return descriptorPath(entry) and entry or nil
  end

  local function looksLikePokedex(state)
    if type(state) ~= "table" or type(state.items) ~= "table" then return false end
    if state.screenId == "PokedexMenu" then return true end
    local title = tostring(state.title or ""):upper()
    -- Covers custom stock-Pokédex replacements such as regional/variant
    -- lists while deliberately avoiding unrelated generic ListMenus.
    return title:find("DEX", 1, true) ~= nil
      and (title:find("POK", 1, true) ~= nil or title:find("DEX", 1, true) == 1)
  end

  local function decoratePokedexRows(game)
    local stack = game and game.stack
    local states = stack and stack.states
    if type(states) ~= "table" then return end
    for _, state in ipairs(states) do
      if looksLikePokedex(state) then
        for _, item in ipairs(state.items or {}) do
          local species = type(item) == "table" and item.value or nil
          local label = type(item) == "table" and tostring(item.label or "") or ""
          if type(species) == "string" and not label:find("-----", 1, true) then
            local descriptor = iconDescriptor(game, species)
            if descriptor then
              -- Do not add item.species here. Modern UI 0.8.x applies a
              -- species palette to explicit row images carrying source.species;
              -- keeping the row image descriptor-only preserves its RGB art.
              item.icon = descriptor
            end
          end
        end
      end
    end
  end

  local function runWithTrueColorGuard(game, callback)
    local graphics = love and love.graphics
    if not (graphics and type(graphics.draw) == "function"
        and type(graphics.newImage) == "function") then
      return callback()
    end

    local paths = rebuildAuthoredPaths(game)
    local originalNewImage = graphics.newImage
    local originalDraw = graphics.draw
    local originalSetShader = graphics.setShader
    local originalGetShader = graphics.getShader

    graphics.newImage = function(source, ...)
      local image = originalNewImage(source, ...)
      if type(source) == "string" and paths[source] then
        taggedImages[image] = true
      end
      return image
    end

    graphics.draw = function(drawable, ...)
      if taggedImages[drawable] and type(originalSetShader) == "function" then
        local previous = type(originalGetShader) == "function"
          and originalGetShader() or nil
        -- Full-colour authored icon: draw its RGB values directly. This only
        -- scopes to the one icon draw; the previous shader is restored before
        -- Modern UI continues drawing the row/panel.
        originalSetShader()
        local result = pack(pcall(originalDraw, drawable, ...))
        originalSetShader(previous)
        if not result[1] then error(result[2], 0) end
        return unpack(result, 2, result.n)
      end
      return originalDraw(drawable, ...)
    end

    local result = pack(pcall(callback))
    graphics.newImage = originalNewImage
    graphics.draw = originalDraw
    if not result[1] then error(result[2], 0) end
    return unpack(result, 2, result.n)
  end

  -- Modern UI 0.8.x registers render.hud at priority 100. A much higher
  -- priority makes this wrapper the outer guard, so all of Modern UI's HUD
  -- drawing happens inside the temporary true-colour interception.
  mod.hooks:wrap("render.hud", function(next, game, viewport)
    decoratePokedexRows(game)
    return runWithTrueColorGuard(game, function()
      return next(game, viewport)
    end)
  end, 1000)

  mod.exports = mod.exports or {}
  mod.exports.version = VERSION
  mod.exports.modernUiIconFix = {
    version = VERSION,
    trueColorAuthoredPokemonIcons = true,
    stockPokedexIcons = true,
  }
end
