# Changelog

## 1.0.0
- Initial compatibility patch for Gen1 Modern UI 0.8.x.
- Preserves full-colour table-valued Pokémon icons at render time.
- Adds authored icons to stock Pokédex rows without modifying Modern UI source files.
