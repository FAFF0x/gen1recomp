-- Performance Monitor v1.5.0 Android Edition
--
-- F3  : show / hide
-- F4  : compact / detailed
-- F6  : reset rolling samples
-- F8  : start/stop a 10-second deep diagnostic capture
-- F9  : export/re-export the frozen diagnostic report
--
-- Android:
--   * a persistent PERF touch button replaces the unavailable F-keys;
--   * HUD / VIEW / RESET / CAPTURE / SAVE are touch-driven;
--   * finishing a capture still writes the sandbox-safe internal report;
--   * when the Android host exposes love.system.createFile, the JSON is staged
--     through the engine-owned persistence filesystem and Android's system
--     ACTION_CREATE_DOCUMENT "Save As" picker opens automatically.
--
-- Three complementary profilers are combined:
--   1. Runtime owner profiler: exclusive CPU time for every mod hook/event.
--   2. Slow-frame correlation: which mod was the largest measured contributor
--      on frames that missed the 60 FPS budget.
--   3. Provenance callback profiler: sandbox-safe timing of mod-authored
--      callbacks found through content-registry/export ownership.
--   4. Optional deep Lua sampler on older/dev hosts that still expose debug.
--
-- No user-space mod can perfectly attribute GPU driver time or C-side engine
-- work. The report therefore keeps an explicit UNATTRIBUTED slow-frame count
-- instead of inventing blame when evidence is missing.

local VERSION = "1.5.0"
local MOD_ID = "performance_monitor"
local GENERATION = {}
local unpack = table.unpack or unpack

local function pack(...)
  return { n = select("#", ...), ... }
end

local function clamp0(v)
  v = tonumber(v) or 0
  return v > 0 and v or 0
end

return function(mod)
  local gameRef
  local visible = true
  local detailed = true
  local now = (love and love.timer and love.timer.getTime) or os.clock

  local function hostOS()
    if love and love.system and love.system.getOS then
      local ok, value = pcall(love.system.getOS)
      if ok then return tostring(value or "?") end
    end
    return "?"
  end

  local IS_ANDROID = hostOS() == "Android"

  -- Android UI / native export state. Coordinates are LOVE window units, the
  -- same space used by render.hud and the public input.pointer hook.
  local androidUi = {
    open = false,
    rects = {},
    pressed = {},
    status = nil,
    statusUntil = 0,
  }

  local androidExport = {
    pending = false,
    openedAt = 0,
    suggestedName = nil,
    status = nil,
    error = nil,
    savedAt = nil,
    lastPoll = 0,
  }

  local TARGET_MS = 1000 / 60
  local SLOW_MS = 18.5
  local SEVERE_MS = 33.3
  local DEEP_INSTRUCTION_INTERVAL = 10000
  local DIAGNOSTIC_SECONDS = 10.0

  -- -----------------------------------------------------------------------
  -- Global frame / renderer stats
  -- -----------------------------------------------------------------------
  local lastHudTime = nil
  local lastStatsTime = 0
  local lastSecondTime = now()
  local frameSamples, frameSampleMax, frameSamplePos, frameSampleCount = {}, 300, 1, 0
  local logicSteps, logicPerSecond, logicWindowSteps = 0, 0, 0
  local f3WasDown, f4WasDown, f6WasDown, f8WasDown, f9WasDown = false, false, false, false, false

  local snapshot = {
    fps = 0, frameMs = 0, avgMs = 0, worstMs = 0, low1 = 0,
    luaMB = 0, textureMB = 0,
    drawcalls = 0, batched = 0, canvasswitches = 0,
    images = 0, canvases = 0, fonts = 0, shaderswitches = 0,
    speed = 1, top = "-", map = "-",
    modCpuMsPerSec = 0, modCpuPercent = 0,
  }

  local function pushFrameSample(ms)
    frameSamples[frameSamplePos] = ms
    frameSamplePos = frameSamplePos % frameSampleMax + 1
    if frameSampleCount < frameSampleMax then frameSampleCount = frameSampleCount + 1 end
  end

  local function computeFrameStats()
    if frameSampleCount == 0 then return 0, 0, 0 end
    local values, sum, worst = {}, 0, 0
    for i = 1, frameSampleCount do
      local v = frameSamples[i] or 0
      values[#values + 1] = v
      sum = sum + v
      if v > worst then worst = v end
    end
    table.sort(values)
    local avg = sum / #values
    local slowCount = math.max(1, math.ceil(#values * 0.01))
    local slowSum = 0
    for i = #values - slowCount + 1, #values do slowSum = slowSum + values[i] end
    local slowMs = slowSum / slowCount
    local low1 = slowMs > 0 and (1000 / slowMs) or 0
    return avg, worst, low1
  end

  local function safeGraphicsStats()
    if not (love and love.graphics and love.graphics.getStats) then return {} end
    local ok, stats = pcall(love.graphics.getStats)
    return ok and type(stats) == "table" and stats or {}
  end

  local function graphicsCounters()
    local s = safeGraphicsStats()
    return tonumber(s.drawcalls) or 0,
           tonumber(s.canvasswitches) or 0,
           tonumber(s.shaderswitches) or 0
  end

  local function topStateName(game)
    local top = game and game.stack and game.stack.top and game.stack:top()
    if type(top) ~= "table" then return "-" end
    return tostring(top.screenId or top.title or "-")
  end

  local function mapName(game)
    local ow = game and game.overworld
    local map = ow and ow.map
    return tostring((map and (map.id or (map.def and map.def.label))) or "-")
  end

  -- -----------------------------------------------------------------------
  -- Portable diagnostic export helpers
  -- -----------------------------------------------------------------------
  -- Gen1Recomp's current mod sandbox blocks love.filesystem. Use the
  -- public per-mod persistent storage API instead. writeBytes stores opaque
  -- bytes with a .bin extension, but the JSON payload remains plain UTF-8.
  local REPORT_LATEST_JSON_KEY = "exports/performance_report_latest_json"
  local REPORT_LATEST_TEXT_KEY = "exports/performance_report_latest_txt"
  local REPORT_ARCHIVE_DIR = "reports"

  local exportState = {
    relativeJson = nil,
    relativeText = nil,
    archiveJson = nil,
    archiveText = nil,
    storageJsonKey = nil,
    storageTextKey = nil,
    error = nil,
    exportedAt = nil,
    androidSaveAs = nil,
    androidSuggestedName = nil,
  }

  local function jsonEscape(value)
    local text = tostring(value or "")
    return '"' .. text:gsub('[%z\1-\31\\"]', function(ch)
      if ch == '"' then return '\\"' end
      if ch == "\\" then return "\\\\" end
      if ch == "\b" then return "\\b" end
      if ch == "\f" then return "\\f" end
      if ch == "\n" then return "\\n" end
      if ch == "\r" then return "\\r" end
      if ch == "\t" then return "\\t" end
      return string.format("\\u%04x", ch:byte())
    end) .. '"'
  end

  local function tableIsArray(value)
    local max, count = 0, 0
    for k in pairs(value) do
      if type(k) ~= "number" or k < 1 or k % 1 ~= 0 then return false, 0 end
      if k > max then max = k end
      count = count + 1
    end
    if max ~= count then return false, 0 end
    return true, max
  end

  local function jsonEncode(value, seen)
    local tv = type(value)
    if tv == "nil" then return "null" end
    if tv == "boolean" then return value and "true" or "false" end
    if tv == "number" then
      if value ~= value or value == math.huge or value == -math.huge then
        return "null"
      end
      return string.format("%.10g", value)
    end
    if tv == "string" then return jsonEscape(value) end
    if tv ~= "table" then return jsonEscape(tostring(value)) end

    seen = seen or {}
    if seen[value] then return jsonEscape("<cycle>") end
    seen[value] = true

    local isArray, n = tableIsArray(value)
    local parts = {}
    if isArray then
      for i = 1, n do parts[#parts + 1] = jsonEncode(value[i], seen) end
      seen[value] = nil
      return "[" .. table.concat(parts, ",") .. "]"
    end

    local keys = {}
    for k in pairs(value) do keys[#keys + 1] = tostring(k) end
    table.sort(keys)
    for _, key in ipairs(keys) do
      local v = value[key]
      if v ~= nil then
        parts[#parts + 1] = jsonEscape(key) .. ":" .. jsonEncode(v, seen)
      end
    end
    seen[value] = nil
    return "{" .. table.concat(parts, ",") .. "}"
  end

  local function copyStringArray(value)
    local out = {}
    for _, v in ipairs(type(value) == "table" and value or {}) do
      out[#out + 1] = tostring(v)
    end
    return out
  end

  local function captureLoadedMods()
    local out, order = {}, {}
    local loader = gameRef and gameRef.mods
    if not loader then return out, order end

    local ok, status = pcall(loader.status, loader)
    if not ok or type(status) ~= "table" then return out, order end
    order = copyStringArray(status.order)

    for _, mf in ipairs(type(status.loaded) == "table" and status.loaded or {}) do
      out[#out + 1] = {
        id = tostring(mf.id or "?"),
        name = tostring(mf.name or mf.id or "?"),
        version = tostring(mf.version or "?"),
        api = tonumber(mf.api) or 1,
        profile = tostring(mf.profile or "content"),
        priority = tonumber(mf.priority) or 0,
        affectsLink = mf.affects_link == true,
        dependencies = copyStringArray(mf.dependencies),
        optionalDependencies = copyStringArray(mf.optional_dependencies),
        permissions = copyStringArray(mf.permissions),
      }
    end
    table.sort(out, function(a, b) return a.id < b.id end)
    return out, order
  end

  local function captureEnvironment(game)
    local env = {
      lua = tostring(_VERSION or "?"),
      gameVersion = "?",
      engineVersion = "?",
      modApi = nil,
      os = "?",
      loveVersion = "?",
      renderer = {},
      window = {},
      gameOptions = {},
    }

    if jit and jit.version then env.jit = tostring(jit.version) end

    local okVersion, Version = pcall(require, "src.core.Version")
    if okVersion and type(Version) == "table" then
      env.engineVersion = tostring(Version.engine or "?")
      env.modApi = tonumber(Version.modApi)
    end

    local okGameVersion, GameVersion = pcall(require, "src.core.GameVersion")
    if okGameVersion and type(GameVersion) == "table" and GameVersion.get then
      local ok, value = pcall(GameVersion.get)
      if ok then env.gameVersion = tostring(value) end
    end

    if love then
      if love.system and love.system.getOS then
        local ok, value = pcall(love.system.getOS)
        if ok then env.os = tostring(value) end
      end
      if love.getVersion then
        local ok, major, minor, revision, codename = pcall(love.getVersion)
        if ok then
          env.loveVersion = ("%s.%s.%s %s"):format(
            tostring(major or "?"), tostring(minor or "?"),
            tostring(revision or "?"), tostring(codename or ""))
        end
      end
      if love.graphics then
        if love.graphics.getRendererInfo then
          local ok, name, version, vendor, device = pcall(love.graphics.getRendererInfo)
          if ok then
            env.renderer = {
              name = tostring(name or "?"),
              version = tostring(version or "?"),
              vendor = tostring(vendor or "?"),
              device = tostring(device or "?"),
            }
          end
        end
        if love.graphics.getDimensions then
          local ok, w, h = pcall(love.graphics.getDimensions)
          if ok then env.window.width, env.window.height = w, h end
        end
        if love.graphics.getPixelDimensions then
          local ok, w, h = pcall(love.graphics.getPixelDimensions)
          if ok then env.window.pixelWidth, env.window.pixelHeight = w, h end
        end
        if love.graphics.getDPIScale then
          local ok, dpi = pcall(love.graphics.getDPIScale)
          if ok then env.window.dpiScale = dpi end
        end
      end
    end

    local opts = game and game.save and game.save.options
    if type(opts) == "table" then
      for _, key in ipairs({
        "speed", "battleLayout", "battleFit", "battleBg",
        "uiLayout", "zoom", "colors", "tilt"
      }) do
        local v = opts[key]
        if type(v) == "string" or type(v) == "number" or type(v) == "boolean" then
          env.gameOptions[key] = v
        end
      end
    end
    return env
  end

  local function frameDistribution(values, duration)
    local n = #(values or {})
    if n == 0 then
      return {
        frames = 0, presentedFps = 0, averageMs = 0, medianMs = 0,
        p95Ms = 0, p99Ms = 0, worstMs = 0, onePercentLowFps = 0,
        missedBudgetFrames = 0, missedBudgetPct = 0,
      }
    end

    local sorted, sum = {}, 0
    local missed = 0
    for i, v in ipairs(values) do
      v = tonumber(v) or 0
      sorted[i] = v
      sum = sum + v
      if v > TARGET_MS then missed = missed + 1 end
    end
    table.sort(sorted)
    local function percentile(pct)
      local idx = math.max(1, math.min(n, math.ceil(n * pct)))
      return sorted[idx]
    end

    local slowCount = math.max(1, math.ceil(n * 0.01))
    local slowSum = 0
    for i = n - slowCount + 1, n do slowSum = slowSum + sorted[i] end
    local onePctMs = slowSum / slowCount

    return {
      frames = n,
      presentedFps = duration and duration > 0 and (n / duration) or 0,
      averageMs = sum / n,
      medianMs = percentile(0.50),
      p95Ms = percentile(0.95),
      p99Ms = percentile(0.99),
      worstMs = sorted[n],
      onePercentLowFps = onePctMs > 0 and (1000 / onePctMs) or 0,
      missedBudgetFrames = missed,
      missedBudgetPct = missed * 100 / n,
    }
  end

  local function topMapRows(map, limit, scaleKey)
    local rows = {}
    for id, value in pairs(map or {}) do
      rows[#rows + 1] = { modId = tostring(id), value = tonumber(value) or 0 }
    end
    table.sort(rows, function(a, b) return a.value > b.value end)
    local out = {}
    for i = 1, math.min(limit or 3, #rows) do
      local row = rows[i]
      if scaleKey == "ms" then
        out[#out + 1] = { modId = row.modId, ms = row.value * 1000 }
      else
        out[#out + 1] = { modId = row.modId, samples = row.value }
      end
    end
    return out
  end

  local function buildTextReport(report)
    local lines = {}
    local function add(fmt, ...)
      if select("#", ...) > 0 then
        lines[#lines + 1] = string.format(fmt, ...)
      else
        lines[#lines + 1] = tostring(fmt)
      end
    end

    add("GEN1RECOMP PERFORMANCE REPORT")
    add("Monitor: %s", tostring(report.monitorVersion))
    add("Capture: %s", tostring(report.captureId))
    add("Generated: %s", tostring(report.generatedUtc))
    add("Duration: %.3f s", tonumber(report.capture.durationSeconds) or 0)
    add("Engine: %s | Game: %s | LÖVE: %s | OS: %s",
      tostring(report.environment.engineVersion),
      tostring(report.environment.gameVersion),
      tostring(report.environment.loveVersion),
      tostring(report.environment.os))
    local r = report.environment.renderer or {}
    add("Renderer: %s | %s | %s | %s",
      tostring(r.name or "?"), tostring(r.version or "?"),
      tostring(r.vendor or "?"), tostring(r.device or "?"))
    add("Loaded mods: %d", #(report.mods or {}))
    add("Profiler: hooks=%d events=%d provenance-callbacks=%d deep=%s",
      tonumber(report.capture.instrumentedHooks) or 0,
      tonumber(report.capture.instrumentedEvents) or 0,
      tonumber(report.capture.instrumentedProvenanceCallbacks) or 0,
      report.capture.deepAvailable and "ON" or "OFF")
    add("")

    local f = report.frames or {}
    add("FRAME FLUIDITY")
    add("Frames: %d | Presented FPS: %.2f | Avg: %.3f ms | 1%% low: %.2f FPS",
      tonumber(f.frames) or 0, tonumber(f.presentedFps) or 0,
      tonumber(f.averageMs) or 0, tonumber(f.onePercentLowFps) or 0)
    add("Median: %.3f ms | P95: %.3f ms | P99: %.3f ms | Worst: %.3f ms",
      tonumber(f.medianMs) or 0, tonumber(f.p95Ms) or 0,
      tonumber(f.p99Ms) or 0, tonumber(f.worstMs) or 0)
    add("Missed 16.67ms budget: %d (%.1f%%) | Slow > %.1fms: %d | Severe >= %.1fms: %d",
      tonumber(f.missedBudgetFrames) or 0, tonumber(f.missedBudgetPct) or 0,
      tonumber(report.thresholds.slowMs) or 0,
      tonumber(report.capture.slowFrames) or 0,
      tonumber(report.thresholds.severeMs) or 0,
      tonumber(report.capture.severeFrames) or 0)
    add("Unattributed slow frames: %d", tonumber(report.capture.unattributedSlowFrames) or 0)
    add("")

    add("MOD FLUIDITY IMPACT")
    for i, row in ipairs(report.modsImpact or {}) do
      add("#%d [%s] %s (%s)", i, tostring(row.verdict), tostring(row.id), tostring(row.name))
      add("  CPU %.2f%% | %.2f ms/s | STUT %.1f%% | MAX %.3f ms | DRAW %.1f/s | DEEP %.1f%%",
        tonumber(row.percent) or 0, tonumber(row.msPerSec) or 0,
        tonumber(row.stutterPct) or 0, tonumber(row.maxMs) or 0,
        tonumber(row.drawsPerSec) or 0, tonumber(row.deepPct) or 0)
      add("  HOT %s", tostring(row.hot or "-"))
      add("  DEEPHOT %s", tostring(row.deepHot or "-"))
    end
    add("")

    add("TOP SLOW FRAMES")
    for i = 1, math.min(30, #(report.slowFrames or {})) do
      local sf = report.slowFrames[i]
      add("#%d t=%.3fs frame=%.3fms winner=%s method=%s state=%s map=%s",
        i, tonumber(sf.t) or 0, tonumber(sf.frameMs) or 0,
        tostring(sf.winner or "UNATTRIBUTED"), tostring(sf.method or "-"),
        tostring(sf.state or "-"), tostring(sf.map or "-"))
    end
    add("")
    add("Upload exports/performance_report_latest_json.bin for full machine-readable analysis.")
    return table.concat(lines, "\n") .. "\n"
  end

  local function storagePathHint(key)
    local context
    if mod.storage and mod.storage.context and gameRef then
      local ok, value = pcall(mod.storage.context, mod.storage, gameRef)
      if ok and type(value) == "table" then context = value end
    end
    if not context then
      return "mod_storage/.../performance_monitor/" .. key .. ".bin"
    end
    return ("mod_storage/%s/%s/performance_monitor/%s.bin"):format(
      tostring(context.gameVersion or "?"),
      tostring(context.playthroughId or "?"),
      key)
  end

  local function storageWriteBytes(key, bytes)
    if not (mod.storage and mod.storage.writeBytes) then
      return false, "mod.storage.writeBytes unavailable"
    end
    if not gameRef then return false, "game not ready" end

    local callOk, writeOk, code, message = pcall(
      mod.storage.writeBytes, mod.storage, gameRef, key, bytes)

    if not callOk then return false, tostring(writeOk) end
    if writeOk ~= true then
      return false, tostring(message or code or "storage write failed")
    end
    return true
  end

  local androidFsCache = false

  local function androidPersistenceFs()
    if not IS_ANDROID then return nil, "not Android" end
    if androidFsCache then return androidFsCache end

    local ok, SaveData = pcall(require, "src.core.SaveData")
    if not ok or type(SaveData) ~= "table"
        or type(SaveData.persistenceFs) ~= "function" then
      return nil, "engine persistence bridge unavailable"
    end

    local fsOk, fs = pcall(SaveData.persistenceFs)
    if not fsOk or type(fs) ~= "table"
        or type(fs.write) ~= "function"
        or type(fs.getInfo) ~= "function" then
      return nil, "engine persistence filesystem unavailable"
    end
    androidFsCache = fs
    return fs
  end

  local function androidRemove(fs, name)
    if fs and type(fs.remove) == "function" then pcall(fs.remove, name) end
  end

  local function androidReadFlag(fs, name)
    if not (fs and type(fs.getInfo) == "function") then return false end
    local ok, info = pcall(fs.getInfo, name)
    return ok and info ~= nil
  end

  local function androidSaveAsAvailable()
    return IS_ANDROID
      and love and love.system
      and type(love.system.createFile) == "function"
  end

  -- Reuse Gen1Recomp Android's existing save-export bridge. The Java side
  -- copies `pending_export.sav` into the URI selected by ACTION_CREATE_DOCUMENT;
  -- the bytes do not need to be a .sav. We stage UTF-8 JSON there and suggest
  -- a .json filename to the system picker.
  local function requestAndroidSaveAs(jsonText, stamp)
    if not IS_ANDROID then return false, "not Android" end
    if type(jsonText) ~= "string" or jsonText == "" then
      return false, "empty report"
    end
    if not androidSaveAsAvailable() then
      androidExport.status = "SAVE AS UNAVAILABLE"
      androidExport.error = "love.system.createFile unavailable"
      exportState.androidSaveAs = "unavailable"
      return false, androidExport.error
    end

    local fs, fsErr = androidPersistenceFs()
    if not fs then
      androidExport.status = "SAVE AS UNAVAILABLE"
      androidExport.error = tostring(fsErr)
      exportState.androidSaveAs = "unavailable"
      return false, fsErr
    end

    -- Clear stale markers from an older attempt. Internal mod.storage copies
    -- already exist, so a cancelled picker can never lose the report.
    androidRemove(fs, "export_done.flag")
    androidRemove(fs, "pending_export.sav")

    local wrote, writeErr = fs.write("pending_export.sav", jsonText)
    if wrote ~= true then
      androidExport.status = "SAVE AS ERROR"
      androidExport.error = "could not stage report: " .. tostring(writeErr)
      exportState.androidSaveAs = "stage_failed"
      return false, androidExport.error
    end

    -- Verify the staging write when this filesystem can read.
    if type(fs.read) == "function" then
      local okRead, staged = pcall(fs.read, "pending_export.sav")
      if not okRead or staged ~= jsonText then
        androidRemove(fs, "pending_export.sav")
        androidExport.status = "SAVE AS ERROR"
        androidExport.error = "staged report could not be verified"
        exportState.androidSaveAs = "verify_failed"
        return false, androidExport.error
      end
    end

    local suggested = "gen1recomp_performance_"
      .. tostring(stamp or math.floor(now() * 1000)) .. ".json"

    local saveDir
    if type(fs.getSaveDirectory) == "function" then
      local okDir, value = pcall(fs.getSaveDirectory)
      if okDir and type(value) == "string" and value ~= "" then
        saveDir = value
      end
    end

    local callOk, opened
    if saveDir then
      callOk, opened = pcall(love.system.createFile, suggested, saveDir)
    else
      -- The Android bridge also has a legacy single-argument entry and can
      -- resolve the identity folder itself.
      callOk, opened = pcall(love.system.createFile, suggested)
    end

    if not callOk or opened ~= true then
      androidRemove(fs, "pending_export.sav")
      androidExport.status = "SAVE AS ERROR"
      androidExport.error = callOk and "system picker could not be opened"
        or tostring(opened)
      exportState.androidSaveAs = "open_failed"
      return false, androidExport.error
    end

    androidExport.pending = true
    androidExport.openedAt = now()
    androidExport.suggestedName = suggested
    androidExport.status = "CHOOSE SAVE LOCATION"
    androidExport.error = nil
    androidExport.savedAt = nil
    exportState.androidSaveAs = "pending"
    exportState.androidSuggestedName = suggested
    androidUi.status = "Android Save As opened"
    androidUi.statusUntil = now() + 4
    return true
  end

  local function pollAndroidSaveAs(t)
    if not IS_ANDROID or not androidExport.pending then return end
    if t - (androidExport.lastPoll or 0) < 0.25 then return end
    androidExport.lastPoll = t

    local fs = androidPersistenceFs()
    if not fs then return end

    if androidReadFlag(fs, "export_done.flag") then
      androidRemove(fs, "export_done.flag")
      androidRemove(fs, "pending_export.sav")
      androidExport.pending = false
      androidExport.status = "REPORT SAVED"
      androidExport.savedAt = t
      androidExport.error = nil
      exportState.androidSaveAs = "saved"
      androidUi.status = "REPORT SAVED"
      androidUi.statusUntil = t + 5
      return
    end

    -- On cancellation Android writes no completion flag. The game is paused
    -- while the SAF activity is on top; after it resumes, monotonic time has
    -- advanced. Give the result bridge a short grace window before treating
    -- a focused app with no flag as a cancellation.
    if t - (androidExport.openedAt or t) >= 1.25 then
      local focused = true
      if love and love.window and type(love.window.hasFocus) == "function" then
        local ok, value = pcall(love.window.hasFocus)
        if ok then focused = value == true end
      end
      if focused then
        androidRemove(fs, "pending_export.sav")
        androidExport.pending = false
        androidExport.status = "SAVE CANCELLED"
        androidExport.error = nil
        exportState.androidSaveAs = "cancelled"
        androidUi.status = "SAVE CANCELLED - report kept internally"
        androidUi.statusUntil = t + 6
      end
    end
  end

  local function exportDiagnosticReport(report)
    exportState.error = nil
    if type(report) ~= "table" then
      exportState.error = "no completed diagnostic report"
      return false
    end

    local stamp
    if os and os.date then
      local ok, value = pcall(os.date, "%Y%m%d_%H%M%S")
      if ok then stamp = value end
    end
    stamp = stamp or tostring(math.floor(now() * 1000))

    local archiveJsonKey = REPORT_ARCHIVE_DIR
      .. "/performance_report_" .. stamp .. "_json"
    local archiveTextKey = REPORT_ARCHIVE_DIR
      .. "/performance_report_" .. stamp .. "_txt"

    report.export = {
      backend = IS_ANDROID and "mod.storage+android_saf" or "mod.storage",
      payloadEncoding = "UTF-8",
      note = IS_ANDROID
        and "Internal sandbox copy plus Android system Save As when the host bridge is available."
        or "The *_json.bin file contains plain JSON and may be uploaded directly.",
      latestJsonKey = REPORT_LATEST_JSON_KEY,
      latestTextKey = REPORT_LATEST_TEXT_KEY,
      latestJsonFile = storagePathHint(REPORT_LATEST_JSON_KEY),
      latestTextFile = storagePathHint(REPORT_LATEST_TEXT_KEY),
      archiveJsonKey = archiveJsonKey,
      archiveTextKey = archiveTextKey,
      archiveJsonFile = storagePathHint(archiveJsonKey),
      archiveTextFile = storagePathHint(archiveTextKey),
    }

    local jsonText = jsonEncode(report)
    local textReport = buildTextReport(report)

    local ok1, err1 = storageWriteBytes(REPORT_LATEST_JSON_KEY, jsonText)
    local ok2, err2 = storageWriteBytes(REPORT_LATEST_TEXT_KEY, textReport)
    local ok3, err3 = storageWriteBytes(archiveJsonKey, jsonText)
    local ok4, err4 = storageWriteBytes(archiveTextKey, textReport)

    if not (ok1 and ok2 and ok3 and ok4) then
      exportState.error = table.concat({
        ok1 and "" or ("latest json: " .. tostring(err1)),
        ok2 and "" or ("latest txt: " .. tostring(err2)),
        ok3 and "" or ("archive json: " .. tostring(err3)),
        ok4 and "" or ("archive txt: " .. tostring(err4)),
      }, " ")
      return false
    end

    exportState.storageJsonKey = REPORT_LATEST_JSON_KEY
    exportState.storageTextKey = REPORT_LATEST_TEXT_KEY
    exportState.relativeJson = storagePathHint(REPORT_LATEST_JSON_KEY)
    exportState.relativeText = storagePathHint(REPORT_LATEST_TEXT_KEY)
    exportState.archiveJson = storagePathHint(archiveJsonKey)
    exportState.archiveText = storagePathHint(archiveTextKey)
    exportState.exportedAt = stamp

    mod.log:info("Performance report exported via mod.storage: %s",
      exportState.relativeJson)

    if IS_ANDROID then
      local opened, saveErr = requestAndroidSaveAs(jsonText, stamp)
      if not opened then
        -- Internal export succeeded, so Save As failure is non-fatal.
        mod.log:warn("Android Save As unavailable/failed: %s", tostring(saveErr))
      end
    end
    return true
  end

  -- -----------------------------------------------------------------------
  -- Runtime hook/event profiler
  -- -----------------------------------------------------------------------
  local profiler = {
    current = {},
    ranked = {},
    windowStart = now(),
    lastScan = 0,
    instrumentedHooks = 0,
    instrumentedEvents = 0,
    instrumentedCallbacks = 0,
    frameDirect = {},
    frameDeep = {},
    windowSlowFrames = 0,
    windowSevereFrames = 0,
    windowUnattributed = 0,
    windowStutterWins = {},
  }

  local function newBucket()
    return {
      total = 0, calls = 0, max = 0,
      hooks = 0, events = 0, callbacks = 0,
      draws = 0, canvas = 0, shaders = 0,
      slots = {},
    }
  end

  local function bucketFor(map, owner)
    local b = map[owner]
    if not b then
      b = newBucket()
      map[owner] = b
    end
    return b
  end

  local function slotRecord(bucket, key, elapsed)
    local s = bucket.slots[key]
    if not s then
      s = { total = 0, calls = 0, max = 0 }
      bucket.slots[key] = s
    end
    s.total = s.total + elapsed
    s.calls = s.calls + 1
    if elapsed > s.max then s.max = elapsed end
  end

  local diagnostic = {
    active = false,
    started = 0,
    duration = 0,
    totals = {},
    slowFrames = 0,
    severeFrames = 0,
    unattributed = 0,
    stutter = {},
    report = nil,
    deepAll = 0,
    deepMod = 0,
    deep = {},
    deepHotspots = {},
    deepAvailable = false,
    deepReason = nil,
    callbackProfilerAvailable = false,
    callbackProfilerCount = 0,
    frameTimesMs = {},
    slowFrameDetails = {},
    series = {},
    lastSeriesSample = 0,
    logicStepsStart = 0,
    loadedMods = {},
    loadOrder = {},
    environment = {},
    captureId = nil,
  }

  local function diagStutter(owner)
    local s = diagnostic.stutter[owner]
    if not s then
      s = { wins = 0, directWins = 0, deepWins = 0, touched = 0, winnerMs = 0 }
      diagnostic.stutter[owner] = s
    end
    return s
  end

  local function record(owner, kind, slot, elapsed, draws, canvas, shaders)
    if not owner or owner == MOD_ID then return end
    elapsed = clamp0(elapsed)

    local b = bucketFor(profiler.current, owner)
    b.total = b.total + elapsed
    b.calls = b.calls + 1
    if elapsed > b.max then b.max = elapsed end
    if kind == "hook" then
      b.hooks = b.hooks + 1
    elseif kind == "event" then
      b.events = b.events + 1
    else
      b.callbacks = b.callbacks + 1
    end
    b.draws = b.draws + clamp0(draws)
    b.canvas = b.canvas + clamp0(canvas)
    b.shaders = b.shaders + clamp0(shaders)
    slotRecord(b, slot, elapsed)

    profiler.frameDirect[owner] = (profiler.frameDirect[owner] or 0) + elapsed

    if diagnostic.active then
      local d = bucketFor(diagnostic.totals, owner)
      d.total = d.total + elapsed
      d.calls = d.calls + 1
      if elapsed > d.max then d.max = elapsed end
      if kind == "hook" then
        d.hooks = d.hooks + 1
      elseif kind == "event" then
        d.events = d.events + 1
      else
        d.callbacks = d.callbacks + 1
      end
      d.draws = d.draws + clamp0(draws)
      d.canvas = d.canvas + clamp0(canvas)
      d.shaders = d.shaders + clamp0(shaders)
      slotRecord(d, slot, elapsed)
    end
  end

  local function topSlot(bucket)
    if not bucket or type(bucket.slots) ~= "table" then return "-", 0 end
    local best, bestTotal = "-", 0
    for key, s in pairs(bucket.slots) do
      if s.total > bestTotal then best, bestTotal = key, s.total end
    end
    return best, bestTotal
  end

  local function displayName(owner)
    local mods = gameRef and gameRef.mods and gameRef.mods.mods
    local loaded = mods and mods[owner]
    local mf = loaded and loaded.manifest
    return tostring((mf and mf.name) or owner)
  end

  local function rowFromBucket(owner, b, elapsed, stutterWins, slowFrames)
    local msPerSec = elapsed > 0 and (b.total * 1000 / elapsed) or 0
    local hot = topSlot(b)
    return {
      id = owner,
      name = displayName(owner),
      msPerSec = msPerSec,
      percent = msPerSec / 10,
      maxMs = b.max * 1000,
      callsPerSec = elapsed > 0 and (b.calls / elapsed) or 0,
      drawsPerSec = elapsed > 0 and (b.draws / elapsed) or 0,
      canvasPerSec = elapsed > 0 and (b.canvas / elapsed) or 0,
      shaderPerSec = elapsed > 0 and (b.shaders / elapsed) or 0,
      hooks = b.hooks,
      events = b.events,
      callbacks = b.callbacks or 0,
      stutterPct = slowFrames > 0 and ((stutterWins or 0) * 100 / slowFrames) or 0,
      hot = hot,
    }
  end

  local function closeProfilerWindow(t)
    local elapsed = t - profiler.windowStart
    if elapsed < 1.0 then return end

    local ranked, totalAll = {}, 0
    for owner, b in pairs(profiler.current) do
      local row = rowFromBucket(owner, b, elapsed,
        profiler.windowStutterWins[owner] or 0, profiler.windowSlowFrames)
      ranked[#ranked + 1] = row
      totalAll = totalAll + row.msPerSec
    end
    table.sort(ranked, function(a, b)
      if a.stutterPct ~= b.stutterPct then return a.stutterPct > b.stutterPct end
      if a.msPerSec ~= b.msPerSec then return a.msPerSec > b.msPerSec end
      return a.maxMs > b.maxMs
    end)

    profiler.current = {}
    profiler.ranked = ranked
    profiler.windowStart = t
    snapshot.modCpuMsPerSec = totalAll
    snapshot.modCpuPercent = totalAll / 10
    profiler.windowSlowFrames = 0
    profiler.windowSevereFrames = 0
    profiler.windowUnattributed = 0
    profiler.windowStutterWins = {}
  end

  -- -----------------------------------------------------------------------
  -- Deep source/provenance sampler
  -- -----------------------------------------------------------------------
  local functionProvenance = setmetatable({}, { __mode = "k" })
  local sourceRoots = {}
  local deepInstalled = false
  local deepHookFn = nil

  local function normalizePath(p)
    p = tostring(p or "")
    p = p:gsub("^@", ""):gsub("\\", "/")
    p = p:gsub("//+", "/")
    return p:lower()
  end

  local function rebuildSourceRoots()
    sourceRoots = {}
    local mods = gameRef and gameRef.mods and gameRef.mods.mods
    for id, row in pairs(mods or {}) do
      if id ~= MOD_ID and row and row.path then
        sourceRoots[#sourceRoots + 1] = { id = id, path = normalizePath(row.path) }
      end
    end
    table.sort(sourceRoots, function(a, b) return #a.path > #b.path end)
  end

  local function ownerForSource(source)
    local s = normalizePath(source)
    if s == "" then return nil end
    for _, r in ipairs(sourceRoots) do
      if s == r.path
          or s:sub(1, #r.path + 1) == r.path .. "/"
          or s:find("/" .. r.path .. "/", 1, true) then
        return r.id
      end
    end
    return nil
  end

  local function provenanceWalk(value, owner, label, seen, depth, budget)
    if budget.n <= 0 or depth > 10 then return end
    local tv = type(value)
    if tv == "function" then
      if not functionProvenance[value] then
        functionProvenance[value] = { owner = owner, label = label }
      end
      budget.n = budget.n - 1
      return
    end
    if tv ~= "table" or seen[value] then return end
    seen[value] = true
    budget.n = budget.n - 1
    for k, v in pairs(value) do
      if budget.n <= 0 then break end
      local child = label .. "." .. tostring(k)
      provenanceWalk(v, owner, child, seen, depth + 1, budget)
    end
  end

  local function rebuildFunctionProvenance()
    functionProvenance = setmetatable({}, { __mode = "k" })
    rebuildSourceRoots()
    if not (gameRef and gameRef.mods) then return end

    local budget = { n = 75000 }
    for regName, registry in pairs(gameRef.mods.content or {}) do
      if type(registry) == "table" and type(registry.ops) == "table" then
        for id, list in pairs(registry.ops) do
          for _, entry in ipairs(list or {}) do
            local owner = entry.owner
            if owner and owner ~= MOD_ID
                and gameRef.mods.mods and gameRef.mods.mods[owner] then
              provenanceWalk(entry.value, owner,
                "registry:" .. tostring(regName) .. ":" .. tostring(id),
                {}, 0, budget)
            end
          end
        end
      end
    end

    -- Exported callbacks are also owned unambiguously by their publishing mod.
    for owner, exports in pairs(gameRef.mods.exports or {}) do
      if owner ~= MOD_ID and gameRef.mods.mods and gameRef.mods.mods[owner] then
        provenanceWalk(exports, owner, "exports:" .. tostring(owner), {}, 0, budget)
      end
    end
  end


  -- -----------------------------------------------------------------------
  -- Sandbox-safe provenance callback profiler
  -- -----------------------------------------------------------------------
  -- Newer Gen1Recomp builds intentionally remove the Lua debug library from
  -- mod sandboxes.  Function identity still survives registry deep copies,
  -- though: Registry.ops records the owner of each contributed value and the
  -- merged game data keeps the same Lua function objects.  We use that
  -- provenance to wrap mod-authored callbacks in the live merged data without
  -- needing debug.getinfo/debug.sethook.
  local provenanceWrapperByOriginal = setmetatable({}, { __mode = "k" })
  local provenanceWrapperMarker = setmetatable({}, { __mode = "k" })
  local ownedTimingStack = {}

  local function timingPush(absorb)
    local frame = { child = 0, absorb = absorb and true or false }
    ownedTimingStack[#ownedTimingStack + 1] = frame
    return frame
  end

  local function timingPop(frame, total)
    if ownedTimingStack[#ownedTimingStack] == frame then
      ownedTimingStack[#ownedTimingStack] = nil
    else
      -- Defensive recovery if a callback altered control flow unexpectedly.
      for i = #ownedTimingStack, 1, -1 do
        if ownedTimingStack[i] == frame then
          table.remove(ownedTimingStack, i)
          break
        end
      end
    end
    local parent = ownedTimingStack[#ownedTimingStack]
    if parent and not parent.absorb then
      parent.child = parent.child + total
    end
  end

  local function timedOwnedCall(owner, slot, fn, ...)
    local frame = timingPush(false)
    local t0 = now()
    local res = pack(pcall(fn, ...))
    local total = clamp0(now() - t0)
    timingPop(frame, total)
    local own = clamp0(total - (frame.child or 0))
    record(owner, "callback", slot, own, 0, 0, 0)
    if not res[1] then error(res[2], 0) end
    return unpack(res, 2, res.n)
  end

  local function provenanceWrapper(fn, prov)
    if provenanceWrapperMarker[fn] then return fn, false end
    local cached = provenanceWrapperByOriginal[fn]
    if cached then return cached, false end

    local owner = prov and prov.owner
    if not owner or owner == MOD_ID then return fn, false end
    local slot = "content:" .. tostring((prov and prov.label) or "callback")

    local wrapped = function(...)
      return timedOwnedCall(owner, slot, fn, ...)
    end
    provenanceWrapperByOriginal[fn] = wrapped
    provenanceWrapperMarker[wrapped] = true
    profiler.instrumentedCallbacks = profiler.instrumentedCallbacks + 1
    return wrapped, true
  end

  local function instrumentProvenanceTree(value, seen, depth, budget)
    if budget.n <= 0 or depth > 14 or type(value) ~= "table" or seen[value] then
      return 0
    end
    seen[value] = true
    budget.n = budget.n - 1
    local changed = 0
    for key, child in pairs(value) do
      if budget.n <= 0 then break end
      if type(child) == "function" then
        local prov = functionProvenance[child]
        if prov and prov.owner ~= MOD_ID then
          local wrapped, did = provenanceWrapper(child, prov)
          if wrapped ~= child then
            value[key] = wrapped
            if did then changed = changed + 1 end
          end
        end
      elseif type(child) == "table" then
        changed = changed + instrumentProvenanceTree(
          child, seen, depth + 1, budget)
      end
    end
    return changed
  end

  local function instrumentProvenanceCallbacks()
    if not (gameRef and gameRef.mods) then return 0 end
    rebuildFunctionProvenance()

    local before = profiler.instrumentedCallbacks
    local seen = {}
    local budget = { n = 200000 }

    -- The merged game data is what engine systems actually call.
    if type(gameRef.data) == "table" then
      instrumentProvenanceTree(gameRef.data, seen, 0, budget)
    end

    -- Compose registries and lazy consumers may read directly from the op
    -- journal after game.ready.  Update those tables too.
    for _, registry in pairs(gameRef.mods.content or {}) do
      if type(registry) == "table" and type(registry.ops) == "table" then
        for _, list in pairs(registry.ops) do
          for _, entry in ipairs(list or {}) do
            if type(entry) == "table" then
              local value = entry.value
              if type(value) == "function" then
                local prov = functionProvenance[value]
                if prov then entry.value = provenanceWrapper(value, prov) end
              elseif type(value) == "table" then
                instrumentProvenanceTree(value, seen, 0, budget)
              end
            end
          end
        end
      end
    end

    -- Cross-mod exports are another common path that bypasses hook/event
    -- buses.  Their functions were included in functionProvenance above.
    for owner, exports in pairs(gameRef.mods.exports or {}) do
      if owner ~= MOD_ID and type(exports) == "table" then
        instrumentProvenanceTree(exports, seen, 0, budget)
      end
    end

    diagnostic.callbackProfilerAvailable = true
    diagnostic.callbackProfilerCount = profiler.instrumentedCallbacks
    return profiler.instrumentedCallbacks - before
  end

  local function shortSource(source)
    local s = tostring(source or "?"):gsub("^@", ""):gsub("\\", "/")
    local tail = s:match("([^/]+/[^/]+)$") or s:match("([^/]+)$") or s
    return tail
  end

  local function deepSample()
    if not diagnostic.active then return end
    if not (debug and debug.getinfo) then return end

    local info = debug.getinfo(2, "fSl")
    if not info then return end

    local prov = info.func and functionProvenance[info.func] or nil
    local owner = prov and prov.owner or ownerForSource(info.source or info.short_src)
    if owner == MOD_ID then return end

    diagnostic.deepAll = diagnostic.deepAll + 1
    if not owner then return end

    diagnostic.deepMod = diagnostic.deepMod + 1
    local d = diagnostic.deep[owner]
    if not d then d = { samples = 0 }; diagnostic.deep[owner] = d end
    d.samples = d.samples + 1
    profiler.frameDeep[owner] = (profiler.frameDeep[owner] or 0) + 1

    local hot = prov and prov.label
      or (shortSource(info.source or info.short_src) .. ":" .. tostring(info.currentline or 0))
    local perOwner = diagnostic.deepHotspots[owner]
    if not perOwner then perOwner = {}; diagnostic.deepHotspots[owner] = perOwner end
    perOwner[hot] = (perOwner[hot] or 0) + 1
  end

  local function stopDeepSampler()
    if not deepInstalled then return end
    if debug and debug.gethook and debug.sethook then
      local current = debug.gethook()
      if current == deepHookFn then pcall(debug.sethook) end
    end
    deepInstalled = false
  end

  local function startDeepSampler()
    diagnostic.deepAvailable = false
    diagnostic.deepReason = nil
    if not (debug and debug.sethook and debug.gethook and debug.getinfo) then
      diagnostic.deepReason = "debug API sandboxed; provenance callback profiler active"
      return false
    end

    local existing = debug.gethook()
    if existing ~= nil then
      diagnostic.deepReason = "another debug profiler is already active; provenance callback profiler active"
      return false
    end

    deepHookFn = deepSample
    local ok, err = pcall(debug.sethook, deepHookFn, "", DEEP_INSTRUCTION_INTERVAL)
    if not ok then
      diagnostic.deepReason = tostring(err)
      return false
    end
    deepInstalled = true
    diagnostic.deepAvailable = true
    return true
  end

  local function topDeepHotspot(owner)
    local map = diagnostic.deepHotspots[owner]
    local best, count = "-", 0
    for key, n in pairs(map or {}) do
      if n > count then best, count = key, n end
    end
    return best, count
  end

  -- -----------------------------------------------------------------------
  -- Runtime instrumentation
  -- -----------------------------------------------------------------------
  local function instrumentHookEntry(hookName, entry)
    if type(entry) ~= "table" or not entry.owner or entry.owner == MOD_ID then return false end
    if entry._performanceMonitor12Token == GENERATION then return false end

    -- Hot-reload safety: peel an older monitor wrapper back to the real callback.
    if entry._performanceMonitor12Original then
      entry.callback = entry._performanceMonitor12Original
      entry._performanceMonitor12Original = nil
      entry._performanceMonitor12 = nil
      entry._performanceMonitor12Token = nil
    elseif entry._performanceMonitor11Original then
      entry.callback = entry._performanceMonitor11Original
      entry._performanceMonitor11Original = nil
      entry._performanceMonitor11 = nil
    end

    if type(entry.callback) ~= "function" then return false end

    local original = entry.callback
    local owner = entry.owner
    local renderLike = tostring(hookName):match("^render%.") ~= nil
    local slot = "hook:" .. tostring(hookName)

    entry.callback = function(nextFn, ...)
      local downstreamTime = 0
      local downstreamDraw, downstreamCanvas, downstreamShader = 0, 0, 0

      local function measuredNext(...)
        local d0, c0, s0 = 0, 0, 0
        if renderLike then d0, c0, s0 = graphicsCounters() end
        -- Absorb nested ownership records from the downstream hook chain.
        -- The whole downstream wall time is subtracted separately below.
        local sentinel = timingPush(true)
        local t0 = now()
        local res = pack(pcall(nextFn, ...))
        local childTotal = clamp0(now() - t0)
        timingPop(sentinel, 0)
        downstreamTime = downstreamTime + childTotal
        if renderLike then
          local d1, c1, s1 = graphicsCounters()
          downstreamDraw = downstreamDraw + clamp0(d1 - d0)
          downstreamCanvas = downstreamCanvas + clamp0(c1 - c0)
          downstreamShader = downstreamShader + clamp0(s1 - s0)
        end
        if not res[1] then error(res[2], 0) end
        return unpack(res, 2, res.n)
      end

      local d0, c0, s0 = 0, 0, 0
      if renderLike then d0, c0, s0 = graphicsCounters() end
      local ownFrame = timingPush(false)
      local t0 = now()
      local res = pack(pcall(original, measuredNext, ...))
      local total = clamp0(now() - t0)
      timingPop(ownFrame, total)
      local elapsed = total - downstreamTime - (ownFrame.child or 0)

      local ownDraw, ownCanvas, ownShader = 0, 0, 0
      if renderLike then
        local d1, c1, s1 = graphicsCounters()
        ownDraw = clamp0((d1 - d0) - downstreamDraw)
        ownCanvas = clamp0((c1 - c0) - downstreamCanvas)
        ownShader = clamp0((s1 - s0) - downstreamShader)
      end

      record(owner, "hook", slot, elapsed, ownDraw, ownCanvas, ownShader)
      if not res[1] then error(res[2], 0) end
      return unpack(res, 2, res.n)
    end

    entry._performanceMonitor12 = true
    entry._performanceMonitor12Original = original
    entry._performanceMonitor12Token = GENERATION
    profiler.instrumentedHooks = profiler.instrumentedHooks + 1
    return true
  end

  local function instrumentEventEntry(eventName, entry)
    if type(entry) ~= "table" or not entry.owner or entry.owner == MOD_ID then return false end
    if entry._performanceMonitor12Token == GENERATION then return false end

    if entry._performanceMonitor12Original then
      entry.callback = entry._performanceMonitor12Original
      entry._performanceMonitor12Original = nil
      entry._performanceMonitor12 = nil
      entry._performanceMonitor12Token = nil
    elseif entry._performanceMonitor11Original then
      entry.callback = entry._performanceMonitor11Original
      entry._performanceMonitor11Original = nil
      entry._performanceMonitor11 = nil
    end

    if type(entry.callback) ~= "function" then return false end

    local original = entry.callback
    local owner = entry.owner
    local slot = "event:" .. tostring(eventName)

    entry.callback = function(...)
      local ownFrame = timingPush(false)
      local t0 = now()
      local res = pack(pcall(original, ...))
      local total = clamp0(now() - t0)
      timingPop(ownFrame, total)
      record(owner, "event", slot,
        clamp0(total - (ownFrame.child or 0)), 0, 0, 0)
      if not res[1] then error(res[2], 0) end
      return unpack(res, 2, res.n)
    end

    entry._performanceMonitor12 = true
    entry._performanceMonitor12Original = original
    entry._performanceMonitor12Token = GENERATION
    profiler.instrumentedEvents = profiler.instrumentedEvents + 1
    return true
  end

  local runtime
  local function scanRuntime()
    if not runtime then
      local ok, r = pcall(require, "src.mods.Runtime")
      if not ok or type(r) ~= "table" then return end
      runtime = r
    end

    local hooks = runtime.hooks and runtime.hooks.chains
    if type(hooks) == "table" then
      for hookName, chain in pairs(hooks) do
        for _, entry in ipairs(type(chain) == "table" and chain or {}) do
          instrumentHookEntry(hookName, entry)
        end
      end
    end

    local listeners = runtime.events and runtime.events.listeners
    if type(listeners) == "table" then
      for eventName, list in pairs(listeners) do
        for _, entry in ipairs(type(list) == "table" and list or {}) do
          instrumentEventEntry(eventName, entry)
        end
      end
    end
  end

  -- -----------------------------------------------------------------------
  -- Slow-frame correlation + diagnostic report
  -- -----------------------------------------------------------------------
  local function frameTop(map)
    local owner, value = nil, 0
    for id, v in pairs(map or {}) do
      if v > value then owner, value = id, v end
    end
    return owner, value
  end

  local function finalizeFrame(frameMs)
    if diagnostic.active then
      diagnostic.frameTimesMs[#diagnostic.frameTimesMs + 1] = frameMs
    end

    if frameMs <= SLOW_MS then
      profiler.frameDirect = {}
      profiler.frameDeep = {}
      return
    end

    profiler.windowSlowFrames = profiler.windowSlowFrames + 1
    if frameMs >= SEVERE_MS then profiler.windowSevereFrames = profiler.windowSevereFrames + 1 end
    if diagnostic.active then
      diagnostic.slowFrames = diagnostic.slowFrames + 1
      if frameMs >= SEVERE_MS then diagnostic.severeFrames = diagnostic.severeFrames + 1 end
    end

    for owner, seconds in pairs(profiler.frameDirect) do
      if seconds >= 0.0005 and diagnostic.active then
        diagStutter(owner).touched = diagStutter(owner).touched + 1
      end
    end

    local directOwner, directSeconds = frameTop(profiler.frameDirect)
    local deepOwner, deepCount = frameTop(profiler.frameDeep)
    local winner, method = nil, nil
    if directOwner and directSeconds >= 0.0005 then
      winner, method = directOwner, "direct"
    elseif diagnostic.active and deepOwner and deepCount > 0 then
      winner, method = deepOwner, "deep"
    end

    if diagnostic.active then
      local gs = safeGraphicsStats()
      diagnostic.slowFrameDetails[#diagnostic.slowFrameDetails + 1] = {
        t = math.max(0, now() - diagnostic.started),
        frameMs = frameMs,
        winner = winner or "UNATTRIBUTED",
        method = method or "none",
        directWinner = directOwner,
        directWinnerMs = (directSeconds or 0) * 1000,
        deepWinner = deepOwner,
        deepWinnerSamples = deepCount or 0,
        directTop = topMapRows(profiler.frameDirect, 5, "ms"),
        deepTop = topMapRows(profiler.frameDeep, 5, "samples"),
        state = topStateName(gameRef),
        map = mapName(gameRef),
        drawcalls = tonumber(gs.drawcalls) or 0,
        canvasswitches = tonumber(gs.canvasswitches) or 0,
        shaderswitches = tonumber(gs.shaderswitches) or 0,
      }
    end

    if winner then
      profiler.windowStutterWins[winner] = (profiler.windowStutterWins[winner] or 0) + 1
      if diagnostic.active then
        local s = diagStutter(winner)
        s.wins = s.wins + 1
        if method == "direct" then
          s.directWins = s.directWins + 1
          s.winnerMs = s.winnerMs + directSeconds * 1000
        else
          s.deepWins = s.deepWins + 1
        end
      end
    else
      profiler.windowUnattributed = profiler.windowUnattributed + 1
      if diagnostic.active then diagnostic.unattributed = diagnostic.unattributed + 1 end
    end

    profiler.frameDirect = {}
    profiler.frameDeep = {}
  end

  local function classify(row, slowFrames)
    local hasSlowEvidence = slowFrames >= 3
    if row.percent >= 20 or row.maxMs >= 16.7
        or (hasSlowEvidence and row.stutterPct >= 25) then
      return "HIGH"
    end
    if row.percent >= 8 or row.maxMs >= 8
        or (hasSlowEvidence and row.stutterPct >= 10) then
      return "MED"
    end
    -- Deep samples alone say "this mod is active", not "this mod hurts
    -- fluidity". This avoids the false HIGH verdict seen on perfectly smooth
    -- captures where a framework simply executes a lot of Lua.
    if (row.deepPct or 0) >= 10 then return "ACTV" end
    return "LOW"
  end

  local function buildDiagnosticReport(t)
    diagnostic.duration = math.max(0.001, t - diagnostic.started)
    local rows, seen = {}, {}

    for owner, b in pairs(diagnostic.totals) do
      local s = diagnostic.stutter[owner] or {}
      local row = rowFromBucket(owner, b, diagnostic.duration,
        s.wins or 0, diagnostic.slowFrames)
      row.deepSamples = diagnostic.deep[owner] and diagnostic.deep[owner].samples or 0
      row.deepPct = diagnostic.deepAll > 0 and (row.deepSamples * 100 / diagnostic.deepAll) or 0
      row.deepHot = topDeepHotspot(owner)
      row.stutterDirect = s.directWins or 0
      row.stutterDeep = s.deepWins or 0
      row.stutterTouched = s.touched or 0
      row.winnerAvgMs = (s.directWins or 0) > 0 and ((s.winnerMs or 0) / s.directWins) or 0
      rows[#rows + 1] = row
      seen[owner] = true
    end

    -- A mod can be invisible to Runtime hooks/events but still show up in the
    -- deep sampler (direct class monkey-patch, custom quest callback, etc.).
    for owner, d in pairs(diagnostic.deep) do
      if not seen[owner] then
        local s = diagnostic.stutter[owner] or {}
        local row = rowFromBucket(owner, newBucket(), diagnostic.duration,
          s.wins or 0, diagnostic.slowFrames)
        row.deepSamples = d.samples or 0
        row.deepPct = diagnostic.deepAll > 0 and (row.deepSamples * 100 / diagnostic.deepAll) or 0
        row.deepHot = topDeepHotspot(owner)
        row.stutterDirect = s.directWins or 0
        row.stutterDeep = s.deepWins or 0
        row.stutterTouched = s.touched or 0
        row.winnerAvgMs = 0
        rows[#rows + 1] = row
      end
    end

    for _, row in ipairs(rows) do
      row.verdict = classify(row, diagnostic.slowFrames)
      local rank = row.verdict == "HIGH" and 4
        or row.verdict == "MED" and 3
        or row.verdict == "ACTV" and 2 or 1
      -- Ordering only. The visible metrics stay raw and independently readable.
      row._rank = rank * 100000
        + row.stutterPct * 500
        + row.percent * 250
        + row.deepPct * 150
        + math.min(row.maxMs, 50) * 100
    end
    table.sort(rows, function(a, b) return a._rank > b._rank end)

    local captureId = diagnostic.captureId or ("perf-" .. tostring(math.floor(diagnostic.started * 1000)))
    local generatedUtc = tostring(captureId)
    if os and os.date then
      local ok, value = pcall(os.date, "!%Y-%m-%dT%H:%M:%SZ")
      if ok then generatedUtc = tostring(value) end
    end

    local frameStats = frameDistribution(diagnostic.frameTimesMs, diagnostic.duration)
    local logicDelta = math.max(0, logicSteps - (diagnostic.logicStepsStart or 0))

    diagnostic.report = {
      reportFormat = "gen1recomp-performance-report",
      reportVersion = 1,
      monitorVersion = VERSION,
      captureId = captureId,
      generatedUtc = generatedUtc,
      environment = diagnostic.environment,
      mods = diagnostic.loadedMods,
      modLoadOrder = diagnostic.loadOrder,
      thresholds = {
        targetFrameMs = TARGET_MS,
        slowMs = SLOW_MS,
        severeMs = SEVERE_MS,
        deepInstructionInterval = DEEP_INSTRUCTION_INTERVAL,
      },
      capture = {
        durationSeconds = diagnostic.duration,
        requestedSeconds = DIAGNOSTIC_SECONDS,
        logicSteps = logicDelta,
        logicStepsPerSecond = logicDelta / diagnostic.duration,
        slowFrames = diagnostic.slowFrames,
        severeFrames = diagnostic.severeFrames,
        unattributedSlowFrames = diagnostic.unattributed,
        deepSamplesAll = diagnostic.deepAll,
        deepSamplesAttributedToMods = diagnostic.deepMod,
        deepAvailable = diagnostic.deepAvailable,
        deepReason = diagnostic.deepReason,
        instrumentedHooks = profiler.instrumentedHooks,
        instrumentedEvents = profiler.instrumentedEvents,
        instrumentedProvenanceCallbacks = profiler.instrumentedCallbacks,
        provenanceCallbackProfilerAvailable = diagnostic.callbackProfilerAvailable,
      },
      frames = frameStats,
      frameTimesMs = diagnostic.frameTimesMs,
      slowFrames = diagnostic.slowFrameDetails,
      timeSeries = diagnostic.series,
      modsImpact = rows,
      analysisNotes = {
        "CPU is exclusive measured hook/event CPU; downstream next() time is removed.",
        "STUT is slow-frame winner correlation, not proof of GPU causality.",
        "DEEP is sampled Lua execution when the host exposes the debug API.",
        "PROV is a sandbox-safe callback profiler that attributes registry/export callbacks by owner provenance.",
        "UNATTRIBUTED slow frames are intentionally left unassigned when evidence is insufficient.",
      },
    }

    mod.log:info(
      "PERF DIAG %.1fs: slow=%d severe=%d unattributed=%d deep=%s",
      diagnostic.duration, diagnostic.slowFrames, diagnostic.severeFrames,
      diagnostic.unattributed, diagnostic.deepAvailable and "on" or "off")
    for i = 1, math.min(10, #rows) do
      local r = rows[i]
      mod.log:info(
        "PERF #%d [%s] %s CPU=%.1f%% STUT=%.1f%% MAX=%.2fms DRAW=%.1f/s DEEP=%.1f%% HOT=%s DEEPHOT=%s",
        i, r.verdict, r.id, r.percent, r.stutterPct, r.maxMs,
        r.drawsPerSec, r.deepPct, tostring(r.hot), tostring(r.deepHot))
    end
    if not exportDiagnosticReport(diagnostic.report) then
      mod.log:warn("Performance report export failed: %s", tostring(exportState.error))
    end
  end

  local function resetProfiler(t)
    frameSamples = {}
    frameSamplePos, frameSampleCount = 1, 0
    profiler.current = {}
    profiler.ranked = {}
    profiler.windowStart = t or now()
    profiler.windowSlowFrames = 0
    profiler.windowSevereFrames = 0
    profiler.windowUnattributed = 0
    profiler.windowStutterWins = {}
    profiler.frameDirect = {}
    profiler.frameDeep = {}
    snapshot.modCpuMsPerSec = 0
    snapshot.modCpuPercent = 0
  end

  local function stopDiagnostic(t)
    if not diagnostic.active then return end
    diagnostic.active = false
    stopDeepSampler()
    buildDiagnosticReport(t or now())
  end

  local function startDiagnostic(t)
    if diagnostic.active then return end
    resetProfiler(t)
    diagnostic.active = true
    diagnostic.started = t
    diagnostic.duration = 0
    diagnostic.totals = {}
    diagnostic.slowFrames = 0
    diagnostic.severeFrames = 0
    diagnostic.unattributed = 0
    diagnostic.stutter = {}
    diagnostic.report = nil
    diagnostic.deepAll = 0
    diagnostic.deepMod = 0
    diagnostic.deep = {}
    diagnostic.deepHotspots = {}
    diagnostic.deepAvailable = false
    diagnostic.deepReason = nil
    diagnostic.callbackProfilerAvailable = false
    diagnostic.callbackProfilerCount = profiler.instrumentedCallbacks
    diagnostic.frameTimesMs = {}
    diagnostic.slowFrameDetails = {}
    diagnostic.series = {}
    diagnostic.lastSeriesSample = t
    diagnostic.logicStepsStart = logicSteps
    diagnostic.loadedMods, diagnostic.loadOrder = captureLoadedMods()
    diagnostic.environment = captureEnvironment(gameRef)
    diagnostic.captureId = "perf-" .. tostring(math.floor(t * 1000))
    exportState.error = nil
    instrumentProvenanceCallbacks()
    startDeepSampler()
    mod.log:info(
      "Performance diagnostic started for %.0f seconds (hooks=%d events=%d callbacks=%d deep=%s)",
      DIAGNOSTIC_SECONDS, profiler.instrumentedHooks, profiler.instrumentedEvents,
      profiler.instrumentedCallbacks, diagnostic.deepAvailable and "ON" or "FALLBACK")
  end

  -- -----------------------------------------------------------------------
  -- Snapshot / input
  -- -----------------------------------------------------------------------
  local function updateSnapshot(game, t)
    if t - lastStatsTime < 0.25 then return end
    lastStatsTime = t

    if love and love.timer and love.timer.getFPS then
      local ok, value = pcall(love.timer.getFPS)
      if ok and type(value) == "number" then snapshot.fps = value end
    end
    snapshot.avgMs, snapshot.worstMs, snapshot.low1 = computeFrameStats()

    if collectgarbage then
      local ok, kb = pcall(collectgarbage, "count")
      if ok and type(kb) == "number" then snapshot.luaMB = kb / 1024 end
    end

    local gs = safeGraphicsStats()
    snapshot.textureMB = (tonumber(gs.texturememory) or 0) / (1024 * 1024)
    snapshot.drawcalls = tonumber(gs.drawcalls) or 0
    snapshot.batched = tonumber(gs.drawcallsbatched) or 0
    snapshot.canvasswitches = tonumber(gs.canvasswitches) or 0
    snapshot.images = tonumber(gs.images) or 0
    snapshot.canvases = tonumber(gs.canvases) or 0
    snapshot.fonts = tonumber(gs.fonts) or 0
    snapshot.shaderswitches = tonumber(gs.shaderswitches) or 0

    if game and game.logicSpeed then
      local ok, speed = pcall(game.logicSpeed, game)
      if ok and type(speed) == "number" then snapshot.speed = speed end
    end
    snapshot.top = topStateName(game)
    snapshot.map = mapName(game)

    if diagnostic.active and t - (diagnostic.lastSeriesSample or 0) >= 0.25 then
      diagnostic.lastSeriesSample = t
      diagnostic.series[#diagnostic.series + 1] = {
        t = math.max(0, t - diagnostic.started),
        fps = snapshot.fps,
        frameMs = snapshot.frameMs,
        averageMs = snapshot.avgMs,
        worstRollingMs = snapshot.worstMs,
        onePercentLowRollingFps = snapshot.low1,
        logicPerSecond = logicPerSecond,
        luaMB = snapshot.luaMB,
        textureMB = snapshot.textureMB,
        drawcalls = snapshot.drawcalls,
        batched = snapshot.batched,
        canvasswitches = snapshot.canvasswitches,
        shaderswitches = snapshot.shaderswitches,
        state = snapshot.top,
        map = snapshot.map,
      }
    end
  end

  local function updateHotkeys(t)
    if not (love and love.keyboard and love.keyboard.isDown) then return end

    local f3 = love.keyboard.isDown("f3")
    if f3 and not f3WasDown then visible = not visible end
    f3WasDown = f3

    local f4 = love.keyboard.isDown("f4")
    if f4 and not f4WasDown then detailed = not detailed end
    f4WasDown = f4

    local f6 = love.keyboard.isDown("f6")
    if f6 and not f6WasDown then resetProfiler(t) end
    f6WasDown = f6

    local f8 = love.keyboard.isDown("f8")
    if f8 and not f8WasDown then
      if diagnostic.active then stopDiagnostic(t) else startDiagnostic(t) end
    end
    f8WasDown = f8

    local f9 = love.keyboard.isDown("f9")
    if f9 and not f9WasDown then
      if diagnostic.report then
        if not exportDiagnosticReport(diagnostic.report) then
          mod.log:warn("Performance report export failed: %s", tostring(exportState.error))
        end
      else
        exportState.error = "run an F8 diagnostic first"
      end
    end
    f9WasDown = f9
  end

  local function androidAction(id, t)
    if id == "perf" then
      androidUi.open = not androidUi.open
      return
    end
    if id == "hud" then
      visible = not visible
      androidUi.status = visible and "HUD ON" or "HUD OFF"
      androidUi.statusUntil = t + 2
      return
    end
    if id == "view" then
      detailed = not detailed
      androidUi.status = detailed and "DETAILED VIEW" or "COMPACT VIEW"
      androidUi.statusUntil = t + 2
      return
    end
    if id == "reset" then
      resetProfiler(t)
      androidUi.status = "SAMPLES RESET"
      androidUi.statusUntil = t + 2
      return
    end
    if id == "capture" then
      if diagnostic.active then stopDiagnostic(t) else startDiagnostic(t) end
      androidUi.status = diagnostic.active and "10s CAPTURE STARTED"
        or "CAPTURE STOPPED"
      androidUi.statusUntil = t + 3
      return
    end
    if id == "save" then
      if diagnostic.report then
        if not exportDiagnosticReport(diagnostic.report) then
          androidUi.status = "EXPORT ERROR"
          androidUi.statusUntil = t + 4
        end
      else
        exportState.error = "run a diagnostic first"
        androidUi.status = "RUN CAPTURE FIRST"
        androidUi.statusUntil = t + 3
      end
    end
  end

  local function pointInside(rect, x, y)
    return rect and x >= rect.x and x <= rect.x + rect.w
      and y >= rect.y and y <= rect.y + rect.h
  end

  local function androidButtonAt(x, y)
    if not IS_ANDROID then return nil end
    -- PERF is always available; the rest exist only while the drawer is open.
    local perf = androidUi.rects.perf
    if pointInside(perf, x, y) then return "perf" end
    if not androidUi.open then return nil end
    for _, id in ipairs({ "hud", "view", "reset", "capture", "save" }) do
      if pointInside(androidUi.rects[id], x, y) then return id end
    end
    return nil
  end

  if IS_ANDROID then
    mod.hooks:wrap("input.pointer", function(nextFn, game, ev)
      if type(ev) ~= "table" then return nextFn(game, ev) end
      local id = ev.id
      if ev.phase == "pressed" then
        local button = androidButtonAt(ev.x or -1, ev.y or -1)
        if button then
          androidUi.pressed[id] = button
          return true
        end
      elseif ev.phase == "released" then
        local pressed = androidUi.pressed[id]
        androidUi.pressed[id] = nil
        if pressed then
          local releasedOn = androidButtonAt(ev.x or -1, ev.y or -1)
          if releasedOn == pressed then androidAction(pressed, now()) end
          return true
        end
      elseif ev.phase == "cancelled" then
        if androidUi.pressed[id] then
          androidUi.pressed[id] = nil
          return true
        end
      elseif ev.phase == "moved" then
        if androidUi.pressed[id] then return true end
      end
      return nextFn(game, ev)
    end, 100000)
  end

  -- Fixed-step counter; it also lets us rescan late/hot-reloaded runtime
  -- registrations even if the HUD is hidden.
  mod.hooks:wrap("input.step", function(nextFn, game, dt)
    logicSteps = logicSteps + 1
    logicWindowSteps = logicWindowSteps + 1
    local t = now()
    pollAndroidSaveAs(t)
    local elapsed = t - lastSecondTime
    if elapsed >= 1.0 then
      logicPerSecond = logicWindowSteps / elapsed
      logicWindowSteps = 0
      lastSecondTime = t
    end
    return nextFn(game, dt)
  end, 900)

  mod.events:on("game.ready", function(ev)
    gameRef = ev and ev.game or nil
    local t = now()
    lastHudTime = t
    lastStatsTime = 0
    lastSecondTime = t
    profiler.windowStart = t
    rebuildFunctionProvenance()
    instrumentProvenanceCallbacks()
    scanRuntime()
    mod.log:info(
      "Performance Monitor %s ready (%d hooks, %d events, %d provenance callbacks instrumented)",
      VERSION, profiler.instrumentedHooks, profiler.instrumentedEvents,
      profiler.instrumentedCallbacks)
  end, 900)

  -- -----------------------------------------------------------------------
  -- HUD
  -- -----------------------------------------------------------------------
  local function fmtInt(v)
    return tostring(math.floor((tonumber(v) or 0) + 0.5))
  end

  local function shortId(s, n)
    s = tostring(s or "?")
    n = n or 22
    if #s <= n then return s end
    return s:sub(1, n - 1) .. "~"
  end

  local function currentRows()
    if diagnostic.report then return diagnostic.report.modsImpact or {}, true end
    return profiler.ranked, false
  end

  local function drawPanel(game, viewport, frameMs)
    if not (love and love.graphics) then return end
    local t = now()

    updateHotkeys(t)
    if t - profiler.lastScan >= 0.50 then
      profiler.lastScan = t
      scanRuntime()
    end
    if diagnostic.active and t - diagnostic.started >= DIAGNOSTIC_SECONDS then
      stopDiagnostic(t)
    end

    closeProfilerWindow(t)
    updateSnapshot(game, t)

    if not visible then return end

    local lines = {
      ("FPS %s  Frame %.2f ms  1%%low %s  Logic/s %.1f"):format(
        fmtInt(snapshot.fps), frameMs, fmtInt(snapshot.low1), logicPerSecond)
    }

    if diagnostic.active then
      local backend = diagnostic.deepAvailable and "DEEP"
        or (diagnostic.callbackProfilerAvailable and "PROV" or "DIRECT")
      lines[#lines + 1] = ("DIAG %.1f/%.1fs  %s  slow>%0.1fms %d"):format(
        t - diagnostic.started, DIAGNOSTIC_SECONDS,
        backend, SLOW_MS, diagnostic.slowFrames)
    elseif diagnostic.report then
      local r = diagnostic.report
      local c = r.capture or {}
      local attr = (c.slowFrames or 0) > 0
        and (((c.slowFrames or 0) - (c.unattributedSlowFrames or 0)) * 100 / c.slowFrames) or 0
      lines[#lines + 1] = ("FROZEN DIAG %.1fs  slow %d severe %d  attributed %.0f%%"):format(
        r.capture and r.capture.durationSeconds or r.duration or 0,
        r.capture and r.capture.slowFrames or r.slowFrames or 0,
        r.capture and r.capture.severeFrames or r.severeFrames or 0, attr)
      if IS_ANDROID and androidExport.status then
        lines[#lines + 1] = "ANDROID: " .. tostring(androidExport.status)
      end
      if exportState.relativeJson then
        lines[#lines + 1] = "EXPORT: " .. shortId(tostring(exportState.relativeJson), 78)
      elseif exportState.error then
        lines[#lines + 1] = "EXPORT ERROR: " .. shortId(exportState.error, 70)
      end
    end

    if detailed then
      lines[#lines + 1] = ("Avg %.2f  Worst %.2f ms  Lua %.1f MB  Texture %.1f MB"):format(
        snapshot.avgMs, snapshot.worstMs, snapshot.luaMB, snapshot.textureMB)
      lines[#lines + 1] = ("Draw %d  Batched %d  Canvas %d  Shader %d  State %s"):format(
        snapshot.drawcalls, snapshot.batched, snapshot.canvasswitches,
        snapshot.shaderswitches, snapshot.top)
      lines[#lines + 1] = "--- MOD FLUIDITY IMPACT ---"

      local rows, frozen = currentRows()
      if #rows == 0 then
        lines[#lines + 1] = diagnostic.active and "collecting diagnostic samples..." or "waiting for profiler sample..."
      else
        for i = 1, math.min(6, #rows) do
          local r = rows[i]
          local verdict = frozen and (r.verdict or "-") or "LIVE"
          local deepPct = frozen and (r.deepPct or 0) or 0
          lines[#lines + 1] = ("%d %-4s %-20s CPU%5.1f%% STUT%4.0f%% MAX%5.2f D%5.0f/s S%4.0f%%"):format(
            i, verdict, shortId(r.id, 20), r.percent or 0, r.stutterPct or 0,
            r.maxMs or 0, r.drawsPerSec or 0, deepPct)
          if frozen then
            local hot = r.deepPct >= 5 and r.deepHot ~= "-" and ("deep " .. tostring(r.deepHot))
              or tostring(r.hot or "-")
            lines[#lines + 1] = "   hot: " .. shortId(hot, 72)
          end
        end
      end

      if diagnostic.report then
        local r = diagnostic.report
        local c = r.capture or {}
        local deepCoverage = (c.deepSamplesAll or 0) > 0
          and ((c.deepSamplesAttributedToMods or 0) * 100 / c.deepSamplesAll) or 0
        lines[#lines + 1] = ("Slow unattrib %d/%d  Deep mod coverage %.1f%%"):format(
          c.unattributedSlowFrames or 0, c.slowFrames or 0, deepCoverage)
        if not c.deepAvailable then
          if c.provenanceCallbackProfilerAvailable then
            lines[#lines + 1] = ("Deep API sandboxed; provenance profiler active (%d callbacks)"):format(
              tonumber(c.instrumentedProvenanceCallbacks) or 0)
          else
            lines[#lines + 1] = "Deep sampler unavailable: " .. tostring(c.deepReason or "unknown")
          end
        end
      else
        lines[#lines + 1] = "CPU=exclusive hook/event/content | STUT=slow-frame wins | S=deep sample%"
      end
      lines[#lines + 1] = IS_ANDROID
        and "Touch PERF for HUD / VIEW / RESET / CAPTURE / SAVE"
        or "F3 hide  F4 compact  F6 reset  F8 10s diagnostic  F9 export"
    else
      local rows, frozen = currentRows()
      local top = rows[1]
      local culprit = top and ("%s CPU %.1f%% STUT %.0f%% MAX %.2fms"):format(
        shortId(top.id, 18), top.percent or 0, top.stutterPct or 0, top.maxMs or 0)
        or "sampling..."
      lines[#lines + 1] = "Top: " .. culprit
      if IS_ANDROID then
        lines[#lines + 1] = frozen and "Touch PERF -> CAPTURE / SAVE / VIEW / HUD"
          or "Touch PERF -> CAPTURE / VIEW / HUD"
      else
        lines[#lines + 1] = frozen and "F8 new diagnostic  F9 export  F4 details  F3 hide"
          or "F8 diagnose  F4 details  F3 hide"
      end
    end

    local pushed = love.graphics.push and pcall(love.graphics.push, "all")
    local font = love.graphics.getFont and love.graphics.getFont() or nil
    local lineH = font and font.getHeight and font:getHeight() or 12
    local maxW = 0
    for _, s in ipairs(lines) do
      local w = (font and font.getWidth) and font:getWidth(s) or (#s * 7)
      if w > maxW then maxW = w end
    end

    local pad = 6
    local panelW = maxW + pad * 2
    local panelH = #lines * lineH + pad * 2 + (#lines - 1) * 2
    local x, y = 6, 6
    if viewport and viewport.gameX and viewport.gameX >= panelW + 12 then
      x = math.max(6, viewport.gameX - panelW - 6)
      y = math.max(6, viewport.gameY or 6)
    end

    if love.graphics.setBlendMode then pcall(love.graphics.setBlendMode, "alpha") end
    love.graphics.setColor(0, 0, 0, 0.84)
    love.graphics.rectangle("fill", x, y, panelW, panelH)
    love.graphics.setColor(1, 1, 1, 1)
    local ty = y + pad
    for _, s in ipairs(lines) do
      love.graphics.print(s, x + pad, ty)
      ty = ty + lineH + 2
    end

    if pushed and love.graphics.pop then love.graphics.pop()
    else love.graphics.setColor(1, 1, 1, 1) end
  end

  local function androidSafeRect()
    local w, h = love.graphics.getDimensions()
    local x, y = 0, 0
    if love.window and type(love.window.getSafeArea) == "function" then
      local ok, sx, sy, sw, sh = pcall(love.window.getSafeArea)
      if ok and tonumber(sw) and tonumber(sh) and sw > 0 and sh > 0 then
        return sx, sy, sw, sh
      end
    end
    return x, y, w, h
  end

  local function drawAndroidButton(id, label, x, y, w, h, enabled, accent)
    androidUi.rects[id] = { x = x, y = y, w = w, h = h }
    local g = love.graphics
    local down = false
    for _, pressed in pairs(androidUi.pressed) do
      if pressed == id then down = true break end
    end

    if not enabled then
      g.setColor(0.08, 0.09, 0.11, 0.66)
    elseif down then
      g.setColor(0.18, 0.42, 0.64, 0.96)
    elseif accent then
      g.setColor(0.11, 0.30, 0.48, 0.94)
    else
      g.setColor(0.035, 0.055, 0.080, 0.92)
    end
    g.rectangle("fill", x, y, w, h, 8, 8)
    g.setLineWidth(1.5)
    g.setColor(enabled and 0.40 or 0.25,
      enabled and 0.70 or 0.27,
      enabled and 0.96 or 0.30, enabled and 0.95 or 0.65)
    g.rectangle("line", x + 0.75, y + 0.75, w - 1.5, h - 1.5, 8, 8)

    local font = g.getFont and g.getFont()
    local tw = font and font.getWidth and font:getWidth(label) or #label * 7
    local th = font and font.getHeight and font:getHeight() or 12
    g.setColor(enabled and 1 or 0.55, enabled and 1 or 0.57,
      enabled and 1 or 0.60, 1)
    g.print(label, x + (w - tw) / 2, y + (h - th) / 2)
  end

  local function drawAndroidTouchUi()
    if not (IS_ANDROID and love and love.graphics) then return end

    local g = love.graphics
    local pushed = g.push and pcall(g.push, "all")
    local sx, sy, sw, sh = androidSafeRect()
    local scale = math.max(0.85, math.min(1.35, math.min(sw / 1280, sh / 720)))
    local buttonW = math.floor(96 * scale + 0.5)
    local buttonH = math.floor(42 * scale + 0.5)
    local gap = math.floor(7 * scale + 0.5)
    local margin = math.floor(10 * scale + 0.5)
    local x = sx + sw - margin - buttonW
    local y = sy + margin

    drawAndroidButton("perf", androidUi.open and "PERF ×" or "PERF",
      x, y, buttonW, buttonH, true, true)

    if androidUi.open then
      local labels = {
        { "hud", visible and "HUD ON" or "HUD OFF", true },
        { "view", detailed and "DETAIL" or "COMPACT", true },
        { "reset", "RESET", true },
        { "capture", diagnostic.active and "STOP" or "CAPTURE", true },
        { "save", "SAVE", diagnostic.report ~= nil },
      }
      for i, row in ipairs(labels) do
        local by = y + i * (buttonH + gap)
        drawAndroidButton(row[1], row[2], x, by,
          buttonW, buttonH, row[3], row[1] == "capture" and diagnostic.active)
      end

      if diagnostic.active then
        local progress = math.max(0, math.min(1,
          (now() - diagnostic.started) / DIAGNOSTIC_SECONDS))
        local py = y + 6 * (buttonH + gap)
        g.setColor(0.02, 0.03, 0.05, 0.86)
        g.rectangle("fill", x, py, buttonW, 8 * scale, 4, 4)
        g.setColor(0.25, 0.72, 1.0, 0.98)
        g.rectangle("fill", x, py, buttonW * progress, 8 * scale, 4, 4)
      end
    else
      androidUi.rects.hud = nil
      androidUi.rects.view = nil
      androidUi.rects.reset = nil
      androidUi.rects.capture = nil
      androidUi.rects.save = nil
    end

    if androidUi.status and now() <= (androidUi.statusUntil or 0) then
      local font = g.getFont and g.getFont()
      local text = tostring(androidUi.status)
      local tw = font and font.getWidth and font:getWidth(text) or #text * 7
      local th = font and font.getHeight and font:getHeight() or 12
      local bx = math.max(sx + margin, x - tw - 26 * scale)
      local by = y
      g.setColor(0.02, 0.03, 0.05, 0.88)
      g.rectangle("fill", bx, by, tw + 16 * scale, buttonH, 8, 8)
      g.setColor(0.90, 0.96, 1.0, 1)
      g.print(text, bx + 8 * scale, by + (buttonH - th) / 2)
    end

    if pushed and g.pop then g.pop()
    else g.setColor(1, 1, 1, 1) end
  end

  -- Outermost HUD wrapper.  Calling next first guarantees every downstream
  -- render.hud mod has finished and its instrumented callback has been
  -- recorded before we classify this frame or display its row.
  mod.hooks:wrap("render.hud", function(nextFn, game, viewport)
    local result = nextFn(game, viewport)
    local t = now()
    local frameMs = lastHudTime and ((t - lastHudTime) * 1000) or TARGET_MS
    lastHudTime = t
    if frameMs > 0 and frameMs < 1000 then
      snapshot.frameMs = frameMs
      pushFrameSample(frameMs)
      finalizeFrame(frameMs)
    else
      -- Ignore focus-loss / debugger pauses rather than charging the next
      -- real frame for callbacks accumulated across a multi-second gap.
      profiler.frameDirect = {}
      profiler.frameDeep = {}
    end
    drawPanel(game or gameRef, viewport, frameMs)
    drawAndroidTouchUi()
    return result
  end, 100000)

  mod.exports.getSnapshot = function()
    local copy = {}
    for k, v in pairs(snapshot) do copy[k] = v end
    copy.logicPerSecond = logicPerSecond
    copy.logicSteps = logicSteps
    copy.visible = visible
    copy.detailed = detailed
    copy.slowThresholdMs = SLOW_MS
    copy.mods = {}
    for i, r in ipairs(profiler.ranked) do
      local row = {}
      for k, v in pairs(r) do row[k] = v end
      copy.mods[i] = row
    end
    return copy
  end

  mod.exports.getDiagnosticReport = function()
    return diagnostic.report
  end

  mod.exports.exportDiagnosticReport = function()
    if not diagnostic.report then return false, "no completed diagnostic report" end
    local ok = exportDiagnosticReport(diagnostic.report)
    return ok, ok and exportState.relativeJson or exportState.error
  end

  mod.exports.getExportState = function()
    local out = {}
    for k, v in pairs(exportState) do out[k] = v end
    out.android = {
      platform = IS_ANDROID,
      saveAsAvailable = androidSaveAsAvailable(),
      pending = androidExport.pending,
      status = androidExport.status,
      suggestedName = androidExport.suggestedName,
      error = androidExport.error,
    }
    return out
  end

  mod.exports.androidEdition = {
    enabled = IS_ANDROID,
    touchControls = IS_ANDROID,
    saveAsBridge = IS_ANDROID and androidSaveAsAvailable() or false,
  }

  mod.exports.startDiagnostic = function()
    if diagnostic.active then return false, "diagnostic already active" end
    startDiagnostic(now())
    return true
  end

  mod.exports.stopDiagnostic = function()
    if not diagnostic.active then return false, "diagnostic is not active" end
    stopDiagnostic(now())
    return true
  end
end
