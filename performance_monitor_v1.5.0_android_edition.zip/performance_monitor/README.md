# Performance Monitor v1.5.0 — Android Edition

Performance Monitor now has a first-class Android workflow. Desktop hotkeys are
still supported unchanged.

## Android touch controls

A small **PERF** button is always available in the top safe area. It is drawn
through `render.hud`, below Gen1Recomp's normal mobile controls, and receives
touches through the public `input.pointer` hook.

Tap **PERF** to open:

- **HUD ON/OFF** — show or hide the profiler panel (desktop F3).
- **DETAIL / COMPACT** — switch profiler detail level (desktop F4).
- **RESET** — clear rolling profiler samples (desktop F6).
- **CAPTURE / STOP** — start or stop the 10-second diagnostic (desktop F8).
- **SAVE** — re-export the frozen diagnostic report (desktop F9).

During capture a progress bar is shown under the touch drawer.

The native D-pad / A / B / Start / Select overlay keeps first refusal, so a
touch captured by Gen1Recomp's mobile controls never reaches Performance
Monitor.

## Android Save As

When a diagnostic finishes, v1.5.0 always saves the report internally first via
`mod.storage`, exactly like v1.4.1.

On Android it then tries to open the system **Save As** document picker
automatically.

Suggested filename:

`gen1recomp_performance_YYYYMMDD_HHMMSS.json`

The player can choose Downloads, Drive, SD-card providers or another location
offered by Android's Storage Access Framework.

### How the bridge works

Current Gen1Recomp Android already has a native `love.system.createFile`
create-document bridge for save export. Performance Monitor reuses it without
requiring raw `love.filesystem` access from the sandbox:

1. the JSON is written to Performance Monitor's normal `mod.storage`;
2. through the declared `engine_internals` permission the mod asks
   `src.core.SaveData.persistenceFs()` for the engine-owned persistence backend;
3. it stages the JSON bytes as the host bridge's `pending_export.sav`;
4. `love.system.createFile()` opens Android `ACTION_CREATE_DOCUMENT` with a
   `.json` suggested name;
5. after success the host writes `export_done.flag`, which the mod consumes;
6. the temporary staging file is removed.

The temporary file being called `pending_export.sav` is only an implementation
detail of the existing Android host bridge. Its contents are UTF-8 JSON and the
file offered to the user is `.json`.

If the system picker is unavailable or the user cancels it, the internal
`mod.storage` report remains intact and **SAVE** can be tapped again.

## Desktop controls

- **F3** show/hide
- **F4** compact/detailed
- **F6** reset rolling samples
- **F8** start/stop the 10-second diagnostic
- **F9** export/re-export the frozen report

Desktop behavior is otherwise unchanged.

## Internal report

The sandbox-safe internal copy is still written under Performance Monitor's
playthrough-scoped `mod_storage` area:

- `exports/performance_report_latest_json.bin`
- `exports/performance_report_latest_txt.bin`
- timestamped archive reports under `reports/`

The JSON `.bin` contains plain UTF-8 JSON.

## Diagnostic attribution

The monitor combines:

1. exclusive Runtime hook/event timing;
2. slow-frame winner correlation;
3. sandbox-safe provenance callback timing;
4. the optional deep Lua sampler when the host exposes the debug API.

GPU/driver time and C-side engine work that cannot be attributed remain
explicitly UNATTRIBUTED rather than being assigned to a mod without evidence.
