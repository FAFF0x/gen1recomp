# Performance Monitor 1.5.0 Android regression

## Touch drawer
1. Boot Android with normal touch controls enabled.
2. PERF button appears near the top-right safe area.
3. Tap PERF: HUD / VIEW / RESET / CAPTURE / SAVE appear.
4. Touching D-pad / A / B / Start / Select does not activate PERF buttons.
5. HUD hides/shows the profiler while PERF remains reachable.
6. VIEW switches compact/detailed.
7. RESET clears rolling values.
8. CAPTURE starts a 10-second diagnostic and shows progress.
9. STOP ends an active capture early.

## Save As
1. Finish a diagnostic.
2. Internal mod.storage JSON/TXT export succeeds first.
3. Android ACTION_CREATE_DOCUMENT opens automatically.
4. Suggested name ends in .json.
5. Save into Downloads and return to the game.
6. Overlay reports REPORT SAVED.
7. Tap SAVE to export the frozen report again.
8. Cancel the picker: internal report remains and SAVE can retry.

## Desktop regression
1. F3/F4/F6/F8/F9 still work.
2. No PERF touch drawer is drawn on Windows/Linux/macOS.
3. No Android staging file is created on desktop.
