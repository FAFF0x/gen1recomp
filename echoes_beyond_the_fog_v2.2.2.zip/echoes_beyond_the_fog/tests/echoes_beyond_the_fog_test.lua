local vanillaBillRows = {
  { "show_text", "_BillsHouseBillCheckOutMyRarePokemonText" },
}
package.preload["src.script.MapScripts"] = function()
  return {
    baseTalk = function(_, talkId)
      if talkId == "TEXT_BILLSHOUSE_BILL_CHECK_OUT_MY_RARE_POKEMON" then
        return vanillaBillRows
      end
      return nil
    end,
  }
end
local function registry()
  local r = { values = {} }
  function r:register(id, value) self.values[id] = value return true end
  return r
end
local saved, questDef = {}, nil
local questGetCalls = 0
local quests = {
  register=function(def) questDef=def return true end,
  start=function() end, update=function() end, complete=function() end, remove=function() end,
  get=function() questGetCalls=questGetCalls+1 return nil end,
}
local mod = {
  id="echoes_beyond_the_fog", path=".",
  content={ commands=registry(), tokens=registry(), trainers=registry(), tilesets=registry(), maps=registry(), map_scripts=registry() },
  save={ get=function(_,k,d) local v=saved[k]; if v==nil then return d end; return v end, set=function(_,k,v) saved[k]=v end },
  find=function(id) if id=="quest_system" then return {exports=quests} end end,
  events={on=function() end, emit=function() end}, exports={},
  log={warn=function() end},
}
local chunk, err=loadfile("main.lua"); assert(chunk,err)
chunk()(mod)
assert(questDef and questDef.id=="echoes_beyond_the_fog.main")

-- Bill regression (v2.2.1):
-- The quest must not own BILL1's post-separator SS Ticket talk at all.
local billScript=assert(mod.content.map_scripts.values["BILLS_HOUSE"],
  "missing BILLS_HOUSE contribution")
assert(billScript.talk["TEXT_BILLSHOUSE_BILL_SS_TICKET"]==nil,
  "quest must not override Bill's SS Ticket dialogue")
assert(billScript.talk["TEXT_BILLSHOUSE_BILL_CHECK_OUT_MY_RARE_POKEMON"]~=nil,
  "quest must hook only post-help BILL2 dialogue")

-- Vanilla fallback must support the engine's NORMAL representation: a table
-- of ScriptRunner rows. Calling this table like a function is the bug that
-- made Bill appear completely silent while the mod was enabled.
local delegatedRows=nil
local fakeRunner={
  exec=function(_,rows,ctx) delegatedRows=rows end,
  resume=function() error("table fallback must not resume callback path") end,
  yield=function() error("table fallback must not yield callback path") end,
}
local baseBillCommand=assert(mod.content.commands.values["fog:base_bill_chat"],
  "missing vanilla Bill delegate")
assert(type(baseBillCommand.fn)=="function", "Bill delegate has no fn")
baseBillCommand.fn({
  runner=fakeRunner,
  game={},
  overworld={},
  npc={},
}, "TEXT_BILLSHOUSE_BILL_CHECK_OUT_MY_RARE_POKEMON")
assert(delegatedRows==vanillaBillRows,
  "Bill table-style vanilla fallback was not executed through runner:exec")

-- Cell Separator / MET flags are intentionally too early to unlock this quest.
local earlyBillGame={save={inventory={SOULBADGE=1},flags={
  EVENT_USED_CELL_SEPARATOR_ON_BILL=true,
  EVENT_MET_BILL=true,
  EVENT_MET_BILL_2=true,
}}}
assert(questDef.hidden(earlyBillGame)==true,
  "quest unlocked before Bill's vanilla ticket/leave sequence completed")

-- The Route 25 post-help transition is the safe unlock point.
local postBillGame={save={inventory={SOULBADGE=1},flags={
  EVENT_USED_CELL_SEPARATOR_ON_BILL=true,
  EVENT_GOT_SS_TICKET=true,
  EVENT_MET_BILL=true,
  EVENT_MET_BILL_2=true,
  EVENT_LEFT_BILLS_HOUSE_AFTER_HELPING=true,
}}}
assert(questDef.hidden(postBillGame)==false,
  "quest did not unlock after the vanilla Bill sequence completed")

-- Performance regression: v2.1.0's completed() called quests.get() from
-- objective/marker resolvers, recursively rebuilding the same snapshot even
-- while the quest was hidden. v2.2.0 keeps the hot resolver surface tiny.
assert(type(questDef.objective)=="string", "objective must be cached/static")
assert(type(questDef.location)=="string", "location must be cached/static")
assert(type(questDef.progress)=="table", "progress must be cached/static")
for _=1,10000 do
  questDef.hidden({save={inventory={},flags={}}})
  questDef.markers[1].when({save={inventory={},flags={}}})
end
assert(questGetCalls==0, "inactive quest resolver called Quest System.get()")

-- One-shot completion: after reward/done state, journal + NPC marker vanish
-- and no replay command is exposed anymore.
saved.done=true
assert(questDef.hidden({save={inventory={SOULBADGE=1},flags={EVENT_LEFT_BILLS_HOUSE_AFTER_HELPING=true}}})==true,
  "completed quest must stay hidden")
assert(questDef.markers[1].when({save={inventory={SOULBADGE=1},flags={EVENT_LEFT_BILLS_HOUSE_AFTER_HELPING=true}}})==false,
  "completed quest marker must stay disabled")
assert(mod.content.commands.values["fog:reset_replay"]==nil, "replay command must not exist")
saved.done=nil
local floors={
 "CAPE_SIGNAL_OBSERVATORY","CAPE_SIGNAL_ENGINE_ROOM","CAPE_SIGNAL_BEACON_DOME",
 "FOGBOUND_CAVERNS","FOGBOUND_RELAY_DEPTHS","FOGBOUND_DOCK_APPROACH",
 "BLACK_TIDE_HIDEOUT","BLACK_TIDE_LABS","BLACK_TIDE_CONTROL",
}
for _,id in ipairs(floors) do
  local map=assert(mod.content.maps.values[id], "missing map "..id)
  assert(map.width==18 and map.height==14 and #map.blocks==252, "bad geometry "..id)
  assert(mod.content.map_scripts.values[id], "missing script "..id)
  local hasMarker=false
  for _,b in ipairs(map.blocks) do if b==24 then hasMarker=true break end end
  assert(hasMarker, "missing visible quest marker in "..id)
end
for id,ts in pairs(mod.content.tilesets.values) do
  assert(ts.imageWidth==800 and ts.imageHeight==32 and ts.tilesPerRow==100, "bad atlas "..id)
  assert(#ts.blocks==25, "bad block count "..id)
  local f=assert(io.open(ts.image,"rb"), "missing image "..ts.image); f:close()
end
for _,area in ipairs({
 {"CAPE_SIGNAL_OBSERVATORY","CAPE_SIGNAL_ENGINE_ROOM","CAPE_SIGNAL_BEACON_DOME"},
 {"FOGBOUND_CAVERNS","FOGBOUND_RELAY_DEPTHS","FOGBOUND_DOCK_APPROACH"},
 {"BLACK_TIDE_HIDEOUT","BLACK_TIDE_LABS","BLACK_TIDE_CONTROL"},
}) do
  local used={}
  for _,id in ipairs(area) do for _,b in ipairs(mod.content.maps.values[id].blocks) do used[b]=true end end
  for b=0,24 do assert(used[b], "metatile "..b.." not used in area") end
end

local game={save={inventory={SOULBADGE=1},flags={EVENT_LEFT_BILLS_HOUSE_AFTER_HELPING=true}},writeSave=function() end}
local queued=0
local ow={queueScript=function(_,rows) assert(type(rows)=="table" and #rows>0); queued=queued+1 end}
local triggerChecks={
 CAPE_SIGNAL_OBSERVATORY={{16,24},{6,6},{8,20},{28,4}},
 CAPE_SIGNAL_ENGINE_ROOM={{6,22},{16,14},{28,4}},
 CAPE_SIGNAL_BEACON_DOME={{6,22},{26,10},{28,4}},
 FOGBOUND_CAVERNS={{6,22},{6,18},{28,4}},
 FOGBOUND_RELAY_DEPTHS={{6,22},{16,14},{28,4}},
 FOGBOUND_DOCK_APPROACH={{6,22},{28,4}},
 BLACK_TIDE_HIDEOUT={{6,22},{6,18},{28,4}},
 BLACK_TIDE_LABS={{6,22},{6,8},{18,8},{30,8},{28,4}},
 BLACK_TIDE_CONTROL={{6,22},{26,8}},
}
for id,cells in pairs(triggerChecks) do
  local script=assert(mod.content.map_scripts.values[id])
  if script.onEnter then script.onEnter(game,ow) end
  for _,cell in ipairs(cells) do
    local handled=script.onStep(game,ow,cell[1],cell[2])
    assert(handled==true, "trigger not handled "..id.." at "..cell[1]..","..cell[2])
  end
end
assert(queued>0, "map scripts queued no guidance")

print("echoes_beyond_the_fog_test: ok")
