## 1.0.4

- Renamed the ambiguous ACTIVE tab to the explicit INCOMP status filter.
- The screen now opens directly on the first achievement.
- Added a solid black triangle cursor to Search, Category and achievement rows.
- The selected achievement receives a bright yellow full-row highlight.
- Replaced variable-width current/target values in the list with fixed-width percentages.
- Added a two-line control legend with separate movement, tab, open and back hints.
- Hardened wrapping against single words wider than the detail panel.
- Added automated checks for the incomplete filter, cursor type and non-overlapping columns.

## 1.0.3

- Rebuilt navigation as one vertical path: Search, Filter, then achievements.
- Search and Filter are now selectable with A; START and SELECT are only optional shortcuts.
- Reduced the visible list to three rows.
- Replaced character-count clipping with measured pixel-width clipping.
- Removed the oversized two-line control footer.
- Separated status, title and progress into fixed non-overlapping columns.
- Reworked the detail page with fixed title, description and progress regions.
- Added exported layout bounds for automated overlap checks.

## 1.0.2

- Rebuilt the interface around readability instead of information density.
- Reduced the achievement list from six compact rows to four large rows.
- Removed category color strips, tiny checkboxes and inline progress bars.
- The list now shows only status, title and progress.
- Full descriptions are displayed only on a separate detail page.
- Enlarged spacing between every text block and simplified footer controls.
- Simplified unlock notifications to two clear lines.

## 1.0.1

- Rebuilt the Achievements screen with a light, high-contrast palette.
- Fixed invisible dark font glyphs over the previous dark-blue background.
- Added solid black borders, bright selected rows and clearer completion marks.
- Updated details and unlock notifications for palette-safe readability.

# Changelog

## v1.0.0
- Added 100 obtainable achievements.
- Added START-menu integration.
- Added ALL, ACTIVE and DONE tabs.
- Added title/description search and category filters.
- Added live progress cards, detail pages and unlock notifications.
- Added persistent battle, evolution, step, map and Safari counters.
