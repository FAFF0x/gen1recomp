-- Kanto Achievements
-- Adds a complete achievement system, persistent progress tracking,
-- an Achievements entry in the START menu, search/filter navigation,
-- details, progress bars and unlock notifications.

local BADGES = {
  "BOULDERBADGE", "CASCADEBADGE", "THUNDERBADGE", "RAINBOWBADGE",
  "SOULBADGE", "MARSHBADGE", "VOLCANOBADGE", "EARTHBADGE",
}

local function loadModFile(mod, filename)
  local source = assert(mod:read(filename), filename .. " missing")
  local chunk, err = load(source, "@" .. mod.path .. "/" .. filename)
  assert(chunk, err)
  return chunk()
end

local function countTrue(t)
  local n = 0
  for _, value in pairs(t or {}) do if value then n = n + 1 end end
  return n
end

local function countSet(t)
  local n = 0
  for _, value in pairs(t or {}) do if value then n = n + 1 end end
  return n
end

local function defaultState()
  return {
    unlocked = {},
    stats = {
      catches = 0, evolutions = 0, battles = 0, wins = 0,
      trainerWins = 0, wildWins = 0, winStreak = 0, maxWinStreak = 0,
      safariCatches = 0, steps = 0, visitedMaps = {},
    },
  }
end

local function normalizeState(state)
  if type(state) ~= "table" then state = defaultState() end
  state.unlocked = type(state.unlocked) == "table" and state.unlocked or {}
  state.stats = type(state.stats) == "table" and state.stats or {}
  local defaults = defaultState().stats
  for key, value in pairs(defaults) do
    if state.stats[key] == nil then
      state.stats[key] = type(value) == "table" and {} or value
    end
  end
  if type(state.stats.visitedMaps) ~= "table" then state.stats.visitedMaps = {} end
  return state
end

local function ownedSet(save)
  return (save and save.pokedex and save.pokedex.owned) or {}
end

local function seenSet(save)
  return (save and save.pokedex and save.pokedex.seen) or {}
end

local function inventory(save)
  return (save and save.inventory) or {}
end

local function pcInventory(save)
  return (save and save.pcItems) or {}
end

local function itemQuantity(save, id)
  return (tonumber(inventory(save)[id]) or 0)
       + (tonumber(pcInventory(save)[id]) or 0)
end

local function ownsSpecies(save, species)
  return ownedSet(save)[species] == true
end

local function machineCount(game, kind)
  local n = 0
  for id, def in pairs(game.data.items or {}) do
    if itemQuantity(game.save, id) > 0 and def.machine and def.machine.kind == kind then
      n = n + 1
    end
  end
  return n
end

local function ownsMachineMove(game, moveId, kind)
  for id, def in pairs(game.data.items or {}) do
    local m = def.machine
    if itemQuantity(game.save, id) > 0 and m and m.move == moveId
       and (not kind or m.kind == kind) then return true end
  end
  return false
end

local function keyItemCount(game)
  local n = 0
  for id, def in pairs(game.data.items or {}) do
    if itemQuantity(game.save, id) > 0 and def and def.keyItem then n = n + 1 end
  end
  return n
end

local function inventoryUnique(save)
  local ids, n = {}, 0
  for id, qty in pairs(inventory(save)) do if qty and qty > 0 then ids[id] = true end end
  for id, qty in pairs(pcInventory(save)) do if qty and qty > 0 then ids[id] = true end end
  for _ in pairs(ids) do n = n + 1 end
  return n
end

local function badgeCount(save)
  local inv, n = inventory(save), 0
  for _, id in ipairs(BADGES) do if inv[id] and inv[id] > 0 then n = n + 1 end end
  return n
end

local function boxedCount(save)
  local n = 0
  for _, box in ipairs((save and save.boxes) or {}) do
    for _ in ipairs(box or {}) do n = n + 1 end
  end
  return n
end

local function maxPartyLevel(save)
  local best = 0
  for _, mon in ipairs((save and save.party) or {}) do
    best = math.max(best, tonumber(mon.level) or 0)
  end
  return best
end

local function partySumLevel(save)
  local total = 0
  for _, mon in ipairs((save and save.party) or {}) do
    total = total + (tonumber(mon.level) or 0)
  end
  return total
end

local function progressFor(achievement, game, state)
  local save = game and game.save or {}
  local condition = achievement.condition or {}
  local kind = condition.kind
  local current, target = 0, tonumber(condition.target) or 1

  if kind == "flag" then
    current = (save.flags and save.flags[condition.name]) and 1 or 0
  elseif kind == "item" then
    current = math.min(itemQuantity(save, condition.id), tonumber(condition.count) or 1)
    target = tonumber(condition.count) or 1
  elseif kind == "item_all" then
    target = #(condition.ids or {})
    for _, id in ipairs(condition.ids or {}) do
      if itemQuantity(save, id) > 0 then current = current + 1 end
    end
  elseif kind == "item_any" then
    for _, id in ipairs(condition.ids or {}) do
      if itemQuantity(save, id) > 0 then current = 1 break end
    end
  elseif kind == "badge_count" then
    current = badgeCount(save)
  elseif kind == "machine_move" then
    current = ownsMachineMove(game, condition.move, condition.machine) and 1 or 0
  elseif kind == "machine_count" then
    current = machineCount(game, condition.machine)
  elseif kind == "key_item_count" then
    current = keyItemCount(game)
  elseif kind == "inventory_unique" then
    current = inventoryUnique(save)
  elseif kind == "owned_count" then
    current = countTrue(ownedSet(save))
  elseif kind == "seen_count" then
    current = countTrue(seenSet(save))
  elseif kind == "owns_species" then
    current = ownsSpecies(save, condition.species) and 1 or 0
  elseif kind == "owns_all_species" then
    target = #(condition.species or {})
    for _, species in ipairs(condition.species or {}) do
      if ownsSpecies(save, species) then current = current + 1 end
    end
  elseif kind == "owns_any_species" then
    for _, species in ipairs(condition.species or {}) do
      if ownsSpecies(save, species) then current = 1 break end
    end
  elseif kind == "party_count" then
    current = #(save.party or {})
  elseif kind == "max_level" then
    current = maxPartyLevel(save)
  elseif kind == "party_all_level" then
    target = tonumber(condition.target) or 6
    for _, mon in ipairs(save.party or {}) do
      if (tonumber(mon.level) or 0) >= (tonumber(condition.level) or 1) then
        current = current + 1
      end
    end
  elseif kind == "party_any_moves" then
    for _, mon in ipairs(save.party or {}) do current = math.max(current, #(mon.moves or {})) end
  elseif kind == "party_all_moves" then
    target = tonumber(condition.target) or 6
    for _, mon in ipairs(save.party or {}) do if #(mon.moves or {}) >= 4 then current = current + 1 end end
  elseif kind == "party_sum_level" then
    current = partySumLevel(save)
  elseif kind == "boxed_count" then
    current = boxedCount(save)
  elseif kind == "visited_maps" then
    current = countSet(state.stats.visitedMaps)
  elseif kind == "money" then
    current = tonumber(save.money) or 0
  elseif kind == "coins" then
    current = tonumber(save.coins) or 0
  elseif kind == "stat" then
    current = tonumber(state.stats[condition.name]) or 0
    if condition.fallback == "owned" then current = math.max(current, countTrue(ownedSet(save))) end
  end

  current = math.max(0, current)
  return current, math.max(1, target)
end

return function(mod)
  local achievements = loadModFile(mod, "achievements.lua")
  local activeGame
  local runtime = { frame = 0, lastMap = nil, lastX = nil, lastY = nil,
                    toastQueue = {}, toastActive = false }

  local function state()
    local s = normalizeState(mod.save:get("achievement_state"))
    return s
  end

  local function persist(s)
    mod.save:set("achievement_state", normalizeState(s))
  end

  local function isUnlocked(achievement)
    return state().unlocked[achievement.id] ~= nil
  end

  local function queueToast(title)
    runtime.toastQueue[#runtime.toastQueue + 1] = title
  end

  local function evaluateAll(game, notify)
    game = game or activeGame
    if not (game and game.save and game.data) then return 0 end
    local s, newly = state(), 0
    for _, achievement in ipairs(achievements) do
      if s.unlocked[achievement.id] == nil then
        local current, target = progressFor(achievement, game, s)
        if current >= target then
          s.unlocked[achievement.id] = { playTime = tonumber(game.save.playTime) or 0 }
          newly = newly + 1
          if notify then queueToast(achievement.title) end
        end
      end
    end
    if newly > 0 then persist(s) end
    return newly
  end

  local function mutateStats(fn)
    local s = state()
    fn(s.stats)
    persist(s)
    evaluateAll(activeGame, true)
  end

  local api = {}
  function api.game() return activeGame end
  function api.list() return achievements end
  function api.state() return state() end
  function api.unlocked(achievement) return state().unlocked[achievement.id] ~= nil end
  function api.progress(achievement)
    if not activeGame then return 0, tonumber(achievement.condition.target) or 1 end
    return progressFor(achievement, activeGame, state())
  end
  function api.evaluate(notify) return evaluateAll(activeGame, notify == true) end
  function api.unlockedCount()
    local s, n = state(), 0
    for _, achievement in ipairs(achievements) do if s.unlocked[achievement.id] then n = n + 1 end end
    return n
  end

  local installUI = loadModFile(mod, "ui.lua")
  installUI(mod, achievements, api)

  mod.hooks:wrap("ui.start_menu.items", function(nextFn, game, items)
    local out = nextFn(game, items)
    if type(out) ~= "table" then return out end
    mod.ui.insertBefore(out, "OPTION", {
      label = "ACHIEVEMENTS",
      onSelect = function()
        activeGame = game
        evaluateAll(game, false)
        mod.ui.push(game, "AchievementsScreen", {
          onClose = function() mod.ui.push(game, "StartMenu") end,
        })
      end,
    })
    return out
  end)

  mod.events:on("game.ready", function(event)
    activeGame = event and event.game or activeGame
    evaluateAll(activeGame, false)
  end)

  mod.events:on("save.created", function()
    runtime.lastMap, runtime.lastX, runtime.lastY = nil, nil, nil
    evaluateAll(activeGame, false)
  end)

  mod.events:on("save.loaded", function()
    runtime.lastMap, runtime.lastX, runtime.lastY = nil, nil, nil
    evaluateAll(activeGame, false)
  end)

  mod.events:on("save.writing", function()
    evaluateAll(activeGame, false)
  end)

  mod.events:on("pokemon.caught", function(event)
    mutateStats(function(stats)
      stats.catches = (stats.catches or 0) + 1
      if event and event.battle and event.battle.safari then
        stats.safariCatches = (stats.safariCatches or 0) + 1
      end
    end)
  end)

  mod.events:on("pokemon.evolved", function()
    mutateStats(function(stats) stats.evolutions = (stats.evolutions or 0) + 1 end)
  end)

  mod.events:on("battle.ended", function(event)
    mutateStats(function(stats)
      stats.battles = (stats.battles or 0) + 1
      local result = event and event.result
      local victory = result == "win" or result == "caught"
      if victory then
        stats.wins = (stats.wins or 0) + 1
        stats.winStreak = (stats.winStreak or 0) + 1
        stats.maxWinStreak = math.max(stats.maxWinStreak or 0, stats.winStreak)
        local kind = event and event.battle and event.battle.kind
        if kind == "trainer" then stats.trainerWins = (stats.trainerWins or 0) + 1
        elseif kind == "wild" then stats.wildWins = (stats.wildWins or 0) + 1 end
      elseif result == "lose" then
        stats.winStreak = 0
      end
    end)
  end)

  mod.hooks:wrap("input.step", function(nextFn, input, dt)
    local result = nextFn(input, dt)
    local game = activeGame
    if game and game.save then
      local ow, p = game.overworld, game.overworld and game.overworld.player
      if ow and ow.map and p then
        local mapId = ow.map.id
        local moved = runtime.lastMap ~= nil and
          (mapId ~= runtime.lastMap or p.cellX ~= runtime.lastX or p.cellY ~= runtime.lastY)
        if moved then
          local s = state()
          s.stats.steps = (s.stats.steps or 0) + 1
          s.stats.visitedMaps[mapId] = true
          persist(s)
        elseif runtime.lastMap == nil then
          local s = state(); s.stats.visitedMaps[mapId] = true; persist(s)
        end
        runtime.lastMap, runtime.lastX, runtime.lastY = mapId, p.cellX, p.cellY
      end

      runtime.frame = runtime.frame + 1
      if runtime.frame % 30 == 0 then evaluateAll(game, true) end

      if not runtime.toastActive and #runtime.toastQueue > 0
         and game.stack and game.stack:top() == game.overworld then
        runtime.toastActive = true
        local title = table.remove(runtime.toastQueue, 1)
        mod.ui.push(game, "AchievementToast", title, function()
          runtime.toastActive = false
        end)
      end
    end
    return result
  end)

  mod.exports.achievements = achievements
  mod.exports.progress = function(achievement, game, customState)
    return progressFor(achievement, game or activeGame, normalizeState(customState or state()))
  end
  mod.exports.evaluate = evaluateAll
  mod.exports.state = state
  mod.exports.count = #achievements
end
