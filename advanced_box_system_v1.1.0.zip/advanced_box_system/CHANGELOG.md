# Changelog

## 1.1.0

- Rebuilds the live Pokemon browser on the released `ListMenu` shape used by Bill's PC.
- Gen1 Modern UI 0.8.2+ now recognizes WITHDRAW, DEPOSIT, RELEASE and SWAP as rich Pokemon lists rather than a generic compatibility list.
- Adds small per-Pokemon row icons through Modern UI's standard icon resolver.
- Adds a large selected-Pokemon front sprite preview.
- Adds selected-Pokemon HP/status and ATK/DEF/SPD/SPC.
- Adds all four current moves with live PP.
- Box records without cached stats are displayed with a temporary read-only Gen 1 stat calculation.
- Automatically respects icon/sprite replacement mods, including NEW ICONS.
- Keeps instant LEFT/RIGHT box switching and direct party/box SWAP.
- Reorders the root operations to WITHDRAW / DEPOSIT / RELEASE / SWAP / CHANGE BOX so Modern UI can identify the stock Bill's-PC source semantics.

## 1.0.0

- Replaces the stock `BoxMenu` through the screen registry.
- Adds instant LEFT/RIGHT box switching to WITHDRAW and DEPOSIT.
- Adds direct party <-> box Pokemon SWAP.
- Adds SWAP shortcuts to WITHDRAW and DEPOSIT Pokemon action menus.
- Allows browsing empty and full boxes instead of aborting the workflow.
- Adds live box switching to RELEASE.
- Preserves CHANGE BOX and Yellow PRINT BOX.
- Preserves engine stat reconstruction for Pokemon entering the party.
- Preserves Yellow deposited-Pikachu happiness handling.
- Adds optional Gen1 Modern UI API v1 compatibility.
