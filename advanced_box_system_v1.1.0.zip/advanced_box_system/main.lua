-- Advanced Box System for Gen1Recomp
-- v1.1.0
--
-- Modern Bill's PC storage workflow:
--   * LEFT/RIGHT changes boxes instantly while browsing.
--   * WITHDRAW and DEPOSIT stay open on empty/full boxes.
--   * SWAP exchanges a boxed Pokemon with a party Pokemon directly.
--   * RELEASE supports live box switching.
--   * The browser is intentionally built on the engine's released ListMenu
--     shape so Gen1 Modern UI 0.8.2+ can use its rich Bill's-PC presenter:
--       - animated small Pokemon icons beside every row
--       - selected Pokemon front sprite
--       - HP / ATK / DEF / SPD / SPC
--       - all four moves with live PP
--     New Icons and other pokemon.icon / pokemon.sprite replacement mods are
--     resolved by Modern UI through the engine's standard sprite hooks.

local SCREEN_ID = "AdvancedBoxBrowser"
local VERSION = "1.1.0"

local function clamp(value, minimum, maximum)
  value = math.floor(tonumber(value) or minimum)
  if value < minimum then return minimum end
  if value > maximum then return maximum end
  return value
end

local function fit(text, maximum)
  text = tostring(text or "")
  if #text <= maximum then return text end
  if maximum <= 1 then return text:sub(1, maximum) end
  return text:sub(1, maximum - 1) .. "."
end

return function(mod)
  local Boxes = require("src.pokemon.Boxes")
  local Party = require("src.pokemon.Party")
  local Stats = require("src.pokemon.Stats")
  local Sound = require("src.core.Sound")
  local Strings = require("src.core.Strings")
  local GameVersion = require("src.core.GameVersion")

  local Font = mod.ui.Font
  local Menu = mod.ui.Menu
  local ListMenu = mod.ui.ListMenu
  local TextBox = mod.ui.TextBox

  local function monDef(game, mon)
    return mon and game.data.pokemon and game.data.pokemon[mon.species] or nil
  end

  local function monName(game, mon)
    local def = monDef(game, mon)
    return mon and (mon.nickname or (def and def.name) or tostring(mon.species)) or "--"
  end

  local function playCry(game, mon)
    if mon and mon.species then Sound.playCry(game.data, mon.species) end
  end

  local function boxAt(game, number)
    local boxes = Boxes.ensure(game.save)
    number = clamp(number or game.save.currentBox or 1, 1, Boxes.COUNT)
    return boxes[number]
  end

  local function setCurrentBox(game, number)
    Boxes.ensure(game.save)
    number = ((math.floor(number or 1) - 1) % Boxes.COUNT) + 1
    game.save.currentBox = number
    return number
  end

  local function nextBox(game, delta)
    return setCurrentBox(game, (game.save.currentBox or 1) + delta)
  end

  local function depositedHappiness(game, mon)
    local ok, follower = pcall(require, "src.world.PikachuFollower")
    if ok and follower and type(follower.modifyHappiness) == "function" then
      follower.modifyHappiness(game.save, "DEPOSITED", mon)
    end
  end

  local function findBoxRoot(game)
    local states = game and game.stack and game.stack.states
    if type(states) ~= "table" then return nil end
    for i = #states, 1, -1 do
      local state = states[i]
      if type(state) == "table" and state.screenId == "BoxMenu"
          and type(state.items) == "table" then
        return state
      end
    end
    return nil
  end

  local function temporaryStats(game, mon)
    if type(mon) ~= "table" then return {} end
    if type(mon.stats) == "table" then return mon.stats end
    local def = monDef(game, mon)
    if not (def and def.baseStats) then return {} end
    local ok, result = pcall(Stats.calc, def, mon.level or 1,
      mon.dvs or {}, mon.statExp)
    return ok and type(result) == "table" and result or {}
  end

  local function rowRight(game, mon)
    local stats = temporaryStats(game, mon)
    local hp = stats.hp
    if hp then
      local current = math.min(tonumber(mon.hp) or hp, hp)
      return ("Lv %d  %d/%d"):format(mon.level or 0, current, hp)
    end
    return ("Lv %d"):format(mon.level or 0)
  end

  local Browser = {}

  local function modeSourceKind(mode)
    if mode == "deposit" or mode == "swap_party" then return "party" end
    return "box"
  end

  local function modernRootIndex(mode)
    -- Gen1 Modern UI's released Bill's-PC presenter recognizes stock source
    -- shapes by the root PC row: 1=box/withdraw, 2=party/deposit,
    -- 3=box/release. Swap reuses the matching source shape while it is open.
    if mode == "deposit" or mode == "swap_party" then return 2 end
    if mode == "release" then return 3 end
    return 1
  end

  function Browser.list(state)
    if modeSourceKind(state.absMode) == "party" then
      return state.game.save.party or {}
    end
    return boxAt(state.game, state.game.save.currentBox)
  end

  function Browser.title(state)
    local boxNo = state.game.save.currentBox or 1
    if state.absMode == "withdraw" then
      return Strings("BOX %d (WITHDRAW)", boxNo)
    elseif state.absMode == "deposit" then
      return Strings("PARTY (DEPOSIT) -> BOX %d", boxNo)
    elseif state.absMode == "release" then
      return Strings("BOX %d (RELEASE)", boxNo)
    elseif state.absMode == "swap_box" or state.absMode == "swap_box_target" then
      return Strings("BOX %d (SWAP)", boxNo)
    elseif state.absMode == "swap_party" then
      return Strings("PARTY (SWAP) -> BOX %d", state.absPendingBoxNo or boxNo)
    end
    return Strings("BOX %d", boxNo)
  end

  function Browser.footer(state)
    if state.absMessage then return state.absMessage end
    if state.absMode == "swap_party" then
      return Strings("Choose party POKéMON.  B: back")
    elseif state.absMode == "swap_box" or state.absMode == "swap_box_target" then
      return Strings("L/R: BOX   A: SWAP   B: back")
    elseif state.absMode == "release" then
      return Strings("L/R: BOX   A: RELEASE   B: back")
    elseif state.absMode == "deposit" then
      return Strings("L/R: destination BOX   A: options")
    end
    return Strings("L/R: BOX   A: options")
  end

  function Browser.applyRootVisual(state)
    local root = state.absRoot
    if root then root.index = modernRootIndex(state.absMode) end
  end

  function Browser.restoreRoot(state)
    local root = state.absRoot
    if root and state.absRootIndex then root.index = state.absRootIndex end
  end

  function Browser.refresh(state, preserveIndex)
    local list = Browser.list(state)
    local oldIndex = state.index or 1
    state.items = {}
    for i, mon in ipairs(list) do
      state.items[#state.items + 1] = {
        label = fit(monName(state.game, mon), 13),
        right = rowRight(state.game, mon),
        value = i,
      }
    end
    state.title = Browser.title(state)
    state.footer = Browser.footer(state)
    if #state.items == 0 then
      state.index, state.scroll = 1, 0
    else
      state.index = clamp(preserveIndex and oldIndex or 1, 1, #state.items)
      local rows = state.rows or 7
      state.scroll = clamp(state.scroll or 0, 0, math.max(0, #state.items - rows))
      if state.index <= state.scroll then state.scroll = state.index - 1 end
      if state.index > state.scroll + rows then state.scroll = state.index - rows end
    end
    Browser.applyRootVisual(state)
  end

  function Browser.setMessage(state, message)
    state.absMessage = message
    state.footer = Browser.footer(state)
  end

  function Browser.clearMessage(state)
    state.absMessage = nil
    state.footer = Browser.footer(state)
  end

  function Browser.showMessage(state, text)
    state.game.stack:push(TextBox.new(state.game, text))
  end

  function Browser.showStats(state, mon)
    if mon then mod.ui.push(state.game, "SummaryMenu", mon) end
  end

  function Browser.switchBox(state, delta)
    if state.absMode == "swap_party" then return false end
    nextBox(state.game, delta)
    Browser.clearMessage(state)
    Browser.refresh(state, true)
    Sound.play(state.game.data, "Press_AB")
    return true
  end

  function Browser.withdrawAt(state, index)
    local boxNo = state.game.save.currentBox or 1
    local box = boxAt(state.game, boxNo)
    local mon = box[index]
    if not mon then return false end
    if #state.game.save.party >= Party.MAX then
      Browser.setMessage(state, "PARTY FULL - USE SWAP")
      return false
    end
    Stats.ensure(monDef(state.game, mon), mon)
    table.remove(box, index)
    table.insert(state.game.save.party, mon)
    playCry(state.game, mon)
    Browser.refresh(state, true)
    Browser.showMessage(state, Strings("%s was taken\nout of BOX %d.",
      monName(state.game, mon), boxNo))
    return true
  end

  function Browser.depositAt(state, index)
    local party = state.game.save.party or {}
    local mon = party[index]
    if not mon then return false end
    if #party <= 1 then
      Browser.setMessage(state, "LAST POKEMON - USE SWAP")
      return false
    end
    local boxNo = state.game.save.currentBox or 1
    local box = boxAt(state.game, boxNo)
    if #box >= Boxes.CAPACITY then
      Browser.setMessage(state, "BOX FULL - LEFT/RIGHT")
      return false
    end
    table.remove(party, index)
    table.insert(box, mon)
    depositedHappiness(state.game, mon)
    playCry(state.game, mon)
    Browser.refresh(state, true)
    Browser.showMessage(state, Strings("%s was stored\nin BOX %d.",
      monName(state.game, mon), boxNo))
    return true
  end

  function Browser.releaseAt(state, index)
    local boxNo = state.game.save.currentBox or 1
    local box = boxAt(state.game, boxNo)
    local mon = box[index]
    if not mon then return false end
    local name = monName(state.game, mon)
    state.game.stack:push(TextBox.new(state.game,
      Strings("Release %s from\nBOX %d forever?", name, boxNo), nil, {
        defaultNo = true,
        choice = function(yes)
          if not yes then return end
          local liveBox = boxAt(state.game, boxNo)
          if liveBox[index] ~= mon then
            Browser.setMessage(state, "POKEMON MOVED - TRY AGAIN")
            return
          end
          table.remove(liveBox, index)
          playCry(state.game, mon)
          Browser.refresh(state, true)
          Browser.showMessage(state, Strings("Bye %s!", name))
        end,
      }))
    return true
  end

  function Browser.beginSwapFromBox(state, index, returnMode)
    local boxNo = state.game.save.currentBox or 1
    local mon = boxAt(state.game, boxNo)[index]
    if not mon then return false end
    state.absPendingBoxNo = boxNo
    state.absPendingBoxIndex = index
    state.absPendingPartyIndex = nil
    state.absReturnMode = returnMode or "swap_box"
    state.absMode = "swap_party"
    state.index, state.scroll = 1, 0
    Browser.setMessage(state, "CHOOSE PARTY POKEMON")
    Browser.refresh(state, false)
    return true
  end

  function Browser.beginSwapFromParty(state, index)
    local mon = state.game.save.party and state.game.save.party[index]
    if not mon then return false end
    state.absPendingPartyIndex = index
    state.absPendingBoxNo = nil
    state.absPendingBoxIndex = nil
    state.absReturnMode = "deposit"
    state.absMode = "swap_box_target"
    state.index, state.scroll = 1, 0
    Browser.setMessage(state, "CHOOSE BOX POKEMON")
    Browser.refresh(state, false)
    return true
  end

  function Browser.finishSwap(state, boxNo, boxIndex, partyIndex)
    local party = state.game.save.party or {}
    local box = boxAt(state.game, boxNo)
    local boxMon = box[boxIndex]
    local partyMon = party[partyIndex]
    if not boxMon or not partyMon then
      Browser.setMessage(state, "SWAP TARGET CHANGED")
      return false
    end

    Stats.ensure(monDef(state.game, boxMon), boxMon)
    box[boxIndex] = partyMon
    party[partyIndex] = boxMon
    depositedHappiness(state.game, partyMon)
    playCry(state.game, boxMon)

    local boxName = monName(state.game, boxMon)
    local partyName = monName(state.game, partyMon)
    local back = state.absReturnMode or "swap_box"
    state.absMode = back
    state.absPendingBoxNo = nil
    state.absPendingBoxIndex = nil
    state.absPendingPartyIndex = nil
    state.absReturnMode = nil

    if back == "swap_box" or back == "withdraw" or back == "release" then
      setCurrentBox(state.game, boxNo)
      state.index = math.min(boxIndex, math.max(1, #box))
    else
      state.index = math.min(partyIndex, math.max(1, #party))
    end
    state.scroll = 0
    Browser.clearMessage(state)
    Browser.refresh(state, true)
    Browser.showMessage(state, Strings("%s joined the party.\n%s moved to BOX %d.",
      boxName, partyName, boxNo))
    return true
  end

  function Browser.activate(state, index)
    Browser.clearMessage(state)
    local list = Browser.list(state)
    if #list == 0 then
      Browser.setMessage(state,
        modeSourceKind(state.absMode) == "party" and "PARTY IS EMPTY" or "BOX IS EMPTY")
      return false
    end
    index = clamp(index or state.index or 1, 1, #list)
    state.index = index
    local mon = list[index]
    if not mon then return false end

    if state.absMode == "withdraw" then
      state.game.stack:push(Menu.new(state.game, {
        { label = "WITHDRAW", onSelect = function() Browser.withdrawAt(state, index) end },
        { label = "SWAP", onSelect = function() Browser.beginSwapFromBox(state, index, "withdraw") end },
        { label = "STATS", keepOpen = true, onSelect = function() Browser.showStats(state, mon) end },
        { label = "CANCEL" },
      }, { tx = 9, ty = 8, tw = 11, th = 10, noSound = true }))
      return true
    elseif state.absMode == "deposit" then
      state.game.stack:push(Menu.new(state.game, {
        { label = "DEPOSIT", onSelect = function() Browser.depositAt(state, index) end },
        { label = "SWAP", onSelect = function() Browser.beginSwapFromParty(state, index) end },
        { label = "STATS", keepOpen = true, onSelect = function() Browser.showStats(state, mon) end },
        { label = "CANCEL" },
      }, { tx = 9, ty = 8, tw = 11, th = 10, noSound = true }))
      return true
    elseif state.absMode == "release" then
      return Browser.releaseAt(state, index)
    elseif state.absMode == "swap_box" then
      return Browser.beginSwapFromBox(state, index, "swap_box")
    elseif state.absMode == "swap_party" then
      if not (state.absPendingBoxNo and state.absPendingBoxIndex) then
        state.absMode = "swap_box"
        Browser.setMessage(state, "SELECT BOX POKEMON AGAIN")
        Browser.refresh(state, false)
        return false
      end
      return Browser.finishSwap(state, state.absPendingBoxNo,
        state.absPendingBoxIndex, index)
    elseif state.absMode == "swap_box_target" then
      if not state.absPendingPartyIndex then
        state.absMode = "deposit"
        Browser.setMessage(state, "SELECT PARTY POKEMON AGAIN")
        Browser.refresh(state, false)
        return false
      end
      return Browser.finishSwap(state, state.game.save.currentBox or 1,
        index, state.absPendingPartyIndex)
    end
    return false
  end

  function Browser.back(state)
    if state.absMode == "swap_party" then
      local boxNo = state.absPendingBoxNo or state.game.save.currentBox or 1
      local boxIndex = state.absPendingBoxIndex or 1
      setCurrentBox(state.game, boxNo)
      state.absMode = state.absReturnMode or "swap_box"
      state.absPendingBoxNo = nil
      state.absPendingBoxIndex = nil
      state.absPendingPartyIndex = nil
      state.absReturnMode = nil
      state.index, state.scroll = boxIndex, 0
      Browser.clearMessage(state)
      Browser.refresh(state, true)
      return true
    elseif state.absMode == "swap_box_target" then
      local partyIndex = state.absPendingPartyIndex or 1
      state.absMode = "deposit"
      state.absPendingBoxNo = nil
      state.absPendingBoxIndex = nil
      state.absPendingPartyIndex = nil
      state.absReturnMode = nil
      state.index, state.scroll = partyIndex, 0
      Browser.clearMessage(state)
      Browser.refresh(state, true)
      return true
    end
    Browser.restoreRoot(state)
    state.game.stack:pop()
    return true
  end

  function Browser.new(game, mode)
    Boxes.ensure(game.save)
    local state
    state = ListMenu.new(game, "", {}, {
      noSound = true,
      wrap = true,
      rows = 7,
      onChoose = function(item)
        Browser.activate(state, item and item.value or state.index)
      end,
    })

    state.absAdvancedBox = true
    state.absMode = mode or "withdraw"
    state.absMessage = nil
    state.absPendingBoxNo = nil
    state.absPendingBoxIndex = nil
    state.absPendingPartyIndex = nil
    state.absReturnMode = nil
    state.absRoot = findBoxRoot(game)
    state.absRootIndex = state.absRoot and state.absRoot.index or nil

    local baseUpdate = state.update
    state.update = function(self, dt)
      local input = self.game.input
      if input:wasPressed("left") then
        Browser.switchBox(self, -1)
        return
      elseif input:wasPressed("right") then
        Browser.switchBox(self, 1)
        return
      elseif input:wasPressed("b") then
        Browser.back(self)
        return
      elseif input:wasPressed("a") and #self.items == 0 then
        Browser.activate(self, 1)
        return
      end
      baseUpdate(self, dt)
    end

    Browser.refresh(state, false)
    return state
  end

  local function openBrowser(game, mode)
    mod.ui.push(game, SCREEN_ID, mode)
  end

  local function changeBox(game)
    local boxes = Boxes.ensure(game.save)
    local items = {}
    for i = 1, Boxes.COUNT do
      local mark = i == (game.save.currentBox or 1) and "*" or " "
      items[#items + 1] = {
        label = Strings("%sBOX %2d", mark, i),
        right = ("%d/%d"):format(#boxes[i], Boxes.CAPACITY),
        value = i,
      }
    end
    game.stack:push(ListMenu.new(game, "CHANGE BOX", items, {
      noSound = true,
      onChoose = function(item, list)
        setCurrentBox(game, item.value)
        if game.writeSave then game:writeSave() end
        list:close()
      end,
    }))
  end

  local function printBox(game)
    local box = boxAt(game, game.save.currentBox)
    local Printer = require("src.core.Printer")
    local h = 32 + math.max(1, #box) * 10
    local saved, err = Printer.save("box_" .. (game.save.currentBox or 1),
      160, h, function()
        love.graphics.setColor(1, 1, 1, 1)
        love.graphics.rectangle("fill", 0, 0, 160, h)
        love.graphics.setColor(0, 0, 0, 1)
        Font.draw(Strings("BOX No.%d", game.save.currentBox or 1), 8, 8)
        if #box == 0 then Font.draw(Strings("Empty."), 8, 24) end
        for i, mon in ipairs(box) do
          local def = monDef(game, mon)
          Font.draw(mon.nickname or (def and def.name) or tostring(mon.species),
            8, 14 + i * 10)
          Font.draw(Strings(":L%d No.%03d", mon.level or 0,
            def and def.dex or 0), 88, 14 + i * 10)
        end
        love.graphics.setColor(1, 1, 1, 1)
      end)
    game.stack:push(TextBox.new(game, saved
      and Strings("Printed BOX %d!\fSaved as\n%s\vin the save\nfolder.",
        game.save.currentBox or 1, saved)
      or Strings("Printer error!\n%s", tostring(err))))
  end

  local function mainMenu(game)
    Boxes.ensure(game.save)
    -- Keep the first three rows aligned with the stock Bill's-PC semantic
    -- order so Gen1 Modern UI can identify our live ListMenu browser as the
    -- rich box/party list. SWAP follows them as an added fourth operation.
    local items = {
      { label = Strings("WITHDRAW <PK><MN>"), keepOpen = true,
        onSelect = function() openBrowser(game, "withdraw") end },
      { label = Strings("DEPOSIT <PK><MN>"), keepOpen = true,
        onSelect = function() openBrowser(game, "deposit") end },
      { label = Strings("RELEASE <PK><MN>"), keepOpen = true,
        onSelect = function() openBrowser(game, "release") end },
      { label = Strings("SWAP <PK><MN>"), keepOpen = true,
        onSelect = function() openBrowser(game, "swap_box") end },
      { label = Strings("CHANGE BOX"), keepOpen = true,
        onSelect = function() changeBox(game) end },
    }
    if GameVersion.isYellow() then
      items[#items + 1] = { label = Strings("PRINT BOX"), keepOpen = true,
        onSelect = function() printBox(game) end }
    end
    items[#items + 1] = { label = Strings("SEE YA!") }

    local menu = Menu.new(game, items,
      { tx = 0, ty = 0, tw = 14, th = math.min(18, #items * 2 + 2), noSound = true })
    local baseDraw = menu.draw
    function menu:draw()
      baseDraw(self)
      Font.drawBox(12, 12, 8, 6)
      love.graphics.setColor(0, 0, 0, 1)
      Font.draw(Strings("BOX"), 104, 104)
      Font.draw(Strings("%02d/%02d", game.save.currentBox or 1, Boxes.COUNT), 104, 120)
      local box = boxAt(game, game.save.currentBox)
      Font.draw(Strings("%02d/%02d", #box, Boxes.CAPACITY), 104, 136)
      love.graphics.setColor(1, 1, 1, 1)
    end
    return menu
  end

  mod.exports.open = function(game, mode)
    openBrowser(game, mode or "swap_box")
  end
  mod.exports.version = VERSION

  mod.content.screens:register(SCREEN_ID, {
    new = function(game, mode)
      return Browser.new(game, mode)
    end,
  })

  -- PCMainMenu opens screen id "BoxMenu". A mod-owned screen record wins
  -- over the builtin, so Bill's PC is replaced without engine patching.
  mod.content.screens:register("BoxMenu", {
    new = function(game)
      return mainMenu(game)
    end,
  })
end
