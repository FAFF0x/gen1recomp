# MODERN BATTLE UI v1.4.4

A standalone modern battle presentation for Gen1Recomp.

This mod is deliberately separate from **Gen1 Modern UI's BATTLE UI (WIP)**.
It does not replace `BattleState` and does not own battle logic. The game and
battle mods still control input, damage, animations, callbacks, Party, Bag,
capture flow and state transitions.

## Visual design

The layout takes inspiration from Gen1 Modern UI's clean presentation language,
but is implemented independently:

- floating rounded HP/status cards;
- animated HP bars using the live `shownHP` value;
- exact player HP and optional enemy HP numbers;
- caught-Pokemon indicator for wild encounters;
- large FIGHT / POKEMON / BAG / RUN cards;
- original vector-style action icons bundled with the mod;
- Safari BALL / BAIT / ROCK / RUN presentation;
- modern 2x2 move cards;
- live move name, PP and type badges;
- optional POWER / ACCURACY / PP detail strip;
- disabled-move and move-swap indicators;
- modern battle-message panel;
- responsive scale for 720p, 1080p, ultrawide and higher-resolution windows;
- MIDNIGHT, GRAPHITE, LIGHT and CRIMSON themes.

## Why it is separate

The new UI uses the battle state's public presentation hooks instead of
rewriting or decorating the battle state.

When the overlay is actively drawing, it asks the engine to hide only the
classic battle-owned status HUD and bottom menu layer. Party, Bag, choice
prompts and other child screens remain source-owned.

The visual layer is then painted in `render.hud`, after the normal game and
other HUD mods have rendered. This makes it suitable for:

- classic battles;
- WIDE battles;
- world-background battles;
- BATTLE ART / 3D-BTL staged voxel battles;
- Crystal 251 species and move data.

## Controls

Controls are still the normal Gen1Recomp controls.

The mod does **not** synthesize A/B presses or replace battle callbacks.
For classic/OG battle layouts it enables the engine's public 2x2 move-grid
navigation hook so directional input matches the displayed 2x2 move cards.

## Options

Open **MODS -> MODERN BATTLE UI -> OPTIONS**:

- MODERN BATTLE UI
- BATTLE UI THEME
- BATTLE UI SCALE
- BATTLE UI LAYOUT
- PANEL OPACITY
- ACTION ICONS
- ENEMY HP NUMBERS
- MOVE DETAILS
- HIDE NATIVE BATTLE UI

`HIDE NATIVE BATTLE UI` can be disabled for debugging. The modern overlay will
continue to draw while the classic battle UI remains visible underneath.

## Gen1 Modern UI compatibility

Gen1 Modern UI may stay installed for Start Menu, Party, Bag, Pokedex,
dialogue and the rest of its presentation.

For the cleanest setup, set:

- **Gen1 Modern UI -> BATTLE UI (WIP): OFF**
- **MODERN BATTLE UI -> MODERN BATTLE UI: ON**
- **MODERN BATTLE UI -> MODERN PARTY / BAG IN BATTLE: ON**

This mod does not depend on Modern UI and does not use its experimental battle
presenter.

## BATTLE ART / 3D-BTL

MODERN BATTLE UI is a screen-space overlay. It does not alter the voxel camera,
Pokemon placement, shadows, scene depth or BATTLE ART animation.

In a staged 3D battle the voxel scene remains the background while the modern
battle cards and command panel are drawn on top.

## Crystal 251 / Generation II

Names, levels, HP, move names, PP and move definitions are read from the live
game data. Generation II species and moves supplied by Crystal 251 therefore
flow through the same UI without a separate 251-species table.

Type colors include the Generation II DARK and STEEL types.

## Notes

This is v1.0.0. The first release intentionally leaves Party/Bag and battle
choice child screens to their existing UI mods. Future versions can add
optional modern target selection, battle notifications and touch/click
interaction without moving battle ownership out of the engine.

## v1.1.0 interaction and child-screen fixes

### True horizontal battle command navigation

The command strip is now genuinely one-dimensional:

**FIGHT → BAG → POKÉMON → RUN**

The game still owns the action IDs and callbacks. MODERN BATTLE UI only remaps
directional edges before BattleState handles them:

- Right or Down: next visible slot.
- Left or Up: previous visible slot.
- A/B remain completely native.

This means moving right from FIGHT now selects BAG, matching the layout on
screen instead of following the engine's hidden 2x2 cursor geometry.

### Modern Party and Bag during battle

When POKÉMON or BAG is opened from a battle, v1.1.0 keeps the same modern
visual language instead of exposing the stock Game Boy child screen.

The underlying PartyMenu/BagMenu still receives every key press and owns every
callback. The mod only draws an opaque modern presentation over the stock
canvas in `render.hud`.

The battle Party overlay includes:

- responsive Pokémon cards;
- HP bars and numeric HP;
- level and status;
- current selection;
- PartyMenu's live action submenu.

The battle Bag overlay includes:

- modern item list and selection;
- count/right-column text;
- selected-item information panel;
- TM/HM move information when available.

This child overlay is controlled by **MODERN PARTY / BAG IN BATTLE**.

### Battle text decoder

v1.0.0 could call `tostring()` on ROM/localization records, producing output
such as `table: 0x...` and implementation/control codes.

v1.1.0 recursively resolves nested `text`, `message`, `label`, `display`,
`name`, `string` and array fragments, strips non-printing controls and never
renders Lua table/userdata identities.

Encounter text is also allowed during intro/non-menu phases. If an overhaul
provides no readable intro text at all, the UI falls back to a readable
`A wild <Pokémon> appeared!` / trainer-battle line rather than leaving the
message area blank.

## v1.2.0 icon + detail overlay update

### Live NEW ITEM ICONS and NEW ICONS compatibility

This release consumes the live icon descriptors published by your two icon mods; it does **not** copy their artwork into MODERN BATTLE UI:

- battle Bag rows now render the same item artwork used by **NEW ITEM ICONS**;
- machine/TM-HM rows use the live move-type icon when available;
- battle Party rows now render the animated runtime species icons from
  **NEW ICONS**;
- the detail pane and summary overlay also use those Pokémon icons.

For Pokémon it reads `game.data.icons.bySpecies[species]`, the registry used by **NEW ICONS**. For items it reads live `def.image`, `def.icon` or `def.itemSprite`, the fields published by **NEW ITEM ICONS**. If either art mod is disabled, the battle UI simply falls back to text/generic presentation instead of duplicating its assets.

### Party layout redesign with persistent sidebar details

The Party screen has been reorganized into:

- a compact list on the left;
- a persistent detail sidebar on the right.

The sidebar shows useful battle information immediately:

- Pokémon icon;
- types;
- HP and HP bar;
- status/level;
- ATK / DEF / SPC / SPD summary;
- the Pokémon's move list;
- move effectiveness against the **current enemy**;
- a `BEST OPTION` recommendation when a move is super effective.

This means most practical information is already visible without needing to
open the stock detail screen.

### Modern Summary overlay

If the player still opens Pokémon details/summary from battle, the UI no longer
falls back visually to the classic Game Boy SummaryMenu.

MODERN BATTLE UI now draws a full-screen modern Summary overlay above the live
source SummaryMenu so the original controls keep working, but the presentation
stays visually consistent.

## v1.2.1 crash and icon-ownership fix

- Removed every copied Pokémon/item icon asset from this package.
- Added `new_icons` and `new_item_icons` as optional dependencies only.
- Pokémon art is loaded from the live icon registry.
- Item art is loaded from the live item definitions.
- Asset handles are passed through the engine `Assets.resolve()` path before loading.
- Fixed the Party coverage crash from v1.2.0: the effectiveness helper no longer references a later lexical local (`moveDefinition`) as a nil global.

This means the icon mods remain the single source of truth. Updating NEW ICONS or NEW ITEM ICONS automatically updates MODERN BATTLE UI without rebuilding this package.

## v1.2.2 — FIGHT effectiveness preview

The FIGHT screen now evaluates every displayed move against the Pokémon
currently on the opposing side.

Each move card shows one of:

- `SUPER x4`
- `SUPER x2`
- `NORMAL x1`
- `RESIST x0.5`
- `RESIST x0.25`
- `NO EFFECT`

The selected move repeats the same matchup result in the bottom detail strip,
alongside TYPE / POWER / ACC / PP.

This is presentation-only. Damage calculation, move legality, targeting and
battle execution remain fully source-owned.

## v1.2.3 — Battle chronology / text recovery

The modern text panel now follows the source BattleState's live `shown` text
window in addition to queue/message fields. This matters because BattleState
can clear the current queue record before an attack animation or HP drain is
finished while keeping the actual displayed text in `shown`.

The UI now preserves a short per-battle history, including messages such as:

- Pokémon used a move;
- super effective / not very effective;
- no effect;
- status changes;
- recoil and secondary effects;
- faint/KO text;
- encounter/trainer intro lines.

The history is no longer cleared when the command menu returns.

During message playback the panel shows the current line plus recent context.
When FIGHT / BAG / POKÉMON / RUN returns, a compact **BATTLE LOG** above the
command strip keeps the last turn visible.


## v1.2.4 — Event battle log + Bag descriptions

The battle log no longer parses `battle.shown`. That engine field contains
encoded glyph arrays for the two-line text window, not a chronological event
list. v1.2.4 uses `BattleState:visibleText()` for the live rendered lines and
uses each `battle.current` queue row as a unique event identity.

This prevents one message from being added every frame while still allowing
the same move/message to appear again on a later turn as a real new event.

The battle Bag now has a dedicated right-side information card with item icon,
name, category, quantity and a full DESCRIPTION panel. Live item help/flavor
fields supplied by content mods are preferred. Stock Gen1 items receive
readable fallback descriptions. TM/HM items also show MOVE DATA with type,
power, accuracy and PP.

NEW ICONS and NEW ITEM ICONS remain external integrations; no icon art is
bundled into this mod.

## v1.3.0 — Integrated EXP Bar

MODERN BATTLE UI now includes its own battle EXP presentation, inspired by the
behavior of `jj_exp_bar v1.1.1` but redrawn to fit this mod's high-resolution
floating HUD.

The active player's status card now has a dedicated EXP strip immediately
under it.

### EXP behavior

- Shows progress from the current level toward the next.
- Reads the Pokémon's live `exp`, species `growthRate` and the engine's
  `Growth.expForLevel`, so custom growth data remains authoritative.
- Listens to the engine's `battle.exp_gained` event.
- Only an actual EXP award animates the bar.
- Battle start and switch-in snap to the active Pokémon's current progress.
- Level-up awards fill to 100%, wrap back to 0%, then continue into the new
  level.
- Multiple level-ups can perform multiple wraps.
- Level-cap Pokémon show a full bar and `MAX`.
- Safari/demo/send-out states where the player HUD is hidden do not draw the
  EXP strip.

### EXP gain feedback

For several seconds after an award, the percentage on the right becomes:

`+XXX EXP`

with a subtle accent pulse. Afterward the display returns to the current
percentage toward the next level.

### Options

- **PLAYER EXP BAR** — show/hide the integrated bar.
- **EXP BAR STYLE**
  - THEME ACCENT
  - GEN 2 BLUE
  - HP MATCH
- **EXP BAR DIRECTION**
  - GEN 2 — right to left
  - MODERN — left to right
- **EXP GAIN AMOUNT** — enable/disable the temporary `+EXP` value.

### jj_exp_bar

The integrated feature replaces the need for `jj_exp_bar` while MODERN BATTLE
UI is active. The manifest declares `jj_exp_bar` as a conflict to prevent two
EXP bars from drawing at the same time.

## v1.4.0 — Pokémon Visual Redesign

This release focuses on visual coherence with the Pokémon series while keeping
all battle logic, compatibility and information features from previous
versions intact.

### Main visual changes

- New **POKEMON** default theme with brighter white/blue panels inspired by
  official Pokémon battle UI language.
- Softer rounded cards with layered borders, light gloss and lighter shadows.
- Player and enemy status cards were redesigned to feel closer to modern
  Pokémon HUDs.
- Added integrated Pokémon species icon thumbnails inside the battle HUD.
- Level values now live inside dedicated level pills.
- HP presentation is cleaner, with explicit `HP` labels and capsule-style HP
  number chips.
- The command menu now uses color-coded action cards:
  - **FIGHT** orange
  - **BAG** yellow
  - **POKEMON** green
  - **RUN** blue
- Move cards now use softer type-tinted surfaces and more Pokémon-like type /
  effectiveness capsules.
- The battle message area was restyled into a clearer battle textbox with a
  `BATTLE TEXT` header and a softer prompt pill.
- The battle mode label was redesigned into a compact Poké Ball pill.
- Child battle overlays (Party / Bag / Summary) inherit the new panel styling
  automatically.

### Notes

- This is a **visual redesign only**: battle logic, compatibility, move
  effectiveness, battle log behavior and the integrated EXP bar all remain
  source-owned exactly as before.
- `POKEMON` is now the default theme, but MIDNIGHT / GRAPHITE / LIGHT /
  CRIMSON remain available.

## v1.4.1 — Caught marker + Battle Log control

### Caught Poké Ball beside the enemy name

When the opposing Pokémon's species is already present in
`save.pokedex.owned`, its battle status card now shows a small classic
red/white Poké Ball immediately after the Pokémon name.

This follows the same useful ownership cue as Catch Helper, but it is rendered
directly by MODERN BATTLE UI in the high-resolution Pokémon-style HUD.

A new **CAUGHT POKEBALL** option can disable the marker independently.

### Optional Battle Log

A new **SHOW BATTLE LOG** option controls only the historical/chronology UI:

- previous history lines in the battle textbox;
- the compact `BATTLE LOG` shown above the command menu.

Turning it OFF does **not** hide the current battle message. Move text,
encounter text, status messages, KO text and prompts remain visible normally.

### Duplicate history fix

During `msgHold` / attack animation the source BattleState can clear
`battle.current` while keeping the last line visibly active. Previous versions
could then treat that same event as both the current message and a historical
message.

v1.4.1 always excludes the active history entry from the "previous messages"
area. The current battle line is therefore drawn only once.

## v1.4.3 — Modern trainer SHIFT prompt

Gen1Recomp's "Will PLAYER change POKéMON?" prompt is not part of BattleState's
normal bottom UI. The engine pushes a separate `ChoiceBox` above the battle.

Previous MODERN BATTLE UI releases therefore temporarily lost visual ownership:
the top state was no longer BattleState and the stock YES/NO box appeared.

v1.4.3 mirrors that specific trainer SHIFT ChoiceBox:

- the stock left-side YES/NO box is hidden through `screen.render_visible`;
- the original ChoiceBox remains active and continues to own UP/DOWN/A/B input;
- the complete modern battle HUD remains visible behind the prompt;
- the current modern battle text remains visible;
- a new Pokémon-style **SWITCH POKEMON?** card displays modern YES / NO buttons;
- the highlighted button follows the source ChoiceBox's real `index`;
- A/B confirmation and the engine's native confirmation hold remain unchanged;
- choosing YES continues into MODERN BATTLE UI's existing modern Party overlay;
- choosing NO returns to the modern battle normally.

The detector deliberately targets only the trainer SHIFT offer (`YES/NO` at
the engine's trainer switch box at tile position 0,7), so unrelated YES/NO
boxes from shops, PC actions or other screens are not hidden.

## v1.4.4 — Level-up and Move Learn continuity

Gen1Recomp temporarily pushes dedicated states above `BattleState` during the
experience flow:

1. the Pokémon grows a level;
2. a source `StatBox` shows Attack / Defense / Speed / Special;
3. the engine checks newly learned moves;
4. if all four move slots are occupied, a `MoveLearnMenu` is pushed.

Those source states previously caused MODERN BATTLE UI to lose visual
ownership because BattleState was no longer the top state.

### Modern Level-Up screen

The source level-up StatBox is now hidden visually and mirrored by a modern
Pokémon-style **LEVEL UP!** panel showing:

- Pokémon name;
- new level;
- Attack;
- Defense;
- Speed;
- Special;
- current/max HP.

The original StatBox remains top-of-stack and still owns A/B dismissal and its
callback.

### Modern Move Learn list

When the source `MoveLearnMenu` reaches its move-selection phase, its classic
move list is hidden and replaced by a modern **LEARN A MOVE** overlay.

It displays:

- Pokémon name;
- the new move and its type;
- all four current moves;
- PP;
- type pills;
- CANCEL / KEEP CURRENT MOVES;
- real source cursor selection.

UP/DOWN/A/B remain fully owned by the original MoveLearnMenu.

### Trying-to-learn / abandon prompts

MoveLearnMenu also uses nested source TextBox/ChoiceBox states for the
"trying to learn", "delete an older move?" and "abandon learning?" exchanges.

v1.4.4 keeps those source prompts and their exact timing/input behavior, but
the modern Pokémon battle HUD no longer disappears behind them. The modern
HP/status/EXP cards remain visible for the entire move-learning sequence.
