# Changelog

## 1.0.6

- Added regional-style Pokédex numbering metadata for Crystal Onix.
- With Pokédex Plus v1.3.1 or newer, normal Onix remains **#095** and Crystal Onix appears immediately beneath it as the separate entry **#95C**.
- Crystal Onix deliberately keeps unique internal numeric dex ID **152** to avoid the duplicate-95 overwrite behavior in stock gen1recomp.
- The Pokédex DATA page shows **No.95C** when opened through Pokédex Plus v1.3.1+.
- Declared Pokédex Plus v1.3.1+ as the optional integration version for the grouped variant display.

## 1.0.5

- Expanded Crystal Onix TM/HM compatibility while preserving every machine normal Onix can already learn.
- Crystal Onix can now use every TM/HM whose move type is **Ice**, **Ground**, or **Rock**.
- In the vanilla Generation I machine set this guarantees compatibility with **Ice Beam, Blizzard, Earthquake, Fissure, Dig, and Rock Slide**.
- Compatibility is discovered from the merged TM/HM and move registries, so compatible machines added by earlier-loaded mods are included automatically.

## 1.0.4

- Fixed Crystal Onix's Pokédex description showing `Data unknown.` after it was owned.
- Registered the Pokédex prose through the text registry, as required by gen1recomp's DexEntryMenu.
- Replaced the old generic description with an origin entry explaining that an Onix spent years in a frozen sea cave, where cold, pressure, and rare minerals slowly crystallized its rocky body.

## 1.0.3

- Fixed the Seafoam B4F encounter blocker where the old Luminous Shard Poké Ball remained on the same tile as Crystal Onix.
- Quest-only Seafoam runtime actors are now removed and rebuilt whenever B4F is entered.
- Prevented duplicate shard/boss objects from accumulating after repeated map visits.
- Shard and Crystal Onix are now mutually exclusive on the encounter tile, so interacting with Crystal Onix correctly starts the battle.

## 1.0.2

- Corrected Crystal Onix's base stats to Generation I's five-stat format.
- New stats: HP 100, Attack 100, Defense 200, Special 80, Speed 100.
- Updated base-stat total from 555 to 580.
- Removed the split Sp. Atk/Sp. Def damage hook; Special 80 now handles both offense and defense.
- Existing Crystal Onix in the party or PC are recalculated automatically on load.
- Existing quest progression and perfect-DV/max-Stat-EXP reward remain unchanged.

## 1.0.1

- Fixed the missing Quest System entry.
- Added **The Living Crystal** to the quest journal.
- Added dynamic objective, location, progress, and completion tracking based on the mod's existing flags.
- Added quest markers for the Vermilion sailor, Cinnabar artisan, Fuchsia researcher, Luminous Shard, and Crystal Onix encounter.
- Made Quest System v1.0.3 or newer a required dependency.

## 1.0.0

- Initial release.
- Added Crystal Onix as Rock/Ice Pokédex #152.
- Added split Sp. Atk 30 / Sp. Def 65 battle logic.
- Added multi-stage Crystal Onix quest.
- Added perfect-DV and maximum-Stat-EXP final reward.
- Added custom battle, icon, and overworld artwork.
