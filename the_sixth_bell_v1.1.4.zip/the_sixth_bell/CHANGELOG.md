# Changelog

## 1.1.4 — Persistence / completed-quest fix

- Fixed a v1.1.3 regression that could reopen The Sixth Bell after restarting the game.
- Removed the full in-memory quest-state cache; persistent quest flags are read directly from `mod.save` again.
- Treats a Quest System journal entry with status `completed` as authoritative and repairs missing `started`/`done` flags automatically.
- Added a second completion guard in the quest activation path, preventing completed saves from restarting the quest on city entry.
- Keeps the v1.1.3 performance fix: `map.palette` is physically unsubscribed whenever the curse is inactive or completed.

## 1.1.3

- Eliminated the remaining completed/inactive quest overhead from the `map.palette` hot path.
- The palette wrapper is now installed only while the curse is actually active.
- The wrapper unsubscribes immediately when the quest completes and is absent entirely for locked/completed saves after `game.ready`.
- Save switching now tears down any old palette wrapper before rebuilding quest state.
- Preserves all v1.1.x save data and quest behavior.

## 1.1.2

- Fixed a performance issue that could affect gameplay even while the quest was inactive or already completed.
- Quest save flags are now cached in memory instead of repeatedly calling `mod.save:get` from frequently queried callbacks.
- Optimized the global `map.palette` hook with a fast inactive/completed path that performs no save reads or map-id lookup.
- Runtime state cache is rebuilt on `game.ready`, preserving existing save compatibility.

## 1.1.1

- Fixed the Lavender Town little girl sometimes not responding to interaction.
- Quest marker now targets the stable NPC object index instead of relying on a text pointer.
- Restores the girl's quest text pointer when Lavender Town loads.
- Added an adjacency fallback for the quest introduction and final turn-in when another mod owns the same talk slot.

## 1.1.0

- Added required compatibility with Quest System 1.0.3.
- Added a QUESTS journal entry with dynamic objectives, locations and reward details.
- Added five-step numeric quest progress.
- Added an NPC quest marker above the Lavender Town little girl.
- Added a turn-in marker after all three haunted trials are complete.
- Added journal completion when Gengar is caught or received.
- Added migration of existing v1.0.0 quest progress into the journal.
- Updated the minimum supported Gen1Recomp version to 0.1.38.

## 1.0.0

- Added a post-sixth-badge horror quest.
- Added Lavender Town activation and haunted arrival scenes.
- Added three Pokemon Tower trials.
- Added a temporary ghostly palette for quest maps.
- Added a level 40 Gengar final encounter and reward logic.
- Preserved the little girl's original dialogue before the quest unlocks.
