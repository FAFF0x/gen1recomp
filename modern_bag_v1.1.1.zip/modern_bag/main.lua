-- Modern Bag for Gen1Recomp
-- Splits the vanilla BagMenu into pockets while delegating every item action
-- to the original menu, preserving engine and inter-mod item behavior.

local PATCH_KEY = "__modern_bag_dispatch_v1"

local POCKETS = {
  { id = "medicine", label = "MEDICINE" },
  { id = "balls", label = "BALLS" },
  { id = "machines", label = "TM HM" },
  { id = "battle", label = "BATTLE" },
  { id = "key", label = "KEY ITEMS" },
  { id = "other", label = "OTHER" },
}

local MEDICINE = {
  POTION = true, SUPER_POTION = true, HYPER_POTION = true,
  MAX_POTION = true, FULL_RESTORE = true,
  ANTIDOTE = true, BURN_HEAL = true, ICE_HEAL = true,
  AWAKENING = true, PARLYZ_HEAL = true, FULL_HEAL = true,
  REVIVE = true, MAX_REVIVE = true,
  FRESH_WATER = true, SODA_POP = true, LEMONADE = true,
  ETHER = true, MAX_ETHER = true, ELIXER = true, MAX_ELIXER = true,
  HP_UP = true, PROTEIN = true, IRON = true, CARBOS = true,
  CALCIUM = true, RARE_CANDY = true, PP_UP = true,
}

local BATTLE_ITEMS = {
  X_ATTACK = true, X_DEFEND = true, X_SPEED = true, X_SPECIAL = true,
  X_ACCURACY = true, DIRE_HIT = true, GUARD_SPEC = true,
  POKE_DOLL = true,
}

local BALL_IDS = {
  MASTER_BALL = true, ULTRA_BALL = true, GREAT_BALL = true,
  POKE_BALL = true, SAFARI_BALL = true,
}

local STONES = {
  FIRE_STONE = true, WATER_STONE = true, THUNDER_STONE = true,
  LEAF_STONE = true, MOON_STONE = true,
}

local function upper(value)
  return tostring(value or ""):upper()
end

local function pocketFor(id, def)
  def = def or {}
  if def.machine then return "machines" end
  if def.ball or BALL_IDS[id] then return "balls" end
  if BATTLE_ITEMS[id] then return "battle" end
  if MEDICINE[id] then return "medicine" end

  -- Friendly inference for modded records. Explicit engine fields win; the
  -- name/effect fallback only catches conventional custom medicines.
  local effect = upper(def.effect)
  if not STONES[id] and (
       effect:find("HEAL", 1, true)
    or effect:find("REVIVE", 1, true)
    or effect:find("MEDIC", 1, true)
    or effect:find("VITAMIN", 1, true)
    or effect:find("ETHER", 1, true)
    or effect:find("ELIX", 1, true)
    or effect:find("CANDY", 1, true)
    or effect:find("PP_UP", 1, true)) then
    return "medicine"
  end

  if def.keyItem or def.tossable == false then return "key" end
  return "other"
end

local function countOf(save, id)
  local value = save and save.inventory and save.inventory[id]
  value = math.floor(tonumber(value) or 0)
  return math.max(0, value)
end

local function positionOf(order, id)
  for i, value in ipairs(order or {}) do
    if value == id then return i end
  end
  return nil
end

local function itemRows(game, pocketId)
  local Bag = require("src.inventory.Bag")
  local order = Bag.order(game.save)
  local rows = {}
  for globalIndex, id in ipairs(order) do
    local count = countOf(game.save, id)
    if count > 0 then
      local def = game.data.items[id]
      if pocketFor(id, def) == pocketId then
        rows[#rows + 1] = {
          label = (def and def.name) or id,
          right = "x" .. tostring(count),
          value = id,
          modernGlobalIndex = globalIndex,
        }
      end
    end
  end
  return rows
end

local function selectedId(list)
  local item = list.items and list.items[list.index or 1]
  return item and item.value or nil
end

local function cursorBucket(state, pocketId)
  state.cursors[pocketId] = state.cursors[pocketId] or { index = 1, scroll = 0 }
  return state.cursors[pocketId]
end

local function saveCursor(list)
  local state = list.modernBag
  local pocket = POCKETS[state.pocket]
  if not pocket then return end
  local cursor = cursorBucket(state, pocket.id)
  cursor.index = list.index or 1
  cursor.scroll = list.scroll or 0
  cursor.selected = selectedId(list)
end

local function restoreCursor(list, rows, preserveId)
  local state = list.modernBag
  local pocket = POCKETS[state.pocket]
  local cursor = cursorBucket(state, pocket.id)
  local wanted = preserveId or cursor.selected
  local index
  if wanted then
    for i, row in ipairs(rows) do
      if row.value == wanted then index = i break end
    end
  end
  list.index = index or math.max(1, math.min(cursor.index or 1, #rows))
  if #rows == 0 then list.index = 1 end
  list.scroll = math.max(0, cursor.scroll or 0)
  local maxScroll = math.max(0, #rows - (list.rows or 7))
  if list.scroll > maxScroll then list.scroll = maxScroll end
  if list.index - list.scroll < 1 then list.scroll = list.index - 1 end
  if list.index - list.scroll > (list.rows or 7) then
    list.scroll = list.index - (list.rows or 7)
  end
end

local function refreshPocket(list, preserveId)
  local state = list.modernBag
  local pocket = POCKETS[state.pocket]
  local rows = itemRows(list.game, pocket.id)
  list.items = rows
  list.title = ("%s %d/%d"):format(pocket.label, state.pocket, #POCKETS)
  list.footer = ("¥%d"):format(list.game.save.money or 0)
  restoreCursor(list, rows, preserveId)

  if state.swapId then
    list.hollowIndex = nil
    for i, row in ipairs(rows) do
      if row.value == state.swapId then list.hollowIndex = i break end
    end
    if not list.hollowIndex then state.swapId = nil end
  else
    list.hollowIndex = nil
  end
end

local function switchPocket(list, delta)
  saveCursor(list)
  local state = list.modernBag
  state.swapId = nil
  list.hollowIndex = nil
  state.pocket = ((state.pocket - 1 + delta) % #POCKETS) + 1
  refreshPocket(list)
end

local function reorderWithinBag(item, list)
  if not item then return end
  local state = list.modernBag
  if not state.swapId then
    state.swapId = item.value
    list.hollowIndex = list.index
    return
  end
  if state.swapId == item.value then
    state.swapId = nil
    list.hollowIndex = nil
    return
  end

  local Bag = require("src.inventory.Bag")
  local order = Bag.order(list.game.save)
  local from = positionOf(order, state.swapId)
  local to = positionOf(order, item.value)
  if from and to then
    order[from], order[to] = order[to], order[from]
    pcall(function() require("src.core.Sound").play(list.game.data, "Swap") end)
  end
  state.swapId = nil
  list.hollowIndex = nil
  refreshPocket(list, item.value)
end

local function decorateBag(game, opts, list)
  if type(list) ~= "table" or list.modernBag then return list end

  local baseUpdate = list.update
  local baseDraw = list.draw
  if type(baseUpdate) ~= "function" or type(baseDraw) ~= "function" then
    return list
  end

  list.modernBag = {
    pocket = 1,
    cursors = {},
    swapId = nil,
    battle = opts and opts.battle or nil,
  }
  list.pageJump = false
  list.onSelectKey = reorderWithinBag

  function list:update(dt)
    local current = selectedId(self)
    refreshPocket(self, current)
    local input = self.game.input
    if input:wasPressed("left") then
      switchPocket(self, -1)
      return
    elseif input:wasPressed("right") then
      switchPocket(self, 1)
      return
    end
    baseUpdate(self, dt)
    if self.modernBag then saveCursor(self) end
  end

  function list:draw()
    baseDraw(self)
  end

  refreshPocket(list)
  return list
end

return function(mod)
  mod.events:on("game.ready", function(event)
    local game = event and event.game
    if not game then
      mod.log:warn("Modern Bag could not install: game.ready had no game object; restart with the mod enabled")
      return
    end

    -- Gen 1 normally allows only 20 distinct non-badge item ids in the bag.
    -- Raising the shared capacity constant removes that slot gate everywhere
    -- Bag.add is used (pickup, shops, scripts) while leaving the independent
    -- vanilla per-item stack limit and all item behavior untouched.
    local bagOk, Bag = pcall(require, "src.inventory.Bag")
    if bagOk and type(Bag) == "table" then
      Bag.CAPACITY = math.huge
    else
      mod.log:warn("Modern Bag could not remove the bag slot limit; src.inventory.Bag was unavailable")
    end

    local ok, BagMenu = pcall(require, "src.ui.BagMenu")
    if not ok or type(BagMenu) ~= "table" or type(BagMenu.new) ~= "function" then
      mod.log:warn("Modern Bag could not find src.ui.BagMenu; check game compatibility and restart")
      return
    end

    local dispatch = rawget(_G, PATCH_KEY)
    if not dispatch then
      dispatch = { baseNew = BagMenu.new }
      rawset(_G, PATCH_KEY, dispatch)
      BagMenu.new = function(currentGame, opts)
        local list = dispatch.baseNew(currentGame, opts)
        local decorator = dispatch.decorate
        if decorator then return decorator(currentGame, opts, list) end
        return list
      end
    end
    dispatch.decorate = decorateBag
    mod.log:info("Modern Bag installed with " .. tostring(#POCKETS) .. " pockets and unlimited item slots")
  end)

  mod.exports.pocketFor = pocketFor
  mod.exports.pockets = function()
    local out = {}
    for i, pocket in ipairs(POCKETS) do
      out[i] = { id = pocket.id, label = pocket.label }
    end
    return out
  end
end
