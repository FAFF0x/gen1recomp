# Modern Bag

Modern Bag divides the Gen1Recomp inventory into six modern-style pockets and removes the original 20-slot limit for distinct bag items while preserving item behavior.

## Pockets

- **MEDICINE** — healing items, status cures, Revives, PP recovery, vitamins and Rare Candy.
- **BALLS** — every built-in or modded item registered as a Poké Ball.
- **TM HM** — all TMs and HMs.
- **BATTLE** — X items, Dire Hit, Guard Spec and Poké Doll.
- **KEY ITEMS** — non-tossable and key items.
- **OTHER** — stones, Repels, Escape Rope, fossils and everything not covered above.

Press **Left/Right** to change pocket. Up/Down, A, B and SELECT keep their original meanings. SELECT reorders items inside the current pocket while preserving the global bag order.

The bag may contain an unlimited number of distinct item types. The vanilla limit of 99 units per individual item stack remains unchanged.

The mod wraps the vanilla BagMenu rather than reimplementing item effects. Items are still used, consumed, taught, thrown and validated by Gen1Recomp's original menu. The same pockets are available when the bag is opened during battle.

## Installation

Import the ZIP in the MODS manager, enable **Modern Bag**, then fully restart Gen1Recomp.

## Compatibility

Custom balls and machines are categorized from their registered item fields. Conventional custom medicines are detected from their effect identifiers; unknown items safely fall back to OTHER.
