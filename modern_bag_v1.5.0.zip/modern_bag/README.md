# Modern Bag

Modern Bag divides the Gen1Recomp inventory into seven modern-style pockets, automatically organizes items, adds Favorites, persistent pinned items, advanced TM/HM tools, quick search and removes both vanilla carrying limits while preserving item behavior.

## Pockets

- **FAVORITES** — items marked as favorites from any other pocket.
- **MEDICINE** — healing items, status cures, Revives, PP recovery, vitamins and Rare Candy.
- **BALLS** — every built-in or modded item registered as a Poké Ball.
- **TM HM** — all TMs and HMs.
- **BATTLE** — X items, Dire Hit, Guard Spec and Poké Doll.
- **KEY ITEMS** — non-tossable and key items.
- **OTHER** — stones, Repels, Escape Rope, fossils and everything not covered above.

Press **Left/Right** to change pocket. The Bag still opens on MEDICINE, while FAVORITES is immediately to its left. Up/Down, A and B keep their original meanings.

## Favorites and pinned items

Press **SELECT** while an item is highlighted to open **ITEM OPTIONS**:

- **ADD FAVORITE / REMOVE FAVORITE** — adds or removes the item from the FAVORITES pocket.
- **PIN TO TOP / UNPIN ITEM** — fixes the item above every unpinned item in its normal category.
- **MOVE ITEM** — starts manual item reordering; press SELECT on the destination item to complete the move.
- **CANCEL** — closes ITEM OPTIONS.

The row markers indicate item status:

- `F` — favorite.
- `P` — pinned.
- `PF` — both pinned and favorite.

Favorites and pins are persistent. If an item stack reaches zero, the item temporarily disappears from the Bag but keeps its saved Favorite and Pin status. It returns automatically when reacquired.

Pinned items are sorted before all unpinned items. Their position is not changed by alphabetical sorting; multiple pinned items follow the order in which they were pinned.

## Automatic sorting

Items are automatically sorted by pocket and display name whenever the Bag is opened. The order is refreshed when a new item type is added or an item stack disappears completely. TMs and HMs are kept in numerical order, with HMs before TMs.

Pinned items always remain at the top of their category. Manual SELECT reordering remains available through **ITEM OPTIONS → MOVE ITEM** for the current Bag session. Closing and reopening the Bag applies automatic sorting again without moving pinned items below unpinned items.

## Quick search

Press **START** from any pocket except TM/HM to open Quick Search.

- Use the D-pad to move across the on-screen keyboard.
- Press **A** to enter a character or activate DEL, CLR, GO and EXIT.
- Press **B** to delete the last character; press it with an empty query to close search.
- Press **SELECT** to clear the full query.
- Press **START** or select **GO** to show all matching items.
- Choosing a result returns to the correct normal pocket with that item selected.

Search works across every pocket and matches both the displayed item name and its internal item identifier. An empty query lists the entire Bag alphabetically. Search results also show the `F`, `P` and `PF` status markers.

## Advanced TM/HM search and move information

The **TM HM** pocket has its own START menu instead of the general item search. It can:

- search by the name of the move contained in the machine;
- filter by elemental move type;
- filter by **PHYSICAL**, **SPECIAL** or **STATUS** damage class;
- sort by machine number, move name, highest power or lowest power;
- combine name, type and damage-class filters.

Generation I uses a type-based physical/special split. Normal, Fighting, Flying, Poison, Ground, Rock, Bug and Ghost attacks are shown as PHYSICAL. Fire, Water, Grass, Electric, Psychic, Ice and Dragon attacks are shown as SPECIAL. Moves with no base power are shown as STATUS.

Press **Y** on a controller or **I** on a keyboard while a TM/HM is highlighted to open **MOVE INFORMATION**. The screen shows:

- machine number and move name;
- elemental type;
- damage class;
- power;
- accuracy;
- PP;
- move effect.

The same Y/I information shortcut works inside filtered TM/HM results. Pinned machines remain above unpinned machines regardless of the selected sorting mode.

## Unlimited inventory

The Bag may contain an unlimited number of distinct item types, and each item stack may grow beyond 99 units. Counts remain finite values earned, bought or received during normal play.

The mod wraps the vanilla BagMenu rather than reimplementing item effects. Items are still used, consumed, taught, thrown and validated by Gen1Recomp's original menu. Pockets, Favorites, pinned items, automatic sorting and search are also available when the Bag is opened during battle.

## Installation

Import the ZIP in the MODS manager, enable **Modern Bag**, then fully restart Gen1Recomp.

Replace older Modern Bag versions instead of enabling multiple versions at the same time.

## Compatibility

Custom balls and machines are categorized from their registered item fields. Conventional custom medicines are detected from their effect identifiers; unknown items safely fall back to OTHER.
