# Changelog

## 1.5.0

- Added a dedicated START search panel for the TM/HM pocket.
- Added move-name search using the move contained inside each TM or HM.
- Added elemental-type filters.
- Added PHYSICAL, SPECIAL and STATUS filters using Generation I damage rules.
- Added sorting by machine number, move name, descending power and ascending power.
- Added a full move-information screen opened with controller Y or keyboard I.
- Move information includes type, class, power, accuracy, PP and effect.
- Added Y/I move information inside filtered results.
- Kept pinned machines above every unpinned machine under all sorting modes.
- Preserved Favorites, normal item actions, general Quick Search and unlimited inventory.

## 1.4.0

- Added a seventh **FAVORITES** pocket containing items selected from any normal pocket.
- Added persistent **PIN TO TOP** support for every item category.
- Pinned items remain above unpinned items regardless of automatic alphabetical sorting.
- Replaced direct SELECT reordering with an **ITEM OPTIONS** menu containing Favorite, Pin and Move actions.
- Added `F`, `P` and `PF` row markers for favorite and pinned items.
- Favorites and pins remain saved when an item stack reaches zero and return when the item is reacquired.
- Preserved Quick Search, battle-bag use, normal item actions and unlimited inventory.

## 1.3.0

- Added automatic sorting by pocket and item name whenever the Bag opens.
- Re-sorts automatically when item types are added or removed.
- Keeps HMs and TMs in numerical order.
- Added START-button Quick Search with an on-screen keyboard.
- Search covers every pocket and jumps directly to the selected result.
- Preserved manual SELECT reordering during the current Bag session.

## 1.2.0

- Removed the 99-unit maximum from individual item stacks.
- Kept the unlimited number of distinct bag item types.
- Added compatibility handling for both current and older Bag implementations.

## 1.1.1

- Removed the visible `L/R POCKET` hint from the bag footer.
- Kept Left/Right pocket switching unchanged.

## 1.1.0

- Removed the vanilla 20-slot limit for distinct bag items.
- Kept the independent vanilla limit of 99 units per item stack.
- Updated package metadata and documentation.

## [1.0.0] - 2026-07-30

### Added
- Six Left/Right inventory pockets.
- Pocket-aware cursor memory and item reordering.
- Automatic classification for built-in and modded items.
- Overworld and battle bag support.
- Vanilla item-action delegation.
