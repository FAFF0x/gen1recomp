# Area DexNav

Premi **SELECT** mentre il personaggio e fermo nell'overworld. La mod avvia
immediatamente una lotta con un Pokemon non ancora posseduto che appartiene
alla tabella incontri reale della zona corrente.

## Regole

- A terra usa gli incontri di erba o interni della mappa.
- Durante SURF usa esclusivamente gli incontri acquatici.
- Le specie gia presenti in `Pokedex.owned` vengono escluse.
- Livelli e peso degli slot originali vengono conservati e rinormalizzati tra
  i soli Pokemon ancora mancanti.
- Se hai completato la zona, appare un messaggio invece della lotta.
- Se la mappa non possiede incontri validi, appare un messaggio dedicato.
- La mod ignora il normale tiro del tasso incontri e il Repellente: SELECT e
  un'attivazione volontaria.
- Gli incontri della Torre Pokemon mantengono la regola dei fantasmi.
- Nella Zona Safari viene mantenuto il menu BALL / BAIT / ROCK / RUN.

Non include Pokemon ottenibili soltanto con pesca, eventi statici, regalo,
scambio o evoluzione: considera soltanto le tabelle casuali di terra/interno e
SURF della zona corrente.

## Controlli

Il tasto SELECT predefinito e **Tab** su tastiera; Shift e il tasto Back/Select
del controller sono alias supportati dal gioco. Un'associazione personalizzata
nelle opzioni continua a funzionare.

## Installazione

Importa direttamente lo ZIP dalla scheda MODS, abilita **Area DexNav**, chiudi
completamente Gen1Recomp e riaprilo.

## Compatibilita

La mod usa l'API mod v2 e dichiara `engine_internals` per preservare il flusso
completo delle lotte, inclusi Safari e fantasmi. Non modifica dati Pokemon,
probabilita di cattura, inventario o salvataggi.
