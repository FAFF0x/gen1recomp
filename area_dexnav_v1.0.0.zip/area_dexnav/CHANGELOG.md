# Changelog

## 1.0.0
- Attivazione con SELECT nell'overworld.
- Selezione pesata di Pokemon non ancora posseduti dalla tabella locale.
- Supporto terra, interni, SURF, Zona Safari e fantasmi della Torre Pokemon.
- Messaggi per zona completa, zona senza incontri e squadra inutilizzabile.
