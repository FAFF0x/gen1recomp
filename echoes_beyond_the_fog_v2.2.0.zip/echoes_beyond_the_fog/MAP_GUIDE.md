# Echoes Beyond the Fog v2.2.0 - Map Guide

## Interaction rule

Walk onto the bright yellow **`!`** marker. It identifies the exact tile used by every mandatory interaction.

## Cape Signal Observatory

1. **Study:** inspect Bill's field log in the north-west room.
2. **Engine Room:** activate the central generator and use the breaker order **SEA -> LENS -> HORN**.
3. **Beacon Dome:** broadcast **LOW-HIGH-LOW**, then enter the marked cliff gate.

## Fogbound Caverns

1. Follow the worked path, bridge and cyan landmarks to the north-east stair.
2. At the central relay, identify the giant Dragonite's call as **A GREETING**, then defeat the Black Tide scout.
3. Use the MAG-KEY at the north-east dock gate.

## Black Tide Hideout

1. Cross the warehouse and take the marked north-east service lift.
2. Disable all three yellow-marked resonance anchors in the laboratory deck.
3. Climb to the control room and confront Captain Morrow at the eastern console.

The giant Dragonite is never captured. After the false signal is destroyed, it answers Bill's authentic call and returns to the open sea.
