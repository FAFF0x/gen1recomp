# Changelog

## v2.2.0

- Fixed the major inactive-quest performance bug: `completed()` no longer calls `Quest System.get()` from inside Quest System resolver callbacks, eliminating recursive full snapshots.
- Replaced dynamic objective/location/progress callbacks with journal state updated only when progression changes.
- Hidden, not-yet-unlocked quest state is now effectively dormant; it performs no boot synchronization unless started.
- Removed all replay logic. The quest is now strictly one-shot per save.
- After the Dragonite reward is claimed, the quest is removed from the active Quest System registry for the session, its marker disappears and Bill immediately falls back to vanilla dialogue.
- Added migration for v2.1.x completed/replay saves: `reward_mon` permanently finalizes the quest and clears legacy replay state.
- Requires Quest System 1.0.5+ for the optimized marker/journal cache path.

## v2.1.0
- Rebuilt all three tileset atlases from the original supplied sprite sheets with clean crops and consistent floor backgrounds.
- Removed label fragments and incoherent random sprite placement.
- Expanded every floor to 18x14 metatiles and redesigned all nine maps by hand.
- Added a bright yellow `!` interaction marker; mandatory interactions are no longer invisible.
- Added explicit objective text on floor entry and route boards in the first floor of each area.
- Added new puzzles: lighthouse breaker order, interpretation of the Dragonite call, and three Black Tide resonance anchors.
- Reworked the lore around Bill's original giant Dragonite encounter, its lonely call, Team Rocket's attack, and the idea that discovery does not require capture.
- The giant Dragonite remains free; the reward is a separate Dragonite rescued from Black Tide.
- Updated replay reset data for every new puzzle flag.

## v2.0.0
- Rebuilt the quest dungeon from scratch.
- Redesigned the three areas as handcrafted multi-level maps: Cape Signal Observatory, Fogbound Caverns, and Black Tide Hideout.
- Reworked map layouts so progression is clearer and each area has a stronger visual identity.
- Ensured every supplied tileset theme is represented across the new dungeon floors.


## v1.4.0
- Rebuilt the quest as nine maps across three multi-level dungeon areas.
- Each area uses a dedicated 24-metatile atlas derived from the supplied sprite sheet.
- Every atlas metatile is placed across its area's three floors.
- Added visible stairs, lifts, gates, guide terminals, machines, caves, bridges, laboratories and control rooms.


## v1.3.0
- Rebuilt all three dungeon maps with visible furniture, machinery, pools, roots, crates, tanks, monitors and lighting.
- Expanded each tileset from 6 to 14 native metatiles.
- Added visible GUIDE signs/terminals at every entrance.
- Added amber, cyan and red route markers for the three areas.
- Interactive objects now use bright floor bars and explicit follow-up directions.
- Replaced broad invisible trigger zones with small pads directly in front of visible objects.
- Improved collision so props occupy their upper cells while their lower interaction pads remain accessible.


## v1.2.3
- Fixed the crash when starting or replaying the quest and warping to Cape Signal Observatory.
- Rebuilt all three bundled graphics as native 8x8 Gen1Recomp tile atlases.
- Corrected out-of-range tile index 20 in 20-tile atlases.
- Added a valid sixth map block for transition cells used by Fogbound Caverns and Black Tide Hideout.
- Resolved bundled asset paths through `mod.path`.
- Marked the custom pixel-art atlases as true-color tilesets.


## v1.2.2
- Fixed replay detection on completed saves by recognizing the reward flag and Quest System completion state.
- Added replay handling to both possible human Bill dialogue objects.
- Added a one-time replay prompt when entering Bill's house after completion.
- Reset quest flags explicitly to false for reliable save compatibility.
- Preserved the original Dragonite reward and prevented duplicate rewards.


## v1.2.1
- Added a replay option when speaking with Bill after completing the quest.
- Replay resets all three-area quest checkpoints while preserving the Dragonite already earned.
- Replaying cannot award a duplicate Dragonite.
- The Quest System entry is reactivated automatically when replay begins.


## v1.2.0
- Expanded the quest into three complete themed areas: Cape Signal Observatory, Fogbound Caverns and Black Tide Hideout.
- Added two new bundled tilesets for the caverns and the hideout.
- Split the dungeon progression across the observatory, the cliffside caverns and the dockside poacher base.
- Updated quest objectives and locations to reflect the new multi-area structure.


## v1.1.0
- Added a custom pixel-art lighthouse tileset to the Cape Signal Observatory.
- The quest dungeon now uses bundled visual assets instead of the generic overworld tiles.
- Updated the package structure to include the new tileset asset.


## 1.0.1

- Fixed the quest not triggering because the Sea Cottage was registered under the incorrect map id.
- Added a direct post-event Bill talk handler using `BILLS_HOUSE`.
- Added full fallback to Bill's vanilla conversation.
- Expanded Bill-event compatibility for imported and older saves.
- Corrected quest marker and return-warp map references.

## 1.0.0

- Added the complete Echoes Beyond the Fog quest.
- Added a new Cape Signal Observatory map.
- Added tidal-log investigation and foghorn tuning puzzle.
- Added a generator encounter and two Black Tide trainer battles.
- Added Quest System objectives, progress tracking and Bill marker.
- Added a one-time level 50 Dragonite reward with maximum DVs and Stat Exp.
- Added automatic party/Box delivery and safe retry when storage is full.
