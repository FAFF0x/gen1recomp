-- Kanto Achievements v1.0.6 interface.
-- The active ALL / INCOMP / DONE tab now uses a bright illuminated fill,
-- a double outline and a downward pointer, so the current view is obvious.
-- A single solid arrow always marks the active control or achievement row.
return function(mod, achievements, api)
  local Font = require("src.render.Font")
  local Screens = require("src.ui.Screens")
  local Menu = require("src.ui.Menu")

  local COLORS = {
    bg = { 0.96, 0.96, 0.93 },
    paper = { 1, 1, 1 },
    ink = { 0, 0, 0 },
    soft = { 0.88, 0.89, 0.90 },
    selected = { 1.00, 0.86, 0.28 },
    tabActive = { 1.00, 0.78, 0.08 },
    tabGlow = { 1.00, 0.95, 0.45 },
    done = { 0.76, 0.93, 0.76 },
    progress = { 0.95, 0.72, 0.16 },
    empty = { 0.72, 0.74, 0.76 },
  }

  local TABS = { "ALL", "INCOMP", "DONE" }
  local FILTERS = {
    "ALL", "STORY", "ITEMS", "COLLECTION",
    "TRAINING", "BATTLE", "EXPLORATION",
  }

  local ROWS = 3
  local FOCUS_SEARCH = 1
  local FOCUS_FILTER = 2
  local FOCUS_LIST = 3

  local function setColor(c)
    love.graphics.setColor(c[1], c[2], c[3], 1)
  end

  local function fill(x, y, w, h, color)
    setColor(color)
    love.graphics.rectangle("fill", x, y, w, h)
  end

  local function box(x, y, w, h, color)
    fill(x, y, w, h, color or COLORS.paper)
    setColor(COLORS.ink)
    love.graphics.rectangle("line", x + 0.5, y + 0.5, w - 1, h - 1)
  end

  -- A real filled triangle is used instead of a font glyph, so the cursor
  -- remains visible with every font, language pack and palette.
  local function drawFocusArrow(x, y)
    setColor(COLORS.ink)
    love.graphics.polygon("fill", x, y, x, y + 8, x + 6, y + 4)
  end

  local function drawText(value, x, y)
    setColor(COLORS.ink)
    Font.draw(tostring(value or ""), x, y)
  end

  local function textWidth(value)
    local s = tostring(value or "")
    if Font.width then return Font.width(s) end
    return #s * 8
  end

  local function fitText(value, maxWidth)
    local s = tostring(value or "")
    if textWidth(s) <= maxWidth then return s end
    local suffix = ".."
    while #s > 0 and textWidth(s .. suffix) > maxWidth do
      s = s:sub(1, #s - 1)
    end
    return s .. suffix
  end

  local function drawRight(value, rightX, y)
    local s = tostring(value or "")
    drawText(s, rightX - textWidth(s), y)
  end

  -- Active status tabs use three independent cues: bright fill, double
  -- outline and a downward pointer. This remains readable even when a
  -- palette compresses the yellow shades into similar colours.
  local function drawStatusTab(x, y, w, h, label, active)
    if active then
      fill(x - 1, y - 1, w + 2, h + 2, COLORS.tabGlow)
      fill(x, y, w, h, COLORS.tabActive)
      setColor(COLORS.ink)
      love.graphics.rectangle("line", x + 0.5, y + 0.5, w - 1, h - 1)
      love.graphics.rectangle("line", x + 2.5, y + 2.5, w - 5, h - 5)
      local center = x + math.floor(w / 2)
      love.graphics.polygon("fill", center - 4, y + h, center + 4, y + h,
        center, y + h + 3)
    else
      box(x, y, w, h, COLORS.soft)
    end
    local tx = x + math.floor((w - textWidth(label)) / 2)
    drawText(label, tx, y + 4)
  end

  local function wrapPixels(value, maxWidth, maxLines)
    local lines, line = {}, ""
    for rawWord in tostring(value or ""):gmatch("%S+") do
      local word = textWidth(rawWord) <= maxWidth and rawWord
        or fitText(rawWord, maxWidth)
      local candidate = line == "" and word or (line .. " " .. word)
      if textWidth(candidate) <= maxWidth then
        line = candidate
      else
        if line ~= "" then lines[#lines + 1] = line end
        if #lines >= maxLines then break end
        line = word
      end
    end
    if #lines < maxLines and line ~= "" then lines[#lines + 1] = line end
    if #lines == maxLines then
      local original = tostring(value or "")
      local joined = table.concat(lines, " ")
      if #joined < #original then
        lines[#lines] = fitText(lines[#lines], math.max(8, maxWidth - 8)) .. "."
      end
    end
    return lines
  end

  local function progressBar(x, y, w, current, target, done)
    fill(x, y, w, 7, COLORS.empty)
    setColor(COLORS.ink)
    love.graphics.rectangle("line", x + 0.5, y + 0.5, w - 1, 6)
    local ratio = math.max(0, math.min(1, current / math.max(1, target)))
    fill(x + 1, y + 1, math.floor((w - 2) * ratio), 5,
      done and COLORS.done or COLORS.progress)
  end

  local AchievementScreen = {}
  AchievementScreen.__index = AchievementScreen
  AchievementScreen.isOpaque = true

  function AchievementScreen:sgbPalettes(game)
    return require("src.render.PaletteFX").wholeNamed(game.data, "MEWMON")
  end

  function AchievementScreen.new(game, opts)
    local self = setmetatable({}, AchievementScreen)
    self.game = game
    self.onClose = opts and opts.onClose
    self.tab = 1
    self.filter = "ALL"
    self.search = ""
    self.focus = FOCUS_LIST
    self.index = 1
    self.scroll = 0
    self.detail = false
    self.items = {}
    self:refresh()
    return self
  end

  function AchievementScreen:refresh()
    local query = self.search:lower()
    local tab = TABS[self.tab]
    self.items = {}
    for _, achievement in ipairs(achievements) do
      local done = api.unlocked(achievement)
      local tabOk = tab == "ALL"
        or (tab == "DONE" and done)
        or (tab == "INCOMP" and not done)
      local filterOk = self.filter == "ALL" or achievement.category == self.filter
      local hay = (achievement.title .. " " .. achievement.description):lower()
      local searchOk = query == "" or hay:find(query, 1, true) ~= nil
      if tabOk and filterOk and searchOk then
        self.items[#self.items + 1] = achievement
      end
    end
    table.sort(self.items, function(a, b)
      local ad, bd = api.unlocked(a), api.unlocked(b)
      if tab == "ALL" and ad ~= bd then return not ad end
      return a.title < b.title
    end)
    if #self.items == 0 then
      self.index, self.scroll = 1, 0
      if self.focus == FOCUS_LIST then self.focus = FOCUS_FILTER end
    else
      self.index = math.max(1, math.min(self.index, #self.items))
      self:syncScroll()
    end
  end

  function AchievementScreen:syncScroll()
    if self.index - self.scroll > ROWS then self.scroll = self.index - ROWS end
    if self.index - self.scroll < 1 then self.scroll = self.index - 1 end
    self.scroll = math.max(0, self.scroll)
  end

  function AchievementScreen:openSearch()
    Screens.push(self.game, "NamingScreen", {
      title = "SEARCH", maxLen = 12, default = self.search,
      onDone = function(value)
        self.search = tostring(value or "")
        self.index, self.scroll = 1, 0
        self:refresh()
      end,
    })
  end

  function AchievementScreen:openFilter()
    local rows = {}
    for _, category in ipairs(FILTERS) do
      local value = category
      rows[#rows + 1] = {
        label = value,
        onSelect = function()
          self.filter = value
          self.index, self.scroll = 1, 0
          self:refresh()
        end,
      }
    end
    self.game.stack:push(Menu.new(self.game, rows, {
      tx = 2, ty = 1, tw = 16, maxVisible = 5,
    }))
  end

  function AchievementScreen:close()
    self.game.stack:pop()
    if self.onClose then self.onClose() end
  end

  function AchievementScreen:moveUp()
    if self.focus == FOCUS_LIST then
      if self.index > 1 then
        self.index = self.index - 1
        self:syncScroll()
      else
        self.focus = FOCUS_FILTER
      end
    elseif self.focus == FOCUS_FILTER then
      self.focus = FOCUS_SEARCH
    end
  end

  function AchievementScreen:moveDown()
    if self.focus == FOCUS_SEARCH then
      self.focus = FOCUS_FILTER
    elseif self.focus == FOCUS_FILTER then
      if #self.items > 0 then self.focus = FOCUS_LIST end
    elseif self.focus == FOCUS_LIST and self.index < #self.items then
      self.index = self.index + 1
      self:syncScroll()
    end
  end

  function AchievementScreen:activate()
    if self.focus == FOCUS_SEARCH then
      self:openSearch()
    elseif self.focus == FOCUS_FILTER then
      self:openFilter()
    elseif self.focus == FOCUS_LIST and self.items[self.index] then
      self.detail = true
    end
  end

  function AchievementScreen:update()
    local input = self.game.input
    if self.detail then
      if input:wasPressed("a") or input:wasPressed("b") then self.detail = false end
      return
    end

    if input:wasPressed("left") then
      self.tab = self.tab > 1 and self.tab - 1 or #TABS
      self.index, self.scroll = 1, 0
      self:refresh()
    elseif input:wasPressed("right") then
      self.tab = self.tab < #TABS and self.tab + 1 or 1
      self.index, self.scroll = 1, 0
      self:refresh()
    elseif input:wasPressed("up") then
      self:moveUp()
    elseif input:wasPressed("down") then
      self:moveDown()
    elseif input:wasPressed("a") then
      self:activate()
    elseif input:wasPressed("start") then
      self.focus = FOCUS_SEARCH
      self:openSearch()
    elseif input:wasPressed("select") then
      self.focus = FOCUS_FILTER
      self:openFilter()
    elseif input:wasPressed("b") then
      self:close()
    end
  end

  function AchievementScreen:drawHeader()
    fill(0, 0, 160, 144, COLORS.bg)

    box(0, 0, 160, 17, COLORS.paper)
    drawText("ACHIEVEMENTS", 6, 5)
    drawRight(("%d/100"):format(api.unlockedCount()), 154, 5)

    for i, label in ipairs(TABS) do
      local x = 4 + (i - 1) * 51
      drawStatusTab(x, 19, 49, 14, label, i == self.tab)
    end
  end

  function AchievementScreen:drawFields()
    local searchSelected = self.focus == FOCUS_SEARCH
    box(4, 37, 152, 14, searchSelected and COLORS.selected or COLORS.paper)
    if searchSelected then drawFocusArrow(10, 40) end
    drawText("SEARCH", 22, 41)
    local searchValue = self.search ~= "" and self.search or "PRESS A"
    drawRight(fitText(searchValue, 64), 150, 41)

    local filterSelected = self.focus == FOCUS_FILTER
    box(4, 53, 152, 14, filterSelected and COLORS.selected or COLORS.paper)
    if filterSelected then drawFocusArrow(10, 56) end
    drawText("CATEGORY", 22, 57)
    drawRight(fitText(self.filter, 64), 150, 57)
  end

  function AchievementScreen:drawList()
    if #self.items == 0 then
      box(4, 70, 152, 55, COLORS.paper)
      drawText("NO RESULTS", 40, 90)
      drawText("CHANGE FILTER", 28, 104)
      return
    end

    for row = 1, ROWS do
      local i = self.scroll + row
      local achievement = self.items[i]
      if not achievement then break end
      local y = 70 + (row - 1) * 19
      local selected = self.focus == FOCUS_LIST and i == self.index
      local done = api.unlocked(achievement)
      local current, target = api.progress(achievement)
      local percent = math.floor(math.max(0, math.min(1, current / math.max(1, target))) * 100)

      box(4, y, 152, 17,
        selected and COLORS.selected or (done and COLORS.done or COLORS.paper))

      if selected then drawFocusArrow(10, y + 4) end
      drawText(fitText(achievement.title, 84), 22, y + 5)
      drawRight(done and "DONE" or (percent .. "%"), 150, y + 5)
    end
  end

  function AchievementScreen:drawFooter()
    box(0, 126, 160, 18, COLORS.soft)
    drawText("UP/DN", 8, 128)
    drawRight("LT/RT TAB", 152, 128)
    drawText("A OPEN", 8, 136)
    drawRight("B BACK", 152, 136)
  end

  function AchievementScreen:drawDetail()
    fill(0, 0, 160, 144, COLORS.bg)
    local achievement = self.items[self.index]
    if not achievement then return end

    local done = api.unlocked(achievement)
    local current, target = api.progress(achievement)

    box(0, 0, 160, 17, done and COLORS.done or COLORS.selected)
    drawText(done and "COMPLETED" or "ACHIEVEMENT", 7, 5)
    drawRight(current .. "/" .. target, 153, 5)

    box(5, 19, 150, 125, COLORS.paper)

    local titleLines = wrapPixels(achievement.title, 134, 2)
    for i, line in ipairs(titleLines) do drawText(line, 13, 25 + (i - 1) * 10) end

    drawText(achievement.category, 13, 49)
    setColor(COLORS.ink)
    love.graphics.line(13, 60, 147, 60)

    local descriptionLines = wrapPixels(achievement.description, 134, 5)
    for i, line in ipairs(descriptionLines) do
      drawText(line, 13, 67 + (i - 1) * 10)
    end

    progressBar(13, 119, 96, current, target, done)
    drawRight(done and "DONE" or (current .. "/" .. target), 147, 118)
    drawRight("B BACK", 147, 133)
  end

  function AchievementScreen:draw()
    if self.detail then
      self:drawDetail()
    else
      self:drawHeader()
      self:drawFields()
      self:drawList()
      self:drawFooter()
    end
    love.graphics.setColor(1, 1, 1, 1)
  end

  local Toast = {}
  Toast.__index = Toast
  Toast.isOpaque = false

  function Toast.new(game, title, onDone)
    return setmetatable({ game = game, title = title, frames = 120, onDone = onDone }, Toast)
  end

  function Toast:finish()
    self.game.stack:pop()
    if self.onDone then self.onDone() end
  end

  function Toast:update()
    self.frames = self.frames - 1
    if self.frames <= 0 or self.game.input:wasPressed("a")
       or self.game.input:wasPressed("b") then self:finish() end
  end

  function Toast:draw()
    box(6, 6, 148, 36, COLORS.paper)
    fill(7, 7, 146, 8, COLORS.selected)
    drawText("ACHIEVEMENT UNLOCKED", 13, 18)
    drawText(fitText(self.title, 132), 13, 30)
    love.graphics.setColor(1, 1, 1, 1)
  end

  -- Gen1 Modern UI compatibility contract (API v1). Kanto Achievements keeps
  -- ownership of navigation, search/filter callbacks, persistence and unlock
  -- logic. Modern UI only receives a read-only model of the live screen and
  -- semantic pointer actions. If Modern UI is absent or disabled, the native
  -- 160x144 interface above remains the fallback.
  local function modernSelectedIndex(state)
    if state.detail then return 1 end
    if state.focus == FOCUS_SEARCH then return 1 end
    if state.focus == FOCUS_FILTER then return 2 end
    return math.max(3, (tonumber(state.index) or 1) + 2)
  end

  local function modernListModel(state)
    local rows = {}
    local savedState = api.state()
    local unlocked = type(savedState) == "table" and savedState.unlocked or {}
    local tab = TABS[state.tab] or "ALL"

    rows[#rows + 1] = {
      label = "SEARCH",
      value = state.search ~= "" and state.search or "PRESS A",
      marker = state.focus == FOCUS_SEARCH,
      enabled = true,
    }
    rows[#rows + 1] = {
      label = "CATEGORY",
      value = state.filter or "ALL",
      marker = state.focus == FOCUS_FILTER,
      enabled = true,
    }

    for _, achievement in ipairs(state.items or {}) do
      local done = unlocked and unlocked[achievement.id] ~= nil
      local current, target = api.progress(achievement, savedState)
      local percent = math.floor(math.max(0,
        math.min(1, current / math.max(1, target))) * 100)
      rows[#rows + 1] = {
        label = achievement.title,
        value = done and "DONE" or (percent .. "%"),
        marker = done,
        enabled = true,
        category = achievement.category,
      }
    end

    return {
      title = ("ACHIEVEMENTS %d/%d - %s"):format(
        api.unlockedCount(), #achievements, tab),
      rows = rows,
      index = modernSelectedIndex(state),
      scroll = (tonumber(state.scroll) or 0) > 0
        and math.max(0, (tonumber(state.scroll) or 0) + 2) or 0,
      footer = { "L/R TAB", "A OPEN", "START SEARCH", "SELECT FILTER", "B BACK" },
    }
  end

  local function modernDetailModel(state)
    local achievement = state.items and state.items[state.index]
    if not achievement then return modernListModel(state) end
    local savedState = api.state()
    local done = savedState.unlocked
      and savedState.unlocked[achievement.id] ~= nil
    local current, target = api.progress(achievement, savedState)
    return {
      title = done and "ACHIEVEMENT COMPLETED" or "ACHIEVEMENT",
      rows = {
        { label = achievement.title, header = true, enabled = false },
        { label = "CATEGORY", value = achievement.category, enabled = false },
        { label = "DESCRIPTION", header = true, enabled = false },
        { label = achievement.description, enabled = false },
        { label = "PROGRESS", value = current .. "/" .. target,
          marker = done, enabled = false },
        { label = "STATUS", value = done and "DONE" or "INCOMPLETE",
          marker = done, enabled = false },
      },
      index = 1,
      scroll = 0,
      footer = { "A/B BACK" },
    }
  end

  local modernUiContract = {
    apiVersion = 1,
    screens = {
      achievements = {
        match = function(state)
          return type(state) == "table" and state.screenId == "AchievementsScreen"
        end,
        canSuppressNative = true,
        model = function(_, state)
          if state.detail then return modernDetailModel(state) end
          return modernListModel(state)
        end,
        actions = {
          hover = function(_, state, index)
            if state.detail then return false end
            index = math.max(1, math.floor(tonumber(index) or 1))
            if index == 1 then
              state.focus = FOCUS_SEARCH
            elseif index == 2 then
              state.focus = FOCUS_FILTER
            else
              local itemIndex = index - 2
              if not state.items[itemIndex] then return false end
              state.focus = FOCUS_LIST
              state.index = itemIndex
              state:syncScroll()
            end
            return true
          end,
          select = function(_, state, index)
            if state.detail then
              state.detail = false
              return true
            end
            if index ~= nil then
              local idx = math.max(1, math.floor(tonumber(index) or 1))
              if idx == 1 then
                state.focus = FOCUS_SEARCH
              elseif idx == 2 then
                state.focus = FOCUS_FILTER
              elseif state.items[idx - 2] then
                state.focus = FOCUS_LIST
                state.index = idx - 2
                state:syncScroll()
              else
                return false
              end
            end
            state:activate()
            return true
          end,
          up = function(_, state)
            if state.detail then return false end
            state:moveUp()
            return true
          end,
          down = function(_, state)
            if state.detail then return false end
            state:moveDown()
            return true
          end,
          left = function(_, state)
            if state.detail then return false end
            state.tab = state.tab > 1 and state.tab - 1 or #TABS
            state.index, state.scroll = 1, 0
            state:refresh()
            return true
          end,
          right = function(_, state)
            if state.detail then return false end
            state.tab = state.tab < #TABS and state.tab + 1 or 1
            state.index, state.scroll = 1, 0
            state:refresh()
            return true
          end,
          start = function(_, state)
            if state.detail then return false end
            state.focus = FOCUS_SEARCH
            state:openSearch()
            return true
          end,
          back = function(_, state)
            if state.detail then
              state.detail = false
            else
              state:close()
            end
            return true
          end,
        },
      },
    },
  }

  local modernUiExports
  local modernUiRegistered = false
  local function ensureModernUiAdapter()
    if type(mod.find) ~= "function" then return false end
    local okFind, handle = pcall(mod.find, "gen1_modern_ui")
    if not okFind or type(handle) ~= "table" or type(handle.exports) ~= "table" then
      modernUiExports, modernUiRegistered = nil, false
      return false
    end
    local ex = handle.exports
    if tonumber(ex.compatibilityApiVersion or 1) ~= 1
        or type(ex.registerAdapter) ~= "function" then
      modernUiExports, modernUiRegistered = ex, false
      return false
    end
    if modernUiRegistered and modernUiExports == ex then return true end
    local ok, registered, reason = pcall(ex.registerAdapter, {
      owner = "kanto_achievements",
      version = "1.0.6",
      contract = modernUiContract,
    })
    if ok and registered ~= false then
      modernUiExports, modernUiRegistered = ex, true
      return true
    end
    modernUiExports, modernUiRegistered = ex, false
    if mod.log then
      mod.log:warn("Gen1 Modern UI adapter unavailable: %s",
        tostring(ok and reason or registered))
    end
    return false
  end

  mod.exports.gen1ModernUi = modernUiContract
  mod.exports.ensureModernUiAdapter = ensureModernUiAdapter

  mod.content.screens:register("AchievementsScreen", { new = AchievementScreen.new })
  mod.content.screens:register("AchievementToast", { new = Toast.new })
  mod.exports.newAchievementsScreen = AchievementScreen.new
  mod.exports.achievementUILayout = {
    rows = ROWS,
    statusTabs = TABS,
    selectionIndicator = "solid_triangle",
    activeTabIndicator = "bright_fill_double_border_pointer",
    header = { 0, 0, 160, 36 },
    search = { 4, 37, 152, 14 },
    filter = { 4, 53, 152, 14 },
    list = { 4, 70, 152, 55 },
    footer = { 0, 126, 160, 18 },
    listColumns = { cursorRight = 16, titleLeft = 22, titleRight = 106, progressLeft = 110, progressRight = 150 },
  }

  -- Register immediately when load order permits it. main.lua retries on
  -- game.ready and every time the Achievements screen is opened.
  ensureModernUiAdapter()
end
