local polygons = {}
_G.love = { graphics = {
  setColor = function() end,
  rectangle = function() end,
  polygon = function(_, ...) polygons[#polygons + 1] = { ... } end,
  line = function() end,
} }

package.preload["src.render.Font"] = function()
  return { width = function(s) return #tostring(s or "") * 8 end, draw = function() end }
end
package.preload["src.ui.Screens"] = function()
  return { push = function() end }
end
package.preload["src.ui.Menu"] = function()
  return { new = function() return {} end }
end

local registered = {}
local mod = {
  exports = {},
  content = { screens = { register = function(_, id, def) registered[id] = def end } },
}
local achievements = {
  { id="a", title="A VERY LONG ACHIEVEMENT TITLE", description="one", category="STORY" },
  { id="b", title="B", description="two", category="ITEMS" },
  { id="c", title="C", description="three", category="BATTLE" },
  { id="d", title="D", description="four", category="STORY" },
}
local api = {
  unlocked = function(a) return a.id == "d" end,
  progress = function(a) return a.id == "d" and 1 or 0, 1 end,
  unlockedCount = function() return 1 end,
}

assert(loadfile("ui.lua"))()(mod, achievements, api)
assert(registered.AchievementsScreen, "screen was not registered")

local pressed = {}
local input = { wasPressed = function(_, key) return pressed[key] == true end }
local stack = { pop = function() end, push = function() end }
local game = { input = input, stack = stack }
local screen = registered.AchievementsScreen.new(game, {})

local function press(key)
  pressed = { [key] = true }
  screen:update()
  pressed = {}
end

assert(screen.focus == 3 and screen.index == 1,
  "the first achievement must be selected when the screen opens")
polygons = {}
screen:draw()
local function activeTabTipX()
  for _, p in ipairs(polygons) do
    if p[2] == 33 and p[4] == 33 and p[6] == 36 then return p[5] end
  end
end
assert(activeTabTipX() == 28, "ALL tab must carry the illuminated pointer")
press("down")
assert(screen.index == 2 and screen.focus == 3,
  "DOWN in the list must advance the arrow one achievement")
press("up")
assert(screen.index == 1 and screen.focus == 3,
  "UP must return the arrow to the first achievement")
press("up")
assert(screen.focus == 2, "UP from the first achievement must select CATEGORY")
press("up")
assert(screen.focus == 1, "UP from CATEGORY must select SEARCH")
press("down")
assert(screen.focus == 2, "DOWN from SEARCH must select CATEGORY")
press("down")
assert(screen.focus == 3 and screen.index == 1,
  "DOWN from CATEGORY must return the arrow to the achievement list")

press("right")
assert(screen.tab == 2, "RIGHT must select the incomplete status tab")
polygons = {}
screen:draw()
assert(activeTabTipX() == 79, "illuminated pointer must move to INCOMP")
assert(#screen.items == 3, "INCOMP must contain only the three incomplete achievements")
for _, item in ipairs(screen.items) do
  assert(item.id ~= "d", "the completed achievement leaked into INCOMP")
end
press("left")
assert(screen.tab == 1, "LEFT must return to ALL")

local layout = mod.exports.achievementUILayout
assert(layout and layout.rows == 3, "expected three visible achievement rows")
assert(layout.statusTabs[2] == "INCOMP", "missing explicit incomplete filter")
assert(layout.selectionIndicator == "solid_triangle", "missing solid selection arrow")
assert(layout.activeTabIndicator == "bright_fill_double_border_pointer",
  "missing illuminated active-tab indicator")
assert(layout.listColumns.cursorRight < layout.listColumns.titleLeft,
  "cursor overlaps achievement title")
assert(layout.listColumns.titleRight < layout.listColumns.progressLeft,
  "achievement title overlaps progress")
local function bottom(r) return r[2] + r[4] end
assert(bottom(layout.header) <= layout.search[2], "header overlaps search")
assert(bottom(layout.search) <= layout.filter[2], "search overlaps filter")
assert(bottom(layout.filter) <= layout.list[2], "filter overlaps list")
assert(bottom(layout.list) <= layout.footer[2], "list overlaps footer")
assert(bottom(layout.footer) <= 144, "footer exceeds the Game Boy canvas")

print("achievement ui navigation ok")
