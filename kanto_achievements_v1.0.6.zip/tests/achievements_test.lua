local source = assert(io.open("achievements.lua", "rb")):read("*a")
local achievements = assert(load(source, "@achievements.lua"))()
assert(#achievements == 100, "expected exactly 100 achievements")
local ids, titles = {}, {}
for i, achievement in ipairs(achievements) do
  assert(type(achievement.id) == "string" and achievement.id ~= "", "missing id " .. i)
  assert(type(achievement.title) == "string" and achievement.title ~= "", "missing title " .. i)
  assert(type(achievement.description) == "string" and achievement.description ~= "", "missing description " .. i)
  assert(type(achievement.category) == "string", "missing category " .. i)
  assert(type(achievement.condition) == "table" and achievement.condition.kind, "missing condition " .. i)
  assert(not ids[achievement.id], "duplicate id " .. achievement.id)
  assert(not titles[achievement.title], "duplicate title " .. achievement.title)
  ids[achievement.id], titles[achievement.title] = true, true
end
print("achievement definitions ok: " .. #achievements)
