_G.love = { graphics = {
  setColor = function() end,
  rectangle = function() end,
  polygon = function() end,
  line = function() end,
} }

package.preload["src.render.Font"] = function()
  return { width = function(s) return #tostring(s or "") * 8 end,
    draw = function() end }
end
package.preload["src.render.PaletteFX"] = function()
  return { wholeNamed = function() return {} end }
end
package.preload["src.ui.Screens"] = function()
  return { push = function() end }
end
package.preload["src.ui.Menu"] = function()
  return { new = function() return {} end }
end

local registered = {}
local adapterSpec
local modernExports = {
  compatibilityApiVersion = 1,
  registerAdapter = function(spec)
    adapterSpec = spec
    return true
  end,
}
local mod = {
  id = "kanto_achievements",
  exports = {},
  content = { screens = { register = function(_, id, def) registered[id] = def end } },
  find = function(id)
    if id == "gen1_modern_ui" then return { exports = modernExports } end
  end,
  log = { warn = function() end },
}
local achievements = {
  { id="a", title="A", description="Alpha achievement", category="STORY" },
  { id="b", title="B", description="Beta achievement", category="ITEMS" },
  { id="c", title="C", description="Gamma achievement", category="BATTLE" },
}
local saved = { unlocked = { b = { playTime = 1 } }, stats = { visitedMaps = {} } }
local api = {
  state = function() return saved end,
  unlocked = function(a) return saved.unlocked[a.id] ~= nil end,
  progress = function(a)
    if a.id == "a" then return 1, 4 end
    if a.id == "b" then return 1, 1 end
    return 0, 2
  end,
  unlockedCount = function() return 1 end,
}

assert(loadfile("ui.lua"))()(mod, achievements, api)
assert(adapterSpec and adapterSpec.owner == "kanto_achievements",
  "Modern UI adapter was not registered")
assert(adapterSpec.version == "1.0.6", "wrong adapter version")
local contract = assert(mod.exports.gen1ModernUi)
assert(contract.apiVersion == 1, "wrong compatibility API")
local descriptor = assert(contract.screens.achievements)
assert(descriptor.canSuppressNative == true, "native UI cannot be suppressed")

local input = { wasPressed = function() return false end }
local popped = 0
local game = { input = input, stack = {
  pop = function() popped = popped + 1 end,
  push = function() end,
} }
local screen = registered.AchievementsScreen.new(game, {})
screen.screenId = "AchievementsScreen"
assert(descriptor.match(screen), "screen match failed")

local model = descriptor.model(game, screen)
assert(model.title == "ACHIEVEMENTS 1/3 - ALL", model.title)
assert(#model.rows == 5, "expected Search, Category and three achievements")
assert(model.rows[1].label == "SEARCH" and model.rows[2].label == "CATEGORY")
assert(model.rows[3].label == "A" and model.rows[3].value == "25%")
assert(model.rows[4].label == "C" and model.rows[4].value == "0%")
assert(model.rows[5].label == "B" and model.rows[5].value == "DONE")
assert(model.index == 3, "first achievement should be selected")

assert(descriptor.actions.hover(game, screen, 1))
assert(screen.focus == 1, "hover SEARCH should move source focus")
assert(descriptor.actions.hover(game, screen, 2))
assert(screen.focus == 2, "hover CATEGORY should move source focus")
assert(descriptor.actions.hover(game, screen, 5))
assert(screen.focus == 3 and screen.index == 3,
  "hover achievement should update source selection")

assert(descriptor.actions.left(game, screen))
assert(screen.tab == 3, "LEFT should wrap ALL to DONE")
assert(descriptor.actions.right(game, screen))
assert(screen.tab == 1, "RIGHT should wrap DONE to ALL")

screen.focus, screen.index = 3, 1
assert(descriptor.actions.select(game, screen, 3))
assert(screen.detail == true, "row select should open achievement details")
local detail = descriptor.model(game, screen)
assert(detail.title == "ACHIEVEMENT", "incomplete detail title mismatch")
assert(detail.rows[1].label == "A")
assert(detail.rows[5].value == "1/4")
assert(descriptor.actions.back(game, screen))
assert(screen.detail == false, "BACK should leave detail")
assert(descriptor.actions.back(game, screen))
assert(popped == 1, "BACK should close source screen")

print("modern ui compatibility ok")
