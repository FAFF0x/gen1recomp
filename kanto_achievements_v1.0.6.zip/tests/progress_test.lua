package.preload["src.render.Font"] = function() return {} end
package.preload["src.ui.Screens"] = function() return { push = function() end } end
package.preload["src.ui.Menu"] = function() return { new = function() return {} end } end

local store = {}
local handlers, hooks = {}, {}
local mod = {
  path = ".",
  exports = {},
  read = function(_, name)
    local f = assert(io.open(name, "rb")); local s = f:read("*a"); f:close(); return s
  end,
  save = {
    get = function(_, key) return store[key] end,
    set = function(_, key, value) store[key] = value end,
  },
  content = { screens = { register = function() end } },
  hooks = { wrap = function(_, id, fn) hooks[id] = fn end },
  events = { on = function(_, id, fn) handlers[id] = fn end },
  ui = { insertBefore = function() end, push = function() end },
}

assert(loadfile("main.lua"))()(mod)
assert(mod.exports.count == 100)
local byId = {}
for _, a in ipairs(mod.exports.achievements) do byId[a.id] = a end
local game = {
  data = { items = {
    HM01 = { machine = { kind = "HM", move = "CUT" } },
    TM01 = { machine = { kind = "TM", move = "MEGA_PUNCH" } },
    KEY = { keyItem = true },
  } },
  save = {
    inventory = { BOULDERBADGE = 1, HM01 = 1, KEY = 1 },
    pcItems = { TM01 = 1 },
    flags = { EVENT_GOT_POKEDEX = true },
    pokedex = { owned = { BULBASAUR = true, SNORLAX = true }, seen = { BULBASAUR = true, SNORLAX = true } },
    party = { { level = 50, moves = {1,2,3,4} } }, boxes = {}, money = 1000, coins = 0,
  },
}
local state = { unlocked = {}, stats = { catches = 0, evolutions = 0, battles = 0, wins = 0,
  trainerWins = 0, wildWins = 0, winStreak = 0, maxWinStreak = 0,
  safariCatches = 0, steps = 0, visitedMaps = {} } }
local function expect(id, current, target)
  local c, t = mod.exports.progress(byId[id], game, state)
  assert(c == current and t == target, id .. ": got " .. tostring(c) .. "/" .. tostring(t))
end
expect("journey_started", 1, 1)
expect("boulder_badge", 1, 1)
expect("boatload_fun", 1, 1)
expect("disk_collector_1", 1, 10)
expect("sleeper_awakes", 1, 1)
expect("halfway_solo", 50, 50)
print("progress engine ok")
