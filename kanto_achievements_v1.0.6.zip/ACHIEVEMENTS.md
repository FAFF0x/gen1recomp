# Achievement Catalog

1. **Journey Has Started** [STORY] — Obtain the Pokedex from Professor Oak.
2. **The United Cities of Kanto** [STORY] — Obtain the Town Map.
3. **Parting Gift** [STORY] — Own at least five Poke Balls.
4. **Rock-Solid Boulder Badge** [STORY] — Defeat the Gym Leader and obtain this Badge.
5. **Raindrop Cascade Badge** [STORY] — Defeat the Gym Leader and obtain this Badge.
6. **Sunny Thunder Badge** [STORY] — Defeat the Gym Leader and obtain this Badge.
7. **Floral Rainbow Badge** [STORY] — Defeat the Gym Leader and obtain this Badge.
8. **Heart and Soul Badge** [STORY] — Defeat the Gym Leader and obtain this Badge.
9. **Golden Marsh Badge** [STORY] — Defeat the Gym Leader and obtain this Badge.
10. **Fiery Volcano Badge** [STORY] — Defeat the Gym Leader and obtain this Badge.
11. **Feathered Earth Badge** [STORY] — Defeat the Gym Leader and obtain this Badge.
12. **Rising Trainer** [STORY] — Collect two Kanto Badges.
13. **Proven Trainer** [STORY] — Collect four Kanto Badges.
14. **Kanto Veteran** [STORY] — Collect six Kanto Badges.
15. **Badge Master** [STORY] — Collect all eight Kanto Badges.
16. **A Boatload of Fun** [STORY] — Obtain the HM containing Cut.
17. **Ghost Buster** [STORY] — Obtain the Silph Scope.
18. **GHOST!?** [STORY] — Obtain the Poke Flute after rescuing Mr. Fuji.
19. **Biggest Ball in Kanto** [STORY] — Obtain the Master Ball.
20. **Pokemon Master!** [STORY] — Defeat the Elite Four and the Champion.
21. **Flashing Lights Warning** [ITEMS] — Obtain the HM containing Flash.
22. **Prepare For Liftoff** [ITEMS] — Obtain the HM containing Fly.
23. **Too Much Water** [ITEMS] — Obtain the HM containing Surf.
24. **Performance Enhancement Disk** [ITEMS] — Obtain the HM containing Strength.
25. **HM Master** [ITEMS] — Own all five Hidden Machines.
26. **Metal Detector** [ITEMS] — Obtain the Itemfinder.
27. **I Like to Ride It** [ITEMS] — Obtain the Bicycle.
28. **Sharing Is Caring** [ITEMS] — Obtain the Exp. All.
29. **Old School Angler** [ITEMS] — Obtain the Old Rod.
30. **Better Bites** [ITEMS] — Obtain the Good Rod.
31. **Super Angler** [ITEMS] — Obtain the Super Rod.
32. **Froggy!** [ITEMS] — Own all three Fishing Rods.
33. **Only Take One** [ITEMS] — Own either the Helix Fossil or the Dome Fossil.
34. **Ancient Amber** [ITEMS] — Obtain the Old Amber.
35. **Key Collector** [ITEMS] — Own five different Key Items.
36. **Key Master** [ITEMS] — Own ten different Key Items.
37. **Disk Collector I** [ITEMS] — Own ten different TMs across the Bag and PC.
38. **Disk Collector II** [ITEMS] — Own twenty-five different TMs across the Bag and PC.
39. **Disk Collector III** [ITEMS] — Own all fifty different TMs across the Bag and PC.
40. **Walking Warehouse** [ITEMS] — Own forty different item types across the Bag and PC.
41. **First Catch** [COLLECTION] — Catch your first wild Pokemon.
42. **Rookie Collector** [COLLECTION] — Own ten different Pokemon species.
43. **Field Researcher** [COLLECTION] — See twenty-five different Pokemon species.
44. **Pokedex Scout** [COLLECTION] — See fifty different Pokemon species.
45. **Pokedex Expert** [COLLECTION] — See one hundred different Pokemon species.
46. **Pokemon Catcher** [COLLECTION] — Own twenty-five different Pokemon species.
47. **Pokemon Collector** [COLLECTION] — Own fifty different Pokemon species.
48. **Pokemon Researcher** [COLLECTION] — Own seventy-five different Pokemon species.
49. **Gotta Catch em All** [COLLECTION] — Own 124 Pokemon species available through a complete Pokemon Red journey.
50. **The Sleeper Awakens** [COLLECTION] — Own a Snorlax.
51. **Uno, Dos, Tres!** [COLLECTION] — Own Articuno, Zapdos and Moltres.
52. **The Strongest Pokemon Ever!** [COLLECTION] — Own Mewtwo.
53. **Lucky Egg** [COLLECTION] — Own Chansey.
54. **Caring Mother** [COLLECTION] — Own Kangaskhan.
55. **Bull Rush** [COLLECTION] — Own Tauros.
56. **Bug Ninja** [COLLECTION] — Own Scyther.
57. **Copycat** [COLLECTION] — Own Ditto.
58. **Dragon Tamer** [COLLECTION] — Own a member of the Dratini evolutionary line.
59. **Gift of the Sea** [COLLECTION] — Own Lapras.
60. **Virtual Prize** [COLLECTION] — Own Porygon.
61. **Enter the Dragon** [COLLECTION] — Own Hitmonlee or Hitmonchan.
62. **Fossil Revival** [COLLECTION] — Own a revived fossil Pokemon.
63. **Stone-Cold Evolution** [COLLECTION] — Own Vaporeon, Jolteon or Flareon.
64. **Starter Graduate** [COLLECTION] — Own Venusaur, Charizard or Blastoise.
65. **Box Keeper** [COLLECTION] — Store at least twenty Pokemon in the PC boxes.
66. **Preparing to Be the Very Best** [TRAINING] — Form a full party of six Pokemon.
67. **Fresh Talent** [TRAINING] — Raise a Pokemon to level 10.
68. **Rising Star** [TRAINING] — Raise a Pokemon to level 25.
69. **Halfway Solo** [TRAINING] — Raise a Pokemon to level 50.
70. **Veteran Pokemon** [TRAINING] — Raise a Pokemon to level 75.
71. **Peak Performance** [TRAINING] — Raise a Pokemon to level 100.
72. **Halfway Party** [TRAINING] — Have six Pokemon at level 50 or higher in the party.
73. **Elite Squad** [TRAINING] — Have six Pokemon at level 60 or higher in the party.
74. **Four-Move Wonder** [TRAINING] — Have a Pokemon that knows four moves.
75. **Complete Movesets** [TRAINING] — Have six party Pokemon that each know four moves.
76. **Evolution Begins** [TRAINING] — Evolve one Pokemon after installing this mod.
77. **Evolution Expert** [TRAINING] — Evolve five Pokemon after installing this mod.
78. **Evolution Master** [TRAINING] — Evolve fifteen Pokemon after installing this mod.
79. **Combined Strength** [TRAINING] — Reach a combined party level of 200.
80. **Elite Combined Strength** [TRAINING] — Reach a combined party level of 300.
81. **First Victory** [BATTLE] — Win your first battle after installing this mod.
82. **Battle Tested** [BATTLE] — Win ten battles.
83. **Veteran Fighter** [BATTLE] — Win fifty battles.
84. **Century Club** [BATTLE] — Win one hundred battles.
85. **Kanto Warrior** [BATTLE] — Win two hundred and fifty battles.
86. **Trainer Hunter** [BATTLE] — Win ten Trainer battles.
87. **Trainer Ace** [BATTLE] — Win fifty Trainer battles.
88. **Wild Hunter** [BATTLE] — Win twenty-five wild battles.
89. **Wild Master** [BATTLE] — Win one hundred wild battles.
90. **Unbroken** [BATTLE] — Reach a win streak of ten battles.
91. **Battle Marathon** [BATTLE] — Complete one hundred battles.
92. **Safari Regular** [BATTLE] — Catch ten Pokemon during Safari battles.
93. **First Steps** [EXPLORATION] — Walk one hundred map steps after installing this mod.
94. **Road Trip** [EXPLORATION] — Walk one thousand map steps.
95. **Long Haul** [EXPLORATION] — Walk five thousand map steps.
96. **Kanto Walker** [EXPLORATION] — Walk ten thousand map steps.
97. **Explorer** [EXPLORATION] — Visit ten different maps after installing this mod.
98. **Cartographer** [EXPLORATION] — Visit twenty-five different maps after installing this mod.
99. **So Rich...** [EXPLORATION] — Hold 9,999 Game Corner coins at once.
100. **Kanto Millionaire** [EXPLORATION] — Hold 999,999 money at once.
