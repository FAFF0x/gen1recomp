# Kanto Achievements

Adds an **ACHIEVEMENTS** entry to the START menu with 100 obtainable goals for a Pokemon Red playthrough.

## Interface

The screen is intentionally linear and low-density:

1. `ALL / INCOMP / DONE` status tabs.
2. A selectable `SEARCH` field.
3. A selectable `FILTER` field.
4. Three achievement rows per page.
5. A separate detail page.

### Controls

- Left / Right: choose ALL, INCOMPLETE or DONE.
- Up / Down: move the solid arrow between Search, Category and achievements.
- A: open the row marked by the arrow.
- B: return.

START and SELECT remain optional shortcuts for Search and Filter, but they are no longer required for navigation.

## Tracking

Progress is stored inside the save. Story, badges, items, Pokedex, party levels, money and current inventory are retroactive. Battles, evolutions, steps, maps visited and Safari catches begin counting after the mod is installed.

The first synchronization is silent so an existing save is not flooded with notifications. Future unlocks display a compact achievement banner.

## Categories

- Story
- Items
- Collection
- Training
- Battle
- Exploration

## Compatibility

The mod inserts its START-menu entry through `ui.start_menu.items` and registers its own screens without replacing the standard START menu. It does not modify Pokemon stats, encounters, story flags or battle rules.

### Gen1 Modern UI

Kanto Achievements v1.0.6 publishes the official `gen1ModernUi` compatibility contract (`apiVersion = 1`). When **Gen1 Modern UI 0.8.1 or newer** is enabled, the Achievements journal is presented using the active Modern UI theme, frame, density, scaling and pointer/click controls while Kanto Achievements continues to own all navigation, filters, search callbacks and save data.

Modern UI is optional. If it is missing or disabled, the original 160x144 Kanto Achievements interface is used automatically.

## Navigation update (v1.0.5)

The screen opens directly on the first achievement. The current ALL, INCOMP or DONE view is now shown with a bright gold fill, double black outline and downward pointer. A solid black triangle and yellow row identify the active Search, Category or achievement selection. Progress in the list is displayed as a compact percentage, while exact values remain on the detail page.

## Modern UI update (v1.0.6)

The main Achievements screen now has a responsive Modern UI presentation with the current ALL/INCOMP/DONE tab in the title, Search and Category as live rows, achievement completion/progress values, and a responsive detail page. Keyboard/controller behavior remains unchanged, while Modern UI can also provide its desktop pointer controls. Unlock banners remain lightweight native overlays so they do not replace the overworld presentation.
