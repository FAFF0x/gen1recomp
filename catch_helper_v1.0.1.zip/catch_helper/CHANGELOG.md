# Changelog

## 1.0.1
- Changed the owned-Pokémon marker to a colored Poké Ball with a red top half, white bottom half, and black outline.

## 1.0.0
- First release.
