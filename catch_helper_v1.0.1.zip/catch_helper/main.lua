-- Catch Helper for Gen1Recomp
-- Draw-only QoL mod. It does not alter capture rolls, inventory, AI or saves.

local STOCK_BALLS = {
  MASTER_BALL = { randMax = 0, autoCatch = true },
  POKE_BALL   = { randMax = 255, hpFactor = 12 },
  GREAT_BALL  = { randMax = 200, hpFactor = 8 },
  ULTRA_BALL  = { randMax = 150, hpFactor = 12 },
  SAFARI_BALL = { randMax = 150, hpFactor = 12 },
}

local STOCK_STATUS_BONUS = {
  SLP = 25,
  FRZ = 25,
  PSN = 12,
  BRN = 12,
  PAR = 12,
}

local function clamp(value, low, high)
  value = tonumber(value) or low
  if value < low then return low end
  if value > high then return high end
  return value
end

local function mergedBallDef(battle, ballId)
  local balls = battle and battle.data and battle.data.balls
  return (balls and balls[ballId]) or STOCK_BALLS[ballId]
end

local function statusBonus(battle, statusId)
  if not statusId then return 0 end
  local statuses = battle and battle.data and battle.data.statuses
  local record = statuses and statuses[statusId]
  if record and record.catchBonus ~= nil then
    return math.max(0, tonumber(record.catchBonus) or 0)
  end
  return STOCK_STATUS_BONUS[statusId] or 0
end

-- Exact probability of the stock Gen 1 ItemUseBall checks.
-- The engine rolls inclusively: rng(0, randMax), then rng(0, 255).
local function catchProbability(battle, ballId)
  if not battle or not battle.enemy or not battle.enemy.mon then return nil end
  local mon = battle.enemy.mon
  local targetDef = battle.enemy.def
    or (battle.data and battle.data.pokemon and battle.data.pokemon[mon.species])
  if not targetDef then return nil end

  local ball = mergedBallDef(battle, ballId)
  if not ball then return nil end
  -- A custom attempt function can replace the complete formula, so displaying
  -- the stock result would be misleading.
  if ball.attempt then return nil end
  if ball.autoCatch then return 1 end

  local randMax = math.max(0, math.floor(tonumber(ball.randMax) or 255))
  local factor = math.max(1, tonumber(ball.hpFactor) or 12)
  local rate = battle.safari and battle.safariCatchRate or targetDef.catchRate
  rate = math.max(0, tonumber(rate) or 0)

  local maxHP = math.max(1, tonumber(mon.stats and mon.stats.hp) or 1)
  local hp = clamp(mon.hp, 1, maxHP)
  local hpQuarter = math.max(1, math.floor(hp / 4))
  local f = math.min(255,
    math.floor(math.floor(maxHP * 255 / factor) / hpQuarter))

  local bonus = statusBonus(battle, mon.status)
  local outcomes = randMax + 1

  -- q < bonus catches immediately after the status subtraction.
  local autoCount = math.min(outcomes, math.max(0, math.floor(bonus)))

  -- bonus <= q <= rate + bonus reaches the second 0..255 HP roll.
  local lower = math.max(0, math.floor(bonus))
  local upper = math.min(randMax, math.floor(rate + bonus))
  local secondCount = math.max(0, upper - lower + 1)
  local secondChance = (f + 1) / 256

  return clamp((autoCount + secondCount * secondChance) / outcomes, 0, 1)
end

local function percent(probability)
  if probability == nil then return "--" end
  return tostring(math.floor(probability * 100 + 0.5))
end

local function isOwned(battle)
  local save = battle and battle.game and battle.game.save
  local owned = save and save.pokedex and save.pokedex.owned
  local species = battle and battle.enemy and battle.enemy.mon
    and battle.enemy.mon.species
  return owned and species and owned[species] == true or false
end

local function enemyHudVisible(battle)
  if not battle or not battle.enemy then return false end
  if battle.showEnemyTrainer or battle.enemySendingOut or battle.introBalls then
    return false
  end
  if battle.enemy.fainted or (battle.introSlide or 0) ~= 0 then return false end
  if battle.growInScale and battle:growInScale(battle.enemy) then return false end
  return true
end

-- Tiny colored Poké Ball marker:
-- K = black outline / center band, R = red upper half, W = white lower half.
local BALL_PIXELS = {
  "..KKKK..",
  ".KRRRRK.",
  "KRRRRRRK",
  "KKKWWKKK",
  "KWWWWWWK",
  ".KWWWWK.",
  "..KKKK..",
}

local BALL_COLORS = {
  K = { 0, 0, 0, 1 },
  R = { 0.85, 0.12, 0.12, 1 },
  W = { 1, 1, 1, 1 },
}

local function drawOwnedBall(g, x, y)
  for row, pixels in ipairs(BALL_PIXELS) do
    for col = 1, #pixels do
      local code = pixels:sub(col, col)
      local color = BALL_COLORS[code]
      if color then
        g.setColor(color)
        g.rectangle("fill", x + col - 1, y + row - 1, 1, 1)
      end
    end
  end
  -- Small black center dot to keep the button recognizable at 1x scale.
  g.setColor(0, 0, 0, 1)
  g.rectangle("fill", x + 4, y + 3, 1, 1)
end

local function classicNameX(Font, name)
  local count = #Font.split(name or "")
  return 8 + (count <= 2 and 16 or count <= 4 and 8 or 0)
end

local function drawOwnedIndicator(mod, battle, g)
  if not isOwned(battle) then return end
  local Font = mod.ui.Font
  local wide = battle.wideLayout and battle:wideLayout()
  local x, y

  if wide then
    -- WideBattle's enemy status panel is 128 px wide. Place the marker directly
    -- beside its name panel so it never collides with the level field.
    x, y = 130, 9
  else
    local name = battle.enemy.name or ""
    local nameX = classicNameX(Font, name)
    local after = nameX + Font.width(name) + 1
    -- Very long names fill the HUD row; in that case put the ball before them.
    x = after <= 89 and after or math.max(0, nameX - 7)
    y = 1
  end

  drawOwnedBall(g, math.floor(x), math.floor(y))
end

local function isCatchableWildBattle(battle)
  if not battle or battle.demo then return false end
  if battle.safari then return true end
  return battle.kind == "wild"
end

local function drawCatchLine(mod, battle)
  if not isCatchableWildBattle(battle) then return end
  local Font = mod.ui.Font
  local wide = battle.wideLayout and battle:wideLayout()
  local line

  if battle.safari then
    line = ("S%s%%"):format(percent(catchProbability(battle, "SAFARI_BALL")))
  else
    local p = percent(catchProbability(battle, "POKE_BALL"))
    local gr = percent(catchProbability(battle, "GREAT_BALL"))
    local u = percent(catchProbability(battle, "ULTRA_BALL"))
    -- Classic has only 96 clear pixels between the HUD and the enemy sprite.
    -- Removing spaces keeps even P100G100U100 inside that strip.
    line = wide and ("P%s G%s U%s"):format(p, gr, u)
      or ("P%sG%sU%s"):format(p, gr, u)
  end

  -- This row is immediately below the enemy HUD and above the player's back
  -- sprite in both layouts, so no battle menu or HP information is covered.
  Font.draw(line, wide and 8 or 0, 32)
end

local function drawOverlay(mod, battle)
  if not enemyHudVisible(battle) then return end
  local g = love and love.graphics
  local Font = mod.ui.Font
  if not g or not Font then return end

  local oldR, oldG, oldB, oldA = g.getColor()
  local oldScissor
  if g.getScissor then oldScissor = { g.getScissor() } end
  if g.setScissor then g.setScissor() end

  g.setColor(0, 0, 0, 1)
  drawOwnedIndicator(mod, battle, g)
  g.setColor(0, 0, 0, 1)
  drawCatchLine(mod, battle)

  if g.setScissor then
    if oldScissor and oldScissor[1] ~= nil then
      g.setScissor(oldScissor[1], oldScissor[2], oldScissor[3], oldScissor[4])
    else
      g.setScissor()
    end
  end
  g.setColor(oldR, oldG, oldB, oldA)
end

return function(mod)
  mod.exports.catchProbability = catchProbability
  mod.exports.isOwned = isOwned

  mod.hooks:wrap("battle.overlay", function(next, battle)
    next(battle)
    drawOverlay(mod, battle)
  end, 220)

  mod.log:info("Catch Helper loaded")
end
