# Catch Helper

Mod QoL per Gen1Recomp.

## Funzioni

- Mostra la probabilità di cattura corrente nelle lotte selvatiche:
  - `P` = Poké Ball
  - `G` = Great Ball
  - `U` = Ultra Ball
  - `S` = Safari Ball
- Usa PS attuali, stato alterato, catch rate della specie e parametri della Ball.
- Disegna una piccola Poké Ball accanto al nome del Pokémon avversario quando la specie risulta già posseduta nel Pokédex.
- L'indicatore compare anche nelle lotte contro Allenatori; le percentuali compaiono soltanto negli incontri catturabili.
- Non cambia i tiri di cattura né il salvataggio.

Esempio classico: `P18G27U36` indica rispettivamente 18%, 27% e 36%. Nel layout wide vengono aggiunti degli spazi.

## Installazione

Importa lo ZIP dalla scheda MODS, assicurati che Catch Helper sia attiva, chiudi completamente Gen1Recomp e riaprilo.

## Compatibilità

API 2. Supporta layout classico e wide. Se un'altra mod sostituisce completamente la formula di una Ball con una funzione personalizzata, la relativa probabilità viene mostrata come `--` invece di fornire un valore errato.
