-- Item Shortcut for Gen1Recomp
-- Opens a five-slot field item launcher with the controller R1 button.

local PATCH_KEY = "__item_shortcut_r1_dispatch_v1"
local BAG_MENU_PATCH_KEY = "__item_shortcut_bag_assign_dispatch_v1"
local STATE_MARK = "__itemShortcutState"
local SLOT_COUNT = 5
local SAVE_KEY = "slots"

-- Capture the original BagMenu constructor before UI overhaul mods decorate it.
-- The hidden list is used only as a dispatcher so every item follows the game's
-- existing USE path, including target pickers, field checks and messages.
local BaseBagMenuNew
local Bag
local ListMenu
local Menu
local TextBox
local Font

do
  local ok, module = pcall(require, "src.ui.BagMenu")
  if ok and type(module) == "table" and type(module.new) == "function" then
    BaseBagMenuNew = module.new
  end
  ok, module = pcall(require, "src.inventory.Bag")
  if ok and type(module) == "table" then Bag = module end
  ok, module = pcall(require, "src.ui.ListMenu")
  if ok and type(module) == "table" then ListMenu = module end
  ok, module = pcall(require, "src.ui.Menu")
  if ok and type(module) == "table" then Menu = module end
  ok, module = pcall(require, "src.render.TextBox")
  if ok and type(module) == "table" then TextBox = module end
  ok, module = pcall(require, "src.render.Font")
  if ok and type(module) == "table" then Font = module end
end

local function mark(state)
  if type(state) == "table" then state[STATE_MARK] = true end
  return state
end

local function copySlots(source)
  local out = {}
  if type(source) ~= "table" then return out end
  for i = 1, SLOT_COUNT do
    if type(source[i]) == "string" and source[i] ~= "" then
      out[i] = source[i]
    end
  end
  return out
end

local function slotsFor(mod)
  local slots = copySlots(mod.save:get(SAVE_KEY))
  mod.save:set(SAVE_KEY, slots)
  return slots
end

local function persistSlots(mod, slots)
  mod.save:set(SAVE_KEY, copySlots(slots))
end

local function countOf(game, id)
  local inventory = game and game.save and game.save.inventory
  local value = inventory and inventory[id]
  if value == true then return 1 end
  value = math.floor(tonumber(value) or 0)
  return math.max(0, value)
end

local function itemName(game, id)
  local def = game and game.data and game.data.items and game.data.items[id]
  return (def and def.name) or id or "EMPTY"
end

local function compact(text, limit)
  text = tostring(text or "")
  if Font and type(Font.split) == "function" then
    local spans = Font.split(text)
    if #spans <= limit then return text end
    if limit <= 1 then return "." end
    local last = spans[limit - 1] and spans[limit - 1].to
    if last then return text:sub(1, last) .. "." end
  end
  if #text <= limit then return text end
  if limit <= 1 then return text:sub(1, limit) end
  return text:sub(1, limit - 1) .. "."
end

local function showMessage(game, text)
  if TextBox and type(TextBox.new) == "function"
      and game and game.stack and type(game.stack.push) == "function" then
    game.stack:push(TextBox.new(game, text))
    return true
  end
  return false
end

local function bagOrder(game)
  if Bag and type(Bag.order) == "function" then
    local ok, order = pcall(Bag.order, game.save)
    if ok and type(order) == "table" then return order end
  end
  local out = {}
  local inventory = game and game.save and game.save.inventory or {}
  for id, value in pairs(inventory) do
    if countOf(game, id) > 0 and not tostring(id):find("BADGE", 1, true) then
      out[#out + 1] = id
    end
  end
  table.sort(out)
  return out
end

local function buildSlotRows(game, slots)
  local rows = {}
  for i = 1, SLOT_COUNT do
    local id = slots[i]
    local count = id and countOf(game, id) or 0
    local right = count > 1 and ("x" .. tostring(count)) or nil
    local maxName = right and 9 or 14
    local name
    if not id then
      name = "EMPTY"
    elseif count <= 0 then
      name = "MISSING"
    else
      name = compact(itemName(game, id), maxName)
    end
    rows[i] = {
      label = tostring(i) .. ". " .. name,
      right = right,
      value = i,
    }
  end
  return rows
end

local function refreshShortcutList(list, game, slots, index)
  if not list then return end
  list.items = buildSlotRows(game, slots)
  list.index = math.max(1, math.min(index or list.index or 1, SLOT_COUNT))
  list.scroll = 0
end

local function removeShortcutStates(game)
  local removed = false
  local stack = game and game.stack
  if not stack or type(stack.top) ~= "function" or type(stack.pop) ~= "function" then
    return false
  end
  while true do
    local top = stack:top()
    if type(top) ~= "table" or not top[STATE_MARK] then break end
    stack:pop()
    removed = true
  end
  return removed
end

local function makeEphemeralBag(game)
  if type(BaseBagMenuNew) ~= "function" then return nil, "BagMenu is unavailable." end
  local ok, list = pcall(BaseBagMenuNew, game, {})
  if not ok or type(list) ~= "table" then
    return nil, "The standard Bag could not be opened."
  end

  local baseUpdate = list.update
  if type(baseUpdate) == "function" then
    function list:update(dt)
      -- The standard Bag intentionally stays open after some field items
      -- (Town Map, Itemfinder and refusal messages). A shortcut should return
      -- directly to the field, so remove this hidden dispatcher when control
      -- comes back to it.
      if self.game and self.game.stack and self.game.stack:top() == self then
        self.game.stack:pop()
        return
      end
      return baseUpdate(self, dt)
    end
  end
  return list
end

local function findBagRow(list, id)
  for _, row in ipairs(list and list.items or {}) do
    if row.value == id then return row end
  end
  return nil
end

local function useThroughStandardBag(mod, game, id)
  if not id or countOf(game, id) <= 0 then
    showMessage(game, "That item is no longer\nin the Bag.")
    return false
  end

  local list, err = makeEphemeralBag(game)
  if not list then
    mod.log:warn("Item Shortcut could not use %s: %s", tostring(id), tostring(err))
    showMessage(game, "The item shortcut\ncould not open the Bag.")
    return false
  end

  local row = findBagRow(list, id)
  if not row or type(list.onChoose) ~= "function" then
    mod.log:warn("Item Shortcut could not find %s in the standard Bag list", tostring(id))
    showMessage(game, "That item cannot be\nused from this shortcut.")
    return false
  end

  game.stack:push(list)
  local ok, chooseErr = pcall(list.onChoose, row, list)
  if not ok then
    if game.stack:top() == list then game.stack:pop() end
    mod.log:warn("Item Shortcut failed while opening USE for %s: %s",
      tostring(id), tostring(chooseErr))
    showMessage(game, "The item could not\nbe used.")
    return false
  end

  -- Out of battle, BagMenu opens the standard USE/TOSS menu. Reproduce the
  -- menu's normal A behavior on the first row (USE): pop the submenu first,
  -- then run its callback. This preserves the original item's complete flow.
  local actionMenu = game.stack:top()
  local useEntry = actionMenu and actionMenu.items and actionMenu.items[1]
  if actionMenu == list or type(useEntry) ~= "table"
      or type(useEntry.onSelect) ~= "function" then
    if game.stack:top() == list then game.stack:pop() end
    mod.log:warn("Item Shortcut did not receive a USE action for %s", tostring(id))
    showMessage(game, "That item cannot be\nused from this shortcut.")
    return false
  end

  game.stack:pop()
  local used, useErr = pcall(useEntry.onSelect)
  if not used then
    if game.stack:top() == list then game.stack:pop() end
    mod.log:warn("Item Shortcut failed while using %s: %s",
      tostring(id), tostring(useErr))
    showMessage(game, "The item could not\nbe used.")
    return false
  end
  return true
end

local function assignItem(mod, slots, slotIndex, itemId)
  -- A single Bag item owns at most one shortcut slot. Reassigning it moves
  -- the item instead of creating duplicate entries in the quick menu.
  for i = 1, SLOT_COUNT do
    if slots[i] == itemId then slots[i] = nil end
  end
  slots[slotIndex] = itemId
  persistSlots(mod, slots)
end

local function buildAssignmentRows(game, slots, itemId)
  local rows = {}
  for i = 1, SLOT_COUNT do
    local assigned = slots[i]
    local name = assigned and compact(itemName(game, assigned), 13) or "EMPTY"
    rows[i] = {
      label = tostring(i) .. ". " .. name,
      right = assigned == itemId and "SET" or nil,
      value = i,
    }
  end
  return rows
end

local function openBagAssignment(mod, game, itemId)
  if not (ListMenu and game and game.stack and itemId) then return false end
  if countOf(game, itemId) <= 0 then
    showMessage(game, "That item is no longer\nin the Bag.")
    return false
  end

  local slots = slotsFor(mod)
  local picker
  picker = mark(ListMenu.new(game, "CHOOSE SLOT", buildAssignmentRows(game, slots, itemId), {
    onChoose = function(row, list)
      assignItem(mod, slots, row.value, itemId)
      list:close()
      showMessage(game, ("Assigned %s\nto shortcut %d.")
        :format(itemName(game, itemId), row.value))
    end,
  }))
  game.stack:push(picker)
  return true
end

local function isUseTossMenu(state)
  if type(state) ~= "table" or type(state.items) ~= "table" then return false end
  local first, second = state.items[1], state.items[2]
  -- Detect the Bag action menu by behavior rather than translated labels.
  -- The normal out-of-battle Bag always creates two callable actions first.
  return type(first) == "table" and type(first.onSelect) == "function"
     and type(second) == "table" and type(second.onSelect) == "function"
end

local function addAssignmentAction(mod, game, actionMenu, itemId)
  if not isUseTossMenu(actionMenu) then return false end
  for _, entry in ipairs(actionMenu.items) do
    if tostring(entry.label or "") == "ASSIGN SHORTCUT" then return true end
  end

  actionMenu.items[#actionMenu.items + 1] = {
    label = "ASSIGN SHORTCUT",
    onSelect = function()
      openBagAssignment(mod, game, itemId)
    end,
  }

  -- The vanilla USE/TOSS box is sized for two rows. Grow it to three rows
  -- and widen it for the new label while keeping the entire box on-screen.
  actionMenu.rowStep = actionMenu.rowStep or 2
  actionMenu.tw = math.max(actionMenu.tw or 7, 18)
  actionMenu.tx = math.max(0, 20 - actionMenu.tw)
  local neededHeight = #actionMenu.items * actionMenu.rowStep + 2
  actionMenu.th = math.max(actionMenu.th or 0, neededHeight)
  actionMenu.ty = math.max(0, math.min(actionMenu.ty or 0, 18 - actionMenu.th))
  if type(actionMenu.clampScroll) == "function" then actionMenu:clampScroll() end
  return true
end

local function decorateBagForAssignment(mod, game, opts, list)
  if type(list) ~= "table" or list.__itemShortcutBagDecorated then return list end
  if opts and opts.battle then return list end
  if type(list.onChoose) ~= "function" then return list end

  list.__itemShortcutBagDecorated = true
  local baseChoose = list.onChoose
  list.onChoose = function(item, currentList)
    baseChoose(item, currentList)
    if type(item) ~= "table" or type(item.value) ~= "string" then return end
    local top = game and game.stack and game.stack:top()
    if top and top ~= currentList then
      addAssignmentAction(mod, game, top, item.value)
    end
  end
  return list
end

local function installBagAssignment(mod, game)
  local ok, BagMenu = pcall(require, "src.ui.BagMenu")
  if not ok or type(BagMenu) ~= "table" or type(BagMenu.new) ~= "function" then
    mod.log:warn("Item Shortcut could not add ASSIGN SHORTCUT to the Bag")
    return false
  end

  local dispatch = rawget(_G, BAG_MENU_PATCH_KEY)
  if type(dispatch) ~= "table" then
    dispatch = { baseNew = BagMenu.new, decorator = nil }
    dispatch.wrapper = function(currentGame, opts)
      local list = dispatch.baseNew(currentGame, opts)
      local decorator = dispatch.decorator
      if decorator then return decorator(currentGame, opts, list) end
      return list
    end
    rawset(_G, BAG_MENU_PATCH_KEY, dispatch)
    BagMenu.new = dispatch.wrapper
  elseif BagMenu.new ~= dispatch.wrapper then
    dispatch.baseNew = BagMenu.new
    BagMenu.new = dispatch.wrapper
  end

  dispatch.decorator = function(currentGame, opts, list)
    return decorateBagForAssignment(mod, currentGame, opts, list)
  end
  return true
end

local function openSlotContext(mod, game, quickList, slots, slotIndex)
  local id = slots[slotIndex]
  if not id then
    showMessage(game, "Open the Bag and choose\nASSIGN SHORTCUT.")
    return
  end

  local entries = {
    {
      label = "USE",
      onSelect = function()
        quickList:close()
        useThroughStandardBag(mod, game, id)
      end,
    },
    {
      label = "CLEAR",
      onSelect = function()
        slots[slotIndex] = nil
        persistSlots(mod, slots)
        refreshShortcutList(quickList, game, slots, slotIndex)
      end,
    },
  }

  local context = mark(Menu.new(game, entries, {
    tx = 9, ty = 3, tw = 11,
  }))
  game.stack:push(context)
end

local function openShortcutMenu(mod, game)
  if not (ListMenu and Menu and game and game.stack and game.save) then
    mod.log:warn("Item Shortcut could not open: required UI services are unavailable")
    return false
  end

  local slots = slotsFor(mod)
  local quick
  quick = mark(ListMenu.new(game, "ITEM SHORTCUT", buildSlotRows(game, slots), {
    footer = "R1 CLOSE",
    onChoose = function(row)
      openSlotContext(mod, game, quick, slots, row.value)
    end,
  }))
  game.stack:push(quick)
  return true
end

local function runnerBusy(overworld)
  local runner = overworld and overworld.runner
  if runner and type(runner.isRunning) == "function" then
    local ok, busy = pcall(runner.isRunning, runner)
    if ok and busy then return true end
  end
  return false
end

local function canOpen(game)
  local stack = game and game.stack
  local overworld = game and game.overworld
  if not stack or not overworld or type(stack.top) ~= "function" then return false end
  if stack:top() ~= overworld then return false end
  if not (game.save and game.save.inventory) then return false end
  if overworld.player and overworld.player.moving then return false end
  if overworld.engaging or overworld.emote then return false end
  if overworld.fishing or overworld.warping or overworld.teleporting then return false end
  if runnerBusy(overworld) then return false end
  return true
end

local function noteGamepad(game)
  local touch = game and game.touchControls
  if touch and type(touch.noteGamepad) == "function" then
    pcall(touch.noteGamepad, touch)
  end
end

local function playOpenSound(game)
  local ok, Sound = pcall(require, "src.core.Sound")
  if ok and Sound and type(Sound.play) == "function" and game and game.data then
    pcall(Sound.play, game.data, "Start_Menu")
  end
end

local function handleR1(mod, game, button)
  if button ~= "rightshoulder" then return false end
  noteGamepad(game)
  if removeShortcutStates(game) then return true end
  if not canOpen(game) then return false end
  playOpenSound(game)
  return openShortcutMenu(mod, game)
end

local function installR1Handler(mod, game)
  if not game or type(game.gamepadpressed) ~= "function" then
    mod.log:warn("Item Shortcut could not install R1 input; restart on a compatible game build")
    return false
  end

  local dispatch = rawget(_G, PATCH_KEY)
  if type(dispatch) ~= "table" then
    dispatch = {
      base = game.gamepadpressed,
      handler = nil,
      log = nil,
    }
    dispatch.wrapper = function(self, joystick, button)
      local handler = dispatch.handler
      if handler then
        local ok, consumed = pcall(handler, self, joystick, button)
        if not ok then
          if dispatch.log and dispatch.log.warn then
            dispatch.log:warn("Item Shortcut R1 handler failed: %s", tostring(consumed))
          end
        elseif consumed then
          return
        end
      end
      if dispatch.base then return dispatch.base(self, joystick, button) end
    end
    rawset(_G, PATCH_KEY, dispatch)
    game.gamepadpressed = dispatch.wrapper
  elseif game.gamepadpressed ~= dispatch.wrapper then
    dispatch.base = game.gamepadpressed
    game.gamepadpressed = dispatch.wrapper
  end

  dispatch.log = mod.log
  dispatch.handler = function(currentGame, _, button)
    return handleR1(mod, currentGame, button)
  end
  return true
end

return function(mod)
  mod.events:on("game.ready", function(event)
    local game = event and event.game
    local inputOk = installR1Handler(mod, game)
    local bagOk = installBagAssignment(mod, game)
    if inputOk and bagOk then
      mod.log:info("Item Shortcut installed: assign from the Bag, use with R1")
    end
  end)

  mod.exports.open = function(game)
    if not canOpen(game) then return false end
    return openShortcutMenu(mod, game)
  end
  mod.exports.getSlots = function()
    return copySlots(slotsFor(mod))
  end
  mod.exports.assign = function(slot, itemId)
    slot = math.floor(tonumber(slot) or 0)
    if slot < 1 or slot > SLOT_COUNT then return false end
    local slots = slotsFor(mod)
    slots[slot] = type(itemId) == "string" and itemId or nil
    persistSlots(mod, slots)
    return true
  end
  mod.exports.clear = function(slot)
    return mod.exports.assign(slot, nil)
  end
end
