# Changelog

## [1.1.0] - 2026-08-02

### Changed

- Item assignment now starts directly from the normal Bag.
- Added **ASSIGN SHORTCUT** to the Bag item action menu.
- The R1 shortcut menu now contains only **USE** and **CLEAR** for assigned items.
- Assigning an already-saved item moves it instead of creating duplicate shortcuts.
- Empty shortcut slots now direct the player to the Bag.

## [1.0.0] - 2026-08-01

### Added

- R1 / Right Shoulder shortcut menu in the overworld.
- Five persistent item slots per save file.
- Assign, use, change, and clear actions.
- Standard Bag item execution for field items, medicine, machines, and other inventory entries.
- Compatibility path for Modern Bag and other Bag presentation mods.
- Missing-item detection for consumed, deposited, or removed entries.
