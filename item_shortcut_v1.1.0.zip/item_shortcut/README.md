# Item Shortcut

Item Shortcut adds five persistent field-item shortcuts to Gen1Recomp.

## Assigning items from the Bag

1. Open the normal **Bag**.
2. Select the item you want to save.
3. Choose **ASSIGN SHORTCUT** below **USE** and **TOSS**.
4. Choose one of the five shortcut slots.

Assigning an item to an occupied slot replaces the previous item. Assigning an item that is already saved moves it to the selected slot, so the same item is never duplicated across multiple shortcuts.

## Using shortcuts

Press **R1 / Right Shoulder** while standing still in the overworld.

The shortcut screen contains five saved slots:

- Select an assigned slot and choose **USE** or **CLEAR**.
- Select an empty slot to see a reminder to assign an item from the Bag.
- Press **R1** again while a shortcut screen is open to close it.

Assignments are stored separately in each save file.

## Item behavior

Shortcut items use the normal Bag execution path. This preserves the original rules and screens for:

- Bicycle
- Town Map
- Old Rod, Good Rod, and Super Rod
- Itemfinder and Poké Flute
- Medicine and evolution stones
- TMs and HMs
- Escape Rope and other field items

An item that has been consumed, deposited, or removed remains assigned but is marked **MISSING** until the slot is cleared or the item is obtained again.

## Compatibility

The Bag action is added after the normal Bag or a compatible visual Bag overhaul creates its item menu. Item Shortcut remains compatible with Modern Bag and continues to use current item effects from other installed mods.

The R1 menu opens only when the overworld is the active screen, the player is standing still, and no scripted sequence is running.

## Installation

1. Extract the `item_shortcut` folder into the Gen1Recomp `mods` directory.
2. Enable **Item Shortcut** in the mod manager.
3. Restart Gen1Recomp.
