# Changelog

## 1.3.0
- Integrated a native modern EXP bar directly under the player's battle HUD.
- Added `battle.exp_gained` tracking; battle logic remains source-owned.
- EXP progress uses the engine Growth tables and each species' live growth rate.
- Battle start/switch-in snap to current EXP; only EXP awards animate.
- Added Gen 2-style fill-to-100-and-wrap behavior on level-up.
- Added support for multiple level-up wraps in one EXP award.
- Added temporary `+XXX EXP` feedback with a subtle pulse.
- Level-cap Pokémon render a full bar with `MAX`.
- Added THEME ACCENT / GEN 2 BLUE / HP MATCH EXP styles.
- Added GEN 2 right-to-left and MODERN left-to-right fill directions.
- Added PLAYER EXP BAR and EXP GAIN AMOUNT toggles.
- Adjusted battle-log spacing so the new EXP strip does not overlap it on short viewports.
- Added `getExpHudState()` export for diagnostics.
- Declared `jj_exp_bar` as a conflict because its functionality is now integrated.

## 1.2.4
- Replaced `battle.shown` parsing with `BattleState:visibleText()` for live battle text.
- Uses each `battle.current` queue object as an event identity, fixing repeated identical log lines every frame.
- Keeps repeated identical move text on later turns as legitimate new events.
- BATTLE LOG now shows the last three distinct events.
- Added a dedicated battle-Bag DESCRIPTION card on the right side.
- Reads description/help/flavor fields from live item definitions first.
- Added stock Gen1 fallback descriptions for medicine, Balls, battle items, PP items, stones, Repels and common field/key items.
- TM/HM descriptions now include move type, power, accuracy and PP.
- No Pokémon/item icon assets are bundled.

## 1.2.3
- Restores battle chronology text that could disappear after v1.2.x replaced the native bottom battle layer.
- Reads the BattleState's live `shown` text window before falling back to queue/message fields.
- Keeps up to 8 unique messages per battle instead of clearing the cache every time the command menu returns.
- Shows recent context above the current message during attack/effect text.
- Adds a compact BATTLE LOG above FIGHT/BAG/POKEMON/RUN after a turn.
- Keeps source text hidden only when the modern UI has source text/history to replace it.
- Retains v1.2.2 FIGHT effectiveness badges and v1.2.1 live icon-mod compatibility.

## 1.2.2
- Added live move-effectiveness badges directly to every FIGHT move card.
- Shows SUPER x4 / SUPER x2 / NORMAL x1 / RESIST x0.5 / RESIST x0.25 / NO EFFECT.
- Matchups are evaluated against the current enemy Pokémon's live types.
- Added the same matchup badge to the selected move's TYPE/POWER/ACC/PP detail strip.
- Keeps the existing Party sidebar coverage preview and external icon-mod compatibility.
- Does not change battle damage, move execution or targeting logic.

## 1.2.1
- Removed all copied NEW ICONS / NEW ITEM ICONS assets from MODERN BATTLE UI.
- Added optional dependencies on `new_icons` and `new_item_icons`.
- Pokémon icons now come exclusively from the live `game.data.icons.bySpecies` registry.
- Item icons now come exclusively from live item `image` / `icon` / `itemSprite` fields.
- Resolves virtual mod asset paths through `src.render.Assets.resolve()` before image loading.
- Fixed a v1.2.0 runtime crash in Party coverage analysis caused by calling a later-declared local function outside its lexical scope.
- Keeps the modern Party detail sidebar and Summary overlay without owning external art assets.

## 1.2.0
- Bundled the runtime Pokémon icon sheets from NEW ICONS into MODERN BATTLE UI.
- Bundled the item icon set from NEW ITEM ICONS into MODERN BATTLE UI.
- Battle Party rows now render species icons instead of the generic placeholder icon.
- Battle Bag rows now render item artwork instead of text-only rows.
- Added TM/HM type-icon support in the Bag detail panel.
- Rebuilt the Party layout into a compact list + persistent detail sidebar.
- The Party detail sidebar now shows types, HP, level/status, ATK/DEF/SPC/SPD and move coverage.
- Added effectiveness analysis for the current enemy and a BEST OPTION move hint.
- Added a modern Summary overlay for in-battle Pokémon details so the UI no longer visually falls back to the stock SummaryMenu.
- Exposed new export flags for bundled icons, summary overlay and side-detail coverage preview.

## 1.1.0
- Changed the standard command strip to true horizontal navigation: FIGHT -> BAG -> POKEMON -> RUN.
- Added an `input.step` direction remapper that updates the original BattleState `menuIndex`, so A/B and battle callbacks remain native.
- Right/Down now advance one visible command; Left/Up move back one command.
- Added a modern battle Party overlay with Pokémon cards, HP, level, status, selection and live PartyMenu action submenu.
- Added a modern battle Bag overlay with item list, counts, selected-item details and machine move information.
- Added the `MODERN PARTY / BAG IN BATTLE` option.
- Party/Bag overlays are visual only; source PartyMenu and BagMenu still own input and callbacks.
- Replaced unsafe battle-text `tostring(table)` behavior with recursive semantic text extraction.
- Strips non-printing control bytes and Lua table/userdata identity strings.
- Battle encounter/intro messages now render outside the old `messages`-only phase gate.
- Added readable wild/trainer encounter fallback text when an overhaul exposes no decodable intro string.

## 1.0.0
- First standalone MODERN BATTLE UI release.
- Added responsive floating enemy/player status cards.
- Added modern HP bars, status pills and caught-Pokemon indicator.
- Added original FIGHT, POKEMON, BAG, RUN, BALL, BAIT and ROCK icon assets.
- Added modern 4-action command panel.
- Added Safari battle command presentation.
- Added 2x2 move cards with PP and type badges.
- Added selected-move POWER / ACCURACY / PP details.
- Added disabled-move and move-swap presentation.
- Added modern battle-message panel.
- Added MIDNIGHT, GRAPHITE, LIGHT and CRIMSON themes.
- Added scale, layout, opacity, icon, HP-number and move-detail options.
- Uses public `battle.status_hud_visible`, `battle.bottom_ui_visible` and
  `battle.move_grid_navigation` hooks instead of replacing BattleState.
- Draws last in `render.hud` at priority 980 for compatibility with Modern UI
  and BATTLE ART.
- Leaves battle logic, state transitions, Party, Bag and child prompts source-owned.
