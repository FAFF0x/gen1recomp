# Manual regression checklist

## Base battle
1. Enable MODERN BATTLE UI.
2. Enter a wild battle.
3. Confirm enemy/player status cards are visible.
4. Confirm FIGHT / POKEMON / BAG / RUN is visible.
5. Move the cursor through all four actions.
6. Choose FIGHT.
7. Confirm the 2x2 move grid follows directional input.
8. Confirm PP, type and selected move details update.
9. Confirm battle messages use the modern bottom panel.

## Trainer battle
1. Enter a trainer battle.
2. Confirm TRAINER BATTLE label.
3. Verify RUN failure does not affect UI state.
4. Verify Pokemon and Bag child screens still open normally.

## BATTLE ART / 3D-BTL
1. Enable BATTLE ART staged 3D battle.
2. Enter a battle.
3. Confirm the voxel scene and Pokemon are unchanged.
4. Confirm modern HP cards and command panel draw over the 3D scene.
5. Confirm FIGHT -> move selection remains visible.

## Gen1 Modern UI
1. Leave Gen1 Modern UI installed.
2. Set its BATTLE UI (WIP) OFF.
3. Confirm MODERN BATTLE UI remains active.
4. Confirm Modern UI still presents non-battle screens.

## Crystal 251
1. Enter a battle with a Johto Pokemon.
2. Confirm its live name/level/HP is shown.
3. Use a Gen II move and confirm name, type, PP and details render.

## Debug fallback
1. Set HIDE NATIVE BATTLE UI OFF.
2. Confirm both classic and modern battle layers are visible.
3. Re-enable it and confirm only the modern battle layer remains.
