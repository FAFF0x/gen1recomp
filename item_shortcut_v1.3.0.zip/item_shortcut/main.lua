-- Item Shortcut for Gen1Recomp
-- Opens a five-slot field item launcher with a configurable keyboard or controller shortcut.

local PATCH_KEY = "__item_shortcut_input_dispatch_v2"
local BAG_MENU_PATCH_KEY = "__item_shortcut_bag_assign_dispatch_v1"
local STATE_MARK = "__itemShortcutState"
local SLOT_COUNT = 5
local SAVE_KEY = "slots"
local FAST_SAVE_KEY = "fast_slot"

local KEYBOARD_OPTION = "keyboard_key"
local GAMEPAD_OPTION = "gamepad_button"
local FAST_KEYBOARD_OPTION = "fast_keyboard_key"
local FAST_GAMEPAD_OPTION = "fast_gamepad_button"

local KEYBOARD_CHOICES = {
  { "I", "i" },
  { "O", "o" },
  { "P", "p" },
  { "U", "u" },
  { "Y", "y" },
  { "H", "h" },
  { "J", "j" },
  { "K", "k" },
  { "L", "l" },
  { "G", "g" },
  { "V", "v" },
  { "B", "b" },
  { "N", "n" },
  { "M", "m" },
  { "F6", "f6" },
  { "F7", "f7" },
  { "F8", "f8" },
  { "F9", "f9" },
}

local GAMEPAD_CHOICES = {
  { "R1", "rightshoulder" },
  { "L1", "leftshoulder" },
  { "R3", "rightstick" },
  { "L3", "leftstick" },
  { "X", "x" },
  { "Y", "y" },
}

local function choiceMaps(choices)
  local allowed, labels = {}, {}
  for _, choice in ipairs(choices) do
    labels[choice[2]] = choice[1]
    allowed[choice[2]] = true
  end
  return allowed, labels
end

local KEYBOARD_ALLOWED, KEYBOARD_LABELS = choiceMaps(KEYBOARD_CHOICES)
local GAMEPAD_ALLOWED, GAMEPAD_LABELS = choiceMaps(GAMEPAD_CHOICES)

-- Capture the original BagMenu constructor before UI overhaul mods decorate it.
-- The hidden list is used only as a dispatcher so every item follows the game's
-- existing USE path, including target pickers, field checks and messages.
local BaseBagMenuNew
local Bag
local ListMenu
local Menu
local TextBox
local Font

do
  local ok, module = pcall(require, "src.ui.BagMenu")
  if ok and type(module) == "table" and type(module.new) == "function" then
    BaseBagMenuNew = module.new
  end
  ok, module = pcall(require, "src.inventory.Bag")
  if ok and type(module) == "table" then Bag = module end
  ok, module = pcall(require, "src.ui.ListMenu")
  if ok and type(module) == "table" then ListMenu = module end
  ok, module = pcall(require, "src.ui.Menu")
  if ok and type(module) == "table" then Menu = module end
  ok, module = pcall(require, "src.render.TextBox")
  if ok and type(module) == "table" then TextBox = module end
  ok, module = pcall(require, "src.render.Font")
  if ok and type(module) == "table" then Font = module end
end

local function mark(state)
  if type(state) == "table" then state[STATE_MARK] = true end
  return state
end

local function copySlots(source)
  local out = {}
  if type(source) ~= "table" then return out end
  for i = 1, SLOT_COUNT do
    if type(source[i]) == "string" and source[i] ~= "" then
      out[i] = source[i]
    end
  end
  return out
end

local function slotsFor(mod)
  local slots = copySlots(mod.save:get(SAVE_KEY))
  mod.save:set(SAVE_KEY, slots)
  return slots
end

local function persistSlots(mod, slots)
  mod.save:set(SAVE_KEY, copySlots(slots))
end

local function fastSlotFor(mod, slots)
  local slot = math.floor(tonumber(mod.save:get(FAST_SAVE_KEY)) or 0)
  if slot >= 1 and slot <= SLOT_COUNT and type(slots[slot]) == "string" then
    return slot
  end
  if slot ~= 0 then mod.save:set(FAST_SAVE_KEY, 0) end
  return nil
end

local function persistFastSlot(mod, slot)
  slot = math.floor(tonumber(slot) or 0)
  if slot < 1 or slot > SLOT_COUNT then slot = 0 end
  mod.save:set(FAST_SAVE_KEY, slot)
end

local function countOf(game, id)
  local inventory = game and game.save and game.save.inventory
  local value = inventory and inventory[id]
  if value == true then return 1 end
  value = math.floor(tonumber(value) or 0)
  return math.max(0, value)
end

local function itemName(game, id)
  local def = game and game.data and game.data.items and game.data.items[id]
  return (def and def.name) or id or "EMPTY"
end

local function compact(text, limit)
  text = tostring(text or "")
  if Font and type(Font.split) == "function" then
    local spans = Font.split(text)
    if #spans <= limit then return text end
    if limit <= 1 then return "." end
    local last = spans[limit - 1] and spans[limit - 1].to
    if last then return text:sub(1, last) .. "." end
  end
  if #text <= limit then return text end
  if limit <= 1 then return text:sub(1, limit) end
  return text:sub(1, limit - 1) .. "."
end

local function showMessage(game, text)
  if TextBox and type(TextBox.new) == "function"
      and game and game.stack and type(game.stack.push) == "function" then
    game.stack:push(TextBox.new(game, text))
    return true
  end
  return false
end

local function bagOrder(game)
  if Bag and type(Bag.order) == "function" then
    local ok, order = pcall(Bag.order, game.save)
    if ok and type(order) == "table" then return order end
  end
  local out = {}
  local inventory = game and game.save and game.save.inventory or {}
  for id, value in pairs(inventory) do
    if countOf(game, id) > 0 and not tostring(id):find("BADGE", 1, true) then
      out[#out + 1] = id
    end
  end
  table.sort(out)
  return out
end

local function selectedOption(mod, key, fallback, allowed)
  local value = mod and mod.options and mod.options:get(key)
  if allowed[value] then return value end
  return fallback
end

local function keyboardBinding(mod)
  return selectedOption(mod, KEYBOARD_OPTION, "i", KEYBOARD_ALLOWED)
end

local function gamepadBinding(mod)
  return selectedOption(mod, GAMEPAD_OPTION, "rightshoulder", GAMEPAD_ALLOWED)
end

local function fastKeyboardBinding(mod)
  return selectedOption(mod, FAST_KEYBOARD_OPTION, "k", KEYBOARD_ALLOWED)
end

local function fastGamepadBinding(mod)
  return selectedOption(mod, FAST_GAMEPAD_OPTION, "leftshoulder", GAMEPAD_ALLOWED)
end

local function shortcutFooter(mod)
  local key = keyboardBinding(mod)
  local pad = gamepadBinding(mod)
  return ("%s/%s CLOSE"):format(KEYBOARD_LABELS[key] or key:upper(),
    GAMEPAD_LABELS[pad] or pad:upper())
end

local function buildSlotRows(game, slots, fastSlot)
  local rows = {}
  for i = 1, SLOT_COUNT do
    local id = slots[i]
    local count = id and countOf(game, id) or 0
    local isFast = i == fastSlot
    local right = isFast and "FAST" or (count > 1 and ("x" .. tostring(count)) or nil)
    local maxName = right and 9 or 14
    local name
    if not id then
      name = "EMPTY"
    elseif count <= 0 then
      name = "MISSING"
    else
      name = compact(itemName(game, id), maxName)
    end
    rows[i] = {
      label = tostring(i) .. ". " .. name,
      right = right,
      value = i,
    }
  end
  return rows
end

local function refreshShortcutList(mod, list, game, slots, index)
  if not list then return end
  list.items = buildSlotRows(game, slots, fastSlotFor(mod, slots))
  list.index = math.max(1, math.min(index or list.index or 1, SLOT_COUNT))
  list.scroll = 0
end

local function removeShortcutStates(game)
  local removed = false
  local stack = game and game.stack
  if not stack or type(stack.top) ~= "function" or type(stack.pop) ~= "function" then
    return false
  end
  while true do
    local top = stack:top()
    if type(top) ~= "table" or not top[STATE_MARK] then break end
    stack:pop()
    removed = true
  end
  return removed
end

local function makeEphemeralBag(game)
  if type(BaseBagMenuNew) ~= "function" then return nil, "BagMenu is unavailable." end
  local ok, list = pcall(BaseBagMenuNew, game, {})
  if not ok or type(list) ~= "table" then
    return nil, "The standard Bag could not be opened."
  end

  local baseUpdate = list.update
  if type(baseUpdate) == "function" then
    function list:update(dt)
      -- The standard Bag intentionally stays open after some field items
      -- (Town Map, Itemfinder and refusal messages). A shortcut should return
      -- directly to the field, so remove this hidden dispatcher when control
      -- comes back to it.
      if self.game and self.game.stack and self.game.stack:top() == self then
        self.game.stack:pop()
        return
      end
      return baseUpdate(self, dt)
    end
  end
  return list
end

local function findBagRow(list, id)
  for _, row in ipairs(list and list.items or {}) do
    if row.value == id then return row end
  end
  return nil
end

local function useThroughStandardBag(mod, game, id)
  if not id or countOf(game, id) <= 0 then
    showMessage(game, "That item is no longer\nin the Bag.")
    return false
  end

  local list, err = makeEphemeralBag(game)
  if not list then
    mod.log:warn("Item Shortcut could not use %s: %s", tostring(id), tostring(err))
    showMessage(game, "The item shortcut\ncould not open the Bag.")
    return false
  end

  local row = findBagRow(list, id)
  if not row or type(list.onChoose) ~= "function" then
    mod.log:warn("Item Shortcut could not find %s in the standard Bag list", tostring(id))
    showMessage(game, "That item cannot be\nused from this shortcut.")
    return false
  end

  game.stack:push(list)
  local ok, chooseErr = pcall(list.onChoose, row, list)
  if not ok then
    if game.stack:top() == list then game.stack:pop() end
    mod.log:warn("Item Shortcut failed while opening USE for %s: %s",
      tostring(id), tostring(chooseErr))
    showMessage(game, "The item could not\nbe used.")
    return false
  end

  -- Out of battle, BagMenu opens the standard USE/TOSS menu. Reproduce the
  -- menu's normal A behavior on the first row (USE): pop the submenu first,
  -- then run its callback. This preserves the original item's complete flow.
  local actionMenu = game.stack:top()
  local useEntry = actionMenu and actionMenu.items and actionMenu.items[1]
  if actionMenu == list or type(useEntry) ~= "table"
      or type(useEntry.onSelect) ~= "function" then
    if game.stack:top() == list then game.stack:pop() end
    mod.log:warn("Item Shortcut did not receive a USE action for %s", tostring(id))
    showMessage(game, "That item cannot be\nused from this shortcut.")
    return false
  end

  game.stack:pop()
  local used, useErr = pcall(useEntry.onSelect)
  if not used then
    if game.stack:top() == list then game.stack:pop() end
    mod.log:warn("Item Shortcut failed while using %s: %s",
      tostring(id), tostring(useErr))
    showMessage(game, "The item could not\nbe used.")
    return false
  end
  return true
end

local function assignItem(mod, slots, slotIndex, itemId)
  -- A single Bag item owns at most one shortcut slot. Reassigning it moves
  -- the item instead of creating duplicate entries in the quick menu.
  local fastSlot = fastSlotFor(mod, slots)
  local previousSlot
  for i = 1, SLOT_COUNT do
    if slots[i] == itemId then
      previousSlot = i
      slots[i] = nil
    end
  end
  slots[slotIndex] = itemId
  persistSlots(mod, slots)

  -- FAST normally belongs to the slot, but follows an item when that same
  -- item is explicitly moved to a different shortcut slot.
  if fastSlot and previousSlot == fastSlot and slotIndex ~= previousSlot then
    persistFastSlot(mod, slotIndex)
  end
end

local function buildAssignmentRows(game, slots, itemId)
  local rows = {}
  for i = 1, SLOT_COUNT do
    local assigned = slots[i]
    local name = assigned and compact(itemName(game, assigned), 13) or "EMPTY"
    rows[i] = {
      label = tostring(i) .. ". " .. name,
      right = assigned == itemId and "SET" or nil,
      value = i,
    }
  end
  return rows
end

local function openBagAssignment(mod, game, itemId)
  if not (ListMenu and game and game.stack and itemId) then return false end
  if countOf(game, itemId) <= 0 then
    showMessage(game, "That item is no longer\nin the Bag.")
    return false
  end

  local slots = slotsFor(mod)
  local picker
  picker = mark(ListMenu.new(game, "CHOOSE SLOT", buildAssignmentRows(game, slots, itemId), {
    onChoose = function(row, list)
      assignItem(mod, slots, row.value, itemId)
      list:close()
      showMessage(game, ("Assigned %s\nto shortcut %d.")
        :format(itemName(game, itemId), row.value))
    end,
  }))
  game.stack:push(picker)
  return true
end

local function isUseTossMenu(state)
  if type(state) ~= "table" or type(state.items) ~= "table" then return false end
  local first, second = state.items[1], state.items[2]
  -- Detect the Bag action menu by behavior rather than translated labels.
  -- The normal out-of-battle Bag always creates two callable actions first.
  return type(first) == "table" and type(first.onSelect) == "function"
     and type(second) == "table" and type(second.onSelect) == "function"
end

local function addAssignmentAction(mod, game, actionMenu, itemId)
  if not isUseTossMenu(actionMenu) then return false end
  for _, entry in ipairs(actionMenu.items) do
    if tostring(entry.label or "") == "ASSIGN SHORTCUT" then return true end
  end

  actionMenu.items[#actionMenu.items + 1] = {
    label = "ASSIGN SHORTCUT",
    onSelect = function()
      openBagAssignment(mod, game, itemId)
    end,
  }

  -- The vanilla USE/TOSS box is sized for two rows. Grow it to three rows
  -- and widen it for the new label while keeping the entire box on-screen.
  actionMenu.rowStep = actionMenu.rowStep or 2
  actionMenu.tw = math.max(actionMenu.tw or 7, 18)
  actionMenu.tx = math.max(0, 20 - actionMenu.tw)
  local neededHeight = #actionMenu.items * actionMenu.rowStep + 2
  actionMenu.th = math.max(actionMenu.th or 0, neededHeight)
  actionMenu.ty = math.max(0, math.min(actionMenu.ty or 0, 18 - actionMenu.th))
  if type(actionMenu.clampScroll) == "function" then actionMenu:clampScroll() end
  return true
end

local function decorateBagForAssignment(mod, game, opts, list)
  if type(list) ~= "table" or list.__itemShortcutBagDecorated then return list end
  if opts and opts.battle then return list end
  if type(list.onChoose) ~= "function" then return list end

  list.__itemShortcutBagDecorated = true
  local baseChoose = list.onChoose
  list.onChoose = function(item, currentList)
    baseChoose(item, currentList)
    if type(item) ~= "table" or type(item.value) ~= "string" then return end
    local top = game and game.stack and game.stack:top()
    if top and top ~= currentList then
      addAssignmentAction(mod, game, top, item.value)
    end
  end
  return list
end

local function installBagAssignment(mod, game)
  local ok, BagMenu = pcall(require, "src.ui.BagMenu")
  if not ok or type(BagMenu) ~= "table" or type(BagMenu.new) ~= "function" then
    mod.log:warn("Item Shortcut could not add ASSIGN SHORTCUT to the Bag")
    return false
  end

  local dispatch = rawget(_G, BAG_MENU_PATCH_KEY)
  if type(dispatch) ~= "table" then
    dispatch = { baseNew = BagMenu.new, decorator = nil }
    dispatch.wrapper = function(currentGame, opts)
      local list = dispatch.baseNew(currentGame, opts)
      local decorator = dispatch.decorator
      if decorator then return decorator(currentGame, opts, list) end
      return list
    end
    rawset(_G, BAG_MENU_PATCH_KEY, dispatch)
    BagMenu.new = dispatch.wrapper
  elseif BagMenu.new ~= dispatch.wrapper then
    dispatch.baseNew = BagMenu.new
    BagMenu.new = dispatch.wrapper
  end

  dispatch.decorator = function(currentGame, opts, list)
    return decorateBagForAssignment(mod, currentGame, opts, list)
  end
  return true
end

local function openSlotContext(mod, game, quickList, slots, slotIndex)
  local id = slots[slotIndex]
  if not id then
    showMessage(game, "Open the Bag and choose\nASSIGN SHORTCUT.")
    return
  end

  local isFast = fastSlotFor(mod, slots) == slotIndex
  local entries = {
    {
      label = "USE",
      onSelect = function()
        quickList:close()
        useThroughStandardBag(mod, game, id)
      end,
    },
    {
      label = isFast and "REMOVE FAST" or "SET FAST",
      onSelect = function()
        if isFast then
          persistFastSlot(mod, nil)
        else
          persistFastSlot(mod, slotIndex)
        end
        refreshShortcutList(mod, quickList, game, slots, slotIndex)
      end,
    },
    {
      label = "CLEAR",
      onSelect = function()
        slots[slotIndex] = nil
        persistSlots(mod, slots)
        if isFast then persistFastSlot(mod, nil) end
        refreshShortcutList(mod, quickList, game, slots, slotIndex)
      end,
    },
  }

  local context = mark(Menu.new(game, entries, {
    tx = 6, ty = 3, tw = 14,
  }))
  game.stack:push(context)
end

local function openShortcutMenu(mod, game)
  if not (ListMenu and Menu and game and game.stack and game.save) then
    mod.log:warn("Item Shortcut could not open: required UI services are unavailable")
    return false
  end

  local slots = slotsFor(mod)
  local quick
  quick = mark(ListMenu.new(game, "ITEM SHORTCUT",
    buildSlotRows(game, slots, fastSlotFor(mod, slots)), {
    footer = shortcutFooter(mod),
    onChoose = function(row)
      openSlotContext(mod, game, quick, slots, row.value)
    end,
  }))
  game.stack:push(quick)
  return true
end

local function runnerBusy(overworld)
  local runner = overworld and overworld.runner
  if runner and type(runner.isRunning) == "function" then
    local ok, busy = pcall(runner.isRunning, runner)
    if ok and busy then return true end
  end
  return false
end

local function canOpen(game)
  local stack = game and game.stack
  local overworld = game and game.overworld
  if not stack or not overworld or type(stack.top) ~= "function" then return false end
  if stack:top() ~= overworld then return false end
  if not (game.save and game.save.inventory) then return false end
  if overworld.player and overworld.player.moving then return false end
  if overworld.engaging or overworld.emote then return false end
  if overworld.fishing or overworld.warping or overworld.teleporting then return false end
  if runnerBusy(overworld) then return false end
  return true
end

local function noteGamepad(game)
  local touch = game and game.touchControls
  if touch and type(touch.noteGamepad) == "function" then
    pcall(touch.noteGamepad, touch)
  end
end

local function playOpenSound(game)
  local ok, Sound = pcall(require, "src.core.Sound")
  if ok and Sound and type(Sound.play) == "function" and game and game.data then
    pcall(Sound.play, game.data, "Start_Menu")
  end
end

local function useFastShortcut(mod, game, slots, fastSlot)
  slots = slots or slotsFor(mod)
  fastSlot = fastSlot or fastSlotFor(mod, slots)
  if not fastSlot then
    showMessage(game, "No FAST item is set.\nUse SET FAST in menu.")
    return false
  end
  return useThroughStandardBag(mod, game, slots[fastSlot])
end

local function handleShortcutInput(mod, game, kind, value)
  local menuMatch, fastMatch
  if kind == "keyboard" then
    menuMatch = value == keyboardBinding(mod)
    fastMatch = value == fastKeyboardBinding(mod)
  elseif kind == "gamepad" then
    menuMatch = value == gamepadBinding(mod)
    fastMatch = value == fastGamepadBinding(mod)
    if menuMatch or fastMatch then noteGamepad(game) end
  else
    return false
  end

  if not menuMatch and not fastMatch then return false end

  -- The menu binding keeps its existing close behavior. This also makes a
  -- shared menu/FAST binding close an open shortcut screen predictably.
  if menuMatch and removeShortcutStates(game) then return true end
  if not canOpen(game) then return false end

  local fastSlots, fastSlot
  if fastMatch then
    fastSlots = slotsFor(mod)
    fastSlot = fastSlotFor(mod, fastSlots)
  end

  -- FAST takes priority when both commands are mapped to the same input.
  if fastMatch and fastSlot then
    useFastShortcut(mod, game, fastSlots, fastSlot)
    return true
  end

  if menuMatch then
    playOpenSound(game)
    return openShortcutMenu(mod, game)
  end

  useFastShortcut(mod, game, fastSlots, fastSlot)
  return true
end

local function installInputHandlers(mod, game)
  if not game or type(game.keypressed) ~= "function"
      or type(game.gamepadpressed) ~= "function" then
    mod.log:warn("Item Shortcut could not install input handlers; restart on a compatible game build")
    return false
  end

  -- Disable the v1 R1-only dispatcher during a development hot reload. A
  -- normal restart never has both versions in memory, but this prevents the
  -- old R1 handler from surviving after the controller binding is changed.
  local oldDispatch = rawget(_G, "__item_shortcut_r1_dispatch_v1")
  if type(oldDispatch) == "table" then oldDispatch.handler = nil end

  local dispatch = rawget(_G, PATCH_KEY)
  if type(dispatch) ~= "table" then
    dispatch = {
      baseKey = game.keypressed,
      basePad = game.gamepadpressed,
      keyHandler = nil,
      padHandler = nil,
      log = nil,
    }

    dispatch.keyWrapper = function(self, key, ...)
      local handler = dispatch.keyHandler
      if handler then
        local ok, consumed = pcall(handler, self, key)
        if not ok then
          if dispatch.log and dispatch.log.warn then
            dispatch.log:warn("Item Shortcut keyboard handler failed: %s", tostring(consumed))
          end
        elseif consumed then
          return
        end
      end
      if dispatch.baseKey then return dispatch.baseKey(self, key, ...) end
    end

    dispatch.padWrapper = function(self, joystick, button, ...)
      local handler = dispatch.padHandler
      if handler then
        local ok, consumed = pcall(handler, self, joystick, button)
        if not ok then
          if dispatch.log and dispatch.log.warn then
            dispatch.log:warn("Item Shortcut controller handler failed: %s", tostring(consumed))
          end
        elseif consumed then
          return
        end
      end
      if dispatch.basePad then
        return dispatch.basePad(self, joystick, button, ...)
      end
    end

    rawset(_G, PATCH_KEY, dispatch)
    game.keypressed = dispatch.keyWrapper
    game.gamepadpressed = dispatch.padWrapper
  else
    if game.keypressed ~= dispatch.keyWrapper then
      dispatch.baseKey = game.keypressed
      game.keypressed = dispatch.keyWrapper
    end
    if game.gamepadpressed ~= dispatch.padWrapper then
      dispatch.basePad = game.gamepadpressed
      game.gamepadpressed = dispatch.padWrapper
    end
  end

  dispatch.log = mod.log
  dispatch.keyHandler = function(currentGame, key)
    return handleShortcutInput(mod, currentGame, "keyboard", key)
  end
  dispatch.padHandler = function(currentGame, _, button)
    return handleShortcutInput(mod, currentGame, "gamepad", button)
  end
  return true
end

return function(mod)
  mod.options:define({
    {
      key = KEYBOARD_OPTION,
      label = "KEYBOARD KEY",
      type = "choice",
      default = "i",
      choices = KEYBOARD_CHOICES,
    },
    {
      key = GAMEPAD_OPTION,
      label = "CONTROLLER",
      type = "choice",
      default = "rightshoulder",
      choices = GAMEPAD_CHOICES,
    },
    {
      key = FAST_KEYBOARD_OPTION,
      label = "FAST KEYBOARD",
      type = "choice",
      default = "k",
      choices = KEYBOARD_CHOICES,
    },
    {
      key = FAST_GAMEPAD_OPTION,
      label = "FAST CONTROLLER",
      type = "choice",
      default = "leftshoulder",
      choices = GAMEPAD_CHOICES,
    },
  })

  mod.events:on("game.ready", function(event)
    local game = event and event.game
    local inputOk = installInputHandlers(mod, game)
    local bagOk = installBagAssignment(mod, game)
    if inputOk and bagOk then
      mod.log:info("Item Shortcut installed: menu %s/%s, FAST %s/%s",
        KEYBOARD_LABELS[keyboardBinding(mod)], GAMEPAD_LABELS[gamepadBinding(mod)],
        KEYBOARD_LABELS[fastKeyboardBinding(mod)], GAMEPAD_LABELS[fastGamepadBinding(mod)])
    end
  end)

  mod.exports.open = function(game)
    if not canOpen(game) then return false end
    return openShortcutMenu(mod, game)
  end
  mod.exports.getSlots = function()
    return copySlots(slotsFor(mod))
  end
  mod.exports.assign = function(slot, itemId)
    slot = math.floor(tonumber(slot) or 0)
    if slot < 1 or slot > SLOT_COUNT then return false end
    local slots = slotsFor(mod)
    if type(itemId) == "string" and itemId ~= "" then
      assignItem(mod, slots, slot, itemId)
    else
      local wasFast = fastSlotFor(mod, slots) == slot
      slots[slot] = nil
      persistSlots(mod, slots)
      if wasFast then persistFastSlot(mod, nil) end
    end
    return true
  end
  mod.exports.clear = function(slot)
    return mod.exports.assign(slot, nil)
  end
  mod.exports.getFastSlot = function()
    local slots = slotsFor(mod)
    return fastSlotFor(mod, slots)
  end
  mod.exports.setFastSlot = function(slot)
    local slots = slotsFor(mod)
    slot = math.floor(tonumber(slot) or 0)
    if slot == 0 then
      persistFastSlot(mod, nil)
      return true
    end
    if slot < 1 or slot > SLOT_COUNT or not slots[slot] then return false end
    persistFastSlot(mod, slot)
    return true
  end
end
