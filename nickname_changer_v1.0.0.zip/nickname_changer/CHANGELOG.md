# Changelog

## 1.0.0

- Initial release.
- Added RENAME to the normal Pokémon party submenu.
- Added stock Gen 1 NamingScreen integration.
- Added 10-character nickname support.
- Prevented RENAME from appearing in battle party menus.
- Added duplicate-entry protection for compatibility with other mods.
