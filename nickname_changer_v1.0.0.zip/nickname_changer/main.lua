-- Nickname Changer v1.0.0
-- Adds RENAME to the normal party Pokémon submenu.
--
-- Uses Gen1Recomp's public ui.party.submenu hook. PartyMenu invokes
-- injected rows through entry.onSelect(mon, game), so the vanilla menu
-- remains intact and other submenu-injection mods can coexist.

local VERSION = "1.0.0"

return function(mod)
  local function insertRename(items, entry)
    -- Prefer placing RENAME immediately after STATS, which keeps the
    -- standard STATS / SWITCH ordering recognizable. If another mod has
    -- replaced the list, append it instead.
    for i, item in ipairs(items) do
      if item and item.action == "stats" then
        table.insert(items, i + 1, entry)
        return
      end
    end
    items[#items + 1] = entry
  end

  local function openNamingScreen(game, mon)
    if not (game and mon) then return end

    local def = game.data and game.data.pokemon
      and game.data.pokemon[mon.species] or nil
    local speciesName = (def and def.name) or tostring(mon.species or "POKEMON")
    local oldNickname = mon.nickname

    local Screens = require("src.ui.Screens")
    Screens.push(game, "NamingScreen", {
      title = "NEW NICKNAME?",
      maxLen = 10,

      -- NamingScreen treats an empty confirm as opts.default. Keeping the
      -- current display name here means accidentally pressing START / ED on
      -- an empty grid never erases an existing nickname.
      default = oldNickname or speciesName,

      onDone = function(name)
        if type(name) ~= "string" or #name == 0 then
          return
        end

        mon.nickname = name

        -- Keep the engine string buffer coherent for any UI/message opened
        -- immediately after the naming screen.
        if game then game.stringBuffer = name end

        mod.log:info(
          "Renamed %s to %s",
          tostring(speciesName),
          tostring(name)
        )
      end,
    })
  end

  mod.hooks:wrap("ui.party.submenu", function(nextFn, game, items, mon, ctx)
    items = nextFn(game, items, mon, ctx)

    if type(items) ~= "table" then
      return items
    end

    -- Renaming is a field/menu convenience, not a battle action.
    if ctx and ctx.battle then
      return items
    end

    -- Avoid a duplicate row if another compatible mod already injected one.
    for _, item in ipairs(items) do
      local label = item and tostring(item.label or ""):upper() or ""
      if label == "RENAME" or label == "NICKNAME" then
        return items
      end
    end

    insertRename(items, {
      label = "RENAME",
      onSelect = function(selectedMon, selectedGame)
        openNamingScreen(selectedGame or game, selectedMon or mon)
      end,
    })

    return items
  end, 500)

  mod.exports.version = VERSION
  mod.exports.rename = function(game, mon)
    openNamingScreen(game, mon)
  end
end
