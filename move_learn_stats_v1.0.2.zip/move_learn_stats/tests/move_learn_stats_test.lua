-- Headless focused test for Move Learn Stats + Gen1 Modern UI adapter.

_G.love = { graphics = { setColor = function() end } }

local registered
local adapterSpec
local readyCallback
local pushed = {}
local mod = {
  id = "move_learn_stats",
  content = {
    screens = {
      _existing = {
        new = function(game, mon, newMoveId, onDone)
          local screen = require("src.ui.MoveLearnMenu").new(game, mon, newMoveId, onDone)
          screen.crystalUpstream = true
          return screen
        end,
      },
      get = function(self, id)
        assert(id == "MoveLearnMenu")
        return self._existing
      end,
      register = function(_, id, record)
        assert(id == "MoveLearnMenu")
        registered = record
      end,
      override = function(_, id, record)
        assert(id == "MoveLearnMenu")
        registered = record
      end,
    },
  },
  exports = {},
  events = {
    on = function(_, name, callback)
      if name == "game.ready" then readyCallback = callback end
    end,
  },
  find = function(id)
    if id ~= "gen1_modern_ui" then return nil end
    return {
      exports = {
        compatibilityApiVersion = 1,
        registerAdapter = function(spec)
          adapterSpec = spec
          return true
        end,
      },
    }
  end,
}

package.preload["src.render.Font"] = function()
  return {
    draw = function() end,
    drawBox = function() end,
    drawCode = function() end,
  }
end
package.preload["src.core.Strings"] = function()
  return function(fmt, ...)
    if select("#", ...) > 0 then return string.format(fmt, ...) end
    return fmt
  end
end
package.preload["src.core.RomText"] = function()
  return function(_, _, fallback) return fallback end
end
package.preload["src.render.TextBox"] = function()
  return {
    new = function(_, text) return { text = text, isTextBox = true } end,
  }
end
package.preload["src.ui.MoveLearnMenu"] = function()
  return {
    new = function(game, mon, newMoveId, onDone)
      return {
        game = game,
        mon = mon,
        newMoveId = newMoveId,
        onDone = onDone,
        index = 1,
        selecting = true,
        vanillaMarker = true,
        confirmAbandon = function(self)
          self.abandonCalled = true
          self.selecting = false
        end,
        finish = function(self, learned)
          self.finishCalled = learned
          self.selecting = false
        end,
      }
    end,
  }
end

local entry = assert(loadfile("main.lua"))
entry()(mod)

assert(registered and type(registered.new) == "function")
assert(adapterSpec and adapterSpec.owner == "move_learn_stats")
assert(adapterSpec.version == "1.0.2")
assert(adapterSpec.contract == mod.exports.gen1ModernUi)
assert(type(readyCallback) == "function")

assert(mod.exports.moveStats({ moves = {
  TACKLE = { name = "TACKLE", power = 40, pp = 35 },
  GROWL = { name = "GROWL", power = 0, pp = 40 },
}}, "TACKLE").power == "40")
assert(mod.exports.moveStats({ moves = {
  GROWL = { name = "GROWL", power = 0, pp = 40 },
}}, "GROWL").power == "---")
assert(mod.exports.moveStats({ moves = {
  GROWL = { name = "GROWL", power = 0, pp = 40 },
}}, "GROWL").pp == "40")
assert(mod.exports.shortName("DOUBLE-EDGE", 8) == "DOUBLE-E")
assert(mod.exports.isHmMove({ constants = { hmMoves = { "WHIRLPOOL" } } }, "WHIRLPOOL") == true)

local game = {
  data = {
    constants = { hmMoves = { "CUT", "FLY", "SURF", "STRENGTH", "FLASH", "WHIRLPOOL", "WATERFALL" } },
    moves = {
      TACKLE = { name = "TACKLE", power = 40, pp = 35 },
      BITE = { name = "BITE", power = 60, pp = 25 },
      CUT = { name = "CUT", power = 50, pp = 30 },
      WHIRLPOOL = { name = "WHIRLPOOL", power = 15, pp = 15 },
    },
  },
  stack = { push = function(_, state) pushed[#pushed + 1] = state end },
}
local mon = { moves = { { id = "TACKLE", pp = 4 }, { id = "CUT", pp = 10 } } }
local screen = registered.new(game, mon, "BITE", function() end)
assert(screen.vanillaMarker == true)
assert(screen.crystalUpstream == true)
assert(screen._moveLearnStats == true)
assert(screen.screenId == "MoveLearnMenu")
assert(screen.draw ~= nil)
screen:draw()

local contract = assert(mod.exports.gen1ModernUi)
assert(contract.apiVersion == 1)
local compat = assert(contract.screens.move_learn_stats)
assert(compat.canSuppressNative == true)
assert(compat.match(screen) == true)
local model = compat.model(game, screen)
assert(model.title == "FORGET A MOVE")
assert(model.rows[1].label == "LEARNING  BITE")
assert(model.rows[1].value == "PWR 60   PP 25")
assert(model.rows[3].label == "TACKLE")
assert(model.rows[3].value == "PWR 40   PP 35")
assert(model.rows[#model.rows].label == "CANCEL")
assert(model.index == 3)

-- Pointer hover maps Modern UI row 4 to vanilla move index 2.
assert(compat.actions.hover(game, screen, 4) == true)
assert(screen.index == 2)

-- HM replacement is blocked and opens the vanilla HM warning TextBox.
assert(compat.actions.select(game, screen, 4) == true)
assert(mon.moves[2].id == "CUT")
assert(#pushed == 1 and pushed[1].isTextBox == true)

-- Select a normal old move: replacement and finish flow stay source-owned.
screen.selecting = true
assert(compat.actions.select(game, screen, 3) == true)
assert(mon.moves[1].id == "BITE" and mon.moves[1].pp == 25)
assert(screen.finishCalled == true)

-- Back uses the ordinary abandon-learning confirmation path.
screen.selecting = true
assert(compat.actions.back(game, screen) == true)
assert(screen.abandonCalled == true)

print("move_learn_stats_test: ok")
