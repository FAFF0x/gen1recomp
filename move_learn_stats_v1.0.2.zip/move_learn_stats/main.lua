-- Move Learn Stats
-- Replaces only the visual layer of MoveLearnMenu. The original menu keeps
-- control of prompts, HM protection, cancellation and the actual move swap.
-- When Gen1 Modern UI is active, a public presentation adapter exposes the
-- same comparison as responsive rows while this mod still owns all actions.

local Font = require("src.render.Font")
local Strings = require("src.core.Strings")
local VanillaMoveLearnMenu = require("src.ui.MoveLearnMenu")
local romText = require("src.core.RomText")

local CURSOR = 0xED
local NAME_GLYPHS = 8
local SCREEN_ID = "MoveLearnMenu"
local MOD_ID = "move_learn_stats"

-- Keep the pointer/click path identical to vanilla MoveLearnMenu.
local HM_MOVES = {
  CUT = true, FLY = true, SURF = true, STRENGTH = true, FLASH = true,
}

-- Prefer the live HM registry so content overhauls (for example CRYSTAL_251)
-- can protect additional HMs such as WHIRLPOOL and WATERFALL. The hardcoded
-- Gen 1 set remains the fallback for older data sets.
local function isHmMove(data, moveId)
  local live = data and data.constants and data.constants.hmMoves
  if type(live) == "table" then
    for _, id in ipairs(live) do
      if id == moveId then return true end
    end
  end
  return HM_MOVES[moveId] == true
end

local function shortName(name, limit)
  name = tostring(name or "---")
  limit = limit or NAME_GLYPHS
  if #name <= limit then return name end
  return name:sub(1, limit)
end

local function moveStats(data, moveId)
  local def = data and data.moves and moveId and data.moves[moveId]
  if not def then
    return { name = "---", power = "---", pp = "---" }
  end
  local power = tonumber(def.power) or 0
  return {
    name = def.name or moveId,
    power = power > 0 and tostring(power) or "---",
    pp = tostring(tonumber(def.pp) or 0),
  }
end

local function statLine(stats)
  return ("PWR %s   PP %s"):format(stats.power, stats.pp)
end

local function drawColumn(x, heading, stats)
  Font.draw(Strings(heading), x, 13 * 8)
  Font.draw(shortName(stats.name), x, 14 * 8)
  Font.draw(Strings("PWR %s", stats.power), x, 15 * 8)
  Font.draw(Strings("PP  %s", stats.pp), x, 16 * 8)
end

local function drawMoveLearnComparison(self)
  if not self.selecting then return end

  -- Keep the vanilla single-spaced move list and CANCEL row.
  Font.drawBox(4, 5, 16, 7)
  love.graphics.setColor(0, 0, 0, 1)
  for i, mv in ipairs(self.mon.moves) do
    local def = self.game.data.moves[mv.id]
    Font.draw((def and def.name) or mv.id, 48, (5 + i) * 8)
  end
  Font.draw(Strings("CANCEL"), 48, (6 + #self.mon.moves) * 8)
  Font.drawCode(CURSOR, 40, (5 + self.index) * 8)

  -- Four interior rows: heading, move name, power, and maximum PP.
  Font.drawBox(0, 12, 20, 6)
  local selectedId
  if self.index <= #self.mon.moves then
    selectedId = self.mon.moves[self.index].id
  end
  drawColumn(8, "SELECTED", moveStats(self.game.data, selectedId))
  drawColumn(88, "LEARNING", moveStats(self.game.data, self.newMoveId))
  love.graphics.setColor(1, 1, 1, 1)
end

local function decorateMoveLearnMenu(screen)
  if type(screen) ~= "table" then return screen end
  screen.draw = drawMoveLearnComparison
  -- Public marker used only by this mod's Modern UI adapter. Screens.lua also
  -- stamps screenId, but the marker keeps matching stable in headless tests
  -- and unusual third-party screen-factory wrappers.
  screen._moveLearnStats = true
  screen.screenId = screen.screenId or SCREEN_ID
  return screen
end

local function newMoveLearnMenu(game, mon, newMoveId, onDone, upstreamFactory)
  local screen
  if type(upstreamFactory) == "function" then
    screen = upstreamFactory(game, mon, newMoveId, onDone)
  else
    screen = VanillaMoveLearnMenu.new(game, mon, newMoveId, onDone)
  end
  return decorateMoveLearnMenu(screen)
end

local function modernModel(state)
  local rows = {}
  local data = state.game and state.game.data or {}
  local learning = moveStats(data, state.newMoveId)

  -- The learning move is always visible at the top and deliberately inert.
  rows[#rows + 1] = {
    label = "LEARNING  " .. learning.name,
    value = statLine(learning),
    category = true,
    enabled = false,
  }
  rows[#rows + 1] = {
    label = "CHOOSE MOVE TO FORGET",
    header = true,
    enabled = false,
  }

  for _, mv in ipairs(state.mon and state.mon.moves or {}) do
    local stats = moveStats(data, mv.id)
    rows[#rows + 1] = {
      label = stats.name,
      value = statLine(stats),
      enabled = true,
    }
  end
  rows[#rows + 1] = { label = "CANCEL", enabled = true }

  return {
    title = "FORGET A MOVE",
    rows = rows,
    -- Two non-selectable rows precede the vanilla move/CANCEL cursor.
    index = math.min(#rows, math.max(3, (tonumber(state.index) or 1) + 2)),
    scroll = 0,
    footer = { "A REPLACE", "B CANCEL" },
  }
end

local function modelIndexToVanilla(state, index)
  index = math.floor(tonumber(index) or 0) - 2
  local count = #(state.mon and state.mon.moves or {}) + 1
  if index < 1 or index > count then return nil end
  return index
end

local function activateSelection(state, index)
  if type(state) ~= "table" or state.selecting ~= true then return false end
  local mapped = modelIndexToVanilla(state, index)
  if not mapped then return false end
  state.index = mapped

  local moves = state.mon and state.mon.moves or {}
  if mapped > #moves then
    if type(state.confirmAbandon) == "function" then
      state:confirmAbandon()
      return true
    end
    return false
  end

  local old = moves[mapped]
  if not old then return false end
  if isHmMove(state.game and state.game.data, old.id) then
    local TextBox = require("src.render.TextBox")
    state.game.stack:push(TextBox.new(state.game,
      romText(state.game.data, "_HMCantDeleteText",
        "HM techniques\ncan't be deleted!")))
    return true
  end

  local mdef = state.game.data.moves[state.newMoveId]
  if not mdef then return false end
  moves[mapped] = { id = state.newMoveId, pp = mdef.pp }
  local oldDef = state.game.data.moves[old.id]
  state.forgot = (oldDef and oldDef.name) or old.id
  if type(state.finish) == "function" then
    state:finish(true)
    return true
  end
  return false
end

return function(mod)
  local modernUiContract = {
    apiVersion = 1,
    screens = {
      move_learn_stats = {
        match = function(state)
          return type(state) == "table"
            and state._moveLearnStats == true
            and state.screenId == SCREEN_ID
            and state.selecting == true
            and type(state.mon) == "table"
            and type(state.game) == "table"
        end,
        canSuppressNative = true,
        model = function(_, state)
          return modernModel(state)
        end,
        actions = {
          hover = function(_, state, index)
            local mapped = modelIndexToVanilla(state, index)
            if not mapped then return false end
            state.index = mapped
            return true
          end,
          select = function(_, state, index)
            return activateSelection(state, index)
          end,
          up = function(_, state)
            local count = #(state.mon and state.mon.moves or {}) + 1
            if count <= 0 then return false end
            local current = math.max(1, math.floor(tonumber(state.index) or 1))
            state.index = current > 1 and current - 1 or count
            return true
          end,
          down = function(_, state)
            local count = #(state.mon and state.mon.moves or {}) + 1
            if count <= 0 then return false end
            local current = math.max(1, math.floor(tonumber(state.index) or 1))
            state.index = current < count and current + 1 or 1
            return true
          end,
          back = function(_, state)
            if type(state.confirmAbandon) ~= "function" then return false end
            state:confirmAbandon()
            return true
          end,
        },
      },
    },
  }

  local modernUiExports
  local modernUiRegistered = false
  local function ensureModernUiAdapter()
    if type(mod.find) ~= "function" then return false end
    local okFind, handle = pcall(mod.find, "gen1_modern_ui")
    if not okFind or type(handle) ~= "table" or type(handle.exports) ~= "table" then
      modernUiExports, modernUiRegistered = nil, false
      return false
    end
    local ex = handle.exports
    if tonumber(ex.compatibilityApiVersion or 1) ~= 1
        or type(ex.registerAdapter) ~= "function" then
      modernUiExports, modernUiRegistered = ex, false
      return false
    end
    if modernUiRegistered and modernUiExports == ex then return true end
    local ok, registered, reason = pcall(ex.registerAdapter, {
      owner = MOD_ID,
      version = "1.0.2",
      contract = modernUiContract,
    })
    if ok and registered ~= false then
      modernUiExports, modernUiRegistered = ex, true
      return true
    end
    modernUiExports, modernUiRegistered = ex, false
    if mod.log and type(mod.log.warn) == "function" then
      mod.log:warn("Gen1 Modern UI adapter unavailable: %s",
        tostring(ok and reason or registered))
    end
    return false
  end

  -- Compose over an existing MoveLearnMenu contribution when one is already
  -- present. CRYSTAL_251 registers this screen first (priority 110) to protect
  -- HM06/HM07; a second register() would collide in the record registry and
  -- disable this mod. Capture the existing factory, then explicitly override
  -- the record with a wrapper that preserves the upstream behavior and changes
  -- only this mod's presentation layer.
  local existingScreen = mod.content.screens:get(SCREEN_ID)
  local upstreamFactory
  if type(existingScreen) == "function" then
    upstreamFactory = existingScreen
  elseif type(existingScreen) == "table" and type(existingScreen.new) == "function" then
    upstreamFactory = existingScreen.new
  end

  local screenRecord = {
    new = function(game, mon, newMoveId, onDone)
      ensureModernUiAdapter()
      return newMoveLearnMenu(game, mon, newMoveId, onDone, upstreamFactory)
    end,
  }

  if existingScreen ~= nil then
    mod.content.screens:override(SCREEN_ID, screenRecord)
  else
    mod.content.screens:register(SCREEN_ID, screenRecord)
  end

  -- Small public helpers make headless validation and compatibility checks
  -- possible without reaching into local functions.
  mod.exports.version = "1.0.2"
  mod.exports.moveStats = moveStats
  mod.exports.shortName = shortName
  mod.exports.isHmMove = isHmMove
  mod.exports.newScreen = function(game, mon, newMoveId, onDone)
    return newMoveLearnMenu(game, mon, newMoveId, onDone)
  end
  mod.exports.decorateScreen = decorateMoveLearnMenu
  mod.exports.modernModel = modernModel
  mod.exports.gen1ModernUi = modernUiContract
  mod.exports.ensureModernUiAdapter = ensureModernUiAdapter

  if mod.events and type(mod.events.on) == "function" then
    mod.events:on("game.ready", function()
      ensureModernUiAdapter()
    end)
  end

  -- Register immediately when load order permits it; screen creation and
  -- game.ready retry for optional-dependency ordering and hot reloads.
  ensureModernUiAdapter()
end
