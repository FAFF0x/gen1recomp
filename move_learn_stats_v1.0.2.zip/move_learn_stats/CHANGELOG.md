# Changelog

## v1.0.2

- Fixed a `MoveLearnMenu` registry collision with CRYSTAL_251 and other mods that already provide the same screen.
- Preserves the upstream Move Learn screen factory before adding the stats presentation layer.
- Modern UI HM protection now reads the live `constants.hmMoves` list, covering Crystal's HM06/HM07 as well as the original five HMs.
- Added `0.0.0-dev` to the supported Gen1Recomp version range so current development builds load the mod.
- Added public `version`, `isHmMove`, and `decorateScreen` helpers for compatibility testing.

## v1.0.1

- Added official Gen1 Modern UI compatibility using the `gen1ModernUi` API v1 contract.
- The Modern UI screen shows the new move and all old moves with POWER and maximum PP.
- Added pointer/mouse/touch selection through Modern UI semantic actions.
- Preserved HM move protection and the normal abandon-learning confirmation flow.
- Modern UI remains optional; the original classic comparison is used as fallback.

## v1.0.0

- Added a two-column comparison panel to the move-forgetting screen.
- Shows POWER and maximum PP for the highlighted old move.
- Shows POWER and maximum PP for the new move being learned.
- Displays `---` as the power of status moves.
- Preserves the original MoveLearnMenu behavior and HM restrictions.
