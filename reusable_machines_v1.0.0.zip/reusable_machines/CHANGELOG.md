# Changelog

## 1.0.0

- TM riutilizzabili e non consumate durante l'insegnamento.
- HM dimenticabili tramite il normale menu di apprendimento.
- Nome della mossa mostrato accanto a ogni TM/HM nello zaino.
- Compatibilità difensiva con Modern Bag e flussi asincroni del menu mosse.
- Compatibilità con la pagina MOVES di Moves Manager v1.0.0.
