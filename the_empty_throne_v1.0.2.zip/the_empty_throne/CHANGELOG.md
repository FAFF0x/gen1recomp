# Changelog

## 1.0.2

- Fixed `attempt to call local 'base' (a table value)` in the Viridian Gym Guide fallback.
- Reworked `runBaseGuideTalk` so ScriptRunner row-table base conversations are routed through `ow.runner:run(...)`.
- Function-style engine talk handlers remain supported.
- Added a safe missing-runner/unsupported-type fallback so the interaction cannot hard-crash.
- Added a diagnostic `baseTalkTableSafe` export.
- Quest progression, rewards and battle content are unchanged.

## 1.0.1

- Fixed a crash when talking to the Viridian Gym Guide before defeating Giovanni.
- The vanilla Gym Guide fallback now correctly handles both function-based and ScriptRunner row-table base conversations.
- Added defensive save/runner guards around the Gym Guide override.

## 1.0.0

- Added The Empty Throne quest after the Earth Badge.
- Added the Gym Guide as a Quest System-compatible quest giver after Giovanni's disappearance.
- Added the custom Viridian Command Vault dungeon beneath Viridian Gym.
- Added four persistent security sectors and an elite Rocket succession gauntlet.
- Added consequential choices involving trapped recruits, the succession archive and Commander Vesper's fate.
- Added alternate full six-Pokemon Commander Vesper teams at levels 55-60.
- Added a level 45 Porygon reward with maximum DVs and Stat Exp.
- Added a Master Ball reward with independent full-Bag retry handling.
- Added Quest System journal, objectives, progress and markers.
