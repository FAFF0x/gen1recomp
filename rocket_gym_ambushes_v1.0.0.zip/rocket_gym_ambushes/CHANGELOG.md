# Changelog

## 1.0.0

- Otto agguati Team Rocket, uno per ogni medaglia.
- Spawn dinamico vicino all'ingresso della Palestra.
- Squadre graduate e leggermente adattive.
- Scelta di un Pokemon avversario dopo ogni vittoria.
- Invio automatico al box quando la squadra e piena.
- Checkpoint persistenti per vittoria e premio.
- Squadra finale: Dragonite, Mewtwo, Nidoking, Snorlax, Magneton e Gyarados.
