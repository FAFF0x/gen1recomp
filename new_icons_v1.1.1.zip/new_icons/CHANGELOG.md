# Changelog

## 1.1.1
- Fixes compatibility with CRYSTAL_251 and other content mods that already register per-species icons.
- Uses `icons:override()` when a species icon already exists and `icons:register()` only for new mappings.
- Keeps NEW ICONS at priority 120 so Crystal 251 (priority 110) loads its gameplay data first and NEW ICONS applies only the final icon artwork.
- No icon artwork changed.

## 1.1.0
- Adds animated menu icons for all 100 Gen 2 / Johto Pokemon (#152-251).
- Expands the icon set from 151 to 251 species while keeping the existing Gen 1 artwork unchanged.
- Generates matching 32x64 two-frame runtime sheets for every new Gen 2 APNG.
- Keeps the existing PartyMenu, Modern UI and Pokedex compatibility behavior.

## 1.0.3
- No icon artwork changed.
- Restores compatibility with the creator's original Gen1 Modern UI 0.8.x release through the separate Modern UI Icon Fix mod.
- Removes the need to install a modified Modern UI build.

## 1.0.2

- Adds documented base Pokédex icon support through Gen1 Modern UI 0.8.4+.
- Adds Pokédex Plus list icon support with Pokédex Plus 1.3.3+.
- Uses the same original full-color two-frame descriptors; no icon pixels were modified.


## 1.0.1

- Requires the corrected Gen1 Modern UI 0.8.3+ compatibility path when Modern UI is enabled.
- Full-color animated icon descriptors are now guaranteed to bypass the RBY species-palette shader in Modern UI.
- No icon artwork was recolored or regenerated; all original source/runtime image pixels remain unchanged.

## 1.0.0

- Initial release as **NEW ICONS**.
- Added animated per-species icons for all 151 Gen 1 Pokemon.
- Preserved all original APNG source assets.
- Added generated 32x64 vertical runtime sheets containing both 32x32 APNG frames pixel-for-pixel.
- Added stock PartyMenu rendering patch for 32x32 two-frame icons.
- Added true-color protection so the supplied colors are not replaced by the stock icon palette.
- Added automatic compatibility with Gen1 Modern UI 0.8.2+.
