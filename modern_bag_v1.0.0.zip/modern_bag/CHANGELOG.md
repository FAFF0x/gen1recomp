# Changelog

## [1.0.0] - 2026-07-30

### Added
- Six Left/Right inventory pockets.
- Pocket-aware cursor memory and item reordering.
- Automatic classification for built-in and modded items.
- Overworld and battle bag support.
- Vanilla item-action delegation.
