local Bag = {}
function Bag.order(save)
  save.bagOrder = save.bagOrder or {}
  return save.bagOrder
end
function Bag.add(save, id, qty)
  local isNew = save.inventory[id] == nil
  local nextQty = (save.inventory[id] or 0) + qty
  if nextQty > 99 then return false end
  save.inventory[id] = nextQty
  if isNew then table.insert(Bag.order(save), id) end
  return true
end
package.preload["src.inventory.Bag"] = function() return Bag end

local constants = { patches = {} }
function constants:patch(id, value) self.patches[id] = value end

local listeners = {}
local mod = {
  content = { constants = constants },
  events = { on = function(_, name, fn) listeners[name] = fn end },
  exports = {},
}

local chunk, err = loadfile("main.lua")
assert(chunk, err)
chunk()(mod)

assert(constants.patches.bagSize == 255)
assert(type(listeners["game.ready"]) == "function")
assert(type(mod.exports.grantAll) == "function")

local items = {}
for i = 1, 50 do
  items[("TM_MOVE_%02d"):format(i)] = {
    machine = { kind = "TM", number = i, move = ("MOVE_%02d"):format(i) },
  }
end
for i = 1, 5 do
  items[("HM_MOVE_%02d"):format(i)] = {
    machine = { kind = "HM", number = i, move = ("HM_MOVE_%02d"):format(i) },
  }
end
items.POTION = { name = "POTION" }

local writes = 0
local game = {
  data = { items = items, constants = { bagSize = 255 } },
  save = {
    inventory = { TM_MOVE_01 = 7, HM_MOVE_01 = 1 },
    bagOrder = { "TM_MOVE_01", "HM_MOVE_01" },
  },
  writeSave = function() writes = writes + 1 end,
}

listeners["game.ready"]({ game = game })

local tmCount, hmCount = 0, 0
for id, qty in pairs(game.save.inventory) do
  if id:match("^TM_") then
    tmCount = tmCount + 1
    assert(qty == 99, id .. " was not stocked to 99")
  elseif id:match("^HM_") then
    hmCount = hmCount + 1
    assert(qty == 1, id .. " was not stocked to 1")
  end
end
assert(tmCount == 50)
assert(hmCount == 5)
assert(writes == 1)
assert(#game.save.bagOrder == 55)

-- A second ready event must be idempotent and must not rewrite the save.
listeners["game.ready"]({ game = game })
assert(writes == 1)

-- Consuming a TM is repaired on the next load.
game.save.inventory.TM_MOVE_25 = 98
listeners["game.ready"]({ game = game })
assert(game.save.inventory.TM_MOVE_25 == 99)
assert(writes == 2)

local discovered = mod.exports.listMachines(game.data)
assert(#discovered == 55)
assert(discovered[1].kind == "TM" and discovered[1].number == 1)
assert(discovered[50].kind == "TM" and discovered[50].number == 50)
assert(discovered[51].kind == "HM" and discovered[51].number == 1)

print("all_tm_hm_unlocker_test: ok")
