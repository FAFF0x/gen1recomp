# Changelog

## v1.0.0

- Initial release.
- Added automatic discovery of all TM and HM item definitions.
- Added TM x99 and HM x1 stocking on game load.
- Added support for existing saves and automatic TM replenishment.
- Increased bag capacity to 255 slots.
