-- All TM & HM Unlocker
-- Grants every machine item found in the active item database.

local Bag = require("src.inventory.Bag")

local TM_QUANTITY = 99
local HM_QUANTITY = 1
local BAG_CAPACITY = 255

local function discoverMachines(data)
  local machines = {}
  for id, def in pairs((data and data.items) or {}) do
    local machine = def and def.machine
    if machine and (machine.kind == "TM" or machine.kind == "HM") then
      machines[#machines + 1] = {
        id = id,
        kind = machine.kind,
        number = tonumber(machine.number) or 0,
      }
    end
  end

  table.sort(machines, function(a, b)
    local aKind = a.kind == "TM" and 1 or 2
    local bKind = b.kind == "TM" and 1 or 2
    if aKind ~= bKind then return aKind < bKind end
    if a.number ~= b.number then return a.number < b.number end
    return a.id < b.id
  end)
  return machines
end

local function ensureMachines(game)
  if not game or not game.data or not game.save or not game.save.inventory then
    return false, 0, 0
  end

  local changed = false
  local added = 0
  local failed = 0

  for _, machine in ipairs(discoverMachines(game.data)) do
    local target = machine.kind == "TM" and TM_QUANTITY or HM_QUANTITY
    local current = tonumber(game.save.inventory[machine.id]) or 0
    if current < target then
      local amount = target - current
      if Bag.add(game.save, machine.id, amount, game.data) then
        changed = true
        added = added + amount
      else
        failed = failed + 1
      end
    end
  end

  if changed and type(game.writeSave) == "function" then
    game:writeSave()
  end

  return changed, added, failed
end

return function(mod)
  -- Fifty TMs plus five HMs exceed the original twenty-slot bag.
  mod.content.constants:patch("bagSize", BAG_CAPACITY)

  mod.events:on("game.ready", function(event)
    ensureMachines(event and event.game)
  end)

  mod.exports.grantAll = ensureMachines
  mod.exports.listMachines = discoverMachines
  mod.exports.tmQuantity = TM_QUANTITY
  mod.exports.hmQuantity = HM_QUANTITY
  mod.exports.bagCapacity = BAG_CAPACITY
end
