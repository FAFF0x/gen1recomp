# Advanced Box System v1.0.0

A modern Bill's PC storage workflow for Gen1Recomp.

## Main features

- **Instant box switching:** while using WITHDRAW, DEPOSIT, RELEASE or the box side of SWAP, press **LEFT / RIGHT** to move directly between Box 1-12. You no longer have to leave the list, choose CHANGE BOX, save, and re-enter.
- **Direct party/box SWAP:** exchange one boxed Pokemon with one party Pokemon in a single operation. The party count never changes during a swap, so this also works with a full 6-Pokemon party or a 1-Pokemon party.
- **Quick SWAP from WITHDRAW/DEPOSIT:** choosing a Pokemon in either workflow also exposes a SWAP action.
- **Browse empty/full boxes:** an empty box no longer blocks WITHDRAW, and a full box no longer blocks DEPOSIT at entry. Switch left/right until you find the box you need.
- **Release across boxes:** RELEASE also supports left/right box switching.
- **Vanilla compatibility:** CHANGE BOX and Yellow's PRINT BOX remain available.
- **Gen1 Modern UI support:** optional API v1 adapter. With Modern UI installed, the custom browser is rendered by the active Modern UI theme; without it, the mod has a complete native 160x144 interface.

## Controls

### WITHDRAW
- UP/DOWN: select boxed Pokemon
- LEFT/RIGHT: previous/next box
- A: WITHDRAW / SWAP / STATS / CANCEL
- B: back

### DEPOSIT
- UP/DOWN: select party Pokemon
- LEFT/RIGHT: change destination box immediately
- A: DEPOSIT / SWAP / STATS / CANCEL
- B: back

### SWAP
1. Select a boxed Pokemon. LEFT/RIGHT changes boxes.
2. Select the party Pokemon to exchange with it.
3. The two Pokemon are exchanged immediately.

### RELEASE
- UP/DOWN: select boxed Pokemon
- LEFT/RIGHT: previous/next box
- A: release confirmation
- B: back

## Data safety

The mod uses Gen1Recomp's existing `save.boxes`, `save.party` and `save.currentBox` structures. It does not create a parallel storage format and does not require a new save.

When a boxed Pokemon enters the party, its battle stats are rebuilt with the engine's `Stats.ensure` path, matching the stock withdraw behavior. In Yellow, depositing or swapping a party Pokemon also calls the normal `DEPOSITED` Pikachu happiness path.

## Installation

Install the `advanced_box_system` folder/ZIP as a normal Mod API 2 content mod. No dependency is required. `gen1_modern_ui` is optional.
