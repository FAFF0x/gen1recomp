# Changelog

## 1.0.0

- Replaces the stock `BoxMenu` through the screen registry.
- Adds instant LEFT/RIGHT box switching to WITHDRAW and DEPOSIT.
- Adds direct party <-> box Pokemon SWAP.
- Adds SWAP shortcuts to WITHDRAW and DEPOSIT Pokemon action menus.
- Allows browsing empty and full boxes instead of aborting the workflow.
- Adds live box switching to RELEASE.
- Preserves CHANGE BOX and Yellow PRINT BOX.
- Preserves engine stat reconstruction for Pokemon entering the party.
- Preserves Yellow deposited-Pikachu happiness handling.
- Adds optional Gen1 Modern UI API v1 compatibility.
