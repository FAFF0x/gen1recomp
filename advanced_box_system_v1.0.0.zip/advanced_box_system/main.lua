-- Advanced Box System for Gen1Recomp
-- Replaces Bill's PC BoxMenu with a modern browser:
--   * LEFT/RIGHT changes boxes instantly while browsing.
--   * WITHDRAW and DEPOSIT stay open on empty/full boxes so another box can
--     be selected without leaving the operation.
--   * SWAP exchanges a boxed Pokemon with a party Pokemon in one operation.
--   * RELEASE also supports live box switching.
--   * Optional Gen1 Modern UI API v1 presentation.

local SCREEN_ID = "AdvancedBoxBrowser"
local OWNER_ID = "advanced_box_system"
local VERSION = "1.0.0"

local function clamp(value, minimum, maximum)
  value = math.floor(tonumber(value) or minimum)
  if value < minimum then return minimum end
  if value > maximum then return maximum end
  return value
end

local function fit(text, maximum)
  text = tostring(text or "")
  if #text <= maximum then return text end
  if maximum <= 1 then return text:sub(1, maximum) end
  return text:sub(1, maximum - 1) .. "."
end

return function(mod)
  local Boxes = require("src.pokemon.Boxes")
  local Party = require("src.pokemon.Party")
  local Stats = require("src.pokemon.Stats")
  local Sound = require("src.core.Sound")
  local Strings = require("src.core.Strings")
  local GameVersion = require("src.core.GameVersion")

  local Font = mod.ui.Font
  local Theme = mod.ui.Theme
  local Menu = mod.ui.Menu
  local ListMenu = mod.ui.ListMenu
  local TextBox = mod.ui.TextBox

  local function monDef(game, mon)
    return mon and game.data.pokemon and game.data.pokemon[mon.species] or nil
  end

  local function monName(game, mon)
    local def = monDef(game, mon)
    return mon and (mon.nickname or (def and def.name) or tostring(mon.species)) or "--"
  end

  local function monRow(game, mon)
    local name = fit(monName(game, mon), 11)
    local level = mon and mon.level or 0
    return Strings("%-11s :L%3d", name, level)
  end

  local function playCry(game, mon)
    if mon and mon.species then Sound.playCry(game.data, mon.species) end
  end

  local function boxAt(game, number)
    local boxes = Boxes.ensure(game.save)
    number = clamp(number or game.save.currentBox or 1, 1, Boxes.COUNT)
    return boxes[number]
  end

  local function setCurrentBox(game, number)
    Boxes.ensure(game.save)
    number = ((math.floor(number or 1) - 1) % Boxes.COUNT) + 1
    game.save.currentBox = number
    return number
  end

  local function nextBox(game, delta)
    return setCurrentBox(game, (game.save.currentBox or 1) + delta)
  end

  local function depositedHappiness(game, mon)
    local ok, follower = pcall(require, "src.world.PikachuFollower")
    if ok and follower and type(follower.modifyHappiness) == "function" then
      follower.modifyHappiness(game.save, "DEPOSITED", mon)
    end
  end

  local Browser = {}
  Browser.__index = Browser
  Browser.isOpaque = true
  Browser.screenId = SCREEN_ID

  function Browser.new(game, mode)
    Boxes.ensure(game.save)
    local self = setmetatable({
      game = game,
      mode = mode or "withdraw",
      index = 1,
      scroll = 0,
      pendingBoxNo = nil,
      pendingBoxIndex = nil,
      pendingPartyIndex = nil,
      returnMode = nil,
      footer = nil,
    }, Browser)
    self:syncSelection()
    return self
  end

  function Browser:isBoxListMode()
    return self.mode == "withdraw"
      or self.mode == "release"
      or self.mode == "swap_box"
      or self.mode == "swap_box_target"
  end

  function Browser:isPartyListMode()
    return self.mode == "deposit" or self.mode == "swap_party"
  end

  function Browser:list()
    if self:isPartyListMode() then return self.game.save.party or {} end
    return boxAt(self.game, self.game.save.currentBox)
  end

  function Browser:visibleCount()
    return 7
  end

  function Browser:syncSelection()
    local list = self:list()
    local n = #list
    if n <= 0 then
      self.index, self.scroll = 1, 0
      return
    end
    self.index = clamp(self.index or 1, 1, n)
    local visible = self:visibleCount()
    if self.index < self.scroll + 1 then self.scroll = self.index - 1 end
    if self.index > self.scroll + visible then self.scroll = self.index - visible end
    self.scroll = clamp(self.scroll or 0, 0, math.max(0, n - visible))
  end

  function Browser:setFooter(text)
    self.footer = text
  end

  function Browser:clearFooter()
    self.footer = nil
  end

  function Browser:modeTitle()
    if self.mode == "withdraw" then return "WITHDRAW"
    elseif self.mode == "deposit" then return "DEPOSIT"
    elseif self.mode == "release" then return "RELEASE"
    elseif self.mode == "swap_box" then return "SWAP: BOX"
    elseif self.mode == "swap_party" then return "SWAP: PARTY"
    elseif self.mode == "swap_box_target" then return "SWAP: BOX" end
    return "BOX"
  end

  function Browser:boxHeader()
    local boxNo = self.game.save.currentBox or 1
    local box = boxAt(self.game, boxNo)
    return ("BOX %02d/%02d  %02d/%02d"):format(
      boxNo, Boxes.COUNT, #box, Boxes.CAPACITY)
  end

  function Browser:switchBox(delta)
    if self.mode == "swap_party" then return false end
    nextBox(self.game, delta)
    if self:isBoxListMode() then
      self.index, self.scroll = 1, 0
      self:syncSelection()
    end
    self:clearFooter()
    Sound.play(self.game.data, "Press_AB")
    return true
  end

  function Browser:move(delta)
    local list = self:list()
    local n = #list
    if n == 0 then return false end
    self.index = self.index + delta
    if self.index < 1 then self.index = n end
    if self.index > n then self.index = 1 end
    self:syncSelection()
    self:clearFooter()
    return true
  end

  function Browser:showMessage(text)
    self.game.stack:push(TextBox.new(self.game, text))
  end

  function Browser:showStats(mon)
    if not mon then return end
    mod.ui.push(self.game, "SummaryMenu", mon)
  end

  function Browser:withdrawAt(index)
    local box = boxAt(self.game, self.game.save.currentBox)
    local mon = box[index]
    if not mon then return false end
    if #self.game.save.party >= Party.MAX then
      self:setFooter("PARTY FULL - USE SWAP")
      return false
    end
    Stats.ensure(monDef(self.game, mon), mon)
    table.remove(box, index)
    table.insert(self.game.save.party, mon)
    playCry(self.game, mon)
    self.index = math.min(index, math.max(1, #box))
    self:syncSelection()
    self:showMessage(Strings("%s was taken\nout of BOX %d.",
      monName(self.game, mon), self.game.save.currentBox or 1))
    return true
  end

  function Browser:depositAt(index)
    local party = self.game.save.party or {}
    local mon = party[index]
    if not mon then return false end
    if #party <= 1 then
      self:setFooter("LAST POKEMON - USE SWAP")
      return false
    end
    local box = boxAt(self.game, self.game.save.currentBox)
    if #box >= Boxes.CAPACITY then
      self:setFooter("BOX FULL - LEFT/RIGHT")
      return false
    end
    table.remove(party, index)
    table.insert(box, mon)
    depositedHappiness(self.game, mon)
    playCry(self.game, mon)
    self.index = math.min(index, math.max(1, #party))
    self:syncSelection()
    self:showMessage(Strings("%s was stored\nin BOX %d.",
      monName(self.game, mon), self.game.save.currentBox or 1))
    return true
  end

  function Browser:releaseAt(index)
    local boxNo = self.game.save.currentBox or 1
    local box = boxAt(self.game, boxNo)
    local mon = box[index]
    if not mon then return false end
    local name = monName(self.game, mon)
    self.game.stack:push(TextBox.new(self.game,
      Strings("Release %s from\nBOX %d forever?", name, boxNo), nil, {
        defaultNo = true,
        choice = function(yes)
          if not yes then return end
          local liveBox = boxAt(self.game, boxNo)
          if liveBox[index] ~= mon then
            self:setFooter("POKEMON MOVED - TRY AGAIN")
            return
          end
          table.remove(liveBox, index)
          playCry(self.game, mon)
          self.index = math.min(index, math.max(1, #liveBox))
          self:syncSelection()
          self:showMessage(Strings("Bye %s!", name))
        end,
      }))
    return true
  end

  function Browser:beginSwapFromBox(index, returnMode)
    local boxNo = self.game.save.currentBox or 1
    local mon = boxAt(self.game, boxNo)[index]
    if not mon then return false end
    self.pendingBoxNo = boxNo
    self.pendingBoxIndex = index
    self.pendingPartyIndex = nil
    self.returnMode = returnMode or "swap_box"
    self.mode = "swap_party"
    self.index, self.scroll = 1, 0
    self:syncSelection()
    self:setFooter("CHOOSE PARTY POKEMON")
    return true
  end

  function Browser:beginSwapFromParty(index)
    local mon = self.game.save.party and self.game.save.party[index]
    if not mon then return false end
    self.pendingPartyIndex = index
    self.pendingBoxNo = nil
    self.pendingBoxIndex = nil
    self.returnMode = "deposit"
    self.mode = "swap_box_target"
    self.index, self.scroll = 1, 0
    self:syncSelection()
    self:setFooter("CHOOSE BOX POKEMON")
    return true
  end

  function Browser:finishSwap(boxNo, boxIndex, partyIndex)
    local party = self.game.save.party or {}
    local box = boxAt(self.game, boxNo)
    local boxMon = box[boxIndex]
    local partyMon = party[partyIndex]
    if not boxMon or not partyMon then
      self:setFooter("SWAP TARGET CHANGED")
      return false
    end

    Stats.ensure(monDef(self.game, boxMon), boxMon)
    box[boxIndex] = partyMon
    party[partyIndex] = boxMon
    depositedHappiness(self.game, partyMon)
    playCry(self.game, boxMon)

    local boxName = monName(self.game, boxMon)
    local partyName = monName(self.game, partyMon)
    local back = self.returnMode or "swap_box"
    self.mode = back
    self.pendingBoxNo, self.pendingBoxIndex, self.pendingPartyIndex = nil, nil, nil
    self.returnMode = nil
    if self.mode == "swap_box" or self.mode == "withdraw" or self.mode == "release" then
      setCurrentBox(self.game, boxNo)
      self.index = math.min(boxIndex, math.max(1, #box))
    else
      self.index = math.min(partyIndex, math.max(1, #party))
    end
    self.scroll = 0
    self:syncSelection()
    self:showMessage(Strings("%s joined the party.\n%s moved to BOX %d.",
      boxName, partyName, boxNo))
    return true
  end

  function Browser:activate(index)
    self:clearFooter()
    local list = self:list()
    if #list == 0 then
      self:setFooter(self:isPartyListMode() and "PARTY IS EMPTY" or "BOX IS EMPTY")
      return false
    end
    index = clamp(index or self.index or 1, 1, #list)
    self.index = index
    local mon = list[index]
    if not mon then return false end

    if self.mode == "withdraw" then
      local screen = self
      self.game.stack:push(Menu.new(self.game, {
        { label = "WITHDRAW", onSelect = function() screen:withdrawAt(index) end },
        { label = "SWAP", onSelect = function() screen:beginSwapFromBox(index, "withdraw") end },
        { label = "STATS", keepOpen = true, onSelect = function() screen:showStats(mon) end },
        { label = "CANCEL" },
      }, { tx = 9, ty = 8, tw = 11, th = 10, noSound = true }))
      return true
    elseif self.mode == "deposit" then
      local screen = self
      self.game.stack:push(Menu.new(self.game, {
        { label = "DEPOSIT", onSelect = function() screen:depositAt(index) end },
        { label = "SWAP", onSelect = function() screen:beginSwapFromParty(index) end },
        { label = "STATS", keepOpen = true, onSelect = function() screen:showStats(mon) end },
        { label = "CANCEL" },
      }, { tx = 9, ty = 8, tw = 11, th = 10, noSound = true }))
      return true
    elseif self.mode == "release" then
      return self:releaseAt(index)
    elseif self.mode == "swap_box" then
      return self:beginSwapFromBox(index, "swap_box")
    elseif self.mode == "swap_party" then
      if not (self.pendingBoxNo and self.pendingBoxIndex) then
        self.mode = "swap_box"
        self:setFooter("SELECT BOX POKEMON AGAIN")
        return false
      end
      return self:finishSwap(self.pendingBoxNo, self.pendingBoxIndex, index)
    elseif self.mode == "swap_box_target" then
      if not self.pendingPartyIndex then
        self.mode = "deposit"
        self:setFooter("SELECT PARTY POKEMON AGAIN")
        return false
      end
      return self:finishSwap(self.game.save.currentBox or 1, index,
        self.pendingPartyIndex)
    end
    return false
  end

  function Browser:back()
    if self.mode == "swap_party" then
      local boxNo = self.pendingBoxNo or self.game.save.currentBox or 1
      local boxIndex = self.pendingBoxIndex or 1
      setCurrentBox(self.game, boxNo)
      self.mode = self.returnMode or "swap_box"
      self.pendingBoxNo, self.pendingBoxIndex, self.pendingPartyIndex = nil, nil, nil
      self.returnMode = nil
      self.index, self.scroll = boxIndex, 0
      self:syncSelection()
      self:clearFooter()
      return true
    elseif self.mode == "swap_box_target" then
      local partyIndex = self.pendingPartyIndex or 1
      self.mode = "deposit"
      self.pendingBoxNo, self.pendingBoxIndex, self.pendingPartyIndex = nil, nil, nil
      self.returnMode = nil
      self.index, self.scroll = partyIndex, 0
      self:syncSelection()
      self:clearFooter()
      return true
    end
    self.game.stack:pop()
    return true
  end

  function Browser:update(dt)
    local input = self.game.input
    if input:wasPressed("left") then
      self:switchBox(-1)
    elseif input:wasPressed("right") then
      self:switchBox(1)
    elseif input:wasPressed("up") then
      self:move(-1)
    elseif input:wasPressed("down") then
      self:move(1)
    elseif input:wasPressed("a") then
      self:activate(self.index)
    elseif input:wasPressed("b") then
      self:back()
    end
  end

  function Browser:draw()
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.rectangle("fill", 0, 0, 160, 144)

    -- Header
    Font.drawBox(0, 0, 20, 5)
    love.graphics.setColor(0, 0, 0, 1)
    Font.draw(Strings(self:modeTitle()), 8, 8)
    Font.draw(Strings(self:boxHeader()), 8, 24)

    -- Pokemon list
    Font.drawBox(0, 4, 20, 11)
    local list = self:list()
    local visible = self:visibleCount()
    if #list == 0 then
      Font.draw(Strings(self:isPartyListMode() and "No party POKéMON." or "This BOX is empty."),
        16, 56)
    else
      local first = self.scroll + 1
      local last = math.min(#list, self.scroll + visible)
      for i = first, last do
        local row = i - self.scroll
        Font.draw(monRow(self.game, list[i]), 24, 36 + row * 12)
      end
      local cursorY = 36 + (self.index - self.scroll) * 12
      Font.drawCode(Theme.cursor, 8, cursorY)
    end

    -- Footer / controls
    Font.drawBox(0, 14, 20, 4)
    love.graphics.setColor(0, 0, 0, 1)
    local footer = self.footer
    if not footer then
      if self.mode == "swap_party" then
        footer = "A SWAP   B BACK"
      elseif self.mode == "swap_box" or self.mode == "swap_box_target" then
        footer = "L/R BOX  A SELECT"
      elseif self.mode == "release" then
        footer = "L/R BOX  A RELEASE"
      else
        footer = "L/R BOX  A OPTIONS"
      end
    end
    Font.draw(Strings(fit(footer, 19)), 8, 124)
    if self.mode ~= "swap_party" then
      Font.draw(Strings("B BACK"), 104, 136)
    end
    love.graphics.setColor(1, 1, 1, 1)
  end

  local function openBrowser(game, mode)
    mod.ui.push(game, SCREEN_ID, mode)
  end

  local function changeBox(game)
    local boxes = Boxes.ensure(game.save)
    local items = {}
    for i = 1, Boxes.COUNT do
      local mark = i == (game.save.currentBox or 1) and "*" or " "
      items[#items + 1] = {
        label = Strings("%sBOX %2d", mark, i),
        right = ("%d/%d"):format(#boxes[i], Boxes.CAPACITY),
        value = i,
      }
    end
    game.stack:push(ListMenu.new(game, "CHANGE BOX", items, {
      noSound = true,
      onChoose = function(item, list)
        setCurrentBox(game, item.value)
        if game.writeSave then game:writeSave() end
        list:close()
      end,
    }))
  end

  local function printBox(game)
    local box = boxAt(game, game.save.currentBox)
    local Printer = require("src.core.Printer")
    local h = 32 + math.max(1, #box) * 10
    local saved, err = Printer.save("box_" .. (game.save.currentBox or 1),
      160, h, function()
        love.graphics.setColor(1, 1, 1, 1)
        love.graphics.rectangle("fill", 0, 0, 160, h)
        love.graphics.setColor(0, 0, 0, 1)
        Font.draw(Strings("BOX No.%d", game.save.currentBox or 1), 8, 8)
        if #box == 0 then Font.draw(Strings("Empty."), 8, 24) end
        for i, mon in ipairs(box) do
          local def = monDef(game, mon)
          Font.draw(mon.nickname or (def and def.name) or tostring(mon.species),
            8, 14 + i * 10)
          Font.draw(Strings(":L%d No.%03d", mon.level or 0,
            def and def.dex or 0), 88, 14 + i * 10)
        end
        love.graphics.setColor(1, 1, 1, 1)
      end)
    game.stack:push(TextBox.new(game, saved
      and Strings("Printed BOX %d!\fSaved as\n%s\vin the save\nfolder.",
        game.save.currentBox or 1, saved)
      or Strings("Printer error!\n%s", tostring(err))))
  end

  local function mainMenu(game)
    Boxes.ensure(game.save)
    local items = {
      { label = Strings("WITHDRAW <PK><MN>"), keepOpen = true,
        onSelect = function() openBrowser(game, "withdraw") end },
      { label = Strings("DEPOSIT <PK><MN>"), keepOpen = true,
        onSelect = function() openBrowser(game, "deposit") end },
      { label = Strings("SWAP <PK><MN>"), keepOpen = true,
        onSelect = function() openBrowser(game, "swap_box") end },
      { label = Strings("RELEASE <PK><MN>"), keepOpen = true,
        onSelect = function() openBrowser(game, "release") end },
      { label = Strings("CHANGE BOX"), keepOpen = true,
        onSelect = function() changeBox(game) end },
    }
    if GameVersion.isYellow() then
      items[#items + 1] = { label = Strings("PRINT BOX"), keepOpen = true,
        onSelect = function() printBox(game) end }
    end
    items[#items + 1] = { label = Strings("SEE YA!") }

    local menu = Menu.new(game, items,
      { tx = 0, ty = 0, tw = 14, th = math.min(18, #items * 2 + 2), noSound = true })
    local baseDraw = menu.draw
    function menu:draw()
      baseDraw(self)
      Font.drawBox(12, 12, 8, 6)
      love.graphics.setColor(0, 0, 0, 1)
      Font.draw(Strings("BOX"), 104, 104)
      Font.draw(Strings("%02d/%02d", game.save.currentBox or 1, Boxes.COUNT), 104, 120)
      local box = boxAt(game, game.save.currentBox)
      Font.draw(Strings("%02d/%02d", #box, Boxes.CAPACITY), 104, 136)
      love.graphics.setColor(1, 1, 1, 1)
    end
    return menu
  end

  -- Modern UI compatibility: this screen remains the owner of all storage
  -- mutations. Modern UI only renders its live model and sends semantic input.
  local function modernRows(state)
    local rows = {}
    for _, mon in ipairs(state:list()) do
      rows[#rows + 1] = {
        label = monName(state.game, mon),
        value = ("Lv.%d"):format(mon.level or 0),
        enabled = true,
      }
    end
    if #rows == 0 then
      rows[1] = {
        label = state:isPartyListMode() and "NO PARTY POKEMON" or "EMPTY BOX",
        value = "--",
        enabled = false,
      }
    end
    return rows
  end

  local function modernModel(state)
    local rows = modernRows(state)
    local actual = #state:list()
    local boxNo = state.game.save.currentBox or 1
    local box = boxAt(state.game, boxNo)
    local title = ("%s  BOX %02d/%02d  %d/%d"):format(
      state:modeTitle(), boxNo, Boxes.COUNT, #box, Boxes.CAPACITY)
    local footer
    if state.mode == "swap_party" then
      footer = { "A SWAP", "B BACK" }
    elseif state.mode == "swap_box" or state.mode == "swap_box_target" then
      footer = { "LEFT/RIGHT BOX", "A SELECT", "B BACK" }
    elseif state.mode == "release" then
      footer = { "LEFT/RIGHT BOX", "A RELEASE", "B BACK" }
    else
      footer = { "LEFT/RIGHT BOX", "A OPTIONS", "B BACK" }
    end
    if state.footer then footer = { state.footer, "B BACK" } end
    return {
      title = title,
      rows = rows,
      index = actual > 0 and clamp(state.index or 1, 1, actual) or 1,
      scroll = state.scroll or 0,
      footer = footer,
    }
  end

  local modernUiContract = {
    apiVersion = 1,
    screens = {
      advanced_box_system = {
        match = function(state)
          return type(state) == "table" and state.screenId == SCREEN_ID
            and type(state.mode) == "string" and type(state.game) == "table"
        end,
        canSuppressNative = true,
        model = function(_, state) return modernModel(state) end,
        actions = {
          hover = function(_, state, index)
            local n = #state:list()
            index = math.floor(tonumber(index) or 0)
            if n <= 0 or index < 1 or index > n then return false end
            state.index = index
            state:syncSelection()
            return true
          end,
          select = function(_, state, index)
            local n = #state:list()
            index = math.floor(tonumber(index) or state.index or 1)
            if n <= 0 then
              state:activate(1)
              return true
            end
            state.index = clamp(index, 1, n)
            state:syncSelection()
            return state:activate(state.index) ~= false
          end,
          up = function(_, state) return state:move(-1) end,
          down = function(_, state) return state:move(1) end,
          left = function(_, state) return state:switchBox(-1) end,
          right = function(_, state) return state:switchBox(1) end,
          back = function(_, state) return state:back() end,
        },
      },
    },
  }

  local modernUiExports
  local modernUiRegistered = false
  local function ensureModernUiAdapter()
    if type(mod.find) ~= "function" then return false end
    local okFind, handle = pcall(mod.find, "gen1_modern_ui")
    if not okFind or type(handle) ~= "table" or type(handle.exports) ~= "table" then
      modernUiExports, modernUiRegistered = nil, false
      return false
    end
    local ex = handle.exports
    if tonumber(ex.compatibilityApiVersion or 1) ~= 1
        or type(ex.registerAdapter) ~= "function" then
      modernUiExports, modernUiRegistered = ex, false
      return false
    end
    if modernUiRegistered and modernUiExports == ex then return true end
    local ok, registered, reason = pcall(ex.registerAdapter, {
      owner = OWNER_ID,
      version = VERSION,
      contract = modernUiContract,
    })
    if ok and registered ~= false then
      modernUiExports, modernUiRegistered = ex, true
      return true
    end
    modernUiExports, modernUiRegistered = ex, false
    if mod.log then
      mod.log:warn("Gen1 Modern UI adapter unavailable: %s",
        tostring(ok and reason or registered))
    end
    return false
  end

  mod.exports.gen1ModernUi = modernUiContract
  mod.exports.ensureModernUiAdapter = ensureModernUiAdapter
  mod.exports.open = function(game, mode) openBrowser(game, mode or "swap_box") end

  mod.content.screens:register(SCREEN_ID, {
    new = function(game, mode)
      ensureModernUiAdapter()
      return Browser.new(game, mode)
    end,
  })

  -- Engine PCMainMenu opens screen id "BoxMenu". A mod-owned screen record
  -- takes precedence over the builtin, so this replaces Bill's PC cleanly
  -- without patching engine files.
  mod.content.screens:register("BoxMenu", {
    new = function(game)
      ensureModernUiAdapter()
      return mainMenu(game)
    end,
  })

  mod.events:on("game.ready", function()
    ensureModernUiAdapter()
  end)

  ensureModernUiAdapter()
end
