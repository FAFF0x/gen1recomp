-- Static contract notes for maintainers.
-- Expected engine contracts used by Advanced Box System:
--   Screens.push(game, "BoxMenu") resolves mod-owned screen records first.
--   Boxes.COUNT == 12 and Boxes.CAPACITY == 20 in the current engine.
--   save.party and save.boxes contain Pokemon tables.
--   Stats.ensure(speciesDef, mon) reconstructs party stat blocks.
--   Gen1 Modern UI optional adapter API version == 1.
return true
