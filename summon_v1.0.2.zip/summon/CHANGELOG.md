# Changelog

## 1.0.2
- Rifatta l'integrazione con Gen1 Modern UI: il selettore non viene più trasformato in una lista verticale.
- Il numero Pokédex viene ora inserito con un vero tastierino a griglia 3 colonne, con tasti grandi e cliccabili/toccabili.
- Aggiunto campo numerico a tre cifre nel presenter moderno.
- DEL cancella una cifra, SELECT/CLEAR azzera il numero, START/OK conferma e B/CANCEL esce.
- Restano disponibili l'inserimento diretto da tastiera 0-9, Backspace, Invio ed Esc.
- Modern UI continua a essere opzionale e la UI classica rimane il fallback.

## 1.0.1
- Aggiunta compatibilità opzionale con Gen1 Modern UI 0.8.1 tramite `gen1ModernUi` API v1.
- Il selettore SUMMON può essere presentato con tema, frame, scaling e layout di Modern UI.
- Aggiunto supporto pointer/click per i tasti numerici, DEL, OK e CANCEL.
- I controlli originali da tastiera/controller restano invariati e la UI classica rimane il fallback.

## 1.0.0
- Aggiunta la voce SUMMON al menu Start.
- Aggiunto tastierino numerico Pokédex con supporto tastiera.
- Avvio di incontri selvatici con livello pari al primo Pokémon sano.
- Supporto alle specie aggiunte da altre mod e alle regole della Zona Safari.
