# Summon

Aggiunge **SUMMON** al menu Start di Gen1Recomp.

## Uso

1. Apri il menu Start.
2. Seleziona **SUMMON**.
3. Inserisci un numero Pokédex con il tastierino oppure con i tasti numerici.
4. Seleziona **OK** o premi START/Invio.
5. Inizia un incontro selvatico con il Pokémon corrispondente.

Il Pokémon evocato ha lo stesso livello del primo Pokémon sano della squadra. La mod usa il registro Pokémon unificato, quindi riconosce anche specie aggiunte da altre mod che possiedono un numero Pokédex valido.

Comandi: frecce per muoversi, A per selezionare, **DEL** per cancellare una cifra, SELECT per pulire tutto il numero, START per confermare e B per annullare. Da tastiera sono supportati direttamente 0-9, Backspace, Invio ed Esc.

La mod non regala direttamente il Pokémon: bisogna catturarlo normalmente. In Zona Safari mantiene le regole Safari.


## Compatibilità con Gen1 Modern UI

Dalla versione **1.0.2**, SUMMON espone il tastierino numerico come una vera
griglia compatibile con il presenter tastiera di Gen1 Modern UI. Con Modern UI
attiva i numeri non vengono più appiattiti in una lista verticale: vengono
mostrati come tasti separati e grandi in disposizione da tastierino/calcolatrice:

```text
1   2   3
4   5   6
7   8   9
DEL 0   OK
CANCEL
```

Ogni tasto può essere selezionato con controller/tastiera oppure cliccato/toccato
direttamente. Il campo di tre cifre è mostrato sopra il tastierino. **DEL**
cancella una cifra, **SELECT/CLEAR** azzera il numero e **START/OK** conferma.

Modern UI resta opzionale: senza di essa SUMMON continua a usare il proprio
tastierino classico.
