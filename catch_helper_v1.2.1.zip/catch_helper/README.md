# Catch Helper 1.2.1

Mostra le probabilità di cattura e, per i Pokémon già posseduti, una Poké Ball nell’HUD della battaglia.

## Opzioni

Aprire `MODS → Catch Helper → OPTIONS`: 

- `SHOW POKEBALL`: mostra o nasconde soltanto la Poké Ball;
- `SHOW CATCH TEXT`: mostra o nasconde soltanto il testo delle probabilità.

Entrambe le opzioni sono attive per impostazione predefinita e sono indipendenti. Non sono presenti opzioni di posizione.

La mod non modifica formule di cattura, inventario, IA o salvataggi. Disabilitare le versioni precedenti prima dell’installazione.
