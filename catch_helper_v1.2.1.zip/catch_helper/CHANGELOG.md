# Changelog

## 1.2.1

- Aggiunta l’opzione `SHOW POKEBALL`.
- Aggiunta l’opzione `SHOW CATCH TEXT`.
- I due elementi possono essere attivati o disattivati indipendentemente.
- Entrambe le opzioni sono attive per impostazione predefinita.
- Nessuna opzione di posizione o offset.

## 1.2.0

- Ricostruito il percorso di rendering sul canvas UI.
