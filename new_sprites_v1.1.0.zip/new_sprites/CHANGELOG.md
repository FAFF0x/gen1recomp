# Changelog

## 1.1.0

- Added animated front sprites for all 100 Generation II Pokemon (#152-251).
- Preserved all existing Generation I front/back assets and animation behavior.
- Added support for front-only species records so Generation II back-sprite requests fall through to the active content mod instead of showing an incorrect front sprite.
- Added CRYSTAL_251 compatibility notes; NEW SPRITES priority 130 applies after CRYSTAL_251 priority 110.
- Converted 5,331 Generation II GIF source frames to 3,301 unique lossless PNG runtime frames.
- Preserved GIF timing on the existing 30 Hz animation clock using cumulative duration conversion.

## 1.0.1

- Slowed sprite animation playback from 60 Hz to 30 Hz.
- Animations now run at 50% of the previous speed while preserving the original frame sequence and image quality.

## 1.0.0

- Initial NEW SPRITES release.
- Added all 151 Kanto front Gen 5 animation atlases.
- Added all 151 Kanto back Gen 5 animation atlases.
- Added 60 Hz repeated-cell timeline playback.
- Added lossless per-species frame deduplication.
- Added full-color true-color rendering through `pokemon.sprite`.
- Added Advanced Box System / Modern UI selected-Pokemon preview support.
- Native battle images are intentionally left untouched because BattleState caches them at battle start.
