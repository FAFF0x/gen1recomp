# HM Anywhere

HM Anywhere turns owned HM items into field tools, so a Pokemon never has to spend a move slot on CUT, FLY, SURF, STRENGTH or FLASH.

## Controls

- Face a cuttable tree or grass patch and press **A** to use CUT.
- Face water and press **A** to use SURF. Press **A** toward land to dismount.
- Face a pushable boulder and press **A** to use STRENGTH and push it.
- In a dark map, press **A** on empty space to use FLASH.
- Outdoors, open Start and select **FLY** with **A** to open the normal fly map.

The corresponding HM item and the normal badge are still required. HM items remain teachable for battle use, but teaching them is optional. Field HM rows are removed from the Pokemon submenu.

The mod detects HMs through each item's `machine.kind = "HM"` and `machine.move` fields, including compatible items added by other mods.
