# Changelog

## 1.0.0

- Added inventory-based CUT, SURF, STRENGTH, FLASH and FLY field actions.
- Added contextual A-button activation for CUT, SURF, STRENGTH and FLASH.
- Added an outdoor FLY entry to the Start menu.
- Preserved badge requirements and normal field restrictions.
- Removed redundant HM field-action rows from Pokemon submenus.
