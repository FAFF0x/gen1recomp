-- MODERN BATTLE UI v1.2.4
--
-- Standalone high-resolution battle presentation for Gen1Recomp.
-- It intentionally does NOT replace BattleState, battle logic, callbacks,
-- damage, menus, or BATTLE ART's 3D scene. The source battle remains the
-- authority; this mod only:
--   * hides the classic battle-owned HUD/bottom layer through public hooks;
--   * opts standard battles into the engine's public 2x2 move-grid navigation;
--   * paints a responsive screen-space HUD through render.hud.
--
-- This design makes it usable over classic, WIDE, WORLD and staged voxel
-- battles without relying on Gen1 Modern UI's experimental Battle presenter.

local MOD_ID = "modern_battle_ui"
local VERSION = "1.2.4"
local unpackValues = table.unpack or unpack

local THEMES = {
  midnight = {
    surface = { 0.035, 0.050, 0.078, 0.96 },
    raised = { 0.060, 0.082, 0.120, 0.98 },
    soft = { 0.105, 0.135, 0.185, 0.96 },
    selected = { 0.115, 0.285, 0.470, 0.98 },
    accent = { 0.35, 0.70, 1.00, 1.00 },
    text = { 0.96, 0.98, 1.00, 1.00 },
    muted = { 0.64, 0.70, 0.79, 1.00 },
    border = { 0.22, 0.30, 0.41, 1.00 },
    shadow = { 0.00, 0.00, 0.00, 0.34 },
    hpTrack = { 0.12, 0.16, 0.22, 1.00 },
  },
  graphite = {
    surface = { 0.080, 0.085, 0.100, 0.96 },
    raised = { 0.115, 0.120, 0.140, 0.98 },
    soft = { 0.160, 0.165, 0.190, 0.96 },
    selected = { 0.240, 0.255, 0.300, 0.98 },
    accent = { 0.80, 0.86, 0.96, 1.00 },
    text = { 0.98, 0.98, 0.99, 1.00 },
    muted = { 0.68, 0.69, 0.74, 1.00 },
    border = { 0.30, 0.31, 0.36, 1.00 },
    shadow = { 0.00, 0.00, 0.00, 0.36 },
    hpTrack = { 0.17, 0.18, 0.21, 1.00 },
  },
  light = {
    surface = { 0.955, 0.965, 0.980, 0.97 },
    raised = { 1.000, 1.000, 1.000, 0.99 },
    soft = { 0.875, 0.900, 0.935, 0.98 },
    selected = { 0.800, 0.890, 0.980, 0.99 },
    accent = { 0.10, 0.42, 0.78, 1.00 },
    text = { 0.08, 0.10, 0.14, 1.00 },
    muted = { 0.35, 0.39, 0.47, 1.00 },
    border = { 0.66, 0.71, 0.79, 1.00 },
    shadow = { 0.00, 0.00, 0.00, 0.20 },
    hpTrack = { 0.76, 0.79, 0.84, 1.00 },
  },
  crimson = {
    surface = { 0.070, 0.035, 0.045, 0.96 },
    raised = { 0.115, 0.050, 0.065, 0.98 },
    soft = { 0.175, 0.080, 0.095, 0.96 },
    selected = { 0.345, 0.090, 0.120, 0.98 },
    accent = { 1.00, 0.35, 0.42, 1.00 },
    text = { 1.00, 0.97, 0.98, 1.00 },
    muted = { 0.78, 0.64, 0.68, 1.00 },
    border = { 0.42, 0.18, 0.23, 1.00 },
    shadow = { 0.00, 0.00, 0.00, 0.36 },
    hpTrack = { 0.19, 0.10, 0.12, 1.00 },
  },
}

local TYPE_COLORS = {
  NORMAL   = { 0.60, 0.61, 0.53, 1 },
  FIRE     = { 0.93, 0.31, 0.20, 1 },
  WATER    = { 0.25, 0.51, 0.93, 1 },
  ELECTRIC = { 0.95, 0.76, 0.16, 1 },
  GRASS    = { 0.35, 0.70, 0.29, 1 },
  ICE      = { 0.43, 0.78, 0.83, 1 },
  FIGHTING = { 0.75, 0.20, 0.18, 1 },
  POISON   = { 0.62, 0.27, 0.67, 1 },
  GROUND   = { 0.78, 0.63, 0.30, 1 },
  FLYING   = { 0.52, 0.65, 0.89, 1 },
  PSYCHIC  = { 0.95, 0.32, 0.56, 1 },
  BUG      = { 0.58, 0.68, 0.17, 1 },
  ROCK     = { 0.67, 0.56, 0.25, 1 },
  GHOST    = { 0.43, 0.38, 0.65, 1 },
  DRAGON   = { 0.42, 0.35, 0.86, 1 },
  DARK     = { 0.38, 0.30, 0.26, 1 },
  STEEL    = { 0.48, 0.58, 0.64, 1 },
  FAIRY    = { 0.88, 0.49, 0.68, 1 },
}

local STATUS_COLORS = {
  PAR = { 0.93, 0.72, 0.16, 1 },
  PSN = { 0.64, 0.28, 0.72, 1 },
  TOX = { 0.56, 0.20, 0.65, 1 },
  BRN = { 0.92, 0.33, 0.18, 1 },
  SLP = { 0.43, 0.49, 0.60, 1 },
  FRZ = { 0.35, 0.74, 0.88, 1 },
}

local STATUS_NAMES = {
  PARALYSIS = "PAR", PARALYZED = "PAR", PAR = "PAR",
  POISON = "PSN", POISONED = "PSN", PSN = "PSN",
  TOXIC = "TOX", BADLY_POISONED = "TOX", TOX = "TOX",
  BURN = "BRN", BURNED = "BRN", BRN = "BRN",
  SLEEP = "SLP", ASLEEP = "SLP", SLP = "SLP",
  FREEZE = "FRZ", FROZEN = "FRZ", FRZ = "FRZ",
}

local ACTIONS = {
  [1] = { id = "fight",   label = "FIGHT",   sub = "Moves",  icon = "fight" },
  [2] = { id = "pokemon", label = "POKEMON", sub = "Party",  icon = "pokemon" },
  [3] = { id = "bag",     label = "BAG",     sub = "Items",  icon = "bag" },
  [4] = { id = "run",     label = "RUN",     sub = "Escape", icon = "run" },
}

-- BattleState remains the action authority.  We only change the *visual and
-- directional* order to a true one-dimensional strip:
-- FIGHT -> BAG -> POKEMON -> RUN.
-- Each slot still stores the source BattleState menuIndex, so pressing A
-- invokes the original callback for the label currently highlighted.
local HORIZONTAL_ACTION_ORDER = { 1, 3, 2, 4 }


local ITEM_HELP = {
  POTION = "Restores 20 HP to one Pokémon.",
  SUPER_POTION = "Restores 50 HP to one Pokémon.",
  HYPER_POTION = "Restores 200 HP to one Pokémon.",
  MAX_POTION = "Fully restores the HP of one Pokémon.",
  FULL_RESTORE = "Fully restores HP and cures status conditions.",
  FRESH_WATER = "Restores 50 HP to one Pokémon.",
  SODA_POP = "Restores 60 HP to one Pokémon.",
  LEMONADE = "Restores 80 HP to one Pokémon.",

  ANTIDOTE = "Cures poisoning.",
  BURN_HEAL = "Cures a burn.",
  ICE_HEAL = "Thaws a frozen Pokémon.",
  AWAKENING = "Wakes a sleeping Pokémon.",
  PARLYZ_HEAL = "Cures paralysis.",
  PARALYZE_HEAL = "Cures paralysis.",
  FULL_HEAL = "Cures all major status conditions.",

  REVIVE = "Revives a fainted Pokémon with half of its maximum HP.",
  MAX_REVIVE = "Revives a fainted Pokémon with all of its HP.",
  ETHER = "Restores 10 PP to one selected move.",
  MAX_ETHER = "Fully restores PP to one selected move.",
  ELIXER = "Restores 10 PP to every move of one Pokémon.",
  ELIXIR = "Restores 10 PP to every move of one Pokémon.",
  MAX_ELIXER = "Fully restores PP to every move of one Pokémon.",
  MAX_ELIXIR = "Fully restores PP to every move of one Pokémon.",

  POKE_BALL = "A standard Ball used to catch wild Pokémon.",
  GREAT_BALL = "A Ball with a better catch rate than a Poké Ball.",
  ULTRA_BALL = "A high-performance Ball with a strong catch rate.",
  MASTER_BALL = "The ultimate Ball. It catches a wild Pokémon without fail.",
  SAFARI_BALL = "A special Ball used during Safari encounters.",

  X_ATTACK = "Raises the active Pokémon's Attack during battle.",
  X_DEFEND = "Raises the active Pokémon's Defense during battle.",
  X_DEFENSE = "Raises the active Pokémon's Defense during battle.",
  X_SPEED = "Raises the active Pokémon's Speed during battle.",
  X_SPECIAL = "Raises the active Pokémon's Special during battle.",
  X_SP_ATK = "Raises the active Pokémon's Special Attack during battle.",
  X_ACCURACY = "Raises the active Pokémon's Accuracy during battle.",
  DIRE_HIT = "Raises the user's critical-hit rate during battle.",
  GUARD_SPEC = "Protects the active Pokémon from stat reductions during battle.",

  POKE_DOLL = "Use in a wild battle to escape from the encounter.",
  POKE_FLUTE = "A reusable flute. In battle it wakes sleeping Pokémon.",
  ESCAPE_ROPE = "Escapes from certain caves and dungeons outside battle.",

  REPEL = "Repels weaker wild Pokémon for a limited number of steps.",
  SUPER_REPEL = "Repels weaker wild Pokémon longer than a Repel.",
  MAX_REPEL = "Repels weaker wild Pokémon for the longest duration.",

  RARE_CANDY = "Raises one Pokémon by one level.",
  PP_UP = "Permanently increases the maximum PP of one move.",
  HP_UP = "Permanently increases HP stat experience.",
  PROTEIN = "Permanently increases Attack stat experience.",
  IRON = "Permanently increases Defense stat experience.",
  CARBOS = "Permanently increases Speed stat experience.",
  CALCIUM = "Permanently increases Special stat experience.",

  FIRE_STONE = "A special stone that evolves certain Pokémon.",
  WATER_STONE = "A special stone that evolves certain Pokémon.",
  THUNDER_STONE = "A special stone that evolves certain Pokémon.",
  LEAF_STONE = "A special stone that evolves certain Pokémon.",
  MOON_STONE = "A mysterious stone that evolves certain Pokémon.",

  BICYCLE = "A folding bicycle used for faster travel outside battle.",
  TOWN_MAP = "Displays the regional map.",
  ITEMFINDER = "Detects hidden items nearby.",
  DOWSING_MACHINE = "Detects hidden items nearby.",
  COIN_CASE = "Stores coins used at the Game Corner.",
  OLD_ROD = "A fishing rod for catching Pokémon in water.",
  GOOD_ROD = "A good fishing rod for catching Pokémon in water.",
  SUPER_ROD = "The best fishing rod for catching Pokémon in water.",
}

local TYPE_EFFECTIVENESS = {
  NORMAL   = { ROCK = 0.5, GHOST = 0, STEEL = 0.5 },
  FIRE     = { FIRE = 0.5, WATER = 0.5, GRASS = 2, ICE = 2, BUG = 2, ROCK = 0.5, DRAGON = 0.5, STEEL = 2 },
  WATER    = { FIRE = 2, WATER = 0.5, GRASS = 0.5, GROUND = 2, ROCK = 2, DRAGON = 0.5 },
  ELECTRIC = { WATER = 2, ELECTRIC = 0.5, GRASS = 0.5, GROUND = 0, FLYING = 2, DRAGON = 0.5 },
  GRASS    = { FIRE = 0.5, WATER = 2, GRASS = 0.5, POISON = 0.5, GROUND = 2, FLYING = 0.5, BUG = 0.5, ROCK = 2, DRAGON = 0.5, STEEL = 0.5 },
  ICE      = { FIRE = 0.5, WATER = 0.5, GRASS = 2, ICE = 0.5, GROUND = 2, FLYING = 2, DRAGON = 2, STEEL = 0.5 },
  FIGHTING = { NORMAL = 2, ICE = 2, POISON = 0.5, FLYING = 0.5, PSYCHIC = 0.5, BUG = 0.5, ROCK = 2, GHOST = 0, DARK = 2, STEEL = 2, FAIRY = 0.5 },
  POISON   = { GRASS = 2, POISON = 0.5, GROUND = 0.5, ROCK = 0.5, GHOST = 0.5, STEEL = 0, FAIRY = 2 },
  GROUND   = { FIRE = 2, ELECTRIC = 2, GRASS = 0.5, POISON = 2, FLYING = 0, BUG = 0.5, ROCK = 2, STEEL = 2 },
  FLYING   = { ELECTRIC = 0.5, GRASS = 2, FIGHTING = 2, BUG = 2, ROCK = 0.5, STEEL = 0.5 },
  PSYCHIC  = { FIGHTING = 2, POISON = 2, PSYCHIC = 0.5, DARK = 0, STEEL = 0.5 },
  BUG      = { FIRE = 0.5, GRASS = 2, FIGHTING = 0.5, POISON = 0.5, FLYING = 0.5, PSYCHIC = 2, GHOST = 0.5, DARK = 2, STEEL = 0.5, FAIRY = 0.5 },
  ROCK     = { FIRE = 2, ICE = 2, FIGHTING = 0.5, GROUND = 0.5, FLYING = 2, BUG = 2, STEEL = 0.5 },
  GHOST    = { NORMAL = 0, PSYCHIC = 2, GHOST = 2, DARK = 0.5 },
  DRAGON   = { DRAGON = 2, STEEL = 0.5, FAIRY = 0 },
  DARK     = { FIGHTING = 0.5, PSYCHIC = 2, GHOST = 2, DARK = 0.5, FAIRY = 0.5 },
  STEEL    = { FIRE = 0.5, WATER = 0.5, ELECTRIC = 0.5, ICE = 2, ROCK = 2, STEEL = 0.5, FAIRY = 2 },
  FAIRY    = { FIRE = 0.5, FIGHTING = 2, POISON = 0.5, DRAGON = 2, DARK = 2, STEEL = 0.5 },
}

local function pack(...)
  return { n = select("#", ...), ... }
end

local function clamp(value, lo, hi)
  value = tonumber(value) or lo
  return math.max(lo, math.min(hi, value))
end


local function safeText(value)
  if value == nil then return "" end
  local text = tostring(value)
  text = text:gsub("<PK>", "PKMN")
  text = text:gsub("\r", "")
  return text
end

-- Battle queue payloads are not guaranteed to be plain strings.  ROM text,
-- localization bridges and content overhauls may wrap text in nested records
-- or arrays. Never tostring(table): that is what produced "table: 0x..." and
-- control-looking codes in v1.0.0.
local function extractText(value, seen, depth)
  depth = (depth or 0) + 1
  if depth > 10 or value == nil then return "" end
  local kind = type(value)
  if kind == "string" then return value end
  if kind == "number" or kind == "boolean" or kind == "function"
      or kind == "userdata" or kind == "thread" then
    return ""
  end
  if kind ~= "table" then return "" end

  seen = seen or {}
  if seen[value] then return "" end
  seen[value] = true

  -- Semantic fields first. `value` is last because many records use a
  -- numeric value for selection/action identity rather than visible text.
  for _, key in ipairs({
      "text", "message", "displayText", "display", "label",
      "name", "string", "value",
    }) do
    local child = rawget(value, key)
    if child ~= nil and child ~= value then
      local out = extractText(child, seen, depth)
      if out ~= "" then
        seen[value] = nil
        return out
      end
    end
  end

  -- Array-like encoded fragments are common in ROM/localized text records.
  local fragments = {}
  for index = 1, #value do
    local fragment = extractText(value[index], seen, depth)
    if fragment ~= "" then fragments[#fragments + 1] = fragment end
  end
  seen[value] = nil
  return table.concat(fragments)
end

local function cleanBattleText(value)
  local text = extractText(value)
  if text == "" then return "" end
  text = text:gsub("<PK>", "PKMN")
  text = text:gsub("<MN>", "MN")
  text = text:gsub("\r", "")
  text = text:gsub("\v", "\n")
  -- Strip non-printing ASCII controls while keeping authored newlines/tabs.
  text = text:gsub("[%z\1-\8\11\12\14-\31]", "")
  -- Defensive cleanup for accidental Lua table identities from third-party
  -- wrappers. Never present implementation addresses to the player.
  text = text:gsub("table:%s*0x[%da-fA-F]+", "")
  text = text:gsub("userdata:%s*0x[%da-fA-F]+", "")
  text = text:gsub("[ \t]+\n", "\n")
  text = text:gsub("\n[ \t]+", "\n")
  text = text:gsub("[ \t][ \t]+", " ")
  text = text:gsub("^%s+", ""):gsub("%s+$", "")
  return text
end

local function viewportRect(viewport)
  if viewport and viewport.safe then
    local safe = viewport.safe
    return safe.x or 0, safe.y or 0,
      math.max(1, safe.width or viewport.width or 1),
      math.max(1, safe.height or viewport.height or 1)
  end
  if viewport and viewport.safeX then
    return viewport.safeX, viewport.safeY,
      math.max(1, viewport.safeWidth or viewport.width or 1),
      math.max(1, viewport.safeHeight or viewport.height or 1)
  end
  if love and love.window and love.window.getSafeArea then
    local ok, x, y, w, h = pcall(love.window.getSafeArea)
    if ok and w and h then return x, y, math.max(1, w), math.max(1, h) end
  end
  local graphics = love and love.graphics
  local w = viewport and viewport.width
    or graphics and graphics.getWidth and graphics.getWidth() or 1280
  local h = viewport and viewport.height
    or graphics and graphics.getHeight and graphics.getHeight() or 720
  return 0, 0, math.max(1, w), math.max(1, h)
end

local function topState(game)
  local stack = game and game.stack
  return stack and type(stack.top) == "function" and stack:top() or nil
end

local function isBattle(state)
  return type(state) == "table"
    and (state.isBattleState == true or state.isBattle == true)
end

local function battleState(game)
  local top = topState(game)
  if isBattle(top) then return top end
  local states = game and game.stack and game.stack.states
  if type(states) ~= "table" then return nil end
  for i = #states, 1, -1 do
    if isBattle(states[i]) then return states[i] end
  end
  return nil
end

local function directBattle(game, battle)
  return battle ~= nil and topState(game) == battle
end


local function battleBelow(game, state)
  local states = game and game.stack and game.stack.states
  if type(states) ~= "table" or state == nil then return nil end
  local found = false
  for i = #states, 1, -1 do
    local candidate = states[i]
    if candidate == state then
      found = true
    elseif found and isBattle(candidate) then
      return candidate
    end
  end
  return nil
end

local function isPartyState(state)
  if type(state) ~= "table" then return false end
  if state.screenId == "PartyMenu" then return true end
  -- PartyMenu is also pushed directly by several callers and may not have a
  -- screenId. These are its stable public/runtime fields.
  return type(state.party) == "table"
    and type(state.index) == "number"
    and (state.submenu ~= nil or state.subItems ~= nil
      or type(state.bottomMessage) == "function")
end

local function isBagState(state)
  return type(state) == "table"
    and state.screenId == "BagMenu"
    and type(state.items) == "table"
    and type(state.index) == "number"
end

local function isSummaryState(state)
  if type(state) ~= "table" then return false end
  if state.screenId == "SummaryMenu" then return true end
  return (state.mon ~= nil or state.pokemon ~= nil or state.member ~= nil)
    and (state.page ~= nil or state.tab ~= nil or state.index ~= nil)
end

local function sourceSlotForMenuIndex(menuIndex, order)
  order = order or HORIZONTAL_ACTION_ORDER
  for slot, sourceIndex in ipairs(order) do
    if sourceIndex == menuIndex then return slot end
  end
  return 1
end

local function normalizeType(value)
  if type(value) == "table" then value = value.name or value.id or value.type end
  local text = safeText(value):upper()
  text = text:gsub("_TYPE$", "")
  text = text:gsub("%s+TYPE$", "")
  text = text:gsub("_", " ")
  if text == "PSYCHIC TYPE" then text = "PSYCHIC" end
  return text ~= "" and text or "NORMAL"
end

local function normalizeStatus(value)
  if type(value) == "table" then value = value.id or value.name or value.status end
  local key = safeText(value):upper():gsub("[^A-Z_]", "")
  return STATUS_NAMES[key] or (key ~= "" and key:sub(1, 3) or nil)
end

return function(mod)
  local fontCache = {}
  local iconCache = {}
  local iconFailed = {}
  local lastMessage = setmetatable({}, { __mode = "k" })
  local battleHistory = setmetatable({}, { __mode = "k" })
  local Assets = nil
  pcall(function() Assets = require("src.render.Assets") end)

  local function option(key, default)
    if mod.options and type(mod.options.get) == "function" then
      local ok, value = pcall(mod.options.get, mod.options, key)
      if ok and value ~= nil then return value end
    end
    return default
  end

  if mod.options and type(mod.options.define) == "function" then
    mod.options:define({
      { key = "enabled", label = "MODERN BATTLE UI", type = "toggle",
        default = true,
        description = "Enable the standalone high-resolution battle interface." },
      { key = "theme", label = "BATTLE UI THEME", type = "choice",
        default = "midnight",
        choices = {
          { "MIDNIGHT", "midnight" },
          { "GRAPHITE", "graphite" },
          { "LIGHT", "light" },
          { "CRIMSON", "crimson" },
        },
        description = "Choose the color language used by battle cards and action panels." },
      { key = "ui_scale", label = "BATTLE UI SCALE", type = "choice",
        default = "100",
        choices = {
          { "80%", "80" }, { "90%", "90" }, { "100%", "100" },
          { "110%", "110" }, { "125%", "125" }, { "150%", "150" },
        },
        description = "Scale the complete battle overlay after responsive sizing." },
      { key = "layout", label = "BATTLE UI LAYOUT", type = "choice",
        default = "adaptive",
        choices = {
          { "ADAPTIVE", "adaptive" },
          { "COMPACT", "compact" },
          { "LARGE", "large" },
        },
        description = "Adjust card and command-panel footprint without changing battle logic." },
      { key = "panel_opacity", label = "PANEL OPACITY", type = "number",
        min = 55, max = 100, step = 5, default = 94,
        description = "Opacity of modern battle panels. The 3D/world scene remains visible behind them." },
      { key = "show_icons", label = "ACTION ICONS", type = "toggle",
        default = true,
        description = "Show modern FIGHT, POKEMON, BAG and RUN icons." },
      { key = "show_enemy_hp", label = "ENEMY HP NUMBERS", type = "toggle",
        default = false,
        description = "Show exact enemy HP values in addition to the HP bar." },
      { key = "move_details", label = "MOVE DETAILS", type = "toggle",
        default = true,
        description = "Show selected move type, power, accuracy and PP." },
      { key = "hide_native", label = "HIDE NATIVE BATTLE UI", type = "toggle",
        default = true,
        description = "Hide the classic battle HUD/bottom layer only while this overlay is actively drawing." },
      { key = "battle_children", label = "MODERN PARTY / BAG IN BATTLE", type = "toggle",
        default = true,
        description = "Keep Party and Bag opened from battle in the same modern visual language instead of falling back to the stock Game Boy panels." },
    })
  end

  local function theme()
    local id = tostring(option("theme", "midnight"))
    local base = THEMES[id] or THEMES.midnight
    local opacity = clamp(option("panel_opacity", 94), 55, 100) / 100
    local out = {}
    for key, color in pairs(base) do
      if type(color) == "table" then
        out[key] = { color[1], color[2], color[3], color[4] }
      else
        out[key] = color
      end
    end
    out.surface[4] = opacity
    out.raised[4] = math.min(1, opacity + 0.03)
    out.soft[4] = math.min(1, opacity + 0.01)
    out.selected[4] = math.min(1, opacity + 0.04)
    return out
  end

  local function responsiveScale(w, h)
    local auto = clamp(math.min(w / 1280, h / 720), 0.72, 1.42)
    local manual = clamp(tonumber(option("ui_scale", "100")) or 100,
      80, 150) / 100
    local layout = tostring(option("layout", "adaptive"))
    local layoutScale = layout == "compact" and 0.86
      or layout == "large" and 1.12 or 1
    return auto * manual * layoutScale
  end

  local function getFont(size)
    local graphics = love and love.graphics
    if not graphics then return nil end
    size = math.max(8, math.floor(size + 0.5))
    if fontCache[size] then return fontCache[size] end
    if type(graphics.newFont) == "function" then
      local ok, created = pcall(graphics.newFont, size)
      if ok and created then
        fontCache[size] = created
        return created
      end
    end
    return graphics.getFont and graphics.getFont() or nil
  end

  local function resolvedAssetPath(path)
    if type(path) ~= "string" or path == "" then return nil end
    if Assets and type(Assets.resolve) == "function" then
      local ok, resolved = pcall(Assets.resolve, path)
      if ok and resolved then return resolved end
    end
    return path
  end

  local function loadImageKeyed(key, path, filter)
    if iconCache[key] then return iconCache[key] end
    if iconFailed[key] then return nil end
    local graphics = love and love.graphics
    if not (graphics and type(graphics.newImage) == "function") then
      iconFailed[key] = true
      return nil
    end
    local resolved = resolvedAssetPath(path)
    if not resolved then
      iconFailed[key] = true
      return nil
    end
    local ok, image = pcall(graphics.newImage, resolved)
    if not ok or not image then
      iconFailed[key] = true
      return nil
    end
    if type(image.setFilter) == "function" then
      image:setFilter(filter or "linear", filter or "linear")
    end
    iconCache[key] = image
    return image
  end

  local function loadAssetImage(rel, filter)
    if not (mod.assets and type(mod.assets.path) == "function") then return nil end
    local okPath, path = pcall(mod.assets.path, mod.assets, rel)
    if not okPath or not path then return nil end
    return loadImageKeyed("asset:" .. rel, path, filter)
  end

  local function loadExternalImage(path, filter)
    if type(path) ~= "string" or path == "" then return nil end
    return loadImageKeyed("path:" .. path, path, filter)
  end

  local function loadIcon(name)
    return loadAssetImage("assets/icons/" .. name .. ".png", "linear")
  end

  local function speciesIconDescriptor(game, mon)
    if type(mon) ~= "table" then return nil end
    local species = mon.species
    local icons = game and game.data and game.data.icons
    local entry = species and icons and icons.bySpecies and icons.bySpecies[species]
    if type(entry) == "table" and type(entry.image) == "string" then
      return { image = entry.image, frames = tonumber(entry.frames) or 1 }
    end
    return nil
  end

  local function drawFallbackActionIcon(name, x, y, size, alpha)
    local image = loadIcon(name)
    if not image then return false end
    local iw, ih = image:getDimensions()
    local scale = math.min(size / iw, size / ih)
    love.graphics.setColor(1, 1, 1, alpha or 1)
    love.graphics.draw(image, x + (size - iw * scale) / 2,
      y + (size - ih * scale) / 2, 0, scale, scale)
    return true
  end

  local function drawSpeciesIcon(game, mon, x, y, size, alpha)
    local descriptor = speciesIconDescriptor(game, mon)
    if not descriptor then
      return drawFallbackActionIcon("pokemon", x, y, size, alpha)
    end
    local image = loadExternalImage(descriptor.image, "nearest")
    if not image then
      return drawFallbackActionIcon("pokemon", x, y, size, alpha)
    end
    local iw, ih = image:getDimensions()
    local g = love.graphics
    g.setColor(1, 1, 1, alpha or 1)
    if descriptor.frames >= 2 and iw == 32 and ih >= 64
        and type(g.newQuad) == "function" then
      local key = "sheet:" .. descriptor.image
      local sheet = iconCache[key]
      if type(sheet) ~= "table" or not sheet.quads then
        sheet = {
          image = image,
          quads = {
            g.newQuad(0, 0, 32, 32, iw, ih),
            g.newQuad(0, 32, 32, 32, iw, ih),
          },
        }
        iconCache[key] = sheet
      end
      local now = (love.timer and love.timer.getTime and love.timer.getTime()) or os.clock()
      local frame = math.floor(now * 3.2) % 2 + 1
      local scale = size / 32
      g.draw(sheet.image, sheet.quads[frame], x, y, 0, scale, scale)
      return true
    end
    local scale = math.min(size / iw, size / ih)
    g.draw(image, x + (size - iw * scale) / 2,
      y + (size - ih * scale) / 2, 0, scale, scale)
    return true
  end

  local function itemIconPath(def)
    if type(def) ~= "table" then return nil end
    -- NEW ITEM ICONS publishes these fields on the live item definition.
    -- Do not guess filenames or copy its assets: consume its presentation API.
    for _, key in ipairs({ "image", "icon", "itemSprite" }) do
      local candidate = def[key]
      if type(candidate) == "string" and candidate ~= "" then
        return candidate
      end
    end
    return nil
  end

  local function drawItemSprite(game, itemId, def, x, y, size, alpha)
    local path = itemIconPath(def)
    if not path then return false end
    local image = loadExternalImage(path, "nearest")
    if not image then return false end
    local iw, ih = image:getDimensions()
    local scale = math.min(size / iw, size / ih)
    love.graphics.setColor(1, 1, 1, alpha or 1)
    love.graphics.draw(image, x + (size - iw * scale) / 2,
      y + (size - ih * scale) / 2, 0, scale, scale)
    return true
  end

  local function monMoveRows(mon)
    if type(mon) ~= "table" then return {} end
    if type(mon.curMoves) == "table" then return mon.curMoves end
    if type(mon.moves) == "table" then return mon.moves end
    return {}
  end

  local function statNumber(mon, ...)
    if type(mon) ~= "table" then return nil end
    local stats = mon.stats or {}
    for i = 1, select('#', ...) do
      local key = select(i, ...)
      local value = stats[key]
      if value == nil then value = mon[key] end
      if tonumber(value) then return math.floor(tonumber(value)) end
    end
    return nil
  end

  local function speciesDefinition(game, mon)
    if type(mon) ~= "table" then return nil end
    local data = game and game.data
    return data and data.pokemon and mon.species and data.pokemon[mon.species] or nil
  end

  local function speciesTypes(game, subject)
    local mon = subject and (subject.mon or subject)
    local out = {}
    local function push(value)
      if value == nil then return end
      local t = normalizeType(value)
      for _, existing in ipairs(out) do
        if existing == t then return end
      end
      out[#out + 1] = t
    end
    if type(mon) == "table" then
      local def = speciesDefinition(game, mon)
      local source = def or mon
      if type(source.types) == "table" then
        for _, value in pairs(source.types) do push(value) end
      end
      push(source.type1)
      push(source.type2)
      push(source.primaryType)
      push(source.secondaryType)
      if #out == 0 then push(source.type) end
    end
    if #out == 0 then out[1] = "NORMAL" end
    return out
  end

  local function typeMultiplier(moveType, targetTypes)
    moveType = normalizeType(moveType)
    local chart = TYPE_EFFECTIVENESS[moveType] or {}
    local multiplier = 1
    for _, targetType in ipairs(targetTypes or {}) do
      multiplier = multiplier * (chart[normalizeType(targetType)] or 1)
    end
    return multiplier
  end

  local function effectivenessTag(mult)
    if mult >= 4 then return 'x4 SUPER', { 0.21, 0.78, 0.40, 1 } end
    if mult >= 2 then return 'x2 SUPER', { 0.25, 0.72, 0.33, 1 } end
    if mult == 0 then return 'NO EFFECT', { 0.55, 0.57, 0.60, 1 } end
    if mult <= 0.25 then return 'x0.25', { 0.86, 0.44, 0.18, 1 } end
    if mult < 1 then return 'x0.5', { 0.89, 0.55, 0.20, 1 } end
    return 'NEUTRAL', { 0.35, 0.45, 0.64, 1 }
  end

  local function fightEffectivenessTag(mult)
    if mult >= 4 then return "SUPER x4", { 0.18, 0.78, 0.39, 1 } end
    if mult >= 2 then return "SUPER x2", { 0.22, 0.72, 0.34, 1 } end
    if mult == 0 then return "NO EFFECT", { 0.48, 0.50, 0.55, 1 } end
    if mult <= 0.25 then return "RESIST x0.25", { 0.86, 0.39, 0.18, 1 } end
    if mult < 1 then return "RESIST x0.5", { 0.90, 0.54, 0.18, 1 } end
    return "NORMAL x1", { 0.33, 0.45, 0.64, 1 }
  end

  local function coverageSummary(game, mon, target)
    local best, all = nil, {}
    local targetTypes = speciesTypes(game, target)
    local moves = game and game.data and game.data.moves
    for _, move in ipairs(monMoveRows(mon)) do
      if type(move) == 'table' and move.id then
        -- IMPORTANT: resolve directly here. v1.2.0 called the later-declared
        -- local moveDefinition(), which was out of lexical scope and became a
        -- nil global at runtime when the Party sidebar was drawn.
        local def = moves and moves[move.id] or nil
        local name = safeText(def and def.name or move.id or '-')
        local typeName = normalizeType(def and def.type)
        local mult = typeMultiplier(typeName, targetTypes)
        local info = { move = move, def = def, name = name, typeName = typeName, mult = mult }
        all[#all + 1] = info
        if not best or mult > best.mult then best = info end
      end
    end
    table.sort(all, function(a, b)
      if a.mult ~= b.mult then return a.mult > b.mult end
      return a.name < b.name
    end)
    return best, all
  end

  local function setColor(color, alpha)
    if not (love and love.graphics) then return end
    love.graphics.setColor(color[1], color[2], color[3],
      alpha ~= nil and alpha or (color[4] or 1))
  end

  local function roundedPanel(x, y, w, h, t, fill, border, selected, radius)
    local g = love.graphics
    radius = radius or 16
    setColor(t.shadow)
    g.rectangle("fill", x + 3, y + 6, w, h, radius, radius)
    setColor(fill or t.raised)
    g.rectangle("fill", x, y, w, h, radius, radius)
    g.setLineWidth(selected and 2.4 or 1.3)
    setColor(selected and t.accent or (border or t.border))
    g.rectangle("line", x + 0.7, y + 0.7, w - 1.4, h - 1.4, radius, radius)
    if selected then
      setColor(t.accent)
      g.rectangle("fill", x, y, 5, h, radius, radius)
    end
  end

  local function healthColor(ratio)
    if ratio > 0.50 then return { 0.18, 0.78, 0.45, 1 } end
    if ratio > 0.20 then return { 0.96, 0.70, 0.16, 1 } end
    return { 0.95, 0.28, 0.26, 1 }
  end

  local function hpInfo(battler)
    if type(battler) ~= "table" then return 0, 1 end
    local mon = battler.mon or battler
    local maxHP = tonumber(mon and mon.stats and mon.stats.hp)
      or tonumber(mon and mon.maxHp) or tonumber(mon and mon.maxHP)
      or tonumber(mon and mon.hp) or 1
    maxHP = math.max(1, maxHP)
    local hp = tonumber(battler.shownHP) or tonumber(mon and mon.hp)
      or tonumber(battler.hp) or 0
    return clamp(hp, 0, maxHP), maxHP
  end

  local function battleName(game, battler)
    if type(battler) ~= "table" then return "POKEMON" end
    local mon = battler.mon or battler
    local data = game and game.data
    local definition = mon and mon.species and data and data.pokemon
      and data.pokemon[mon.species]
    return safeText(battler.name or mon.nickname
      or definition and definition.name or mon.species or "POKEMON")
  end

  local function battleLevel(battler)
    local mon = battler and (battler.mon or battler)
    return tonumber(mon and mon.level)
  end

  local function battleStatus(battler)
    local mon = battler and (battler.mon or battler)
    return normalizeStatus(battler and battler.shownStatus
      or mon and mon.status)
  end

  local function enemyCaught(game, battle)
    local mon = battle and battle.enemy and (battle.enemy.mon or battle.enemy)
    local species = mon and mon.species
    local dex = game and game.save and game.save.pokedex
    return species ~= nil and dex and type(dex.owned) == "table"
      and dex.owned[species] == true
  end

  local function drawIcon(name, x, y, size, color)
    if option("show_icons", true) == false then return false end
    local image = loadIcon(name)
    if not image then return false end
    local g = love.graphics
    local iw, ih = image:getDimensions()
    local scale = math.min(size / iw, size / ih)
    setColor(color)
    g.draw(image, x + (size - iw * scale) / 2,
      y + (size - ih * scale) / 2, 0, scale, scale)
    return true
  end

  local function drawPokeballMark(cx, cy, r, color)
    local g = love.graphics
    setColor(color)
    g.setLineWidth(math.max(1.5, r * 0.20))
    g.circle("line", cx, cy, r)
    g.line(cx - r, cy, cx + r, cy)
    g.circle("fill", cx, cy, r * 0.30)
  end

  local function drawStatusCard(game, battle, battler, x, y, w, h,
      playerSide, t, s)
    if type(battler) ~= "table" then return end
    roundedPanel(x, y, w, h, t, t.raised, t.border, false, 15 * s)

    local pad = 16 * s
    local nameFont = getFont(18 * s)
    local metaFont = getFont(12 * s)
    local valueFont = getFont(13 * s)
    if nameFont then love.graphics.setFont(nameFont) end

    setColor(t.text)
    local name = battleName(game, battler)
    love.graphics.print(name, x + pad, y + 12 * s)

    local level = battleLevel(battler)
    local levelText = level and ("Lv " .. tostring(math.floor(level))) or ""
    if valueFont then love.graphics.setFont(valueFont) end
    setColor(t.muted)
    local lw = valueFont and valueFont:getWidth(levelText) or 0
    if levelText ~= "" then
      love.graphics.print(levelText, x + w - pad - lw, y + 15 * s)
    end

    local status = battleStatus(battler)
    if status then
      local c = STATUS_COLORS[status] or t.accent
      if metaFont then love.graphics.setFont(metaFont) end
      local sw = (metaFont and metaFont:getWidth(status) or 24) + 12 * s
      local sh = 20 * s
      setColor(c, 0.95)
      love.graphics.rectangle("fill", x + pad, y + 38 * s,
        sw, sh, sh / 2, sh / 2)
      setColor({1,1,1,1})
      love.graphics.print(status, x + pad + 6 * s, y + 40 * s)
    end

    if not playerSide and enemyCaught(game, battle) then
      drawPokeballMark(x + w - 22 * s, y + h - 20 * s,
        7 * s, t.accent)
    end

    local hp, maxHP = hpInfo(battler)
    local ratio = clamp(hp / math.max(1, maxHP), 0, 1)
    local barX = x + pad
    local barW = w - pad * 2
    local barH = 9 * s
    local barY = y + h - 24 * s
    setColor(t.hpTrack)
    love.graphics.rectangle("fill", barX, barY, barW, barH,
      barH / 2, barH / 2)
    setColor(healthColor(ratio))
    love.graphics.rectangle("fill", barX, barY, barW * ratio, barH,
      barH / 2, barH / 2)

    local showNumbers = playerSide or option("show_enemy_hp", false) == true
    if showNumbers then
      local label = ("%d / %d"):format(math.floor(hp), math.floor(maxHP))
      if metaFont then love.graphics.setFont(metaFont) end
      setColor(t.muted)
      local tw = metaFont and metaFont:getWidth(label) or 0
      love.graphics.print(label, x + w - pad - tw, barY - 19 * s)
    end
  end

  local function safariActions(battle)
    local balls = battle.safari and tonumber(battle.safari.balls) or 0
    return {
      { id = "ball", label = "BALL", sub = "x" .. tostring(balls or 0),
        icon = "ball" },
      { id = "bait", label = "BAIT", sub = "Throw", icon = "bait" },
      { id = "rock", label = "ROCK", sub = "Throw", icon = "rock" },
      { id = "run", label = "RUN", sub = "Escape", icon = "run" },
    }
  end

  local function menuSelection(battle)
    if battle.demo and tonumber(battle.demoTimer) then
      return battle.demoTimer <= 80 and 1 or 3
    end
    return clamp(math.floor(tonumber(battle.menuIndex) or 1), 1, 4)
  end

  local function drawActionPanel(game, battle, x, y, w, h, t, s)
    roundedPanel(x, y, w, h, t, t.surface, t.border, false, 18 * s)
    local labelFont = getFont(17 * s)
    local subFont = getFont(11 * s)
    local headerFont = getFont(11 * s)
    local selected = menuSelection(battle)
    local rows = battle.safari and safariActions(battle) or ACTIONS
    local visualOrder = battle.safari and { 1, 2, 3, 4 }
      or HORIZONTAL_ACTION_ORDER

    if headerFont then love.graphics.setFont(headerFont) end
    setColor(t.muted)
    love.graphics.print(battle.safari and "SAFARI ACTION" or "YOUR TURN",
      x + 20 * s, y + 13 * s)

    local gap = 10 * s
    local innerX = x + 14 * s
    local innerW = w - 28 * s
    local buttonY = y + 34 * s
    local buttonH = h - 46 * s
    local buttonW = (innerW - gap * 3) / 4
    local pulse = 0.5 + 0.5 * math.sin(
      ((love.timer and love.timer.getTime and love.timer.getTime()) or 0) * 5.5)

    for slot = 1, 4 do
      local sourceIndex = visualOrder[slot]
      local action = rows[sourceIndex]
      local bx = innerX + (slot - 1) * (buttonW + gap)
      local active = sourceIndex == selected
      local fill = active and t.selected or t.raised
      roundedPanel(bx, buttonY, buttonW, buttonH,
        t, fill, active and t.accent or t.border, active, 13 * s)

      local iconSize = math.min(34 * s, buttonH * 0.46)
      local iconX = bx + 14 * s
      local iconY = buttonY + (buttonH - iconSize) / 2
      local iconColor = active and t.accent or t.muted
      local hasIcon = drawIcon(action.icon, iconX, iconY, iconSize, iconColor)

      local textX = bx + (hasIcon and 58 * s or 16 * s)
      local titleY = buttonY + 13 * s
      if labelFont then love.graphics.setFont(labelFont) end
      setColor(active and t.text or t.text)
      love.graphics.print(action.label, textX, titleY)

      if subFont then love.graphics.setFont(subFont) end
      setColor(active and t.accent or t.muted)
      love.graphics.print(action.sub, textX, titleY + 25 * s)

      if active then
        setColor(t.accent, 0.16 + pulse * 0.05)
        love.graphics.rectangle("fill", bx + 5 * s,
          buttonY + 5 * s, buttonW - 10 * s, buttonH - 10 * s,
          10 * s, 10 * s)
      end
    end
  end

  local function moveRows(battle)
    if battle.phase == "mimicSelect" then
      return type(battle.mimicMoves) == "table" and battle.mimicMoves or {},
        clamp(math.floor(tonumber(battle.mimicIndex) or 1), 1, 4)
    end
    local player = battle.player
    return player and type(player.curMoves) == "table" and player.curMoves or {},
      clamp(math.floor(tonumber(battle.moveIndex) or 1), 1, 4)
  end

  local function moveDefinition(game, move)
    return move and game and game.data and game.data.moves
      and game.data.moves[move.id] or nil
  end

  local function moveMaxPP(def, move)
    if not (def and tonumber(def.pp)) then return nil end
    return def.pp + (tonumber(move and move.ppUps) or 0) * math.floor(def.pp / 5)
  end

  local function moveAccuracy(value)
    value = tonumber(value)
    if not value or value <= 0 then return "-" end
    if value > 100 and value <= 255 then
      value = math.floor(value * 100 / 255 + 0.5)
    end
    return tostring(math.floor(value)) .. "%"
  end

  local function drawTypePill(typeName, x, y, font, s)
    local color = TYPE_COLORS[typeName] or TYPE_COLORS.NORMAL
    local label = typeName
    local tw = font and font:getWidth(label) or (#label * 7 * s)
    local w = tw + 18 * s
    local h = 22 * s
    setColor(color, 0.96)
    love.graphics.rectangle("fill", x, y, w, h, h / 2, h / 2)
    if font then love.graphics.setFont(font) end
    setColor({1,1,1,1})
    love.graphics.print(label, x + 9 * s, y + 3 * s)
    return w, h
  end

  local function drawMovePanel(game, battle, x, y, w, h, t, s)
    roundedPanel(x, y, w, h, t, t.surface, t.border, false, 18 * s)
    local moves, selected = moveRows(battle)
    local headerFont = getFont(11 * s)
    local nameFont = getFont(15 * s)
    local smallFont = getFont(10.5 * s)
    local detailFont = getFont(11.5 * s)
    local enemy = battle and battle.enemy and (battle.enemy.mon or battle.enemy)
      or nil
    local enemyTypes = enemy and speciesTypes(game, enemy) or nil

    if headerFont then love.graphics.setFont(headerFont) end
    setColor(t.muted)
    love.graphics.print(battle.phase == "mimicSelect"
      and "CHOOSE A TECHNIQUE" or "CHOOSE A MOVE", x + 20 * s, y + 13 * s)

    local gap = 10 * s
    local left = x + 14 * s
    local top = y + 34 * s
    local detailH = option("move_details", true) ~= false and 38 * s or 4 * s
    local gridH = h - 44 * s - detailH
    local cellW = (w - 28 * s - gap) / 2
    local cellH = (gridH - gap) / 2

    for i = 1, 4 do
      local row = math.floor((i - 1) / 2)
      local col = (i - 1) % 2
      local bx = left + col * (cellW + gap)
      local by = top + row * (cellH + gap)
      local active = i == selected
      local move = moves[i]
      local def = moveDefinition(game, move)
      local typeName = normalizeType(def and def.type)
      local typeColor = TYPE_COLORS[typeName] or TYPE_COLORS.NORMAL

      roundedPanel(bx, by, cellW, cellH, t,
        active and t.selected or t.raised,
        active and typeColor or t.border, active, 12 * s)

      setColor(typeColor)
      love.graphics.rectangle("fill", bx, by, 5 * s, cellH,
        12 * s, 12 * s)

      local moveName = move
        and safeText(def and def.name or move.id or "-") or "-"
      if nameFont then love.graphics.setFont(nameFont) end
      setColor(move and t.text or t.muted)
      love.graphics.print(moveName, bx + 15 * s, by + 11 * s)

      if smallFont then love.graphics.setFont(smallFont) end
      local pp = "-"
      if move and move.pp ~= nil then
        local maxPP = moveMaxPP(def, move)
        pp = maxPP and ("%d/%d"):format(move.pp, maxPP)
          or tostring(move.pp)
      end
      setColor(t.muted)
      local ppText = "PP " .. pp
      local ppW = smallFont and smallFont:getWidth(ppText) or 0
      love.graphics.print(ppText, bx + cellW - 13 * s - ppW,
        by + 12 * s)

      if move then
        local typePillW = select(1, drawTypePill(typeName,
          bx + 15 * s, by + cellH - 29 * s, smallFont, s))

        if enemyTypes then
          local multiplier = typeMultiplier(typeName, enemyTypes)
          local effectText, effectColor = fightEffectivenessTag(multiplier)
          local effectFont = getFont(9.5 * s)
          if effectFont then love.graphics.setFont(effectFont) end
          local effectW = (effectFont and effectFont:getWidth(effectText)
            or #effectText * 5.5 * s) + 16 * s
          local effectH = 20 * s
          local effectX = bx + cellW - 13 * s - effectW
          local effectY = by + cellH - 28 * s

          -- If a very narrow viewport would make the type/effect pills touch,
          -- prefer the matchup information and keep the type pill readable.
          local typeEnd = bx + 15 * s + typePillW
          if effectX < typeEnd + 7 * s then
            effectW = math.max(62 * s, bx + cellW - 20 * s - typeEnd)
            effectX = bx + cellW - 13 * s - effectW
          end

          setColor(effectColor, 0.96)
          love.graphics.rectangle("fill", effectX, effectY,
            effectW, effectH, effectH / 2, effectH / 2)
          setColor({ 1, 1, 1, 1 })
          if effectFont then
            local textW = effectFont:getWidth(effectText)
            love.graphics.print(effectText,
              effectX + math.max(6 * s, (effectW - textW) / 2),
              effectY + 3 * s)
          else
            love.graphics.print(effectText, effectX + 7 * s,
              effectY + 3 * s)
          end
        end
      end

      if battle.moveSwapIndex == i then
        local label = "SWAP"
        local lw = smallFont and smallFont:getWidth(label) or 24
        setColor(t.accent, 0.92)
        love.graphics.rectangle("fill",
          bx + cellW - lw - 24 * s, by + cellH - 28 * s,
          lw + 14 * s, 20 * s, 10 * s, 10 * s)
        setColor({1,1,1,1})
        love.graphics.print(label, bx + cellW - lw - 17 * s,
          by + cellH - 25 * s)
      end

      if battle.player and battle.player.disabledSlot == i then
        setColor({ 0.92, 0.23, 0.25, 0.92 })
        love.graphics.rectangle("fill", bx + 8 * s, by + 7 * s,
          cellW - 16 * s, cellH - 14 * s, 9 * s, 9 * s)
        if smallFont then love.graphics.setFont(smallFont) end
        setColor({1,1,1,1})
        love.graphics.print("DISABLED", bx + 16 * s, by + cellH - 29 * s)
      end
    end

    if option("move_details", true) ~= false then
      local move = moves[selected]
      local def = moveDefinition(game, move)
      local typeName = normalizeType(def and def.type)
      local power = def and tonumber(def.power)
      local powerText = power and power > 0 and tostring(math.floor(power)) or "-"
      local accuracyText = moveAccuracy(def and def.accuracy)
      local maxPP = moveMaxPP(def, move)
      local ppText = move and move.pp ~= nil and maxPP
        and ("%d/%d"):format(move.pp, maxPP) or "-"
      local detailY = y + h - 31 * s
      if detailFont then love.graphics.setFont(detailFont) end
      setColor(t.muted)
      local text = ("TYPE  %s     POWER  %s     ACC  %s     PP  %s")
        :format(typeName, powerText, accuracyText, ppText)
      love.graphics.print(text, x + 20 * s, detailY)

      if move and enemyTypes then
        local multiplier = typeMultiplier(typeName, enemyTypes)
        local effectText, effectColor = fightEffectivenessTag(multiplier)
        local effectFont = getFont(10 * s)
        if effectFont then love.graphics.setFont(effectFont) end
        local effectW = (effectFont and effectFont:getWidth(effectText)
          or #effectText * 5.5 * s) + 18 * s
        local effectH = 21 * s
        local effectX = x + w - 20 * s - effectW
        local effectY = y + h - 34 * s
        setColor(effectColor, 0.96)
        love.graphics.rectangle("fill", effectX, effectY,
          effectW, effectH, effectH / 2, effectH / 2)
        setColor({ 1, 1, 1, 1 })
        local labelW = effectFont and effectFont:getWidth(effectText) or 0
        love.graphics.print(effectText,
          effectX + (effectW - labelW) / 2, effectY + 3 * s)
      end
    end
  end

  local function historyState(battle)
    local state = battleHistory[battle]
    if not state then
      state = {
        entries = {},
        lastSource = nil,
        activeIndex = nil,
        lastLooseKey = nil,
      }
      battleHistory[battle] = state
    end
    return state
  end

  local function messageKey(text)
    text = cleanBattleText(text)
    return text:gsub("%s+", " ")
  end

  local function appendHistoryEntry(history, text)
    text = cleanBattleText(text)
    if text == "" then return nil end
    history.entries[#history.entries + 1] = text
    while #history.entries > 10 do
      table.remove(history.entries, 1)
      if history.activeIndex then
        history.activeIndex = math.max(1, history.activeIndex - 1)
      end
    end
    return #history.entries
  end

  local function sourceFullText(source)
    if type(source) ~= "table" then return "" end
    return cleanBattleText(source.text or source.message or source.label)
  end

  local function sourceVisibleText(battle)
    if type(battle) ~= "table" or type(battle.visibleText) ~= "function" then
      return ""
    end
    local ok, result = pcall(battle.visibleText, battle)
    if not ok or type(result) ~= "table" then return "" end
    local lines = {}
    for _, value in ipairs(result) do
      local line = cleanBattleText(value)
      if line ~= "" then lines[#lines + 1] = line end
    end
    return table.concat(lines, "\n")
  end

  local function trackCurrentBattleEvent(battle)
    if type(battle) ~= "table" then return "" end
    local history = historyState(battle)
    local source = battle.current

    if type(source) == "table" then
      local full = sourceFullText(source)
      local visible = sourceVisibleText(battle)
      local display = visible ~= "" and visible or full

      if source ~= history.lastSource then
        history.lastSource = source
        history.activeIndex = nil
        local eventText = full ~= "" and full or display
        if eventText ~= "" then
          history.activeIndex = appendHistoryEntry(history, eventText)
        end
      elseif history.activeIndex and full ~= ""
          and history.entries[history.activeIndex] ~= full then
        history.entries[history.activeIndex] = full
      end

      if display ~= "" then
        lastMessage[battle] = display
        return display
      end
    end

    local loose = cleanBattleText(battle.message)
    if loose ~= "" then
      local key = messageKey(loose)
      if key ~= history.lastLooseKey then
        history.lastLooseKey = key
        history.activeIndex = appendHistoryEntry(history, loose)
      end
      lastMessage[battle] = loose
      return loose
    end

    if battle.msgHold or battle.animPlaying or battle.draining
        or battle.msgWaiting or battle.msgPrompt then
      return lastMessage[battle] or ""
    end
    return ""
  end

  local function hasSourceBattleText(battle)
    if type(battle) ~= "table" then return false end
    if sourceVisibleText(battle) ~= "" then return true end
    if sourceFullText(battle.current) ~= "" then return true end
    if cleanBattleText(battle.message) ~= "" then return true end
    return battle.msgHold == true or battle.msgWaiting == true
      or battle.msgPrompt == true or battle.animPlaying == true
  end

  local function recentBattleHistory(battle, count, excludeActive)
    local state = battleHistory[battle]
    if not state or type(state.entries) ~= "table" then return {} end
    local out = {}
    local skip = excludeActive and battle.current == state.lastSource
      and state.activeIndex or nil
    for i = #state.entries, 1, -1 do
      if i ~= skip then
        table.insert(out, 1, state.entries[i])
        if #out >= (count or 3) then break end
      end
    end
    return out
  end

  local function visibleMessage(battle, game)
    if type(battle) ~= "table" then return "" end

    local live = trackCurrentBattleEvent(battle)
    if live ~= "" then return live end

    local phase = safeText(battle.phase)
    if phase == "intro" or battle.introSlide or battle.introBalls then
      local fallback
      if battle.kind == "trainer" then
        local trainer = cleanBattleText(battle.trainerName
          or battle.trainer and (battle.trainer.name or battle.trainer.label))
        fallback = trainer ~= "" and (trainer .. " wants to battle!")
          or "A TRAINER wants to battle!"
      elseif battle.enemy then
        fallback = "A wild " .. battleName(game, battle.enemy) .. " appeared!"
      end

      if fallback and fallback ~= "" then
        local history = historyState(battle)
        local key = "intro:" .. messageKey(fallback)
        if history.lastLooseKey ~= key then
          history.lastLooseKey = key
          history.activeIndex = appendHistoryEntry(history, fallback)
        end
        lastMessage[battle] = fallback
        return fallback
      end
    end

    return ""
  end

  local function drawBattleHistoryStrip(battle, x, y, w, h, t, s)
    local entries = recentBattleHistory(battle, 3, false)
    if #entries == 0 then return false end

    roundedPanel(x, y, w, h, t, t.surface, t.border, false, 12 * s)
    local headerFont = getFont(9.5 * s)
    local lineFont = getFont(10 * s)
    if headerFont then love.graphics.setFont(headerFont) end
    setColor(t.accent)
    love.graphics.print("BATTLE LOG", x + 14 * s, y + 7 * s)

    if lineFont then love.graphics.setFont(lineFont) end
    local lineY = y + 21 * s
    for i, text in ipairs(entries) do
      setColor(i == #entries and t.text or t.muted)
      local compact = cleanBattleText(text):gsub("\n", " / ")
      local prefix = i == #entries and "› " or "  "
      love.graphics.printf(prefix .. compact,
        x + 14 * s, lineY, w - 28 * s, "left")
      lineY = lineY + 15 * s
    end
    return true
  end

  local function drawMessagePanel(battle, message, x, y, w, h, t, s)
    message = cleanBattleText(message)
    if message == "" then return false end
    roundedPanel(x, y, w, h, t, t.surface, t.border, false, 18 * s)
    setColor(t.accent)
    love.graphics.rectangle("fill", x, y, 5 * s, h,
      18 * s, 18 * s)

    local historyFont = getFont(10 * s)
    local bodyFont = getFont(16 * s)
    local hintFont = getFont(10.5 * s)

    local previous = recentBattleHistory(battle, 2, true)
    local cursorY = y + 11 * s
    if #previous > 0 then
      if historyFont then love.graphics.setFont(historyFont) end
      for _, old in ipairs(previous) do
        setColor(t.muted)
        love.graphics.printf(cleanBattleText(old),
          x + 22 * s, cursorY, w - 44 * s, "left")
        cursorY = cursorY + 16 * s
      end
      setColor(t.border)
      love.graphics.rectangle("fill", x + 22 * s, cursorY + 1 * s,
        w - 44 * s, 1)
      cursorY = cursorY + 8 * s
    end

    if bodyFont then love.graphics.setFont(bodyFont) end
    setColor(t.text)
    love.graphics.printf(message, x + 22 * s, cursorY,
      w - 44 * s, "left")

    if battle.msgWaiting or battle.msgPrompt or battle.waitingForInput then
      if hintFont then love.graphics.setFont(hintFont) end
      local label = "A  CONTINUE"
      local tw = hintFont and hintFont:getWidth(label) or 60
      local pw = tw + 20 * s
      local ph = 22 * s
      setColor(t.soft)
      love.graphics.rectangle("fill", x + w - pw - 16 * s,
        y + h - ph - 10 * s, pw, ph, ph / 2, ph / 2)
      setColor(t.accent)
      love.graphics.print(label, x + w - pw - 6 * s,
        y + h - ph - 7 * s)
    end
    return true
  end

  local function drawBattleLabel(battle, x, y, t, s)
    local font = getFont(10.5 * s)
    if font then love.graphics.setFont(font) end
    local text = battle.safari and "SAFARI BATTLE"
      or battle.kind == "trainer" and "TRAINER BATTLE"
      or battle.demo and "DEMO BATTLE"
      or "WILD BATTLE"
    local tw = font and font:getWidth(text) or #text * 6 * s
    local w = tw + 22 * s
    local h = 23 * s
    setColor(t.surface)
    love.graphics.rectangle("fill", x - w / 2, y, w, h, h / 2, h / 2)
    setColor(t.border)
    love.graphics.rectangle("line", x - w / 2, y, w, h, h / 2, h / 2)
    setColor(t.muted)
    love.graphics.print(text, x - tw / 2, y + 4 * s)
  end

  local function drawChildBackdrop(viewport, t)
    local x, y, w, h = viewportRect(viewport)
    setColor(t.surface, 1)
    love.graphics.rectangle("fill", x, y, w, h)
    return x, y, w, h
  end

  local function drawChildHeader(title, subtitle, x, y, w, t, s)
    local titleFont = getFont(26 * s)
    local subFont = getFont(11.5 * s)
    if titleFont then love.graphics.setFont(titleFont) end
    setColor(t.text)
    love.graphics.print(title, x, y)
    if subtitle and subtitle ~= "" then
      if subFont then love.graphics.setFont(subFont) end
      setColor(t.muted)
      love.graphics.print(subtitle, x, y + 36 * s)
    end
    setColor(t.accent)
    love.graphics.rectangle("fill", x, y + 58 * s, math.min(w, 148 * s),
      3 * s, 2 * s, 2 * s)
  end

  local function monSpeciesName(game, mon)
    if type(mon) ~= 'table' then return 'POKEMON' end
    local def = speciesDefinition(game, mon)
    return safeText(mon.nickname or def and def.name or mon.species or 'POKEMON')
  end

  local function monHp(mon)
    if type(mon) ~= 'table' then return 0, 1 end
    local maxHP = tonumber(mon.stats and mon.stats.hp)
      or tonumber(mon.maxHp) or tonumber(mon.maxHP) or tonumber(mon.hp) or 1
    return clamp(tonumber(mon.hp) or 0, 0, math.max(1, maxHP)), math.max(1, maxHP)
  end

  local function drawStatChip(label, value, x, y, w, t, s)
    roundedPanel(x, y, w, 34 * s, t, t.soft, t.border, false, 10 * s)
    local labelFont = getFont(10.5 * s)
    local valueFont = getFont(13 * s)
    if labelFont then love.graphics.setFont(labelFont) end
    setColor(t.muted)
    love.graphics.print(label, x + 10 * s, y + 6 * s)
    if valueFont then love.graphics.setFont(valueFont) end
    setColor(t.text)
    local text = safeText(value or '-')
    local tw = valueFont and valueFont:getWidth(text) or 0
    love.graphics.print(text, x + w - 10 * s - tw, y + 8 * s)
  end

  local function drawEffectBadge(text, color, x, y, s)
    local font = getFont(10 * s)
    local tw = font and font:getWidth(text) or (#text * 6 * s)
    local w = tw + 14 * s
    local h = 18 * s
    setColor(color, 0.96)
    love.graphics.rectangle('fill', x, y, w, h, h / 2, h / 2)
    if font then love.graphics.setFont(font) end
    setColor({1,1,1,1})
    love.graphics.print(text, x + 7 * s, y + 2.5 * s)
    return w, h
  end

  local function drawMoveSummaryRow(game, move, target, x, y, w, t, s)
    local nameFont = getFont(12.5 * s)
    local metaFont = getFont(10.5 * s)
    local def = moveDefinition(game, move)
    local typeName = normalizeType(def and def.type)
    local mult = target and typeMultiplier(typeName, speciesTypes(game, target)) or 1
    local badge, badgeColor
    if target then
      badge, badgeColor = effectivenessTag(mult)
    else
      badge, badgeColor = 'PREVIEW', { 0.35, 0.45, 0.64, 1 }
    end
    roundedPanel(x, y, w, 40 * s, t, t.soft, t.border, false, 10 * s)
    if nameFont then love.graphics.setFont(nameFont) end
    setColor(t.text)
    local name = safeText(def and def.name or move and move.id or '-')
    love.graphics.print(name, x + 12 * s, y + 8 * s)
    if metaFont then love.graphics.setFont(metaFont) end
    local pp = '-'
    if move and move.pp ~= nil then
      local maxPP = moveMaxPP(def, move)
      pp = maxPP and string.format('%d/%d', move.pp, maxPP) or tostring(move.pp)
    end
    setColor(t.muted)
    love.graphics.print('PP ' .. pp, x + 12 * s, y + 22 * s)
    local pillFont = getFont(9.5 * s)
    local typeW = select(1, drawTypePill(typeName, x + w - 178 * s, y + 8 * s, pillFont, s))
    drawEffectBadge(badge, badgeColor, x + w - 178 * s + typeW + 8 * s, y + 10 * s, s)
  end

  local function drawMonDetailPane(game, mon, battle, x, y, w, h, t, s, showFooter)
    roundedPanel(x, y, w, h, t, t.surface, t.border, false, 16 * s)
    if type(mon) ~= 'table' then return end

    local pad = 18 * s
    local iconSize = math.min(96 * s, math.max(60 * s, h * 0.16))
    drawSpeciesIcon(game, mon, x + pad, y + pad, iconSize, 1)

    local titleFont = getFont(20 * s)
    local metaFont = getFont(11.5 * s)
    local bodyFont = getFont(12 * s)
    local nameX = x + pad + iconSize + 16 * s
    if titleFont then love.graphics.setFont(titleFont) end
    setColor(t.text)
    love.graphics.print(monSpeciesName(game, mon), nameX, y + pad + 2 * s)

    if metaFont then love.graphics.setFont(metaFont) end
    setColor(t.muted)
    local level = tonumber(mon.level)
    local status = normalizeStatus(mon.status)
    local meta = level and ('Lv ' .. math.floor(level)) or ''
    if status then meta = meta ~= '' and (meta .. '   ' .. status) or status end
    love.graphics.print(meta, nameX, y + pad + 30 * s)

    local types = speciesTypes(game, mon)
    local tx = nameX
    for _, typeName in ipairs(types) do
      local tw = select(1, drawTypePill(typeName, tx, y + pad + 52 * s, metaFont, s))
      tx = tx + tw + 8 * s
    end

    local hp, maxHP = monHp(mon)
    local ratio = hp / math.max(1, maxHP)
    local barX = x + pad
    local barY = y + pad + iconSize + 14 * s
    local barW = w - pad * 2
    setColor(t.hpTrack)
    love.graphics.rectangle('fill', barX, barY, barW, 10 * s, 6 * s, 6 * s)
    setColor(healthColor(ratio))
    love.graphics.rectangle('fill', barX, barY, barW * ratio, 10 * s, 6 * s, 6 * s)
    if bodyFont then love.graphics.setFont(bodyFont) end
    setColor(t.muted)
    love.graphics.print(string.format('HP  %d / %d', hp, maxHP), barX, barY + 14 * s)

    local chipY = barY + 38 * s
    local chipGap = 8 * s
    local chipW = (w - pad * 2 - chipGap) / 2
    drawStatChip('ATK', statNumber(mon, 'attack', 'atk') or '-', x + pad, chipY, chipW, t, s)
    drawStatChip('DEF', statNumber(mon, 'defense', 'def') or '-', x + pad + chipW + chipGap, chipY, chipW, t, s)
    chipY = chipY + 40 * s
    drawStatChip('SPC', statNumber(mon, 'specialAttack', 'special', 'spc', 'spatk') or '-', x + pad, chipY, chipW, t, s)
    drawStatChip('SPD', statNumber(mon, 'speed', 'spe') or '-', x + pad + chipW + chipGap, chipY, chipW, t, s)

    local enemy = battle and battle.enemy and (battle.enemy.mon or battle.enemy) or nil
    if bodyFont then love.graphics.setFont(bodyFont) end
    setColor(t.text)
    local sectionY = chipY + 48 * s
    local targetName = enemy and monSpeciesName(game, enemy) or 'CURRENT TARGET'
    love.graphics.print('MOVE COVERAGE vs ' .. targetName, x + pad, sectionY)
    sectionY = sectionY + 20 * s

    local rows = monMoveRows(mon)
    local maxRows = math.min(4, #rows)
    for i = 1, maxRows do
      drawMoveSummaryRow(game, rows[i], enemy, x + pad, sectionY + (i - 1) * (44 * s), w - pad * 2, t, s)
    end

    local best = enemy and select(1, coverageSummary(game, mon, enemy)) or nil
    local footerY = y + h - 40 * s
    if best then
      local tag, color = effectivenessTag(best.mult)
      setColor(t.muted)
      love.graphics.print('BEST OPTION', x + pad, footerY)
      if bodyFont then love.graphics.setFont(bodyFont) end
      setColor(t.text)
      love.graphics.print(best.name .. ' (' .. best.typeName .. ')', x + pad + 92 * s, footerY)
      drawEffectBadge(tag, color, x + w - pad - 86 * s, footerY - 1 * s, s)
    elseif enemy then
      setColor(t.muted)
      love.graphics.print('No usable moves detected for effectiveness preview.', x + pad, footerY)
    end

    if showFooter then
      local hintFont = getFont(11 * s)
      if hintFont then love.graphics.setFont(hintFont) end
      setColor(t.muted)
      love.graphics.print(showFooter, x + pad, y + h - 18 * s)
    end
  end

  local function drawPartyChild(game, state, viewport, t, s)
    local x, y, w, h = drawChildBackdrop(viewport, t)
    local margin = 30 * s
    local contentX, contentY = x + margin, y + margin
    local contentW, contentH = w - margin * 2, h - margin * 2
    drawChildHeader('POKEMON', 'BATTLE PARTY', contentX, contentY, contentW, t, s)

    local battle = battleBelow(game, state)
    local party = state.party or game.save and game.save.party or {}
    local selected = clamp(math.floor(tonumber(state.index) or 1), 1, math.max(1, #party))
    local selectedMon = party[selected]

    local topY = contentY + 82 * s
    local gap = 14 * s
    local listW = math.min(contentW * 0.44, 440 * s)
    local detailW = contentW - listW - gap
    local listH = contentH - 82 * s
    local cardGap = 10 * s
    local cardH = math.max(60 * s, math.min(74 * s, (listH - cardGap * 5) / 6))
    roundedPanel(contentX, topY, listW, listH, t, t.raised, t.border, false, 16 * s)

    for i, mon in ipairs(party) do
      local cy = topY + 12 * s + (i - 1) * (cardH + cardGap)
      local cx = contentX + 12 * s
      local cw = listW - 24 * s
      local active = i == selected
      roundedPanel(cx, cy, cw, cardH, t,
        active and t.selected or t.soft,
        active and t.accent or t.border, active, 12 * s)

      local iconSize = math.min(40 * s, cardH - 16 * s)
      drawSpeciesIcon(game, mon, cx + 8 * s, cy + (cardH - iconSize) / 2, iconSize, 1)
      local tx = cx + 58 * s
      local nameFont = getFont(14 * s)
      local metaFont = getFont(10.5 * s)
      if nameFont then love.graphics.setFont(nameFont) end
      setColor(t.text)
      love.graphics.print(monSpeciesName(game, mon), tx, cy + 8 * s)

      if metaFont then love.graphics.setFont(metaFont) end
      local level = tonumber(mon.level)
      local status = normalizeStatus(mon.status)
      setColor(t.muted)
      love.graphics.print(level and ('Lv ' .. math.floor(level)) or '', tx, cy + 27 * s)
      if status then
        setColor(STATUS_COLORS[status] or t.accent)
        love.graphics.print(status, tx + 54 * s, cy + 27 * s)
      end
      local hp, maxHP = monHp(mon)
      local ratio = hp / math.max(1, maxHP)
      local barX, barY = tx, cy + cardH - 16 * s
      local barW = math.max(30 * s, cw - (tx - cx) - 12 * s)
      setColor(t.hpTrack)
      love.graphics.rectangle('fill', barX, barY, barW, 6 * s, 4 * s, 4 * s)
      setColor(healthColor(ratio))
      love.graphics.rectangle('fill', barX, barY, barW * ratio, 6 * s, 4 * s, 4 * s)
    end

    drawMonDetailPane(game, selectedMon, battle,
      contentX + listW + gap, topY, detailW, listH, t, s,
      'A  CHOOSE / DETAILS     B  BACK')

    if state.submenu and type(state.subItems) == 'table' then
      setColor({ 0, 0, 0, 0.50 })
      love.graphics.rectangle('fill', x, y, w, h)
      local items = state.subItems
      local modalW = math.min(440 * s, w - margin * 2)
      local rowH = 48 * s
      local modalH = 72 * s + rowH * math.max(1, #items)
      local mx, my = x + (w - modalW) / 2, y + (h - modalH) / 2
      roundedPanel(mx, my, modalW, modalH, t, t.surface, t.border, false, 16 * s)
      local modalTitle = getFont(18 * s)
      if modalTitle then love.graphics.setFont(modalTitle) end
      setColor(t.text)
      love.graphics.print('POKEMON ACTIONS', mx + 22 * s, my + 18 * s)
      local subIndex = clamp(math.floor(tonumber(state.subIndex) or 1), 1, math.max(1, #items))
      local rowFont = getFont(14 * s)
      for i, item in ipairs(items) do
        local ry = my + 58 * s + (i - 1) * rowH
        local active = i == subIndex
        if active then
          setColor(t.selected)
          love.graphics.rectangle('fill', mx + 12 * s, ry, modalW - 24 * s, rowH - 5 * s, 10 * s, 10 * s)
        end
        if rowFont then love.graphics.setFont(rowFont) end
        setColor(active and t.text or t.muted)
        love.graphics.print(cleanBattleText(item.label or item.text or item.name), mx + 28 * s, ry + 12 * s)
      end
    end
    return true
  end

  local function itemLabel(item)
    if type(item) ~= 'table' then return safeText(item) end
    return cleanBattleText(item.label or item.text or item.name or item.value)
  end

  local function itemRight(item)
    if type(item) ~= 'table' then return '' end
    return cleanBattleText(item.right or item.countText or item.quantityText)
  end

  local function itemDescription(game, itemId, def)
    if type(def) == "table" then
      for _, key in ipairs({
          "description", "desc", "effectText", "help", "helpText",
          "flavorText", "flavor", "summary",
        }) do
        local text = cleanBattleText(def[key])
        if text ~= "" then return text end
      end

      if type(def.machine) == "table" and def.machine.move
          and game and game.data and game.data.moves then
        local move = game.data.moves[def.machine.move]
        if move then
          local power = tonumber(move.power)
          local lines = {
            "Teaches " .. safeText(move.name or def.machine.move) .. ".",
            "Type: " .. normalizeType(move.type),
            ("Power: %s   Accuracy: %s   PP: %s"):format(
              power and power > 0 and tostring(math.floor(power)) or "-",
              moveAccuracy(move.accuracy),
              tostring(move.pp or "-")),
          }
          local category = cleanBattleText(move.category or move.damageClass)
          if category ~= "" then
            lines[#lines + 1] = "Category: " .. category
          end
          return table.concat(lines, "\n")
        end
      end
    end

    local fallback = ITEM_HELP[tostring(itemId or "")]
    if fallback then return fallback end

    if type(def) == "table" and type(def.effect) == "string"
        and def.effect ~= "" then
      local readable = def.effect:gsub("_", " "):lower()
      readable = readable:gsub("^%l", string.upper)
      return "Effect: " .. readable .. "."
    end

    return "No detailed description is available for this item."
  end

  local function itemKind(itemId, def)
    itemId = tostring(itemId or "")
    if type(def) == "table" and type(def.machine) == "table" then
      return "TM / HM"
    end
    if itemId:find("_BALL$") then return "POKÉ BALL" end
    if itemId:find("POTION$") or itemId == "FULL_RESTORE"
        or itemId:find("REVIVE$") or itemId == "ANTIDOTE"
        or itemId == "BURN_HEAL" or itemId == "ICE_HEAL"
        or itemId == "AWAKENING" or itemId == "PARLYZ_HEAL"
        or itemId == "PARALYZE_HEAL" or itemId == "FULL_HEAL" then
      return "MEDICINE"
    end
    if itemId:find("^X_") or itemId == "DIRE_HIT"
        or itemId == "GUARD_SPEC" then
      return "BATTLE ITEM"
    end
    return "ITEM"
  end

  local function drawBagChild(game, state, viewport, t, s)
    local x, y, w, h = drawChildBackdrop(viewport, t)
    local margin = 30 * s
    local contentX, contentY = x + margin, y + margin
    local contentW, contentH = w - margin * 2, h - margin * 2
    local title = cleanBattleText(state.title)
    if title == '' then title = 'BAG' end
    drawChildHeader(title, 'BATTLE ITEMS', contentX, contentY, contentW, t, s)

    local items = state.items or {}
    local selected = clamp(math.floor(tonumber(state.index) or 1), 1, math.max(1, #items))
    local panelY = contentY + 82 * s
    local panelH = contentH - 82 * s
    local listW = math.min(contentW * 0.54, 620 * s)
    local detailX = contentX + listW + 16 * s
    local detailW = math.max(1, contentW - listW - 16 * s)
    roundedPanel(contentX, panelY, listW, panelH, t, t.surface, t.border, false, 16 * s)
    roundedPanel(detailX, panelY, detailW, panelH, t, t.raised, t.border, false, 16 * s)

    local rowH = 52 * s
    local visible = math.max(1, math.floor((panelH - 28 * s) / rowH))
    local scroll = math.max(0, math.floor(tonumber(state.scroll) or 0))
    if selected <= scroll then scroll = selected - 1 end
    if selected > scroll + visible then scroll = selected - visible end
    scroll = clamp(scroll, 0, math.max(0, #items - visible))

    local rowFont = getFont(14 * s)
    local rightFont = getFont(11 * s)
    for slot = 1, visible do
      local index = scroll + slot
      local item = items[index]
      if not item then break end
      local ry = panelY + 12 * s + (slot - 1) * rowH
      local active = index == selected
      if active then
        setColor(t.selected)
        love.graphics.rectangle('fill', contentX + 10 * s, ry, listW - 20 * s, rowH - 6 * s, 10 * s, 10 * s)
        setColor(t.accent)
        love.graphics.rectangle('fill', contentX + 10 * s, ry, 4 * s, rowH - 6 * s, 4 * s, 4 * s)
      end
      local itemId = type(item) == 'table' and item.value or nil
      local def = itemId and game.data and game.data.items and game.data.items[itemId] or nil
      local iconSize = 30 * s
      drawItemSprite(game, itemId, def, contentX + 18 * s, ry + 8 * s, iconSize, 1)
      if rowFont then love.graphics.setFont(rowFont) end
      setColor(t.text)
      love.graphics.print(itemLabel(item), contentX + 58 * s, ry + 11 * s)
      local right = itemRight(item)
      if right ~= '' then
        if rightFont then love.graphics.setFont(rightFont) end
        setColor(t.muted)
        local rw = rightFont and rightFont:getWidth(right) or 0
        love.graphics.print(right, contentX + listW - 24 * s - rw, ry + 17 * s)
      end
    end

    local current = items[selected]
    local itemId = type(current) == 'table' and current.value or nil
    local def = itemId and game.data and game.data.items and game.data.items[itemId] or nil
    local detailTitle = itemLabel(current)
    if detailTitle == '' then detailTitle = cleanBattleText(def and def.name) end
    if detailTitle == '' then detailTitle = 'ITEM' end

    local titleFont = getFont(19 * s)
    local metaFont = getFont(10.5 * s)
    local bodyFont = getFont(12 * s)
    local sectionFont = getFont(10 * s)

    local detailPad = 20 * s
    local heroSize = math.min(58 * s, detailW * 0.20)
    drawItemSprite(game, itemId, def,
      detailX + detailPad, panelY + 18 * s, heroSize, 1)

    if titleFont then love.graphics.setFont(titleFont) end
    setColor(t.text)
    love.graphics.printf(detailTitle,
      detailX + detailPad + heroSize + 14 * s,
      panelY + 20 * s,
      detailW - detailPad * 2 - heroSize - 14 * s,
      'left')

    if metaFont then love.graphics.setFont(metaFont) end
    setColor(t.accent)
    love.graphics.print(itemKind(itemId, def),
      detailX + detailPad + heroSize + 14 * s,
      panelY + 48 * s)

    local owned = itemRight(current)
    if owned ~= "" then
      setColor(t.muted)
      local ow = metaFont and metaFont:getWidth(owned) or 0
      love.graphics.print(owned,
        detailX + detailW - detailPad - ow,
        panelY + 48 * s)
    end

    local descY = panelY + 88 * s
    local hasMachine = def and type(def.machine) == "table"
      and def.machine.move
    local descH = hasMachine and math.max(116 * s, panelH * 0.42)
      or math.max(150 * s, panelH - 145 * s)

    roundedPanel(detailX + detailPad, descY,
      detailW - detailPad * 2, descH,
      t, t.soft, t.border, false, 12 * s)

    if sectionFont then love.graphics.setFont(sectionFont) end
    setColor(t.accent)
    love.graphics.print("DESCRIPTION",
      detailX + detailPad + 14 * s, descY + 12 * s)

    if bodyFont then love.graphics.setFont(bodyFont) end
    setColor(t.text)
    love.graphics.printf(itemDescription(game, itemId, def),
      detailX + detailPad + 14 * s,
      descY + 33 * s,
      detailW - detailPad * 2 - 28 * s,
      'left')

    if hasMachine then
      local move = game.data and game.data.moves and game.data.moves[def.machine.move]
      if move then
        local moveY = descY + descH + 12 * s
        local moveH = math.max(78 * s, panelY + panelH - 42 * s - moveY)
        roundedPanel(detailX + detailPad, moveY,
          detailW - detailPad * 2, moveH,
          t, t.soft, t.border, false, 12 * s)

        if sectionFont then love.graphics.setFont(sectionFont) end
        setColor(t.accent)
        love.graphics.print("MOVE DATA",
          detailX + detailPad + 14 * s, moveY + 10 * s)

        local pillFont = getFont(9.5 * s)
        local typeW = select(1, drawTypePill(normalizeType(move.type),
          detailX + detailPad + 14 * s,
          moveY + 31 * s, pillFont, s))

        if bodyFont then love.graphics.setFont(bodyFont) end
        setColor(t.text)
        love.graphics.print(safeText(move.name or def.machine.move),
          detailX + detailPad + 24 * s + typeW,
          moveY + 33 * s)

        local power = tonumber(move.power)
        local stats = ("POWER %s   ACC %s   PP %s"):format(
          power and power > 0 and tostring(math.floor(power)) or "-",
          moveAccuracy(move.accuracy),
          tostring(move.pp or "-"))
        if metaFont then love.graphics.setFont(metaFont) end
        setColor(t.muted)
        love.graphics.print(stats,
          detailX + detailPad + 14 * s,
          moveY + 58 * s)
      end
    end

    if bodyFont then love.graphics.setFont(bodyFont) end
    setColor(t.muted)
    love.graphics.print('A  USE     B  BACK',
      detailX + detailPad, panelY + panelH - 25 * s)

    return true
  end

  local function summarySubject(game, state, battle)
    if type(state) ~= 'table' then return nil end
    return state.mon or state.pokemon or state.member or state.current
      or (type(state.party) == 'table' and state.index and state.party[state.index])
      or (battle and battle.player and (battle.player.mon or battle.player))
  end

  local function drawSummaryChild(game, state, viewport, t, s)
    local x, y, w, h = drawChildBackdrop(viewport, t)
    local margin = 30 * s
    local contentX, contentY = x + margin, y + margin
    local contentW, contentH = w - margin * 2, h - margin * 2
    local battle = battleBelow(game, state)
    local mon = summarySubject(game, state, battle)
    local tabLabel = state.tab or state.page or state.pageIndex or state.mode
    drawChildHeader('POKEMON DETAILS', tabLabel and ('ACTIVE PAGE: ' .. cleanBattleText(tabLabel)) or 'MODERN OVERLAY', contentX, contentY, contentW, t, s)
    drawMonDetailPane(game, mon, battle, contentX, contentY + 82 * s, contentW, contentH - 82 * s, t, s,
      'Use the original inputs normally.     B  BACK')
    return true
  end

  local function drawBattleChildUi(game, viewport)
    if option('enabled', true) == false or option('battle_children', true) == false then
      return false
    end
    local state = topState(game)
    if type(state) ~= 'table' or not battleBelow(game, state) then return false end
    local _, _, w, h = viewportRect(viewport)
    local s = responsiveScale(w, h)
    local t = theme()

    love.graphics.push('all')
    love.graphics.origin()
    local drawn = false
    if isPartyState(state) then
      drawn = drawPartyChild(game, state, viewport, t, s)
    elseif isBagState(state) then
      drawn = drawBagChild(game, state, viewport, t, s)
    elseif isSummaryState(state) then
      drawn = drawSummaryChild(game, state, viewport, t, s)
    end
    love.graphics.pop()
    return drawn
  end

  local function drawBattleUi(game, viewport)
    if option("enabled", true) == false then return false end
    local battle = battleState(game)
    if not battle or not directBattle(game, battle) or battle.blankForAskName then
      return false
    end
    if not (love and love.graphics) then return false end

    local x, y, w, h = viewportRect(viewport)
    local s = responsiveScale(w, h)
    local t = theme()
    local g = love.graphics

    g.push("all")
    g.origin()

    local margin = 24 * s
    local cardW = clamp(318 * s, 225, math.max(225, w * 0.34))
    local cardH = 92 * s
    local cardY = y + margin
    local leftX = x + margin
    local rightX = x + w - margin - cardW

    if battle.enemy then
      drawStatusCard(game, battle, battle.enemy,
        leftX, cardY, cardW, cardH, false, t, s)
    end
    if battle.player then
      drawStatusCard(game, battle, battle.player,
        rightX, cardY, cardW, cardH, true, t, s)
    end

    drawBattleLabel(battle, x + w / 2, y + 27 * s, t, s)

    local panelW = math.min(w - margin * 2, 980 * s)
    local phase = safeText(battle.phase)
    local message = visibleMessage(battle, game)
    local panelH
    if phase == "moveSelect" or phase == "mimicSelect" then
      panelH = 226 * s
    elseif phase == "menu" then
      panelH = 132 * s
    elseif message ~= "" or phase == "messages" or phase == "intro" then
      panelH = 146 * s
    else
      panelH = 0
    end

    if panelH > 0 then
      local panelX = x + (w - panelW) / 2
      local panelY = y + h - margin - panelH
      if phase == "menu" then
        drawActionPanel(game, battle, panelX, panelY,
          panelW, panelH, t, s)
        -- Keep the last turn visible even after control returns to the command
        -- strip. This is a compact chronology, not another input surface.
        local logH = 70 * s
        local logY = panelY - logH - 10 * s
        if logY > y + cardH + margin then
          drawBattleHistoryStrip(battle, panelX, logY,
            panelW, logH, t, s)
        end
      elseif phase == "moveSelect" or phase == "mimicSelect" then
        drawMovePanel(game, battle, panelX, panelY,
          panelW, panelH, t, s)
      else
        drawMessagePanel(battle, message, panelX, panelY,
          panelW, panelH, t, s)
      end
    end

    g.pop()
    return true
  end

  local function activelyPresenting(battle)
    if option("enabled", true) == false or type(battle) ~= "table" then
      return false
    end
    local game = battle.game
    return directBattle(game, battle) and not battle.blankForAskName
  end

  local function bottomPhaseOwned(battle)
    if not activelyPresenting(battle) then return false end
    local phase = safeText(battle.phase)
    return phase == "menu" or phase == "moveSelect"
      or phase == "mimicSelect" or phase == "messages"
      or hasSourceBattleText(battle)
  end

  local function remapHorizontalMenu(game)
    if option("enabled", true) == false then return end
    local battle = battleState(game)
    if not battle or not directBattle(game, battle)
        or safeText(battle.phase) ~= "menu" then
      return
    end

    local input = game and game.input
    local queue = input and input.pressQueue
    if type(queue) ~= "table" then return end

    local order = battle.safari and { 1, 2, 3, 4 }
      or HORIZONTAL_ACTION_ORDER
    local slot = sourceSlotForMenuIndex(
      clamp(math.floor(tonumber(battle.menuIndex) or 1), 1, 4), order)
    local changed = false

    -- The UI is one horizontal strip. Left/up move one slot left and
    -- right/down one slot right. Consume the source 2x2 direction so
    -- BattleState cannot immediately apply its old grid movement afterward.
    for i = #queue, 1, -1 do
      local key = queue[i]
      local delta
      if key == "left" or key == "up" then delta = -1
      elseif key == "right" or key == "down" then delta = 1 end
      if delta then
        table.remove(queue, i)
        slot = ((slot - 1 + delta) % 4) + 1
        changed = true
      end
    end

    if changed then battle.menuIndex = order[slot] end
  end

  local function safeWrap(name, handler, priority)
    if not (mod.hooks and type(mod.hooks.wrap) == "function") then return false end
    local ok, problem = pcall(mod.hooks.wrap, mod.hooks,
      name, handler, priority or 980)
    if not ok and mod.log and type(mod.log.warn) == "function" then
      mod.log:warn("MODERN BATTLE UI: hook %s unavailable: %s",
        name, tostring(problem))
    end
    return ok
  end

  -- Convert the source 2x2 battle command cursor into the true horizontal
  -- strip shown by this mod while keeping A/B and action callbacks native.
  safeWrap("input.step", function(next, game, dt)
    remapHorizontalMenu(game)
    return next(game, dt)
  end, 990)

  -- Hide only battle-owned source UI we fully replace. Child Party/Bag/choice
  -- screens remain native because they sit above BattleState and directBattle()
  -- becomes false while they are open.
  safeWrap("battle.status_hud_visible", function(next, battle)
    local upstream = next(battle)
    if option("hide_native", true) ~= false and activelyPresenting(battle) then
      return false
    end
    return upstream
  end, 980)

  safeWrap("battle.bottom_ui_visible", function(next, battle)
    local upstream = next(battle)
    if option("hide_native", true) ~= false and bottomPhaseOwned(battle) then
      return false
    end
    return upstream
  end, 980)

  -- Make classic/OG battles navigate the same 2x2 move grid this UI displays.
  -- WIDE battles already use the engine's native grid and skip this hook.
  safeWrap("battle.move_grid_navigation", function(next, battle)
    local upstream = next(battle)
    if activelyPresenting(battle) then return true end
    return upstream
  end, 980)

  -- Highest visual priority among the user's current UI stack. Call every
  -- previous HUD hook first, then paint our battle layer last.
  safeWrap("render.hud", function(next, game, viewport)
    local result = pack(next(game, viewport))
    local ok, problem = xpcall(function()
      if not drawBattleChildUi(game, viewport) then
        drawBattleUi(game, viewport)
      end
    end, function(err)
      if debug and type(debug.traceback) == "function" then
        return debug.traceback(err, 2)
      end
      return tostring(err)
    end)
    if not ok and mod.log and type(mod.log.warn) == "function" then
      mod.log:warn("MODERN BATTLE UI draw failed: %s", tostring(problem))
    end
    return unpackValues(result, 1, result.n)
  end, 980)

  mod.exports = mod.exports or {}
  mod.exports.version = VERSION
  mod.exports.modernBattleUi = {
    version = VERSION,
    id = MOD_ID,
    themes = { "midnight", "graphite", "light", "crimson" },
    standalone = true,
    sourceBattleOwned = true,
    horizontalActionStrip = true,
    battlePartyBagOverlay = true,
    recursiveBattleText = true,
    livePokemonIconCompatibility = true,
    liveItemIconCompatibility = true,
    battleSummaryOverlay = true,
    sideDetailCoveragePreview = true,
    fightEffectivenessBadges = true,
    persistentBattleLog = true,
    sourceShownTextRecovery = false,
    battleVisibleTextEvents = true,
    itemDescriptionPanel = true,
  }
  mod.exports.isBattleUiActive = function(game)
    local battle = battleState(game)
    return battle ~= nil and activelyPresenting(battle)
  end

  if mod.log and type(mod.log.info) == "function" then
    mod.log:info(
      "MODERN BATTLE UI %s installed: standalone battle HUD/actions/moves/messages",
      VERSION)
  end
end
