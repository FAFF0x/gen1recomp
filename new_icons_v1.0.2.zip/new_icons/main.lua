-- NEW ICONS v1.0.2
--
-- Replaces the small Pokemon icons used by party/menu UIs with the supplied
-- two-frame animated MiniDex artwork. The source files are APNGs (32x32,
-- two frames). gen1recomp/LÖVE does not play APNGs as animated textures, so
-- this mod ships a runtime-safe vertical sheet for every species: 32x64,
-- frame 1 on top and frame 2 below. Both source APNG frames are preserved
-- pixel-for-pixel in the runtime sheet.
--
-- The normal Gen 1 PartyMenu only understands 16x16 icon frames. We wrap
-- PartyMenu.drawIcon for OUR descriptors only and draw each 32x32 frame at
-- 0.5x, keeping the original two-frame animation semantics. Modern UI reads
-- the same { image, frames = 2 } descriptor directly and scales/animates it
-- in its own rows. Gen1 Modern UI 0.8.4+ also resolves that descriptor for
-- known rows in the base Pokédex, while Pokédex Plus 1.3.3+ exposes the same
-- species metadata for its list.

local SPECIES = {
  "BULBASAUR",
  "IVYSAUR",
  "VENUSAUR",
  "CHARMANDER",
  "CHARMELEON",
  "CHARIZARD",
  "SQUIRTLE",
  "WARTORTLE",
  "BLASTOISE",
  "CATERPIE",
  "METAPOD",
  "BUTTERFREE",
  "WEEDLE",
  "KAKUNA",
  "BEEDRILL",
  "PIDGEY",
  "PIDGEOTTO",
  "PIDGEOT",
  "RATTATA",
  "RATICATE",
  "SPEAROW",
  "FEAROW",
  "EKANS",
  "ARBOK",
  "PIKACHU",
  "RAICHU",
  "SANDSHREW",
  "SANDSLASH",
  "NIDORAN_F",
  "NIDORINA",
  "NIDOQUEEN",
  "NIDORAN_M",
  "NIDORINO",
  "NIDOKING",
  "CLEFAIRY",
  "CLEFABLE",
  "VULPIX",
  "NINETALES",
  "JIGGLYPUFF",
  "WIGGLYTUFF",
  "ZUBAT",
  "GOLBAT",
  "ODDISH",
  "GLOOM",
  "VILEPLUME",
  "PARAS",
  "PARASECT",
  "VENONAT",
  "VENOMOTH",
  "DIGLETT",
  "DUGTRIO",
  "MEOWTH",
  "PERSIAN",
  "PSYDUCK",
  "GOLDUCK",
  "MANKEY",
  "PRIMEAPE",
  "GROWLITHE",
  "ARCANINE",
  "POLIWAG",
  "POLIWHIRL",
  "POLIWRATH",
  "ABRA",
  "KADABRA",
  "ALAKAZAM",
  "MACHOP",
  "MACHOKE",
  "MACHAMP",
  "BELLSPROUT",
  "WEEPINBELL",
  "VICTREEBEL",
  "TENTACOOL",
  "TENTACRUEL",
  "GEODUDE",
  "GRAVELER",
  "GOLEM",
  "PONYTA",
  "RAPIDASH",
  "SLOWPOKE",
  "SLOWBRO",
  "MAGNEMITE",
  "MAGNETON",
  "FARFETCHD",
  "DODUO",
  "DODRIO",
  "SEEL",
  "DEWGONG",
  "GRIMER",
  "MUK",
  "SHELLDER",
  "CLOYSTER",
  "GASTLY",
  "HAUNTER",
  "GENGAR",
  "ONIX",
  "DROWZEE",
  "HYPNO",
  "KRABBY",
  "KINGLER",
  "VOLTORB",
  "ELECTRODE",
  "EXEGGCUTE",
  "EXEGGUTOR",
  "CUBONE",
  "MAROWAK",
  "HITMONLEE",
  "HITMONCHAN",
  "LICKITUNG",
  "KOFFING",
  "WEEZING",
  "RHYHORN",
  "RHYDON",
  "CHANSEY",
  "TANGELA",
  "KANGASKHAN",
  "HORSEA",
  "SEADRA",
  "GOLDEEN",
  "SEAKING",
  "STARYU",
  "STARMIE",
  "MR_MIME",
  "SCYTHER",
  "JYNX",
  "ELECTABUZZ",
  "MAGMAR",
  "PINSIR",
  "TAUROS",
  "MAGIKARP",
  "GYARADOS",
  "LAPRAS",
  "DITTO",
  "EEVEE",
  "VAPOREON",
  "JOLTEON",
  "FLAREON",
  "PORYGON",
  "OMANYTE",
  "OMASTAR",
  "KABUTO",
  "KABUTOPS",
  "AERODACTYL",
  "SNORLAX",
  "ARTICUNO",
  "ZAPDOS",
  "MOLTRES",
  "DRATINI",
  "DRAGONAIR",
  "DRAGONITE",
  "MEWTWO",
  "MEW",
}

return function(mod)
  local paths = {}
  local registered, skipped = 0, 0

  for _, species in ipairs(SPECIES) do
    local rel = "assets/icons_runtime/" .. species .. ".png"
    if mod:read(rel) then
      local path = mod.assets:path(rel)
      paths[species] = path
      mod.content.icons:register(species, {
        image = path,
        frames = 2,
      })
      registered = registered + 1
    else
      skipped = skipped + 1
      mod.log:warn("NEW ICONS: missing runtime icon for %s", species)
    end
  end

  -- Stock PartyMenu integration. A descriptor registered by this mod is a
  -- 32x64 vertical two-frame sheet. Only intercept entries that still point
  -- at NEW ICONS' own path so another icon mod can override us cleanly.
  local ok, err = pcall(function()
    local Assets = require("src.render.Assets")
    local PartyMenu = require("src.ui.PartyMenu")
    local PaletteFX = require("src.render.PaletteFX")

    PartyMenu._newIconsPaths = paths
    PartyMenu._newIconsCache = PartyMenu._newIconsCache or {}

    if not PartyMenu._newIconsCacheInvalidation then
      Assets.register(function()
        PartyMenu._newIconsCache = {}
      end)
      PartyMenu._newIconsCacheInvalidation = true
    end

    if not PartyMenu._newIconsWrapped then
      PartyMenu._newIconsOriginalDrawIcon = PartyMenu.drawIcon

      local function loadSheet(path)
        local cache = PartyMenu._newIconsCache
        local hit = cache[path]
        if hit ~= nil then return hit or nil end

        local okImage, image = pcall(love.graphics.newImage, Assets.resolve(path))
        if not okImage or not image then
          cache[path] = false
          return nil
        end
        pcall(function() image:setFilter("nearest", "nearest") end)

        local iw, ih = image:getDimensions()
        if iw ~= 32 or ih ~= 64 then
          cache[path] = false
          return nil
        end

        local q1 = love.graphics.newQuad(0, 0, 32, 32, iw, ih)
        local q2 = love.graphics.newQuad(0, 32, 32, 32, iw, ih)
        hit = { image = image, quads = { q1, q2 } }
        cache[path] = hit
        return hit
      end

      function PartyMenu.drawIcon(game, mon, x, y, selected, counter, forceAlt)
        local species = mon and mon.species
        local wanted = species and PartyMenu._newIconsPaths
          and PartyMenu._newIconsPaths[species]
        if wanted then
          local icons = game and game.data and game.data.icons
          local entry = icons and icons.bySpecies and icons.bySpecies[species]
          if type(entry) == "table" and entry.image == wanted then
            local sheet = loadSheet(wanted)
            if sheet then
              local alt = forceAlt == true
              if selected then
                local maxHP = mon.stats and mon.stats.hp or 1
                local hp = mon.hp or maxHP
                local px = math.floor(hp * 48 / math.max(1, maxHP))
                local speed = px >= 27 and 5 or px >= 10 and 16 or 32
                alt = math.floor((counter or 0) / speed) % 2 == 1
              end

              love.graphics.setColor(1, 1, 1, 1)
              love.graphics.draw(sheet.image, sheet.quads[alt and 2 or 1],
                x, y, 0, 0.5, 0.5)
              -- Keep authored colors intact instead of recoloring them through
              -- the stock MEWMON/SGB icon palette.
              PaletteFX.markTrueColor(x, y, 16, 16)
              return true
            end
          end
        end

        return PartyMenu._newIconsOriginalDrawIcon(
          game, mon, x, y, selected, counter, forceAlt)
      end

      PartyMenu._newIconsWrapped = true
    end
  end)

  if not ok then
    mod.log:warn("NEW ICONS: PartyMenu animation patch failed: %s", tostring(err))
  end

  mod.log:info(
    "NEW ICONS: registered %d animated species icons (%d skipped), stock patch=%s",
    registered, skipped, tostring(ok)
  )
end
